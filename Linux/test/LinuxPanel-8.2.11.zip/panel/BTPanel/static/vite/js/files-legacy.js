System.register(["./main-legacy.js?v=1713521634517"],(function(e,t){"use strict";var n;return{setters:[function(e){n=e.H}],execute:function(){e("g",(function(){return n.post("files/GetTaskSpeed")})),e("r",(function(e){return n.post("files/RemoveTask",{data:e,check:"msg"})}))}}}));

