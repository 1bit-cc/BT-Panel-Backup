import{H as s}from"./main.js?v=1713521634517";const e=()=>s.post("files/GetTaskSpeed"),a=e=>s.post("files/RemoveTask",{data:e,check:"msg"});export{e as g,a as r};

