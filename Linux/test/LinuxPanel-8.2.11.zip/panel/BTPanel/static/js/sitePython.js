function CreateWebsiteModel(config) {
    this.type = config.type;
    this.tips = config.tips;
    this.pyVersionList = []; // python版本列表
    this.pyAllVersion = []; // 所有版本
    this.pyVindexOf = 0;  // python版本索引
    this.addModelForm = null; // 添加项目表单
		this.commandPath = []; // 命令行环境路径
    this.methods = {
        createProject: ['CreateProject', false,false],  // 第一个参数是否采用需要加载load，第一个是否跳过msg直接返回数据
        getConfFile: ['GetConfFile', '获取项目配置文件信息'],
        saveConfFile: ['SaveConfFile', '修改项目配置文件信息'],
        getinfo: ['get_info', '获取' + config.tips + '项目信息'],
				getInfoByRunfile: ['get_info_by_runfile', '获取' + config.tips + '项目信息'],
				rePrepEnv: ['re_prep_env', '重新准备' + config.tips + '项目环境'],
        modifyProject: ['ChangeProjectConf', '修改' + config.tips + '项目'],
        stopProject: ['StopProject', '停止' + config.tips + '项目'],
        startProject: ['StartProject', '启动' + config.tips + '项目'],
        restartProject: ['RestartProject', '重启' + config.tips + '项目'],
        getCloudPython: ['list_py_version', '获取' + config.tips + '版本'],
        installPythonV: ['InstallPythonV', false,false],
        removePythonV: ['RemovePythonV', '卸载' + config.tips + '版本'],
        removeProject: ['RemoveProject', '删除' + config.tips + '项目'],
        getProjectInfo: ['GetProjectInfo', '获取' + config.tips + '项目信息'],
        addProjectDomain: ['AddProjectDomain', '添加' + config.tips + '项目域名'],
        removeProjectDomain: ['RemoveProjectDomain','删除' + config.tips + '项目域名',],
        getProjectLog: ['GetProjectLog', '获取' + config.tips + '项目日志'],
        bindExtranet: ['BindExtranet', '开启外网映射'],
        unbindExtranet: ['unBindExtranet', '关闭外网映射'],
        get_log_split: ['get_log_split', '获取' + config.tips + '项目日志切割任务'],
        mamger_log_split: ['mamger_log_split', '设置' + config.tips + '项目日志切割任务'],
        set_log_split: ['set_log_split', '设置' + config.tips + '项目日志切割状态'],
    };
    this.bindHttp(); //将请求映射到对象
    this.renderProjectList(); // 渲染列表
    this.getPythonVersion(); // 获取python版本
}

/**
 * @description python项目存在准备中时的定时器
 */
CreateWebsiteModel.prototype.pthyonProjectRefleshTimeout = null;

/**
 * @description python项目列表
 */
CreateWebsiteModel.prototype.pthyonProjectList = null;

/**
 * @description 渲染获取项目列表
 */
CreateWebsiteModel.prototype.renderProjectList = function () {
    var _that = this;
    $('#bt_' + this.type + '_table').empty();
		$('#bt_' + this.type + '_table').append('<div class="mask_layer hide"><div class="prompt_description python-model"></div></div>')
    site.model_table = bt_tools.table({
        el: '#bt_' + this.type + '_table',
        url: '/project/' + _that.type + '/GetProjectList',
        minWidth: '1000px',
        autoHeight: true,
        default: '项目列表为空', //数据为空时的默认提示
        load: '正在获取' + _that.tips + '项目列表，请稍候...',
        clickInto:'您的项目列表为空，您可以<a class="btlink" onClick="$(\'#bt_' + this.type + '_table .pull-left button\').eq(0).click()">添加一个项目</a>',
        beforeRequest: function (params) {
            if (params.hasOwnProperty('data') && typeof params.data === 'string') {
                var oldParams = JSON.parse(params['data']);
                delete params['data'];
                return { data: JSON.stringify($.extend(oldParams, params,{type_id:bt.get_cookie('site_type_' + _that.type)})) };
            }
            return { data: JSON.stringify(params) };
        },
        dataFilter:function(data,e){
					  // 创建失败、准备中、运行中、未启动
						var exitsRunning = false;
            $.each(data['data'],function(index,element) {
							element.status = element.status == 1 ? true : false;
							if(element.project_config.prep_status === 'running'){
								exitsRunning = true;
							}
							if(element.project_config.prep_status && element.project_config.prep_status !=='complete'){
								element.status = element.project_config.prep_status
							}
            });
						_that.__proto__.pthyonProjectList = data['data'];
						// 存在正在创建中的项目，3秒后刷新表格
						if(exitsRunning){
							_that.__proto__.pthyonProjectRefleshTimeout = setTimeout(function(){e.$refresh_table_list()},3000)
						} else if(_that.__proto__.pthyonProjectRefleshTimeout) {
							clearTimeout(_that.__proto__.pthyonProjectRefleshTimeout)
						}
            bt.getSiteNum() // 获取数量
            return data
        },
        sortParam: function (data) {
            return { order: data.name + ' ' + data.sort };
        },
        column: [
            { type: 'checkbox', class: '', width: 20 },
            {
                fid: 'name',
                title: '项目名称',
                type: 'link',
                event: function (row, index, ev, key, that) {
										if(_that.validateRunning(row, index, ev, key, that)) return;
                    _that.renderProjectInfoView(row);
                },
            },
            {
                fid: 'status',
                title: '服务状态',
                width: 80,
                // config: {
                    //     icon: true,
                    //     list: [
                //         ['running', '创建中', 'bt_warning'],
                //         ['failure', '创建失败', 'bt_danger creatd_false_flag', 'glyphicon-pause'],
                //         [true, '运行中', 'bt_success', 'glyphicon-play'],
                //         [false, '未启动', 'bt_danger', 'glyphicon-pause'],
                //     ],
                // },
                // type: 'status',
                template: function (row) {
                    var list = [
                        ['running', '创建中', 'bt_warning'],
                        ['failure', '创建失败', 'bt_danger creatd_false_flag', 'glyphicon-pause'],
                        [true, '运行中', 'bt_success', 'glyphicon-play'],
                        [false, '未启动', 'bt_danger', 'glyphicon-pause'],
                    ],listed = []
                    $.each(list, function (index, items) {
                        if (items[0] === row.status) listed = items;
                    });
					return '<a class="btlink '+ listed[2] +' status_tips" data-project="'+ row.id +'" data-name="'+ row.name +'" data-type="python" data-status="'+ row.status +'" href="javascript:;">\
						<span>'+ listed[1] +'</span>\
						<span class="glyphicon '+ listed[3] +'"></span>\
					</a>'
				},
                event: function (row, index, ev, key, that) {
										if(_that.validateRunning(row, index, ev, key, that)) return;
										var status = row.status;
                    bt.simple_confirm(
                        {
                            title: (status ? '停止项目' : '启动项目')+'【' + row.name + '】',
                            msg: status
                                ? '停用项目后将无法正常访问项目，是否继续操作？'
                                : '启用项目后，用户可以正常访问项目内容，是否继续操作？',
                        },
                        function (index) {
                            layer.close(index);
                            _that[status ? 'stopProject' : 'startProject'](
                                { name: row.name },
                                function (res) {
                                    bt.msg({
                                        status: res.status,
                                        msg: res.msg || res.error_msg,
                                    });
                                    that.$refresh_table_list(true);
                                }
                            );
                        }
                    );
                },
            },
            {
                title: 'CPU',
                width: 60,
                type: 'text',
                template: function (row) {
                    if (typeof row['cpu'] == 'undefined') return '<span>-</span>'
                    return '<span>' + row['cpu'].toFixed(2) + '%</span>'
                }
            },
            {
                title: '内存',
                width: 80,
                type: 'text',
                template: function (row) {
                    if (typeof row['mem'] == 'undefined') return '<span>-</span>'
                    return '<span>' + bt.format_size(row['mem']) + '</span>'
                }
            },
            {
							fid: 'path',
							title: '根目录',
						 width:220,
							type: 'link',
							event:function(row, index, ev, key, that){
									if(_that.validateRunning(row, index, ev, key, that)) return;
									openPath(row.path)
							},
						},{
							title: '<span style="display:flex"><span onclick="bt.soft.product_pay_view({ totalNum: 67, limit: \'ltd\', closePro: true })" class="firwall_place_of_attribution"></span>目录详情</span>',
							width:120,
							type: 'text',
							template:function(row,index,ev){

								return bt.files.dir_details_span(row.path);
							},
						},
            {
            fid: 'edate',
            title: '到期时间',
            width: 120,
            class: 'set_site_edate',
            template: function (row, index) {
              var _endtime = row.edate || row.endtime;
              if (_endtime === '0000-00-00') {
                return '<a href="#" class="btlink setTimes" data-id="'+row.id+'" id="python_endtime_' + row.id + '" >永久</a>';
              } else {
                if (new Date(_endtime).getTime() < new Date().getTime()) {
                  return '<a href="#" class="bt_danger btlink setTimes" data-id="'+row.id+'" id="python_endtime_' + row.id + '" >' + _endtime + '</a>';
                } else {
                  return '<a href="#" class="btlink setTimes" data-id="'+row.id+'" id="python_endtime_' + row.id + '" >' + _endtime + '</a>';
                }
              }
            },
            event: function (row) {}, //模拟点击误删
          },
            {
                fid: 'ps',
                title: '备注',
                type: 'input',
                blur: function (row, index, ev, key, that) {
                    if (row.ps == ev.target.value) return false;
                    bt.pub.set_data_ps(
                        { id: row.id, table: 'sites', ps: ev.target.value },
                        function (res) {
                            bt_tools.msg(res, { is_dynamic: true });
                        }
                    );
                },
                keyup: function (row, index, ev) {
                    if (ev.keyCode === 13) {
                        $(this).blur();
                    }
                },
            },
						{
							fid: 'ssl',
							title: 'SSL证书',
							tips: '部署证书',
							width: 100,
							type: 'text',
							template: function (row, index) {
								if(row.ssl === undefined) return '';
								var _ssl = row.ssl,
									_info = '',
									_arry = [
										['issuer', '证书品牌'],
										['notAfter', '到期日期'],
										['notBefore', '申请日期'],
										['dns', '可用域名'],
									];
								try {
									if (typeof row.ssl.endtime != 'undefined') {
										if (row.ssl.endtime < 1) {
											return '<a class="btlink bt_danger" href="javascript:;">已过期</a>';
										}
									}
								} catch (error) {}
								for (var i = 0; i < _arry.length; i++) {
									var item = _ssl[_arry[i][0]];
									_info +=
										_arry[i][1] + ':' + item + (_arry.length - 1 != i ? '\n' : '');
								}
								return row.ssl === -1
									? '<a class="btlink bt_warning" href="javascript:;">未部署</a>'
									: '<a class="btlink ' +
											(row.ssl.endtime < 7 ? 'bt_danger' : '') +
											'" href="javascript:;" title="' +
											_info +
											'">剩余' +
											row.ssl.endtime +
											'天</a>';
							},
							event: function (row, index, ev, key, that) {
								if(_that.validateRunning(row, index, ev, key, that)) return;
								_that.renderProjectInfoView(row);
								setTimeout(function () {
									$('.site-menu p:eq(5)').click();
								}, 500);
							},
						},
            {
                title: '操作',
                type: 'group',
                width: 168,
                align: 'right',
                group: [
                    {
                        title: '终端',
                        event: function (row, index, ev, key, that){
														if(_that.validateRunning(row, index, ev, key, that)) return;
                            bt.clear_cookie('Path')
                            Term.route = '/pyenv_webssh'
                            Term.ssh_info = {pj_name:row.name}
                            Term.run()
                        }
                    },
                    {
                        title: '设置',
                        event: function (row, index, ev, key, that) {
														if(_that.validateRunning(row, index, ev, key, that)) return;
                            _that.renderProjectInfoView(row);
                        },
                    },
                    {
                        title:'模块',
                        event:function(row, index, ev, key, that){
														if(_that.validateRunning(row, index, ev, key, that)) return;
                            _that.renderProjectModuleView(row);
                        }
                    },
                    {
                        title: '删除',
												key:'del',
                        event: function (row, index, ev, key, that) {
													if(_that.validateRunning(row, index, ev, key, that)) return;
                            bt.input_confirm({
                                    title: '删除项目 - [' + row.name + ']',
                                    value: '删除项目',
                                    msg: '<span class="color-org">风险操作，此操作不可逆</span>，删除' + _that.tips + '项目后您将无法管理该项目，是否继续操作？<div style="display:flex;align-items:center;">\
																		<input type="checkbox" style="margin:0;margin-right:5px;" checked class="form—checkbox-input" name="deleteAll">\
																		<span class="vertical_middle labelClick">同时删除虚拟环境</span>\
																		</div>'},
                                function () {
                                    _that.removeProject(
                                        { name: row.name,remove_env:$('[name=deleteAll]').prop('checked')?1:0 },
                                        function (res) {
                                            bt.msg({
                                                status: res.status,
                                                msg: res.msg,
                                            });
                                            site.model_table.$refresh_table_list(true);
                                        }
                                    );
                                }
                            );
                        },
                    },
                ],
            },
        ],
        // 渲染完成
        tootls: [
            {
                // 按钮组
                type: 'group',
                positon: ['left', 'top'],
                list: [
                    {
                        title: '添加' + _that.tips + '项目',
                        active: true,
                        event: function (ev) {
                            _that.renderAddProject(function () {
                                site.model_table.$refresh_table_list(true);
                            });
                        },
                    },
                    {
                        title: 'Python版本管理',
                        event: function(){
                            _that.getVersionManagement()
                        }
                    },
                    {
                        title: '命令行环境管理',
                        event:function(){
                            _that.setPythonCmdVersion()
                        }
                    },
                    {
                        title:'项目守护间隔时间',
                        event:function(){
                            bt_tools.send({url:'/project/'+ _that.type + '/' + 'get_daemon_time'},function(res){
                                bt_tools.open({
                                    title:'设置项目守护间隔时间',
                                    area:'350px',
                                    btn:['保存','取消'],
                                    content:{
                                        class:'pd20',
                                        form:[
                                            {
                                                label:'间隔时间',
                                                group: {
                                                    type:'text',
                                                    name:'daemon_time',
                                                    width:'150px',
                                                    unit:'秒',
                                                    value:res.daemon_time
                                                }
                                            }
                                        ]
                                    },yes:function(formData,index,layero){
                                        bt_tools.send({url:'/project/'+ _that.type + '/' + 'set_daemon_time',data:{daemon_time:formData.daemon_time}},function(res){
                                            layer.msg(res.msg,{icon:res.status?1:2})
                                            if(res.status) layer.close(index)
                                        },'正在设置项目启动时间')
                                    }
                                })
                            },'正在获取项目启动时间')
                        }
                    }
                ],
            },
            {
                // 搜索内容
                type: 'search',
                positon: ['right', 'top'],
                placeholder: '请输入项目名称或备注',
                searchParam: 'search', //搜索请求字段，默认为 search
                value: '', // 当前内容,默认为空
            },
            {
                // 批量操作
                type: 'batch', //batch_btn
                positon: ['left', 'bottom'],
                placeholder: '请选择批量操作',
                buttonValue: '批量操作',
                disabledSelectValue: '请选择需要批量操作的站点!',
                selectList: [
                    {
                        title: '开启项目',
                        url: '/project/' + _that.type + '/StartProject',
                        param: function (row) {
                            return {
                                data: JSON.stringify({ name: row.name }),
                            };
                        },
                        load: true,
                        verify: false,
                        refresh: true,
                        callback: function (that) {
                            bt.simple_confirm(
                                {title: '批量开启项目',
                                msg: '您正在开启选中的' + _that.tips + '项目，是否继续操作？'},
                                function () {
                                    that.start_batch({}, function (list) {
                                        var html = '';
                                        for (var i = 0; i < list.length; i++) {
                                            var item = list[i];
                                            html +=
                                                '<tr><td><span>' +
                                                item.name +
                                                '</span></td><td><div style="float:right;"><span style="color:' +
                                                (item.requests.status ? '#20a53a' : 'red') +
                                                '">' + item.requests.msg +
                                                '</span></div></td></tr>';
                                        }
                                        site.model_table.$batch_success_table({
                                            title: '批量开启项目',
                                            th: '项目名称',
                                            html: html,
                                        });
                                        site.model_table.$refresh_table_list(true);
                                    });
                                }
                            );
                        }
                    },
                    {
                        title: '停止项目',
                        url: '/project/' + _that.type + '/StopProject',
                        param: function (row) {
                            return {
                                data: JSON.stringify({ name: row.name }),
                            };
                        },
                        load: true,
                        verify: false,
                        refresh: true,
                        callback: function (that) {
                            bt.simple_confirm(
                                {title: '批量停止项目',
                                msg: '您正在停止选中的' + _that.tips + '项目，是否继续操作？'},
                                function () {
                                    that.start_batch({}, function (list) {
                                        var html = '';
                                        for (var i = 0; i < list.length; i++) {
                                            var item = list[i];
                                            html +=
                                                '<tr><td><span>' +
                                                item.name +
                                                '</span></td><td><div style="float:right;"><span style="color:' +
                                                (item.requests.status ? '#20a53a' : 'red') +
                                                '">' + item.requests.msg +
                                                '</span></div></td></tr>';
                                        }
                                        site.model_table.$batch_success_table({
                                            title: '批量停止项目',
                                            th: '项目名称',
                                            html: html,
                                        });
                                        site.model_table.$refresh_table_list(true);
                                    });
                                }
                            );
                        },
                    },
                    {
                        title: '重启项目',
                        url: '/project/' + _that.type + '/RestartProject',
                        param: function (row) {
                            return {
                                data: JSON.stringify({ name: row.name }),
                            };
                        },
                        load: true,
                        verify: false,
                        refresh: true,
                        callback: function (that) {
                            bt.simple_confirm(
                                {title: '批量重启项目',
                                msg: '您正在重启选中的' + _that.tips + '项目，是否继续操作？'},
                                function () {
                                    that.start_batch({}, function (list) {
                                        var html = '';
                                        for (var i = 0; i < list.length; i++) {
                                            var item = list[i];
                                            html +=
                                                '<tr><td><span>' +
                                                item.name +
                                                '</span></td><td><div style="float:right;"><span style="color:' +
                                                (item.requests.status ? '#20a53a' : 'red') +
                                                '">' + item.requests.msg +
                                                '</span></div></td></tr>';
                                        }
                                        site.model_table.$batch_success_table({
                                            title: '批量重启项目',
                                            th: '项目名称',
                                            html: html,
                                        });
                                        site.model_table.$refresh_table_list(true);
                                    });
                                }
                            );
                        },
                    },
                    {
                        title: '设置分类',
                        url: '/project/' + _that.type + '/set_project_site_type',
                        paramName: 'site_ids', //列表参数名,可以为空
                        paramId: 'type_id', // 需要传入批量的id
                        refresh: true,
                        beforeRequest: function (list) {
                            var arry = [];
                            $.each(list, function (index, item) {
                                arry.push(item.id);
                            });
                            return JSON.stringify(arry);
                        },
                        confirm: {
                            title: '批量设置分类',
                            content:
                                '<div class="line"><span class="tname">站点分类</span><div class="info-r"><select class="bt-input-text mr5 site_types" name="site_types" style="width:150px"></select></span></div></div>',
                            success: function () {
                                bt_tools.send({url:'/project/' + _that.type + '/project_site_types'},function(res){
                                    var html = '';
                                    $.each(res, function (index, item) {
                                        html += '<option value="' + item.id + '">' + item.name + '</option>';
                                    });
                                    $('[name="site_types"]').html(html);
                                });
                            },
                            yes: function (index, layers, request) {
                                request({ type_id: $('[name="site_types"]').val() });
                            },
                        },
                        tips: false,
                        success: function (res, list, that) {
                            var html = '';
                            $.each(list, function (index, item) {
                                html += '<tr><td>' + item.name + '</td><td><div style="float:right;"><span style="color:' + (res.status ? '#20a53a' : 'red') + '">' + res.msg + '</span></div></td></tr>';
                            });
                            that.$batch_success_table({ title: '批量设置分类', th: '站点名称', html: html });
                            that.$refresh_table_list(true);
                        },
                    },
                    {
                        title: '删除项目',
                        url: '/project/' + _that.type + '/RemoveProject',
                        param: function (row) {
                            return {
                                data: JSON.stringify({ name: row.name }),
                            };
                        },
                        refresh: true,
                        callback: function (that) {
                            bt.prompt_confirm(
                                '批量删除项目',
                                '您正在删除选中的' + _that.tips + '项目，继续吗？',
                                function () {
                                    that.start_batch({}, function (list) {
                                        var html = '';
                                        for (var i = 0; i < list.length; i++) {
                                            var item = list[i];
                                            html +=
                                                '<tr><td><span>' +
                                                item.name +
                                                '</span></td><td><div style="float:right;"><span style="color:' +
                                                (item.requests.status ? '#20a53a' : 'red') +
                                                '">' + item.requests.msg +
                                                '</span></div></td></tr>';
                                        }
                                        site.model_table.$batch_success_table({
                                            title: '批量删除项目',
                                            th: '项目名称',
                                            html: html,
                                        });
                                        site.model_table.$refresh_table_list(true);
                                    });
                                }
                            );
                        },
                    }
                ],
            },
            {
                //分页显示
                type: 'page',
                positon: ['right', 'bottom'], // 默认在右下角
                pageParam: 'p', //分页请求字段,默认为 : p
                page: 1, //当前分页 默认：1
                numberParam: 'limit',
                //分页数量请求字段默认为 : limit
                number: 20,
                //分页数量默认 : 20条
                numberList: [10, 20, 50, 100, 200], // 分页显示数量列表
                numberStatus: true, //　是否支持分页数量选择,默认禁用
                jump: true, //是否支持跳转分页,默认禁用
            },
        ],
        success: function (e) {
            if(site.model_table){
                var elTable = site.model_table.config.el
                if($(elTable+' .tootls_top .pull-left .bt-desired').length === 0){
                    $(elTable+' .tootls_top .pull-left').append('<div class="inlineBlock mlr15"><a href="https://www.bt.cn/bbs/thread-125161-1-1.html" data-status="true" data-type="python" target="_blank" title="Python项目教程" class="bt_success"><span>Python项目教程</span> <span class="glyphicon glyphicon-transpond"></span></a></div><span class="bt-desired ml10" style="background-size:contain;"><a href="javascript:;" class="btlink ml5 npsFeedback">需求反馈</a></span>')
                    // 网站nps入口
                    $('.npsFeedback').on('click',function(){
                        bt_tools.nps({name:'网站',type:14})
                    })
                    site.init_project_type(_that.type)
                }
            }
            // 服务状态事件
			site.server_status_event()
			// 详情事件
					bt.files.dir_details()
          //设置到期时间
          $('a.setTimes').each(function () {
            var _this = $(this);
            var id = _this.attr('id');
            laydate.render({
              elem: '#' + id, //指定元素
              min: bt.get_date(1),
              max: '2099-12-31',
              vlue: bt.get_date(365),
              type: 'date',
              format: 'yyyy-MM-dd',
              trigger: 'click',
              btns: ['perpetual', 'confirm'],
              theme: '#20a53a',
              done: function (dates) {
                bt.site.set_other_endtime($('#' + id).data('id'), dates, function (rdata) {
                  site.model_table.$refresh_table_list(true);
                });
              },
            });
          })
				}
    });
};

/**
 * @description 获取添加项目配置
 */
CreateWebsiteModel.prototype.getAddProjectConfig = function (data) {
    var that = this,
        data = data || {},
        config = [
						{
								label: '运行文件',
								formLabelWidth: '110px',
								must: '*',
								group: [{
										type: 'text',
										width: '400px',
										value: '',
										name: 'rfile',
										placeholder: '项目的运行文件',
										icon: {
												type: 'glyphicon-folder-open',
												select: 'file',
												event: function (ev) {},
												callback: function (runfile) {
													this.config.form[0].group[0].value = runfile;
													this.$replace_render_content(0);
													// debugger
													var cThis = this;
													// 尝试获取运行文件等信息
													runfile = runfile.replace('//','/')
													cThis.config.form[0].group[0].value = runfile
													cThis.$replace_render_content(0)
													that.getInfoByRunfile({runfile:runfile},function(res){
															runfile = runfile.replace('//','/')
															if(res.path){
																cThis.config.form[2].group[0].value = res.path;
																cThis.$replace_render_content(2);
																var pathList = res.path.split('/');
																var fileName = pathList[pathList.length - 1] == '' ? pathList[pathList.length - 2] : pathList[pathList.length - 1];
																if(fileName == '') {
																	var temp = runfile.split('/');
																	fileName = temp[(temp.length)-1]
															}
																cThis.config.form[1].group[0].value = fileName
																cThis.$replace_render_content(1);
															}
															if(res.framework) cThis.config.form[7].group[0].value = res.framework;cThis.$replace_render_content(7);
															if(res.requirement_path) cThis.config.form[11].group[0].value = res.requirement_path;cThis.$replace_render_content(11);
															if(res.runfile) cThis.config.form[0].group[0].value = res.runfile;cThis.$replace_render_content(0);
															if(res.stype){
																cThis.config.form[8].group[0].value = res.stype;
																if(res.stype === 'python'){
																	cThis.config.form[9].group.display = false;
																}else{
																	cThis.config.form[9].group.value = res.xsgi;
																}
																cThis.$replace_render_content(8);
															}
															if(res.stype == 'python' || res.stype == 'command'){
																cThis.config.form[11].display = true;
																cThis.$replace_render_content(11)
															}
													})
												},
										},
										verify: function (val) {
												if (val === '') {
														bt.msg({ msg: '请选择项目运行文件', status: false });
														return false;
												}
										},
								}],
						},
            {
                label: '项目名称',
                formLabelWidth: '110px',
                must: '*',
                group: [{
                    type: 'text',
                    name: 'pjname',
                    width: '400px',
                    placeholder: '请输' + that.tips + '项目名称',
                    disabled: data.type != 'edit' ? false : true,
                    verify: function (val) {
                        if (val === '') {
                            bt.msg({ msg: '请输入项目名称', status: false });
                            return false;
                        }
                    },
                }],
            },
						{
							label: '项目路径',
							formLabelWidth: '110px',
							must: '*',
							group: [{
									type: 'text',
									width: '400px',
									value: '',
									name: 'path',
									placeholder: '项目的根路径',
									disabled: data.type != 'edit' ? false : true,
									icon: {
											type: 'glyphicon-folder-open',
											select: 'dir',
											event: function (ev) {},
											callback: function (path) {
													var pathList = path.split('/');
													var fileName = pathList[pathList.length - 1] == '' ? pathList[pathList.length - 2] : pathList[pathList.length - 1];
													this.config.form[2].group[0].value = path;
													this.config.form[1].group[0].value = fileName;
													this.$replace_render_content(2);
													this.$replace_render_content(1);
													var cThis = this;
													// 尝试获取运行文件等信息
													that.getinfo({path:path},function(res){
															if(res.framework) cThis.config.form[7].group[0].value = res.framework;cThis.$replace_render_content(7);
															if(res.requirement_path) cThis.config.form[11].group[0].value = res.requirement_path;cThis.$replace_render_content(11);
															if(res.runfile) cThis.config.form[0].group[0].value = res.runfile;cThis.$replace_render_content(0);
															if(res.stype || res.xsgi){
																	cThis.config.form[8].group[0].value = res.stype;
																	cThis.config.form[9].group.value = res.xsgi;
																	cThis.$replace_render_content(8);
																	if(res.stype == 'python' || res.stype == 'command'){
																			cThis.config.form[11].display = true;
																			cThis.$replace_render_content(11)
																	}
															}
													})
											},
									},
									verify: function (val) {
											if (val === '') {
													bt.msg({ msg: '请选择项目运行文件', status: false });
													return false;
											}
									},
							}],
					},
            {
                label: '项目端口',
                formLabelWidth: '110px',
                must: '*',
                group: [{
                    type: 'number',
                    name: 'port',
                    width: '220px',
                    class: 'port_input',
                    placeholder: '请输入项目的真实端口',
                    verify: function (val) {
                        if (val === '') {
                            bt.msg({ msg: '请输入项目端口', status: false });
                            return false;
                        }
                    },
                    change: function (form, value, val, field) {
                        setTimeout(function () {//延迟校验端口,解决点击放行端口无效问题
                            if(form.port !== '') {
                                bt_tools.send({url:'/project/'+ that.type + '/' + 'advance_check_port',data:{port:form.port}},function(res){
                                    if (!res.status){
                                        $('.port_input').val('')
                                        bt_tools.msg({status:false,msg:res.msg})
                                    }
                                },{load:'正在校验端口',verify:false})
                            }
                        }, 500)
                    }
                },{
                    type: 'checkbox',
                    display: data.type === 'edit' ? false : true,
                    class: 'port_check',
                    name: 'release_firewall',
                    width: '220px',
                    title: '放行端口<a class="bt-ico-ask">?</a>'
                }],
            },
						{
							label: that.tips+'环境',
							formLabelWidth: '110px',
							display: data.type === 'edit' ? false : true,
							group:{
									name: '',
									type: 'other',
									boxcontent:'<div class="btn-group">\
									<button type="button" data-type="version" class="btn btn-sm btn-success">从已有版本新建环境</button>\
									<button type="button" data-type="environment" class="btn btn-sm btn-default">选择已有环境</button>\
								</div>'
							}
					},
					{
						label: '',
						formLabelWidth: '110px',
						display: false,
						group: [{
								type: 'select',
								name: 'venv_path',
								width: '150px',
								list: (function(){
										var list = [];
										for(var i=0;i<that.commandPath.length;i++){
											if(that.commandPath[i].type == 'project'){
												list.push({title:that.commandPath[i].project_name,value:that.commandPath[i].python_path});
											}
										}
										return list;
								})(),
								tips: '',
						},]
				},
            {
                label:data.type === 'edit' ? that.tips+'版本':'',
                formLabelWidth: '110px',
                group: [{
                    type: 'select',
                    name: 'version',
                    width: '150px',
                    value: that.pyVindexOf != undefined ? that.pyVindexOf : '',
                    list: (function(){
                        var list = [];
                        for(var i=0;i<that.pyVersionList.length;i++){
                            list.push({title:that.pyVersionList[i] + '(' + (that.commandPath[i].is_pypy? 'PyPy':'CPython') + ')',value:that.pyVersionList[i]});
                        }
                        return list;
                    })(),
                    tips: '',
                    change:function(formD,el,formConfig,rthat){
                        if(data.type != 'edit')return
                            var config = formConfig.config.form
														if(rthat.value != formD.version){
                            config[6].group[3].hide = false
                        }else{
                            config[6].group[3].hide = true
                        }
												config[6].group[0].value = formD.version
                        formConfig.$replace_render_content(6)
                    }
                },{
                    type:'link',
                    'class': 'mr5',
                    hide:data.type == 'edit',
                    title:'版本管理',
                    event:function(form,namek,cthat,index,el){
                        if($(el.currentTarget).parent('div').hasClass('recover_version')) return
                        that.getVersionManagement()
                    }
                },{
                    type:'link',
                    class:'recover_version',
                    hide:!data.back_env,
                    title:'恢复版本',
                },{
                    type:'other',
                    hide:true,
                    boxcontent:'<button class="btn btn-default btn-sm ml5 ToggleVersion">切换</button>',
                }]
            },
            {
                label: '框架',
                formLabelWidth: '110px',
                group: [{
                    type: 'select',
                    name: 'framework',
                    width: '150px',
                    disabled: data.type != 'edit' ? false : true,
                    unit: '* 未使用框架请选择python',
                    list: [
                        { title: 'django', value: 'django' },
                        { title: 'flask', value: 'flask' },
                        { title: 'sanic', value: 'sanic' },
                        { title: 'python', value: 'python' },
                    ],
                    tips: '',
                    change:function(value,form,that){
                        switch(value['framework']){
                            case 'django':
                            case 'flask':
                                that.config.form[9].group.value = 'wsgi';
                                break;
                            case 'sanic':
                                that.config.form[9].group.value = 'asgi';
                                break;
                        }
                        that.$replace_render_content(9)
                    }
                }],
            },
            {
                label: '运行方式',
                formLabelWidth: '110px',
                group: [{
                    type: 'radio',
                    name: 'stype',
                    value:'uwsgi',
                    list: [
                        { title: 'uwsgi', value: 'uwsgi' },
                        { title: 'gunicorn', value: 'gunicorn' },
                        { title: 'python', value: 'python' },
                        { title: '自定义', value: 'command' },
                    ],
                    event:function(formData, element,that){
                        that.config.form[8].group[0].value = formData.stype;
                        that.data.stype = formData.stype;
                        switch(formData.stype){
                            case 'uwsgi':
                            case 'gunicorn':
                                that.config.form[9].display = true;
                                that.config.form[10].display = false;
                                break;
                            case 'python':
                            case 'command':
                                that.config.form[9].display = false;
                                var isDiy = false;
                                if(formData.stype == 'command'){
                                    isDiy = true;
                                    $('#webedit-con form .line,.bt-model-create-view form .line').eq(0).find('.tname .color-red').hide()
                                }else{
                                    $('#webedit-con form .line,.bt-model-create-view form .line').eq(0).find('.tname .color-red').show()
                                }
                                that.config.form[10].display = true;
                                that.config.form[10].label = isDiy?'自定义命令':'启动方式';
                                that.config.form[10].group.placeholder = isDiy?'请输入自定义命令':'自定义启动参数';
                                that.config.form[10].group.name = isDiy?'project_cmd':'parm';
                                that.config.form[10].group.value = (data.type == 'edit'?(isDiy?data.project_cmd:data.parm):'');
                                break;
                        }

                        if(data.type == 'edit'){
                            that.config.form[11].display = (formData['stype'] == 'python' || formData['stype'] == 'command') ? false : true;
                            that.$replace_render_content(11)
                            //通信方式
                            that.config.form[13].display = formData['stype'] == 'uwsgi' ? true:false;
                            that.$replace_render_content(13)
                        }
                        that.$replace_render_content(8)
                        that.$replace_render_content(9)
                        that.$replace_render_content(10)
                    }
                }]
            },
            {
                label: '网络协议',
                formLabelWidth: '110px',
                display: (data.type == 'edit' && data.stype == 'python') ? false : true,
                group:{
                    type: 'select',
                    name: 'xsgi',
                    width: '150px',
                    list: [
                        { title: 'wsgi', value: 'wsgi' },
                        { title: 'asgi', value: 'asgi' },
                    ],
                }
            },
            {
                label: '启动方式',
                formLabelWidth: '110px',
                display:false,
                group: {
                    type: 'text',
                    name: 'parm',
                    width: '400px',
                    placeholder: '自定义的启动参数',
                }
            },
            {
                label: '安装依赖包',
                formLabelWidth: '110px',
                group: [{
                    type: 'text',
                    width: '400px',
                    value: '',
                    // disabled: data.type != 'edit' ? false : true,
                    name: 'requirement_path',
                    placeholder: '如需安装依赖包,请填写依赖包的文件地址[为空则不安装依赖包]',
                    icon: {
                        type: 'glyphicon-folder-open',
                        select: 'file',
                        event: function (ev) {},
                        callback: function (path) {
                            this.config.form[11].group[0].value = path;
                            this.$replace_render_content(11);
                        },
                    },
                }]
            },
            {
                formLabelWidth: '25px',
                group: {
                    type: 'help',
                    list: [
                        '执行命令：请输入项目需要携带的参数，默认请输入执行文件名',
                    ],
                },
            }
        ];
    if (data.type == 'edit') {
        config.splice(12, 1);
        config[6].group[0].value = data.version //版本
        config = $.merge(config,[{
            label: '进程数',
            formLabelWidth: '110px',
            must: '*',
            display:data.type != 'edit' || (data.type == 'edit' && data.stype === 'python') ? false : true,
            group: [{
                type: 'number',
                name: 'processes',
                width: '150px',
                placeholder: '进程数',
            },{
                label: '<span class="color-red mr5">*</span>线程数',
                style:{'vertical-align':'inherit'},
                type: 'number',
                name: 'threads',
                width: '150px',
                placeholder: '线程数',
            }]
        },{
            label: '启动用户',
            formLabelWidth: '110px',
            group: {
                type: 'select',
                name: 'user',
                width: '150px',
                list: [
                    { title: 'www', value: 'www' },
                    { title: 'root', value: 'root' },
                ],
                // disabled: (data.type == 'edit' && data.stype != 'gunicorn') ? false : true,
            }
        },{
            label: '通信方式',
            formLabelWidth: '110px',
            group: {
                type: 'select',
                name: 'is_http',
                width: '150px',
                list: [
                    { title: 'http', value: true },
                    { title: 'socket', value: false },
                ]
            }
        },{
            formLabelWidth: '110px',
            group: {
                type: 'button',
                name: 'submitForm',
                title: '保存配置',
                event: function (fromData, ev,thatC) {
                    if(data.stype == 'uwsgi' || data.stype == 'gunicorn'){
                        fromData['logpath'] = thatC['data']['logpath'];
                        fromData['loglevel'] = thatC['data']['loglevel'];
                    }
                    if(fromData.rfile == '' && data.stype != 'command') return bt.msg({ msg: '请选择项目运行文件', status: false });
                    switch(thatC['data']['stype']){
                        case 'uwsgi':
                            fromData.is_http = fromData.is_http == 'true' ? true : false;
                        case 'python':
                            if (parseInt(fromData.port) < 0 || parseInt(fromData.port) > 65535) return layer.msg('项目端口格式错误，可用范围：1-65535',{icon:2})
                            if(fromData.processes == '') return bt.msg({ msg: '请输入进程数', status: false });
                            if(fromData.threads == '') return bt.msg({ msg: '请输入线程数', status: false });
                            break;
                        case 'gunicorn':
                            if(fromData.parm == '') return bt.msg({ msg: '请输入启动参数', status: false });
                            break;
                    }
                    // 编辑项目
                    that.modifyProject({name:data.pjname,data:fromData}, function (res) {
                        site.model_table.$refresh_table_list()
                        bt.msg({ status: res.status, msg: res.msg });
                        that.simulatedClick(0);
                    });
                },
            },
        }])

        if(data.stype == 'python' || data.stype == 'command'){
            var eisDiy = data.stype == 'command';
            config[9].display = false
            config[10].display = true
            config[10].label = eisDiy?'自定义命令':'启动方式';
            config[10].group.placeholder = eisDiy?'请输入自定义命令':'自定义启动参数';
            config[10].group.name = eisDiy?'project_cmd':'parm';
            config[10].group.value = (data.type == 'edit'?(eisDiy?data.project_cmd:data.parm):'');
            config[11].display = false;
        }
        if(data.stype != 'uwsgi'){
            config[13].display = false
        }
    }
    config.splice(config.length - 1,0,{
        label: '开机启动',
        formLabelWidth: '110px',
        group: {
            type: 'checkbox',
            name: 'auto_run',
            title: '是否开启启动项目（默认自带守护进程每120秒检测一次）',
        },
    })
    return config;
};
/**
 * @description 打开日志
 */
CreateWebsiteModel.prototype.openSiteLog = function (config) {
    var that = this;
    var r_command = layer.open({
        title: config.name || '正在配置中，请稍候...',
        type: 1,
        closeBtn: 2,
        area: ['500px', '346px'],
        skin: config.class || 'module_commmand',
        shadeClose: false,
        content: '<div class="soft_module_command"></div>',
        success: function () {
            var sokcet = bt_tools.command_line_output({ el: '.soft_module_command', shell: 'tail -f '+config.shell, area: config.area || ['100%', '300px'] });
            // 每1秒检查一次sokcet.fragment最后一个元素是否包含bt_successful或bt_failed
            var _timer = setInterval(function () {
                if (sokcet.fragment.length > 0) {
                    var _last = sokcet.fragment[sokcet.fragment.length - 1];
                    if (_last.indexOf('bt_successful') != -1 || _last.indexOf('bt_failed') != -1) {
                        clearInterval(_timer);
                        setTimeout(function () {
                            layer.close(r_command);
                            if(_last.indexOf('bt_successful') != -1) {that.frestInstall = false;}
                        }, 1000);
                        // 提示信息
                        layer.msg(_last.indexOf('bt_successful')?'配置失败':'配置成功',{icon:_last.indexOf('bt_successful')?2:1});
                    }
                }
            }, 1000);
        },
    });
}

/**
 * @description 渲染添加项目表单
 */
CreateWebsiteModel.prototype.renderAddProject = function (callback) {
    var that = this;
    this.addModelForm = bt_tools.open({
        title: '添加' + this.tips + '项目',
        area: '620px',
        btn: ['提交', '取消'],
        content: {
            class: 'pd30 bt-model-create-view',
            formLabelWidth: '120px',
            form: (function () {
                return that.getAddProjectConfig();
            })(),
        },
				success:function(){
					$('.btn-group button').click(function() {
						$(this).addClass('btn-success').removeClass('btn-default').siblings().removeClass('btn-success').addClass('btn-default')
						var type = $(this).data('type')
						if(type == 'version'){
							that.addModelForm.form.config.form[5].display = false
							that.addModelForm.form.config.form[6].display = true
						}else{
							that.addModelForm.form.config.form[5].display = true
							that.addModelForm.form.config.form[6].display = false
						}
						that.addModelForm.form.$replace_render_content(5)
						that.addModelForm.form.$replace_render_content(6)
					})
				},
        yes: function (formData, indexs, layero) {
            if (parseInt(formData.port) < 0 || parseInt(formData.port) > 65535) return layer.msg('项目端口格式错误，可用范围：1-65535',{icon:2})
            var _command = null;
						var command = that.commandPath.find(function(item){return item.version == formData.version})
						if(command?.is_pypy){
							formData.is_pypy = true
						}
					var loadT = bt.load('正在加载，请稍后...')
            that.createProject(formData, function (res) {
                if (res.status) {
                    layer.close(indexs);
                    if (_command > 0) layer.close(_command);
                    if (callback) callback(res);
                }else{
                    _command = -1
                }
                layer.msg(res.msg, { icon: res.status ? 1 : 2,shade: [0.3, '#000'],shadeClose: true,time: 0 });
            });
						// 项目加载详情
            setTimeout(function () {
                if (_command < 0) return false;
                loadT.close()
								// 弹窗。
                _command = that.installVersionLog({projectname: formData.pjname,isCreateProject:true,name:'项目正在准备中，请稍候...', shell: 'tail -f  /www/server/python_project/vhost/logs/'+formData.pjname+'.log' })
            }, 1000);
        },
    });
    layer.ready(function () {
		$('.port_check .bt-ico-ask').hover(function () {
			layer.tips('选中将在防火墙安全组放行监听端口，放行后该项目可在外网访问', $(this), { tips: [2, '#555'],time: 0})
		},function () {
			layer.closeAll('tips')
		})
	})
    return this.addModelForm;
};

/**
 * @description 检查是否执行中running
 */
CreateWebsiteModel.prototype.validateRunning = function (row, index, ev, key, that) {
	var _that = this;
	var status = row.status;
	if(ev && ev.currentTarget && ev.currentTarget.innerText === '删除'){
		return false
	}
	if(status == 'failure'){
		bt.simple_confirm(
				{
						title: '重新准备项目'+'【' + row.name + '】',
						msg: '项目环境准备失败，是否再次尝试准备？',
				},
				function (index) {
					_that.rePrepEnv({name:row.name},function(res){
						bt.msg({
								status: res.status,
								msg: res.msg || res.error_msg,
						});
						that.$refresh_table_list(true)
					})
				}
		);
		return true;
	}
	if(status == 'running'){
		_that.installVersionLog({projectname: row.name,isCreateProject:true, shell: 'tail -f  /www/server/python_project/vhost/logs/'+row.project_config.pjname+'.log',name:'项目正在准备中，请稍候...'})
		return true;
	}
	return false;
}


/**
 * @description 获取python版本安装情况
 */
CreateWebsiteModel.prototype.getVersionManagement = function () {
    var _that = this;
    bt_tools.open({
        type: 1,
        title: _that.tips +'版本管理',
        area: ['500px', '630px'],
        btn: false,
        skin:'py_version_management',
        content: '<div class="pd15"><div id="versionManagement"></div></div>',
        success: function () {
            //渲染顶部筛选,更新按钮
            //#region
            var topDiv = document.createElement('div');
            var topHtml =
                '<div class="tab-switch tab-left" style="cursor: pointer;"><span class="tab active" data-index=0>所有版本</span><span class="tab" data-index=1>常用版本</span><span class="tab" data-index=2>所有PyPy版本</span></div>'+
                '<span class="bt-right">' +
                '<button class="btn btn-default btn-sm btn-update" >更新版本列表</button>' +
                '</span>';
            topDiv.innerHTML = topHtml;
            $(topDiv).insertBefore($('.py_version_management .layui-layer-content'));
            $(topDiv).css({ margin: '15px 15px 0', display: 'flex', 'justify-content': 'space-between',"align-items":"center" });
            //#endregion

            $('.tab-switch .tab').click(function (){
                $(this).addClass('active').siblings().removeClass('active');
                _that.changeSelectHandle(_that,this.dataset.index)
            })
            // 绑定事件
            $('.btn-update')[0].addEventListener('click', _that.clickUpdateHandle(_that));

            _that.firstRenderSDKTable({ _that: _that, type: 'all' });
            $('#versionManagement').find('.mtb10').css({ margin: '0', 'max-height': '495px' });
        },
        cancel: function () {
            if(_that.addModelForm != null && $('.bt-model-create-view').length > 0){
                var versionIndex = _that.pyVersionList[0]
                var _addModel = _that.addModelForm.form
                _addModel.config.form[6]['group'][0].value = versionIndex != undefined ? versionIndex.version : ''
                _addModel.config.form[6]['group'][0].list = (function(){
                    var list = [];
                    for(var i=0;i<_that.pyVersionList.length;i++){
                        var _isInstall = _that.pyVersionList[i]
                        var command = _that.commandPath.find(function(item){return item.version == _isInstall})
                        list.push({title:_isInstall + '(' + (command?.is_pypy? 'PyPy':'CPython') + ')',value:_isInstall});
                    }
                    return list;
                })()
                _that.addModelForm.form.$replace_render_content(6)
            }
        }
    })
};
/**
 * @description 设置python命令行环境
 */
CreateWebsiteModel.prototype.setPythonCmdVersion = function () {
    var _this = this;
    bt_tools.open({
        type:1,
        title:'设置命令行环境',
        area:['500px','410px'],
        content:'<div class="pd15"><div id="cmdVersionTable"></div></div>',
        btn:false,
        success:function () {
            _this.renderCmdTableList()
        }
    })
}
CreateWebsiteModel.prototype.renderCmdTableList = function(){
    var thisV = '',that = this;
    bt_tools.table({
        el:'#cmdVersionTable',
        url:'/project/python/list_py_version',
        cancelRefresh:true,
        height: '284',
        dataFilter:function(res){
            thisV = res.use
            return {data:res.command_path}
        },
        column: [
            {
                title:'名称',
                template:function (row) {
                    var isVersion = row.type == 'version' ? true : false;
                    return '<span>'+(isVersion? '<span>'+row.version+'</span>':'<span>['+row.project_name+']项目的环境</span>')+(thisV == row.python_path?'<span style="color:#20a53a">[正在使用]</span>':'')+'</span>'
                }
            },
						{
							title:'解释器',
							type:'text',
							template:function (row) {
									return '<span>'+( row.is_pypy? 'PyPy':'CPython' )+'</span>'
							},
						},
            {
                title:'路径',
                template:function () {
                    return '<span class="btlink">查看</span>'
                },
                event:function(row){
                    openPath(row.python_path)
                }
            },
            {
                title:'操作',
                type:'group',
                align:'right',
                group:[
                    {
                        title:'应用到命令行',
                        hide:function(rows){
                            return thisV == rows.python_path
                        },
                        event:function(row){
                            var isVersion = row.type == 'version' ? true : false;
														var params = {env_type:row.type,env_key:isVersion?row.version:row.project_name}
														if(isVersion && row.is_pypy){
															params.is_pypy = true
														}
                            bt_tools.send({url:'/project/python/set_python_version',data:params},function(res){
                                if(res.status){
                                    that.renderCmdTableList()
                                }
                                layer.msg(res.msg, { icon: res.status ? 1 : 2 });
                            })
                        }

                    }
                ]
            }
        ],
        tootls:[
            {
                type:'group',
                positon:['right','top'],
                list:[
                    {
                        title:'取消命令行设置',
                        event:function(){
                            bt.confirm({msg:'是否取消【'+thisV+'】默认命令行',title:'取消默认命令行设置'},function(){
                                bt_tools.send({url:'/project/python/set_python_version',data:{ env_type:'clear',env_key:''}},function(res){
                                    if(res.status){
                                        that.renderCmdTableList()
                                    }
                                    layer.msg(res.msg, { icon: res.status ? 1 : 2 });
                                })
                            })
                        }
                    }
                ]
            }
        ]
    })
}
/**
 * 第一次开打py项目的SDK管理渲染模块
 * @param {Object} options 参数里面有sdk的类型，和是否重新刷新
 */
CreateWebsiteModel.prototype.firstRenderSDKTable  = function (options) {
    var _that = options._that;
    var that = this;
    var type = options.type || 'all';
    var used = ''
    // 生成表格
    var versionTable = bt_tools.table({
        el: '#versionManagement',
        url: '/project/python/list_py_version',
        height: '500px',
        load: '获取版本信息',
        dataFilter: function (res) {
            _that.pyVersionList = res.cpy_installed.concat(res.pypy_installed);
            _that.pyAllVersion = res.sdk
            used = res.use // 获取正在使用的sdk版本
            res.sdk[type].sort((a,b)=> b.installed - a.installed)   // 排序， 已安装的先显示
            return { data: res.sdk[type] };
        },
        column: [
            {
                type: 'text',
                title: '版本',
                template: function (row) {
                    const version = row.version
                    return '<span class="version">'+ version +'</span>'
                },
            },
            {
                type: 'text',
                title: '安装状态',
                template: function (row) {
                    return row.installed ? '<span style="color:#20a53a;cursor:pointer;">已安装</span>' : '<span style="color:#d9534f;cursor:pointer;">未安装</span>';
                },
            },
            {
                type: 'text',
                align: 'right',
                title: '操作',
                template: function (row) {
                    return row.installed ? '<a class="bterror">卸载</a>' : '<a class="btlink">安装</a>';
                },
                event: function (form,index,ev) {
                    if(this.classList.contains('version')) return;
                    var is_installed = form.installed;
                    bt.confirm(
                        {
                            title: (is_installed ? '卸载' : '安装') + 'Python版本',
                            msg: is_installed ? '卸载[' + form.version + ']版本后，相关项目将无法启动，是否继续？' : '是否安装[' + form.version + ']版本？',
                        },
                        function (index) {
                            layer.close(index);
                            if(is_installed){
                                //卸载
																var params = {version:form.version}
																var type = $('.tab-switch').find('.tab.active').data('index')
																if(type == 2){
																	params.is_pypy = true
																}
                                bt_tools.send({url:'/project/python/RemovePythonV',data:params},function (data){
																	// bt_tools.send({url:'/project/python/RemovePythonV',data:{data:JSON.stringify({version:form.version}) }},function (data){
                                    _that.clickUpdateHandle(_that)
                                },'卸载版本')
                            }else{
                                var _command = null;
                                setTimeout(function () {
                                    if (_command < 0) return false;
                                    _command = _that.installVersionLog({ shell: 'tail -f /www/server/python_project/vhost/logs/py.log' })
                                }, 500);
                                //安装
																var params = {version:form.version}
																var type = $('.tab-switch').find('.tab.active').data('index')
																if(type == 2){
																	params.is_pypy = true
																}
                                bt_tools.send({url:'/project/python/install_py_version',data:params},function (data){
                                    _that.clickUpdateHandle(_that)

                                    setTimeout(function () {layer.close(_command);},1000)
                                })
                            }
                        }
                    );
                },
            },
        ],
    });
}
//渲染表格的函数
CreateWebsiteModel.prototype.renderVersionTable = function  (data)  {
	data && data.sort((a,b)=> b.installed - a.installed)   // 排序，已安装的先显示
    //根据数据渲染表格
    bt_tools.table({
        el: '#versionManagement',
        data:data,
        height: '500px',
        load: '获取版本信息',
        column: [
            {
                type: 'text',
                title: 'SDK版本',
                template: function (row) {
                    const version = row.version.slice(2);
                    return '<span class="version">'+ version + (row.type === "stable" ? "(稳定版)" : "") +'</span>'
                },
            },
            {
                type: 'text',
                title: '安装状态',
                template: function (row) {
                    return row.installed ? '<span style="color:#20a53a">已安装</span>' : '<span style="color:#d9534f">未安装</span>';
                },
            },
            {
                type: 'text',
                align: 'right',
                title: '操作',
                template: function (row) {
                    return row.installed ? '<a class="bterror">卸载</a>' : '<a class="btlink">安装</a>';
                },
            }]
    })
}
//sdk版本管理里面的下拉框事件处理函数
CreateWebsiteModel.prototype.changeSelectHandle = function (that,index) {
    // var type = index == 0 ? 'all' : 'streamline';
		var type = 'none'
		switch(Number(index)){
			case 0:
				type = 'all'
				break;
			case 1:
				type = 'streamline'
				break;
			case 2:
				type = 'pypy'
				break;
		}
    var data = that.pyAllVersion[type];
		if(type == 'none'){
			data = []
		}
    //更新表格渲染。
    that.renderVersionTable(data)
}
//sdk版本管理里面的更新列表点击处理函数
CreateWebsiteModel.prototype.clickUpdateHandle = function (that) {
    return function () {
        var type = $('.tab-switch .tab.active').data('index') == 0 ? 'all' : 'common';
        var loadT = layer.msg('正在获取版本列表，请稍侯...', {
            icon: 16,
            time: 0,
            shade: 0.3,
        })
        bt_tools.send({url:'/project/python/list_py_version',data:{force:1}},function (data) {
            layer.close(loadT);
            that.pyAllVersion = data.sdk;
            var data = that.pyAllVersion[type];
            that.renderVersionTable(data)
        })
    };
}
/**
 * @description 获取python版本安装情况
 */
CreateWebsiteModel.prototype.getPythonVersion = function (callback) {
    var _this = this;
    this.getCloudPython({},function (res) {
        _this.pyVersionList = res.cpy_installed.concat(res.pypy_installed);
        _this.pyAllVersion = res.sdk
				_this.commandPath = res.command_path
        _this.pyVindexOf = res.cpy_installed[0]
        _this.cmdVersion = res.use
        if(callback) callback(res)
    })
}
/**
 * @description
 * @param {string} name 站点名称
 */
CreateWebsiteModel.prototype.renderProjectInfoView = function (row) {
    var that = this;
    bt.open({
        type: 1,
        title:this.tips + '项目管理-[' + row.name + ']，添加时间[' + row.addtime + ']',
        skin: 'model_project_dialog',
        area: ['780px', '720px'],
        content:
            '<div class="bt-tabs">' +
            '<div class="bt-w-menu site-menu pull-left"></div>' +
            '<div id="webedit-con" class="bt-w-con pd15" style="height:100%">' +
            '</div>' +
            '<div class="mask_module hide" style="left:110px;"><div class="node_mask_module_text">请开启<a href="javascript:;" class="btlink mapExtranet" onclick="site.node.simulated_click(2)"> 外网映射 </a>后查看配置信息</div></div>' +
            '</div>',
        btn: false,
        success: function (layers) {
            var $layers = $(layers),
                $content = $layers.find('#webedit-con');

            function render_tab_list(config) {
                for (var i = 0; i < config.list.length; i++) {
                    var item = config.list[i],
                        tab = $(
                            '<p class="' + (i === 0 ? 'bgw' : '') + '">' + item.title + '</p>'
                        );
                    $(config.el).append(tab);
                    (function (i, item) {
                        tab.on('click', function (ev) {
                            $('.mask_module').addClass('hide');
                            $(this).addClass('bgw').siblings().removeClass('bgw');
                            if ($(this).hasClass('bgw')) {
                                that.getProjectInfo({ name: row.name }, function (res) {
                                    config.list[i].event.call(that, $content, res, ev);
                                });
                            }
                        });
                        if (item.active) tab.click();
                    })(i, item);
                }
            }
            render_tab_list(
                {
                    el: $layers.find('.bt-w-menu'),
                    list: [
                        {
                            title: '项目配置',
                            active: true,
                            event: that.renderProjectConfigView,
                        },
                        {
                            title: '域名管理',
                            event: that.renderDomainManageView,
                        },
                        {
                            title: '外网映射',
                            event: that.renderProjectMapView,
                        },
                        {
                            title: '配置文件',
                            event: that.renderFileConfigView,
                        },
                        {
                            title: '运行配置',
                            event: that.renderFrameworkConfigView,
                        },
												{
													title: 'SSL',
													event: that.reanderProjectSslView,
												},
												{
													title: '重定向',
													event: that.reander_project_redirect,
											},
                        {
                            title: '服务状态',
                            event: that.renderServiceStatusView,
                        },
                        {
                            title: '项目日志',
                            event: that.renderProjectLogsView,
                        },
                        {
                            title: '网站日志',
                            event: that.renderSiteLogsView,
                        }
                    ],
                },
                function (config, i, ev) {}
            );
            // 切换py版本
            $('#webedit-con').on('click', '.ToggleVersion', function () {
							var params = {name:row.name,update_version:$('select[name=version]').val()}
							for (var index = 0; index < that.commandPath.length; index++) {
								var item = that.commandPath[index];
								if(item.version == $('select[name=version]').val()){
									if(item.is_pypy){
										params.is_pypy = true
										break;
									}
								}
							}
                bt_tools.send({url:'/project/python/update_env',data:params},function(res){})
                var _command = null;
                setTimeout(function () {
                    if (_command < 0) return false;
                    _command = that.openSiteLog({ shell: '/www/server/python_project/vhost/logs/'+row.name+'_update.log',name:'切换版本' });
                }, 200);
            })
            // 恢复版本
            $('#webedit-con').on('click', '.recover_version', function () {
                bt_tools.send({url:'/project/python/recover_env',data:{name:row.name}},function(res){})
                var _command = null;
                setTimeout(function () {
                    if (_command < 0) return false;
                    _command = that.openSiteLog({ shell: '/www/server/python_project/vhost/logs/'+row.name+'_update.log',name:'恢复版本' });
                }, 200);
            })
        },
    });
};
/**
 * @description 项目配置
 * @param {object} row 项目信息
 */
CreateWebsiteModel.prototype.renderProjectConfigView = function (el, row) {
    var that = this,
        projectConfig = row.project_config,
        _config = that.getAddProjectConfig( $.extend(projectConfig,{ type: 'edit',back_env:row.back_env }) );
    bt_tools.form({
        el: '#webedit-con',
        data: projectConfig,
        class: 'ptb15',
        form: _config
    });
};
/**
 * @description 域名管理
 * @param {object} row 项目信息
 */
CreateWebsiteModel.prototype.renderDomainManageView = function (el, row,ev) {
    var that = this,
        list = [
            {
                class: 'mb0',
                items: [
                    {
                        name: 'modeldomain',
                        width: '430px',
                        type: 'textarea',
                        placeholder:
                            '如果需要绑定外网，请输入需要映射的域名，该选项可为空<br>多个域名，请换行填写，每行一个域名，默认为80端口<br>泛解析添加方法：先添加一个域名 domain.com，后换行添加*.domain.com<br>如另加端口格式为 www.domain.com:88',
                    },
                    {
                        name: 'btn_model_submit_domain',
                        text: '添加',
                        type: 'button',
                        callback: function (sdata) {
                            var arrs = sdata.modeldomain.split('\n');
                            var domins = [];
                            for (var i = 0; i < arrs.length; i++) domins.push(arrs[i]);
                            if (domins[0] == '')
                                return layer.msg('域名不能为空', { icon: 0 });
                            that.addProjectDomain(
                                { name: row.name, domains: domins },
                                function (res) {
                                    if (typeof res.status == 'undefined') {
                                        $('[name=modeldomain]').val('');
                                        $('.placeholder').css('display', 'block');
                                        site.render_domain_result_table(res)
                                        project_domian.$refresh_table_list(true);
                                    }else{
                                        bt.msg({ status: res.status, msg: res.error_msg });
                                    }
                                }
                            );
                        },
                    },
                ],
            },
        ];
    var _form_data = bt.render_form_line(list[0]),
        loadT = null,
        placeholder = null;
				setTimeout(() => {
					$('[name=modeldomain]').siblings('.placeholder').css({lineHeight:'21px'})
				}, 50);
    el.html(_form_data.html + '<div id="project_domian_list"></div>');
    bt.render_clicks(_form_data.clicks);
    // domain样式
    $('.btn_model_submit_domain')
        .addClass('pull-right')
        .css('margin', '30px 35px 0 0');
    $('textarea[name=modeldomain]').css('height', '120px');
    placeholder = $('.placeholder');
    placeholder
        .click(function () {
            $(this).hide();
            $('.modeldomain').focus();
        })
        .css({
            width: '340px',
            heigth: '120px',
            left: '0px',
            top: '0px',
            'padding-top': '10px',
            'padding-left': '15px',
        });
    $('.modeldomain')
        .focus(function () {
            placeholder.hide();
            loadT = layer.tips(placeholder.html(), $(this), {
                tips: [1, '#20a53a'],
                time: 0,
                area: $(this).width(),
            });
        })
        .blur(function () {
            if ($(this).val().length == 0) placeholder.show();
            layer.close(loadT);
        });
    var project_domian = bt_tools.table({
        el: '#project_domian_list',
        url: '/project/' + that.type + '/GetProjectDomain',
        default: '暂无域名列表',
        param: { name: row.name },
        height: 375,
        beforeRequest: function (params) {
            if (params.hasOwnProperty('data') && typeof params.data === 'string')
                return params;
            return { data: JSON.stringify(params) };
        },
        column: [
            { type: 'checkbox', class: '', width: 20 },
            {
                fid: 'name',
                title: '域名',
                type: 'text',
                template: function (row) {
                    return (
                        '<a href="http://' +
                        row.name +
                        ':' +
                        row.port +
                        '" target="_blank" class="btlink">' +
                        row.name +
                        '</a>'
                    );
                },
            },
            {
                fid: 'port',
                title: '端口',
                type: 'text',
            },
            {
                title: '操作',
                type: 'group',
                width: '100px',
                align: 'right',
                group: [
                    {
                        title: '删除',
                        template: function (row, that) {
                            return that.data.length === 1 ? '<span>不可操作</span>' : '删除';
                        },
                        event: function (rowc, index, ev, key, rthat) {
                            if (ev.target.tagName == 'SPAN') return;
                            if (rthat.data.length === 1) {
                                return bt.msg({ status: false, msg: '最后一个域名不能删除!' });
                            }
                            that.removeProjectDomain(
                                { name: row.name, domain: rowc.name+ ':' + rowc.port },
                                function (res) {
                                    bt.msg({
                                        status: res.status,
                                        msg: res.msg,
                                    });
                                    rthat.$refresh_table_list(true);
                                }
                            );
                        },
                    },
                ],
            },
        ],
        tootls: [
            {
                // 批量操作
                type: 'batch',
                positon: ['left', 'bottom'],
                placeholder: '请选择批量操作',
                buttonValue: '批量操作',
                disabledSelectValue: '请选择需要批量操作的站点!',
                selectList: [
                    {
                        title: '删除域名',
                        load: true,
                        url: '/project/' + that.type + '/MultiRemoveProjectDomain',
                        param: {name:row.name},
                        paramId: 'id',
                        paramName: 'domain_ids',
                        theadName: '域名',
                        confirmVerify: false, //是否提示验证方式
                        refresh: true,
                        beforeRequest: function (list) {
                            var arry = [];
                            $.each(list, function (index, item) {
                                arry.push(item.id);
                            });
                            return JSON.stringify(arry);
                        }
                        // callback: function (that) {
                        // 	// 手动执行,data参数包含所有选中的站点
                        // 	bt.show_confirm(
                        // 		'批量删除域名',
                        // 		"<span style='color:red'>同时删除选中的域名，是否继续？</span>",
                        // 		function () {
                        // 			var param = {};
                        // 			that.start_batch(param, function (list) {
                        // 				var html = '';
                        // 				for (var i = 0; i < list.length; i++) {
                        // 					var item = list[i];
                        // 					html +=
                        // 						'<tr><td>' +
                        // 						item.name +
                        // 						'</td><td><div style="float:right;"><span style="color:' +
                        // 						(item.request.status ? '#20a53a' : 'red') +
                        // 						'">' +
                        // 						(item.request.status ? '成功' : '失败') +
                        // 						'</span></div></td></tr>';
                        // 				}
                        // 				project_domian.$batch_success_table({
                        // 					title: '批量删除',
                        // 					th: '删除域名',
                        // 					html: html,
                        // 				});
                        // 				project_domian.$refresh_table_list(true);
                        // 			});
                        // 		}
                        // 	);
                        // },
                    },
                ],
            },
        ],
    });
    setTimeout(function () {
        $(el).append(
            '<ul class="help-info-text c7">' +
            '<li>如果您的是HTTP项目，且需要映射到外网，请至少绑定一个域名</li>' +
            '<li>建议所有域名都使用默认的80端口</li>' +
            '</ul>'
        );
    }, 100);
};

/**
 * @description 渲染项目外网映射
 * @param el {object} 当前element节点
 * @param row {object} 当前项目数据
 */
CreateWebsiteModel.prototype.renderProjectMapView = function (el, row) {
    var that = this;
    el.html(
        '<div class="pd15"><div class="ss-text mr50" style="display: block;height: 35px;">' +
        '   <em title="外网映射">外网映射</em>' +
        '       <div class="ssh-item">' +
        '           <input class="btswitch btswitch-ios" id="model_project_map" type="checkbox">' +
        '           <label class="btswitch-btn" for="model_project_map" name="model_project_map"></label>' +
        '       </div>' +
        '</div><ul class="help-info-text c7"><li>如果您的是HTTP项目，且需要外网通过80/443访问，请开启外网映射</li><li>开启外网映射前，请到【域名管理】中至少添加1个域名</li></ul></div>'
    );
    $('#model_project_map').attr(
        'checked',
        row['project_config']['bind_extranet'] ? true : false
    );
    $('[name=model_project_map]').click(function () {
        var _check = $('#model_project_map').prop('checked'),
            param = { name: row.name };
        if (!_check) param['domains'] = row['project_config']['domains'];
        layer.confirm(
            (!_check ? '开启外网映射后，可以通过绑定域名进行访问' : '关闭外网映射后，已绑定域名将取消关联访问') + '，是否继续操作？',
            {
                title: '外网映射',
                icon: 0,
                closeBtn: 2,
                cancel: function () {
                    $('#model_project_map').prop('checked', _check);
                },
            },
            function () {
                that[_check ? 'unbindExtranet' : 'bindExtranet'](param, function (res) {
                    if (!res.status) $('#model_project_map').prop('checked', _check);
                    bt.msg({
                        status: res.status,
                        msg: res.msg,
                    });
                    row['project_config']['bind_extranet'] = _check ? 0 : 1;
                });
            },
            function () {
                $('#model_project_map').prop('checked', _check);
            }
        );
    });
};

/**
 * @description 渲染项目服务状态
 * @param el {object} 当前element节点
 * @param row {object} 当前项目数据
 */
CreateWebsiteModel.prototype.renderServiceStatusView = function (el, row) {
    var _this = this
    var arry = [
            { title: '启动', event: this.startProject },
            { title: '停止', event: this.stopProject },
            { title: '重启', event: this.restartProject },
        ],
        that = this,
        html = $(
            '<div class="soft-man-con bt-form"><p class="status"></p><div class="sfm-opt"></div>\
            <div id="alert_setting">\
					<span style="margin-right:10px;font-size:14px">项目异常停止时提醒我:</span>\
					<div class="outer_state_alert">\
						<input class="btswitch btswitch-ios isServerStop" data-project="'+ row.id +'" data-name="'+ row.name +'" data-status="'+ row.run +'" data-type="'+ _this.tips.toLowerCase() +'" type="checkbox" id="is'+ _this.tips +'Stop"><label class="btswitch-btn" for="is'+ _this.tips +'Stop"></label>\
					</div>\
					<span class="btlink serverStopSet" data-project="'+ row.id +'" data-name="'+ row.name +'" data-status="'+ row.run +'" data-type="'+ _this.tips.toLowerCase() +'" style="margin-left:10px;font-size:14px">告警设置</span>\
				</div>\
                <div class="run_setting flex ptb20 mt20 align-center" style="border-top: 1px dashed #EBEEF5;">\
									<span style="margin-right:10px;font-size:14px">项目定时重启：</span>\
									<div class="outer_state_alert">\
										<input class="btswitch btswitch-ios isRunStop" data-type="node" type="checkbox" id="isRunStop">\
                    <label class="btswitch-btn" for="isRunStop"></label>\
									</div>\
									<span class="btlink runStopSet" data-type="node" style="margin-left:10px;font-size:14px">定时重启设置</span>\
								</div>\
			</div>'
        );
    bt.timingRestartProject({name: row.name,type: _this.type})
    function reander_service(status) {
        var status_info = status
            ? ['开启', '#20a53a', 'play']
            : ['停止', 'red', 'pause'];
        return (
            '当前状态：<span>' +
            status_info[0] +
            '</span><span style="color:' +
            status_info[1] +
            '; margin-left: 3px;" class="glyphicon glyphicon glyphicon-' +
            status_info[2] +
            '"></span>'
        );
    }
    html.find('.status').html(reander_service(row.run));
    el.html(html);
    site.server_status_event({project: row.id,name: row.name,status: row.run,type: _this.tips.toLowerCase()},true)
    for (var i = 0; i < arry.length; i++) {
        var item = arry[i],
            btn = $('<button class="btn btn-default btn-sm"></button>');
        (function (btn, item, indexs) {
            !(row.run && indexs === 0) || btn.addClass('hide');
            !(!row.run && indexs === 1) || btn.addClass('hide');
            btn
                .on('click', function () {
                    bt.simple_confirm(
                        {
                            title: item.title +_this.tips+ '项目【' + row.name + '】',
                            msg: item.title + '项目后'+ (item.title === '停止' ? '将无法正常访问项目' : (item.title === '启动' ? '，用户可以正常访问项目内容' : '将重新加载项目')) + '，是否继续操作？',
                        },
                        function (index) {
                            layer.close(index);
                            item.event.call(that, { name: row.name }, function (res) {
                                row.run = indexs === 0 ? true : indexs === 1 ? false : row.run;
                                html.find('.status').html(reander_service(row.run));
                                $('.sfm-opt button').eq(0).addClass('hide');
                                $('.sfm-opt button').eq(1).addClass('hide');
                                $('.sfm-opt button')
                                    .eq(row.run ? 1 : 0)
                                    .removeClass('hide');
                                bt.msg({ status: res.status, msg: res.msg });
                            });
                        }
                    );
                })
                .text(item.title);
        })(btn, item, i);
        el.find('.sfm-opt').append(btn);
    }
};


/**
 * @description 项目SSL
 * @param el {object} 当前element节点
 * @param row {object} 当前项目数据
 */
CreateWebsiteModel.prototype.reanderProjectSslView = function (el, row) {
	el.empty();
	if (row.project_config.bind_extranet === 0) {
		$('.mask_module')
			.removeClass('hide')
			.find('.node_mask_module_text:eq(1)')
			.hide()
			.prev()
			.show();
		return false;
	}
	site.set_ssl({ name: row.name, ele: el, id: row.id });
	site.ssl.reload();
};

 /**
         * @description 项目重定向
         */
 CreateWebsiteModel.prototype.reander_project_redirect = function (el, row) {
	var _that = this;
	el.empty();
	if (row.project_config.bind_extranet === 0) {
			$('.mask_module').removeClass('hide').find('.node_mask_module_text:eq(1)').hide().prev().show();
			return false;
	}
	el.html(
			'<div>\
			<div id="website_redirect"></div>\
			<ul class="help-info-text c7">\
					<li>设置域名重定向后，该域名的404重定向将失效</li>\
			</ul>\
	</div>'
	);
	site.edit.redirect_table = bt_tools.table({
			el: '#website_redirect',
			url: '/project/'+ _that.type +'/get_project_redirect_list',
			param: { sitename: row.name },
			height: 500,
			dataFilter: function (res) {
					$.each(res, function (i, item) {
							if (!item.hasOwnProperty('errorpage')) {
									item.errorpage = 0;
							}
					});
					return { data: res };
			},
			column: [
					// { type: 'checkbox', width: 20 },
					{
							fid: 'sitename',
							title: '被重定向',
							type: 'text',
							width: 120,
							template: function (row, index) {
									var conter = '空';
									if (row.domainorpath == 'path' && row.errorpage !== 1) {
											conter = row.redirectpath || '空';
									} else {
											conter = row.redirectdomain ? row.redirectdomain.join('、') : '空';
									}
									return '<span style="width:100px;" title="' + conter + '">' + conter + '</span>';
							},
					},
					{
							fid: 'method',
							title: '重定向类型',
							type: 'text',
							width: 90,
							template: function (row, index) {
									var str = '';
									if (row.errorpage == 1) {
											str = '错误';
									} else if (row.domainorpath == 'path') {
											str = '路径';
									} else if (row.domainorpath == 'domain') {
											str = '域名';
									}
									return '<span>' + str + '</span>';
							},
					},
					{
							fid: 'path',
							title: '重定向到',
							type: 'text',
							template: function (row, index) {
									var path = row.tourl ? row.tourl : row.topath;
									return (
											'<span title="' +
											path +
											'" style="display: flex;">\
											<span class="size_ellipsis" style="flex: 1; width: 0;">' +
											(row.topath && path == '/' ? '首页' : path) +
											'</span>\
									</span>'
									);
							},
					},
					{
							fid: 'type',
							title: '状态',
							width: 70,
							config: {
									icon: true,
									list: [
											[1, '运行中', 'bt_success', 'glyphicon-play'],
											[0, '已停止', 'bt_danger', 'glyphicon-pause'],
									],
							},
							type: 'status',
							event: function (row, index, ev, key, that) {
									row.type = !row.type ? 1 : 0;
									row.redirectdomain = JSON.stringify(row['redirectdomain']);

									modify_node_refirect(row, function (res) {
											row.redirectdomain = JSON.parse(row['redirectdomain']);
											that.$modify_row_data({ status: row.type });
											bt.msg(res);
									});
							},
					},
					{
							title: '操作',
							width: 150,
							type: 'group',
							align: 'right',
							group: [
									{
											title: '配置文件',
											event: function (row, index, ev, key, that) {
													if(row.type == 0){
															return layer.msg('重定向已暂停',{icon:2})
													}
													var type = '';
													try {
															type = bt.get_cookie('serverType') || serverType;
													} catch (err) {}
													bt.open({
															type: 1,
															area: ['550px', '550px'],
															title: '编辑配置文件[' + row.redirectname + ']',
															closeBtn: 2,
															shift: 0,
															content:
																	'\
													<div class="bt-form pd15">\
															<p style="color: #666; margin-bottom: 7px">提示：Ctrl+F 搜索关键字，Ctrl+S 保存，Ctrl+H 查找替换</p>\
															<div id="redirect_config_con" class="bt-input-text ace_config_editor_scroll" style="height: 350px; line-height: 18px;"></div>\
															<button id="OnlineEditFileBtn" class="btn btn-success btn-sm" style="margin-top:10px;">保存</button>\
															<ul class="help-info-text c7">\
																	<li>此处为该负载均衡的配置文件，若您不了解配置规则,请勿随意修改。</li>\
															</ul>\
													"</div>',
															success: function (layers, indexs) {
																	bt_tools.send(
																			{ url: '/files?action=GetFileBody', data: { path: row.redirect_conf_file } },function (res) {
																					var editor = bt.aceEditor({
																							el: 'redirect_config_con',
																							content: res.data,
																							mode: 'nginx',
                                                                                            path: row.redirect_conf_file,
																							// saveCallback: function (val) {
																							// 	bt.site.save_redirect_config({ path: rdata[1], data: val, encoding: rdata[0].encoding }, function (ret) {
																							// 		if (ret.status) {
																							// 			site.reload(11);
																							// 			layer.close(indexs);
																							// 		}
																							// 		bt.msg(ret);
																							// 	});
																							// },
																					});
																					$('#OnlineEditFileBtn').click(function () {
																							bt.saveEditor(editor);
																					});
																			})
															},
													});
											},
									},
									{
											title: '编辑',
											event: function (crow, index, ev, key, that) {
													node_refirect_301(row.name, row.id, crow);
											},
									},
									{
											title: '删除',
											event: function (row, index, ev, key, that) {
													bt_tools.send({url:'/project/'+ _that.type +'/remove_project_redirect',data:{sitename:row.sitename,redirectname:row.redirectname}},function(rdata){
															bt.msg(rdata);
															if (rdata.status) that.$delete_table_row(index);
													});
											},
									},
							],
					},
			],
			tootls: [
					{
							// 按钮组
							type: 'group',
							positon: ['left', 'top'],
							list: [
									{
											title: '添加重定向',
											active: true,
											event: function (ev) {
													node_refirect_301(row.name, row.id);
											},
									}
							],
					},
					// {
					// 	//批量操作
					// 	type: 'batch',
					// 	positon: ['left', 'bottom'],
					// 	placeholder: '请选择批量操作',
					// 	buttonValue: '批量操作',
					// 	disabledSelectValue: '请选择需要批量操作的任务!',
					// 	selectList: [
					// 		{
					// 			title: '启用重定向规则',
					// 			url: '/site?action=ModifyRedirect',
					// 			param: function (row) {
					// 				row.type = 1;
					// 				row.redirectdomain = JSON.stringify(row['redirectdomain']);
					// 				return row;
					// 			},
					// 			callback: function (that) {
					// 				bt.simple_confirm({ title: '批量启用重定向规则', msg: '批量启用当前选中的规则后，配置的重定向域名/目录将重新指向目标地址，是否继续操作？' }, function (index) {
					// 					layer.close(index);
					// 					var param = {};
					// 					that.start_batch(param, function (list) {
					// 						var html = '';
					// 						for (var i = 0; i < list.length; i++) {
					// 							var item = list[i];
					// 							var name = '';
					// 							if (item.domainorpath == 'path' && item.errorpage !== 1) {
					// 								name = item.redirectpath;
					// 							} else {
					// 								item.redirectdomain = JSON.parse(item.redirectdomain);
					// 								name = item.redirectdomain ? item.redirectdomain.join('、') : '空';
					// 							}
					// 							html +=
					// 								'<tr><td>' + name + '</td><td><div class="text-right"><span style="color:' + (item.request.status ? '#20a53a' : 'red') + '">' + item.request.msg + '</span></div></td></tr>';
					// 						}
					// 						site.edit.redirect_table.$batch_success_table({
					// 							title: '批量开启服务',
					// 							th: '被重定向',
					// 							html: html,
					// 						});
					// 						site.edit.redirect_table.$refresh_table_list(true);
					// 					});
					// 				});
					// 			},
					// 		},
					// 		{
					// 			title: '停用重定向规则',
					// 			url: '/site?action=ModifyRedirect',
					// 			param: function (row) {
					// 				row.type = 0;
					// 				row.redirectdomain = JSON.stringify(row['redirectdomain']);
					// 				return row;
					// 			},
					// 			callback: function (that) {
					// 				bt.simple_confirm({ title: '批量停用重定向规则', msg: '批量停用当前选中的规则后，配置的重定向域名/目录将指向源地址，是否继续操作？' }, function (index) {
					// 					layer.close(index);
					// 					var param = {};
					// 					that.start_batch(param, function (list) {
					// 						var html = '';
					// 						for (var i = 0; i < list.length; i++) {
					// 							var item = list[i];
					// 							var name = '';
					// 							if (item.domainorpath == 'path' && item.errorpage !== 1) {
					// 								name = item.redirectpath;
					// 							} else {
					// 								item.redirectdomain = JSON.parse(item.redirectdomain);
					// 								name = item.redirectdomain ? item.redirectdomain.join('、') : '空';
					// 							}
					// 							html +=
					// 								'<tr><td>' + name + '</td><td><div class="text-right"><span style="color:' + (item.request.status ? '#20a53a' : 'red') + '">' + item.request.msg + '</span></div></td></tr>';
					// 						}
					// 						site.edit.redirect_table.$batch_success_table({
					// 							title: '批量停止服务',
					// 							th: '被重定向',
					// 							html: html,
					// 						});
					// 						site.edit.redirect_table.$refresh_table_list(true);
					// 					});
					// 				});
					// 			},
					// 		},
					// 		{
					// 			title: '删除重定向规则',
					// 			url: '/site?action=del_redirect_multiple',
					// 			// param: { site_id: web.id },
					// 			// paramId: 'redirectname',
					// 			// paramName: 'redirectnames',
					// 			// theadName: '重定向名称',
					// 			// confirmVerify: false, // 是否提示验证方式
					// 			// refresh: true,
					// 			param: function (row) {
					// 				return {
					// 					site_id: web.id,
					// 					redirectnames: row.redirectname,
					// 				};
					// 			},
					// 			callback: function (that) {
					// 				bt.simple_confirm(
					// 					{
					// 						title: '批量删除重定向规则',
					// 						msg: '批量删除当前选中的规则后，配置的重定向域名/目录将会彻底失效，是否继续操作？',
					// 					},
					// 					function (index) {
					// 						layer.close(index);
					// 						var param = {};
					// 						that.start_batch(param, function (list) {
					// 							var html = '';
					// 							for (var i = 0; i < list.length; i++) {
					// 								var item = list[i];
					// 								var name = '';
					// 								if (item.domainorpath == 'path' && item.errorpage !== 1) {
					// 									name = item.redirectpath;
					// 								} else {
					// 									name = item.redirectdomain ? item.redirectdomain.join('、') : '空';
					// 								}
					// 								html +=
					// 									'<tr><td>' +
					// 									name +
					// 									'</td><td><div class="text-right"><span style="color:' +
					// 									(item.request.status ? '#20a53a' : 'red') +
					// 									'">' +
					// 									(item.request.status ? '删除成功' : '删除失败') +
					// 									'</span></div></td></tr>';
					// 							}
					// 							site.edit.redirect_table.$batch_success_table({
					// 								title: '批量删除操作完成！',
					// 								th: '被重定向',
					// 								html: html,
					// 							});
					// 							site.edit.redirect_table.$refresh_table_list(true);
					// 						});
					// 					}
					// 				);
					// 			},
					// 		},
					// 	],
					// },
			],
	});
	function modify_node_refirect(obj,callback){
			bt_tools.send({url:'/project/'+ _that.type +'/modify_project_redirect',data:obj},function(res){
					if(callback) callback(res)
			},'设置重定向')
	}
	function node_refirect_301(sitename, id, nrow){
			var isEdit = !!nrow;
			var form = isEdit
					? nrow
					: {
							redirectname: new Date().valueOf(),
							tourl: 'http://',
							redirectdomain: [],
							redirectpath: '',
							redirecttype: '',
							type: 1,
							domainorpath: 'domain',
							holdpath: 1,
					};
			var helps = [
					'重定向类型：表示访问选择的“域名”或输入的“路径”时将会重定向到指定URL',
					'目标URL：可以填写你需要重定向到的站点，目标URL必须为可正常访问的URL，否则将返回错误',
					'重定向方式：使用301表示永久重定向，使用302表示临时重定向',
					'保留URI参数：表示重定向后访问的URL是否带有子路径或参数如设置访问http://b.com 重定向到http://a.com',
					'保留URI参数：  http://b.com/1.html ---> http://a.com/1.html',
					'不保留URI参数：http://b.com/1.html ---> http://a.com',
			];
			bt_tools.send({url:'/project/'+ _that.type +'/GetProjectDomain',data:{data:JSON.stringify({name:sitename})}},function(rdata){

					var flag = true;
					var domain_html = '';
					var select_list = [];
					var table_data = site.edit.redirect_table.data;
					for (var i = 0; i < rdata.length; i++) {
							flag = true;
							for (var j = 0; j < table_data.length; j++) {
									var con1 = site.edit.get_list_equal(table_data[j].redirectdomain, rdata[i].name);
									var con2 = !site.edit.get_list_equal(form.redirectdomain, rdata[i].name);
									if (con1 && con2) {
											flag = false;
											break;
									}
							}
							if (flag) {
									select_list.push(rdata[i]);
									var selected = site.edit.get_list_equal(form.redirectdomain, rdata[i].name);
									domain_html += '<li ' + (selected ? 'class="selected"' : '') + '><a><span class="text">' + rdata[i].name + '</span><span class="glyphicon glyphicon-ok check-mark"></span></a></li>';
							}
					}
					if (!domain_html) {
							domain_html = '<div style="padding: 14px 0; color: #999; text-align: center; font-size: 12px;">暂无域名可选</div>';
					}

					var content =
							'<style>select.bt-input-text { width: 100px; }</style>\
					<div id="form_redirect" class="bt-form-new pd20">\
							<div class="form-inline">\
									<div class="form-item">\
											<div class="form-label">开启重定向</div>\
											<div class="form-value">\
													<input class="btswitch btswitch-ios" id="type" type="checkbox" name="type" checked />\
													<label class="btswitch-btn phpmyadmin-btn" for="type"></label>\
											</div>\
									</div>\
									<div class="form-item">\
											<div class="form-label">保留URI参数</div>\
											<div class="form-value">\
													<input class="btswitch btswitch-ios" id="holdpath" type="checkbox" name="holdpath" checked />\
													<label class="btswitch-btn phpmyadmin-btn" for="holdpath"></label>\
											</div>\
									</div>\
							</div>\
							<div class="form-inline">\
									<div class="form-item">\
											<div class="form-label">重定向类型</div>\
											<div class="form-value">\
													<select class="bt-input-text" name="domainorpath">\
															<option value="domain">域名</option>\
															<option value="path">路径</option>\
													</select>\
											</div>\
									</div>\
									<div class="form-item">\
											<div class="form-label" style="width: 90px;">重定向方式</div>\
											<div class="form-value">\
													<select class="bt-input-text" style="width: 150px;" name="redirecttype">\
															<option value="301">301（永久重定向）</option>\
															<option value="302">302（临时重定向）</option>\
													</select>\
											</div>\
									</div>\
							</div>\
							<div class="form-inline redirectdomain" style="flex-wrap: nowrap;">\
									<div class="form-item">\
											<div class="form-label">重定向域名</div>\
											<div class="form-value">\
													<div class="btn-group bootstrap-select show-tick redirect_domain" style="width: 200px;">\
															<button type="button" class="btn dropdown-toggle btn-default" style="height: 32px; line-height: 18px; font-size: 12px">\
																	<span class="filter-option pull-left"></span>\
																	<span class="bs-caret"><span class="caret"></span></span>\
															</button>\
															<div class="dropdown-menu open">\
																	<div class="bs-actionsbox">\
																			<div class="btn-group btn-group-sm btn-block">\
																					<button type="button" class="actions-btn bs-select-all btn btn-default">全选</button>\
																					<button type="button" class="actions-btn bs-deselect-all btn btn-default">取消全选</button>\
																			</div>\
																	</div>\
																	<div class="dropdown-menu inner">' +
							domain_html +
							'</div>\
															</div>\
													</div>\
											</div>\
									</div>\
									<div class="form-item">\
											<div class="form-label" style="width: 80px;">目标URL</div>\
											<div class="form-value">\
													<input class="bt-input-text" name="tourl" type="text" style="width: 200px;" value="http://" />\
											</div>\
									</div>\
							</div>\
							<div class="form-inline redirectpath" style="display: none; flex-wrap: nowrap;">\
									<div class="form-item">\
											<div class="form-label">重定向路径</div>\
											<div class="form-value">\
													<input class="bt-input-text" name="redirectpath" placeholder="如: http://' +
							sitename +
							' " type="text" style="width: 200px;" />\
											</div>\
									</div>\
									<div class="form-item">\
											<div class="form-label" style="width: 80px;">目标URL</div>\
											<div class="form-value">\
													<input class="bt-input-text" name="tourl1" type="text" style="width: 200px;" value="http://" />\
											</div>\
									</div>\
							</div>\
							<div style="height: 15px;"></div>\
							' +
							bt.render_help(helps) +
							'\
					</div>';
					var redirectdomain = form.redirectdomain;

					var form_redirect = bt.open({
							type: 1,
							skin: 'demo-class',
							area: '650px',
							title: !isEdit ? '添加重定向' : '修改重定向',
							closeBtn: 2,
							shift: 5,
							shadeClose: false,
							btn: ['提交', '取消'],
							content: content,
							success: function () {
									var show_domain_name = function () {
											var text = '';
											if (redirectdomain.length > 0) {
													text = [];
													for (var i = 0; i < redirectdomain.length; i++) {
															text.push(redirectdomain[i]);
													}
													text = text.join(', ');
											} else {
													text = '请选择站点';
											}
											$('.redirect_domain .btn .filter-option').text(text);
									};

									show_domain_name();

									$('.redirect_domain .btn').click(function (e) {
											var $parent = $(this).parent();
											$parent.toggleClass('open');
											$(document).one('click', function () {
													$parent.removeClass('open');
											});
											e.stopPropagation();
									});

									// 单选
									$('.redirect_domain .dropdown-menu li').click(function (e) {
											var $this = $(this);
											var index = $this.index();
											var name = select_list[index].name;
											$this.toggleClass('selected');
											if ($this.hasClass('selected')) {
													redirectdomain.push(name);
											} else {
													var remove_index = -1;
													for (var i = 0; i < redirectdomain.length; i++) {
															if (redirectdomain[i] == name) {
																	remove_index = i;
																	break;
															}
													}
													if (remove_index != -1) {
															redirectdomain.splice(remove_index, 1);
													}
											}
											show_domain_name();
											e.stopPropagation();
									});

									// 全选
									$('.redirect_domain .bs-select-all').click(function () {
											redirectdomain = [];
											for (var i = 0; i < select_list.length; i++) {
													redirectdomain.push(select_list[i].name);
											}
											$('.redirect_domain .dropdown-menu li').addClass('selected');
											show_domain_name();
									});

									// 取消全选
									$('.redirect_domain .bs-deselect-all').click(function () {
											redirectdomain = [];
											$('.redirect_domain .dropdown-menu li').removeClass('selected');
											show_domain_name();
									});

									// 重定向类型
									$('[name="domainorpath"]').change(function () {
											var path = $(this).val();
											$('.redirect_domain .bs-deselect-all').click();
											$('[name="redirectpath"]').val('');
											$('.redirectpath, .redirectdomain').hide();
											switch (path) {
													case 'path':
															$('.redirectpath').show();
															break;
													case 'domain':
															$('.redirectdomain').show();
															break;
											}
									});

									if (isEdit) {
											$('[name="type"]').prop('checked', form.type == 1);
											$('[name="holdpath"]').prop('checked', form.holdpath == 1);
											$('[name="domainorpath"]').val(form.domainorpath);
											$('[name="redirecttype"]').val(form.redirecttype);
											$('[name="' + (form.domainorpath == 'path' ? 'tourl1' : 'tourl') + '"]').val(form.tourl);
											$('[name="redirectpath"]').val(form.redirectpath);
											$('.redirectpath, .redirectdomain').hide();
											switch (form.domainorpath) {
													case 'path':
															$('.redirectpath').show();
															break;
													case 'domain':
															$('.redirectdomain').show();
															break;
											}
									}

									$('#form_redirect').parent().css('overflow', 'inherit');
							},
							yes: function () {
									form.type = $('[name="type"]').prop('checked') ? 1 : 0;
									form.holdpath = $('[name="holdpath"]').prop('checked') ? 1 : 0;
									form.redirecttype = $('[name="redirecttype"]').val();
									form.domainorpath = $('[name="domainorpath"]').val();
									form.redirectpath = $('[name="redirectpath"]').val();
									form.tourl = $('[name="' + (form.domainorpath == 'path' ? 'tourl1' : 'tourl') + '"]').val();
									form.redirectdomain = JSON.stringify(redirectdomain);
									bt_tools.send({url:'/project/'+ _that.type +'/'+(isEdit?'modify':'create')+'_project_redirect',data:$.extend(form,{sitename: sitename})},function(rdata){
											if (rdata.status) {
													form_redirect.close();
													site.edit.redirect_table.$refresh_table_list();
											}
											bt.msg(rdata);
									})
							},
					});

			},'获取域名列表')
	}
};


/**
 * @description 渲染项目日志
 * @param el {object} 当前element节点
 * @param row {object} 当前项目数据
 */
CreateWebsiteModel.prototype.renderProjectLogsView = function (el, row) {
    var that = this,
        _config = row.project_config,
        log_config = '<div class="model_project_log_config" style="margin-bottom: 15px;">\
		'+(_config.stype == 'gunicorn'?'日志级别 <select class="bt-input-text mr5" name="model_log_level">\
				<option>debug</option>\
				<option>info</option>\
				<option>warning</option>\
				<option>error</option>\
				<option>critical</option>\
			</select>':'')+'\
		日志路径 <input type="text" name="model_log_path" id="model_log_path" value="'+_config.logpath+'" placeholder="日志路径" class="bt-input-text mr10" style="width:350px" />\
		<span class="glyphicon glyphicon-folder-open cursor mr10" onclick="bt.select_path(\'model_log_path\',\'dir\')"></span>\
		<button class="btn btn-success btn-sm" name="submitLogConfig">保存</button>\
		</div>'
    el.html(log_config+'<div class="model_project_log"></div>');
    $('[name=model_log_level]').val(_config.loglevel);
    this.getProjectLog({ name: row.name }, function (res) {
        $('#webedit-con .model_project_log').html(
            '<div class="mb15">日志大小<span class="ml10">'+ res.size +'</span></div><pre class="command_output_pre" style="height:500px;">' +
            (typeof res == 'object' ? res.data : res) +
            '</pre>'
        );
		$.post({url: '/project/python/get_log_split', data: { name: row.name }}, function (rdata) {
          var html = '',configInfo = {}
          if(rdata.status) configInfo = rdata.data
			    html = '开启后' + (rdata.status ? rdata.data.log_size ? '日志文件大小超过'+ bt.format_size(rdata.data.log_size,true,2,'MB') +'时进行切割日志文件' : '每天'+ rdata.data.hour +'点' + rdata.data.minute + '分进行切割日志文件' : '默认每天2点0分进行切割日志文件')
          $('#webedit-con .model_project_log .command_output_pre').before('<div class="inlineBlock log-split mb20" style="line-height: 32px;">\
          <label>\
            <div class="bt-checkbox '+ (rdata.status && rdata.data.status ? 'active':'') +'"></div>\
            <span>日志切割</span>\
          </label>\
          <span class="unit">'+html+'，如需修改请点击<a href="javascript:;" class="btlink mamger_log_split">编辑配置</a></span>\
          </div>')
					$('#webedit-con .model_project_log .log-split').hover(function(){
            layer.tips('当日志文件过大时，读取和搜索时间会增加，同时也会占用存储空间，因此需要对日志进行切割以方便管理和维护。', $(this), {tips: [3, '#20a53a'], time: 0});
          },function(){
            layer.closeAll('tips');
          })
          $('#webedit-con .model_project_log label').click(function(){
            if(rdata['is_old']){
                bt_tools.msg(rdata)
                return;
            }
            bt.confirm({title:'设置日志切割任务',msg: !rdata.status || (rdata.status && !rdata.data.status) ? '开启后对该项目日志进行切割，是否继续操作？' : '关闭后将无法对该项目日志进行切割，是否继续操作？'},function(){
              if(rdata.status){
                bt_tools.send({url:'/project/python/set_log_split',data:{name: row.name}},function(res){
                  bt_tools.msg(res)
                  if(res.status) {
                    that.simulatedClick(7);
                  }
                })
              }else{
                bt_tools.send({url:'/project/python/mamger_log_split',data:{name: row.name}},function(res){
                  bt_tools.msg(res)
                  if(res.status) {
                    that.simulatedClick(7);
                    layer.close(indexs)
                  }
                })
              }
            })
          })
          $('.mamger_log_split').click(function(){
            if(rdata['is_old']){
                bt_tools.msg(rdata)
                return;
            }
            bt_tools.open({
              type: 1,
              area: '460px',
              title: '配置日志切割任务',
              closeBtn: 2,
              btn: ['提交', '取消'],
              content: {
                'class': 'pd20 mamger_log_split_box',
                form: [{
                  label: '执行时间',
                  group: [{
										type: 'text',
										name: 'day',
										width: '44px',
										value: '每天',
										disabled: true
									},{
                    type: 'number',
                    name: 'hour',
                    'class': 'group',
                    width: '70px',
                    value: configInfo.hour || '2',
                    unit: '时',
                    min: 0,
                    max: 23
                  }, {
                    type: 'number',
                    name: 'minute',
                    'class': 'group',
                    width: '70px',
                    min: 0,
                    max: 59,
                    value: configInfo.minute || '0',
                    unit: '分'
                  }]
                },{
                  label: '日志大小',
                  group:{
                    type: 'text',
                    name: 'log_size',
                    width: '210px',
                    value: configInfo.log_size ? bt.format_size(configInfo.log_size,true,2,'MB').replace(' MB','') : '',
                    unit: 'MB',
                    placeholder: '请输入日志大小',
                  }
                }, {
                  label: '保留最新',
                  group:{
                    type: 'number',
                    name: 'num',
                    'class': 'group',
                    width: '70px',
                    value: configInfo.num || '180',
                    unit: '份'
                  }
                },
                {
                    label: '',
                    group: [
                        {
                            type: 'checkbox',
                            name: 'compress',
                            title: '切割后压缩日志',
                            value: configInfo.compress,
                        },
                    ],
                },]
              },
              success: function (layero, index) {
                $(layero).find('.mamger_log_split_box .bt-form').prepend('<div class="line">\
                <span class="tname">切割方式</span>\
                <div class="info-r">\
                  <div class="replace_content_view" style="line-height: 32px;">\
                    <div class="checkbox_config">\
											<i class="file_find_radio '+ (configInfo.log_size ? 'active' : '') +'"></i>\
                      <span class="laberText" style="font-size: 12px;">按日志大小</span>\
                    </div>\
                    <div class="checkbox_config">\
                      <i class="file_find_radio '+ (configInfo.log_size > 0 ? '' : 'active') +'"></i>\
                      <span class="laberText" style="font-size: 12px;">按执行时间</span>\
                    </div>\
                  </div>\
                </div>')
                $(layero).find('.mamger_log_split_box .bt-form').append('<div class="line"><div class=""><div class="inlineBlock  "><ul class="help-info-text c7"><li>每5分钟执行一次</li><li>【日志大小】：日志文件大小超过指定大小时进行切割日志文件</li><li>【保留最新】：保留最新的日志文件，超过指定数量时，将自动删除旧的日志文件</li></ul></div></div></div>')
                $(layero).find('.replace_content_view .checkbox_config').click(function(){
                  var index = $(this).index()
                  $(this).find('i').addClass('active').parent().siblings().find('i').removeClass('active')
                  if(index){
                    $(layero).find('[name=hour]').parent().parent().parent().show()
                    $(layero).find('[name=log_size]').parent().parent().parent().hide()
                    $(layero).find('.help-info-text li').eq(0).hide().next().hide()
                  }else{
                    $(layero).find('[name=hour]').parent().parent().parent().hide()
                    $(layero).find('[name=log_size]').parent().parent().parent().show()
                    $(layero).find('.help-info-text li').eq(0).show().next().show()
                  }
                })
                if(configInfo.log_size) {
                  $(layero).find('[name=hour]').parent().parent().parent().hide()
                }else{
                  $(layero).find('[name=log_size]').parent().parent().parent().hide()
                  $(layero).find('.help-info-text li').eq(0).hide().next().hide()
                }
                $(layero).find('[name=log_size]').on('input', function(){
                  if($(this).val() < 1 || !bt.isInteger(parseFloat($(this).val()))) {
                    layer.tips('请输入日志大小大于0的的整数', $(this), { tips: [1, 'red'], time: 2000 })
                  }
                })
                $(layero).find('[name=hour]').on('input', function(){
                  if($(this).val() > 23 || $(this).val() < 0 || !bt.isInteger(parseFloat($(this).val()))) {
                    layer.tips('请输入小时范围0-23的整数时', $(this), { tips: [1, 'red'], time: 2000 })
                  }
                  $(layero).find('.hour').text($(this).val())
                })
                $(layero).find('[name=minute]').on('input', function(){
                  if($(this).val() > 59 || $(this).val() < 0 || !bt.isInteger(parseFloat($(this).val()))) {
                    layer.tips('请输入正确分钟范围0-59分的整数', $(this), { tips: [1, 'red'], time: 2000 })
                  }
                  $(layero).find('.minute').text($(this).val())
                })
                $(layero).find('[name=num]').on('input', function(){
                  if($(this).val() < 1 || $(this).val() > 1800 || !bt.isInteger(parseFloat($(this).val()))) {
                    layer.tips('请输入保留最新范围1-1800的整数', $(this), { tips: [1, 'red'], time: 2000 })
                  }
                })
              },
              yes: function (formD,indexs) {
                formD['name'] = row.name
								delete formD['day']
                if($('.mamger_log_split_box .file_find_radio.active').parent().index()) {
									if (formD.hour < 0 || formD.hour > 23 || isNaN(formD.hour) || formD.hour === '' || !bt.isInteger(parseFloat(formD.hour))) return layer.msg('请输入小时范围0-23时的整数')
									if (formD.minute < 0 || formD.minute > 59 || isNaN(formD.minute) || formD.minute === '' || !bt.isInteger(parseFloat(formD.minute))) return layer.msg('请输入正确分钟范围0-59分的整数')
									formD['log_size'] = 0
								}else{
									if(formD.log_size == '' || !bt.isInteger(parseFloat(formD.log_size))) return layer.msg('请输入日志大小大于0的的整数')
								}
								if(formD.num < 1 || formD.num > 1800 || !bt.isInteger(parseFloat(formD.num))) return layer.msg('请输入保留最新范围1-1800的整数')
						formD.compress = formD.compress ? 1 : 0;
                        if(!rdata.status || (rdata.status && !rdata.data.status)) {
									if(rdata.status){
										that.set_log_split({name: row.name},function(res){
											if(res.status) {
												pub_open()
											}
										})
									}else{
										pub_open()
									}
								}else{
									pub_open()
								}
								function pub_open() {
									that.mamger_log_split(formD,function(res){
										bt.msg(res)
										if(res.status) {
											that.renderProjectLogsView(el, row);
											layer.close(indexs)
										}
									})
								}
              }
            })
          })
        })
        $('.command_output_pre').scrollTop(
            $('.command_output_pre').prop('scrollHeight')
        );
    });
    // 保存按钮
    $('[name=submitLogConfig]').click(function () {
        var logpath = $('[name=model_log_path]').val(),
            loglevel = $('[name=model_log_level]').val(),
            param  = { name: row.name, data:{logpath: logpath} };
        if (!logpath) {
            bt.msg({ status: false, msg: '日志路径不能为空' });
            return;
        }
        //gunicorn时才有日志级别
        if(_config.stype == 'gunicorn'){
            param.data.loglevel = loglevel;
        }
        // 编辑项目
        that.modifyProject(param, function (res) {
            bt.msg({ status: res.status, msg: res.msg });
            that.simulatedClick(5);
        });
    })
};

/**
 * @description 渲染项目日志
 * @param el {object} 当前element节点
 * @param row {object} 当前项目数据
 */
CreateWebsiteModel.prototype.renderSiteLogsView = function (el, row) {
    el.empty();
    if (row.project_config.bind_extranet === 0) {
        $('.mask_module')
            .removeClass('hide')
            .find('.node_mask_module_text:eq(1)')
            .hide()
            .prev()
            .show();
        return false;
    }
    $(el).html('<div id="tabLogs" class="tab-nav"></div><div class="tab-con" style="padding:10px 0px;"></div>')
    var _tab = [
        {
            title: '响应日志',
            on: true,
            callback: function (robj) {
                bt_tools.send({url: '/logs/site/get_ip_area'},function(resStatus) {
                    var ip_area = bt.get_cookie('ltd_end') > 0 ? resStatus.msg : 0
                    getSiteLogs(ip_area)
                    function getSiteLogs(ip_area_num) {
                        bt.site.getSiteLogs({ip_area: ip_area_num,siteName: row.name},function(rdata) {
                            var _logs_info = $('<div></div>').text(rdata.msg);
                            var logs = { class: 'bt-logs site_log_hover', items: [{ name: 'site_logs', height: '545px', value: _logs_info.html(), width: '100%', type: 'textarea' }] },
                                _form_data = bt.render_form_line(logs);
                            robj.empty()
                            robj.append('<div class="refresh-btn-box mb10 flex" style="justify-content: space-between;">\
          <div class="ip-area-box"><input type="checkbox" class="ip_area" id="ip_area" name="ip_area" '+ (ip_area_num ? 'checked' : '') +'><label for="ip_area">显示IP归属地信息<span class="glyphicon icon-vipLtd" style="margin-left: 6px;position: relative;top: -2px;"></span></label></div>\
          <button type="button" title="刷新设置" class="btn btn-default btn-sm mr15 refreshSiteSunLogs refresh-btn relative" >\
                    <div class="plr10 flex align-center refresh-div">\
                    <div class="countdown">\
                        <svg viewBox="0 0 100 100"><path d="\
                        M 50 50\
                        m 0 -46\
                        a 46 46 0 1 1 0 92\
                        a 46 46 0 1 1 0 -92\
                        " stroke="#ccc" stroke-width="8" fill="#fff" class="el-progress-circle__track" style="stroke-dasharray: 289.027px, 289.027px; stroke-dashoffset: 0px;"></path><path d="\
                        M 50 50\
                        m 0 -46\
                        a 46 46 0 1 1 0 92\
                        a 46 46 0 1 1 0 -92\
                        " stroke="#20a53a" fill="none" stroke-linecap="round" stroke-width="8" class="el-progress-circle__path" style="stroke-dasharray: 289.027px, 289.027px; stroke-dashoffset: 0px; transition: stroke-dasharray 0.6s ease 0s, stroke 0.6s ease 0s;"></path></svg>\
                        <div class="time"></div>\
                    </div>\
                    <span>刷新日志</span></div>\
                    <div class="down-box">\
                        <svg width="12.000000" height="12.000000" viewBox="0 0 12 5" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">    				        <desc>    				            Created with Pixso.    				        </desc>    				        <defs></defs>    				        <path id="path" d="M0.123291 0.809418L4.71558 5.84385C4.8786 6.02302 5.16846 6.04432 5.33038 5.86389L9.87927 0.783104C10.0412 0.602676 10.04 0.311989 9.87701 0.132816C9.79626 0.0446892 9.68945 0 9.58374 0C9.47693 0 9.36938 0.0459404 9.28827 0.136574L5.02881 4.89284L0.708618 0.15662C0.627869 0.0684967 0.522217 0.0238075 0.415405 0.0238075C0.307434 0.0238075 0.20105 0.0697479 0.119873 0.160381C-0.041626 0.338303 -0.0393677 0.630241 0.123291 0.809418Z" fill-rule="nonzero" fill="#999999"></path>    				    </svg>\
                        <div class="refreshMenu"></div>\
                    </div>\
                    <div class="refreshMenu"></div>\
                    </button></div>'+_form_data.html);
                            bt.render_clicks(_form_data.clicks);

                            $('[name=ip_area]').unbind('change').change(function () {
                                var _checked = $(this).prop('checked'),ltd_end = bt.get_cookie('ltd_end');
                                if(ltd_end > 0) {
                                    getSiteLogs(_checked ? 1 : 0)
                                }else {
                                    $(this).prop('checked',false)
                                    product_recommend.pay_product_sign('ltd', 184,'ltd')
                                }
                            })

                            function refreshLogs () {
                                var _ip_status = $('[name=ip_area]').prop('checked') ? 1 : 0;
                                bt.site.getSiteLogs({ip_area: _ip_status,siteName: row.name}, function (rdata1) {
                                    var _logs_info1 = $('<div></div>').text(rdata1.msg);
                                    $('textarea[name="site_logs"]').val(_logs_info1.html());
                                });
                            }
                            bt.refreshLogBtn({func: refreshLogs,cookie: 'sitelog'+ row.id})

                            $('.refresh-btn .refresh-div').unbind('click').click(function () {
                                refreshLogs()
                            })

                            $('textarea[name="site_logs"]').attr('readonly', true);
                            $('textarea[name="site_logs"]').scrollTop(100000000000);
                            $('textarea[name="site_logs"]').parent().css('position', 'relative');
                            $('textarea[name="site_logs"]').parent().append(
                                '<button class="hide full btn btn-sm btn-success"\
                                                         style="position:absolute;top:10px;right:10px">全屏展示</button>'
                            );
                            $('.site_log_hover')
                                .unbind('hover')
                                .hover(
                                    function (e) {
                                        $('.full').removeClass('hide');
                                        e.stopPropagation();
                                        e.preventDefault();
                                    },
                                    function (e) {
                                        $('.full').addClass('hide');
                                        e.stopPropagation();
                                        e.preventDefault();
                                    }
                                );
                            bt.site.fullScreenLog(_logs_info, row, '响应');
                        })
                    }
                })
            },
        },
        {
            title: '错误日志',
            callback: function (robj) {
                bt.site.get_site_error_logs(row.name, function (rdata) {
                    var _logs_info = $('<div></div>').text(rdata.msg);
                    var logs = { class: 'bt-logs error_log_hover', items: [{ name: 'site_logs', height: '590px', value: _logs_info.html(), width: '100%', type: 'textarea' }] },
                        _form_data = bt.render_form_line(logs);
                    robj.append(_form_data.html);
                    bt.render_clicks(_form_data.clicks);
                    $('textarea[name="site_logs"]').attr('readonly', true);
                    $('textarea[name="site_logs"]').scrollTop(100000000000);
                    $('textarea[name="site_logs"]').parent().css('position', 'relative');
                    $('textarea[name="site_logs"]').parent().append(
                        '<button class="hide full btn btn-sm btn-success"\
                        style="position:absolute;top:10px;right:10px">全屏展示</button>'
                    );
                    $('.error_log_hover')
                        .unbind('hover')
                        .hover(
                            function (e) {
                                $('.full').removeClass('hide');
                                e.stopPropagation();
                                e.preventDefault();
                            },
                            function (e) {
                                $('.full').addClass('hide');
                                e.stopPropagation();
                                e.preventDefault();
                            }
                        );
                    bt.site.fullScreenLog(_logs_info, web, '错误');
                });
            },
        },
        {
            title: '日志安全分析',
            callback: function (robj) {
                logs.siteLogs.getSiteWeb(robj,row.name)
                return
            },
        },
    ];
    bt.render_tab('tabLogs', _tab);
    $('#tabLogs span:eq(0)').click();
};

/**
 * @description 渲染项目配置文件
 * @param el {object} 当前element节点
 * @param row {object} 当前项目数据
 */
CreateWebsiteModel.prototype.renderFileConfigView = function (el, row) {
    el.empty();
    if (row.project_config.bind_extranet === 0) {
        $('.mask_module')
            .removeClass('hide')
            .find('.node_mask_module_text:eq(1)')
            .hide()
            .prev()
            .show();
        return false;
    }
    site.edit.set_config({ name: this.type + '_' + row.name });
};
/**
 * @description 渲染运行配置文件
 * @param el {object} 当前element节点
 * @param row {object} 当前项目数据
 */
CreateWebsiteModel.prototype.renderFrameworkConfigView = function(el,row){
    var that = this,_aceEditor = null;
    var con = '<div class="bt-input-text ace_config_editor_scroll" style="height: 400px; line-height:18px;font-size:12px" id="siteConfigBody"></div>\
	<button id="OnlineProjectSubmit" class="btn btn-success btn-sm" style="margin-top:10px;">保存</button>\
	<ul class="c7 ptb15">\
		<li>此处为运行配置文件,若您不了解配置规则,请勿随意修改.</li>\
	</ul>';
    $("#webedit-con").html(con);
    this.getConfFile({ name: row.name }, function (res) {
        _aceEditor = ace.edit('siteConfigBody', {
            theme: "ace/theme/chrome", //主题
            mode: "ace/mode/python", // 语言类型
            wrap: true,
            showInvisibles: false,
            showPrintMargin: false,
            showFoldWidgets: false,
            useSoftTabs: true,
            tabSize: 2,
            showPrintMargin: false,
            readOnly: false
        })

        _aceEditor.setValue(res.data)
    })
    $("#OnlineProjectSubmit").click(function (e) {
        that.saveConfFile({ name: row.name, data: _aceEditor.getValue()  }, function (res) {
            if(res.status) bt.msg({ status: res.status, msg: res.msg });
        })
    });
}
/**
 * @description 渲染项目模块
 * @param row {object} 当前项目数据
 */
CreateWebsiteModel.prototype.renderProjectModuleView = function(row){
    var that = this;
    bt_tools.open({
        type: 1,
        title: '项目【' + row.name + '】模块管理',
        area: ['600px', '430px'],
        closeBtn: 2,
        btn:false,
        content: '<div class="project_module_title" style="padding: 15px 15px 0 15px;">\
				<input type="text" name="project_module_name" placeholder="虚拟环境模块名称" class="bt-input-text mr10" style="width:270px" />\
				<input type="text" name="project_module_version" placeholder="模块版本" class="bt-input-text mr10" style="width:160px" />\
				<button class="btn btn-success btn-sm" name="project_module_install">安装模块</button>\
			</div>\
			<div class="project_module_table plr15"></div>',
        success:function(){
            var project_model = bt_tools.table({
                el: '.project_module_table',
                url: '/project/' + that.type + '/GetPackages',
                param: { name: row.name },
                load:'获取模块列表',
                height:'317px',
                column:[
                    { fid: '0',title: '模块名',type: 'text',template:function(row){return row[0]} },
                    { fid: '1',title: '版本',type: 'text',width:60,template:function(row){return row[1]} },
                    { title: '操作',type: 'group',width: 70,align: 'right',group: [
                            {
                                title: '卸载',
                                event: function (rowc) {
                                    bt.confirm({
                                        title: '卸载项目环境模块',
                                        msg: '卸载['+rowc[0]+']后，模块相关的全局变量将无法调用，是否继续？'
                                    }, function () {
                                        bt_tools.send({url: '/project/' + that.type + '/MamgerPackage',data: { name:row.name,act:'uninstall',p:rowc[0],v:rowc[1]}},function (res) {
                                            bt.msg(res);
                                            if(res.status)project_model.$refresh_table_list(true);
                                        },{ load: '正在卸载项目模块' });
                                    });
                                }
                            }
                        ]}
                ]
            })

            //安装模块
            $('[name=project_module_install]').click(function(){
                var name = $('[name=project_module_name]').val(),
                    version = $('[name=project_module_version]').val();
                if(!name){
                    bt.msg({status:false,msg:'虚拟环境模块名称不能为空'});
                    return;
                }
                bt_tools.send({url: '/project/' + that.type + '/MamgerPackage',data: { name:row.name,act:'install',p:name,v:version}},function (res) {
                    bt.msg(res);
                    if(res.status){
                        $('[name=project_module_name],[name=project_module_version]').val('')
                        project_model.$refresh_table_list(true);
                    }
                },{ load: '正在安装项目模块' });
            })
        }
    })
};
/**
 * @description 模拟点击
 */
CreateWebsiteModel.prototype.simulatedClick = function (num) {
    $('.bt-w-menu p:eq(' + num + ')').click();
};
/**
 * @description 获取python版本安装情况
 */
CreateWebsiteModel.prototype.installVersionLog = function (config) {
	  var _that = this;
		var interval = null
    var r_command = layer.open({
        type: 1,
        title: config.name || '正在安装python版本，请稍候...',
        closeBtn: 2,
        area: ['500px', '344px'],
        skin: config.class || 'module_commmand',
        shadeClose: false,
        content: '<div class="python_module_command"></div>',
        success: function () {
          bt_tools.command_line_output({ el: '.python_module_command', shell: config.shell, area: config.area || ['100%', '300px'] })
            if(config.isCreateProject){
                interval = setInterval(()=>{
                    for(var i=0;i<_that.pthyonProjectList.length;i++){
                        if(_that.pthyonProjectList[i].name==config.projectname){
                            if(_that.pthyonProjectList[i].status === 'running'){
                                return
                            }
                            if(_that.pthyonProjectList[i].status === true || _that.pthyonProjectList[i].status === false){
                                // 项目环境准备成功
                                bt.msg({status:true,msg:'项目环境准备成功'});
                                setTimeout(function () {
                                    layer.close(r_command);
                                },200)
                                clearInterval(interval)
                                return
                            }else{
                                // 环境准备失败
                                bt_tools.msg({status:false,msg:'项目环境准备失败'});
                            }
                        }
                    }
                },2000)
            }
        },
        cancel: function () {
            if(interval)clearInterval(interval)
        }
    })
    return r_command;
}
/**
 * @description 绑定请求
 */
CreateWebsiteModel.prototype.bindHttp = function () {
    var that = this;
    for (const item in this.methods) {
        if (Object.hasOwnProperty.call(this.methods, item)) {
            const element = that.methods[item];
            (function (element) {
                CreateWebsiteModel.prototype[item] = function (param, callback) {
                    bt_tools.send(
                        {
                            url: '/project/' + that.type + '/' + element[0],
                            data: { data: JSON.stringify(param) },
                        },
                        function (data) {
                            if (callback) callback(data);
                        },
                        { load: element[1],verify:element[2] }
                    );
                };
            })(element);
        }
    }
};
