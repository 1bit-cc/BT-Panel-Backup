function CreateWebsiteModel(config) {
  this.type = config.type;
  this.tips = config.tips;
  this.methods = {
    createProject: ['create_project', '创建' + config.tips + '项目'],
    modifyProject: ['modify_project', '修改' + config.tips + '项目'],
    removeProject: ['remove_project', '删除' + config.tips + '项目'],
    startProject: ['start_project', '启动' + config.tips + '项目'],
    stopProject: ['stop_project', '停止' + config.tips + '项目'],
    restartProject: ['restart_project', '重启' + config.tips + '项目'],
    getProjectInfo: ['get_project_info', '获取' + config.tips + '项目信息'],
    getProjectDomain: ['project_get_domain', '获取' + config.tips + '项目域名'],
    addProjectDomain: ['project_add_domain', '添加' + config.tips + '项目域名'],
    removeProjectDomain: [
      'project_remove_domain',
      '删除' + config.tips + '项目域名',
    ],
    getProjectLog: ['get_project_log', '获取' + config.tips + '项目日志'],
    change_log_path: ['change_log_path', '修改' + config.tips + '项目日志路径'],
    get_log_split: ['get_log_split', '获取' + config.tips + '项目日志切割任务'],
    mamger_log_split: ['mamger_log_split', '设置' + config.tips + '项目日志切割任务'],
    set_log_split: ['set_log_split', '设置' + config.tips + '项目日志切割状态'],
    bindExtranet: ['bind_extranet', '开启外网映射'],
    unbindExtranet: ['unbind_extranet', '关闭外网映射'],
  };
  this.bindHttp(); //将请求映射到对象
  this.reanderProjectList(); // 渲染列表
}
/**
 * @description 渲染获取项目列表
 */
CreateWebsiteModel.prototype.reanderProjectList = function () {
  var _that = this;
  $('#bt_' + this.type + '_table').empty();
  site.model_table = bt_tools.table({
    el: '#bt_' + this.type + '_table',
    url: '/project/' + _that.type + '/GetSiteList',
    minWidth: '1000px',
    autoHeight: true,
    default: '项目列表为空', //数据为空时的默认提示\
    load: '正在获取' + _that.tips + '项目列表，请稍候...',
    pageName: 'nodejs',
    beforeRequest: function (params) {
      params['table']='sites';
      params['type']=bt.get_cookie('site_type_' + _that.type)
      return params;
    },
    dataFilter: function (res) {
      bt.getSiteNum() // 获取数量
      return res
    },
    column: [
      { type: 'checkbox', class: '', width: 20 },
      {
        fid: 'name',
        title: '项目名称',
        type: 'link',
        event: function (row, index, ev) {
          _that.reanderProjectInfoView(row);
        },
      },
      {
        fid: 'path',
        title: '根目录',
        width:220,
        type: 'link',
        event:function(row,index,ev){
          openPath(row.path)
        },
      },{
        title: '<span style="display:flex"><span onclick="bt.soft.product_pay_view({ totalNum: 67, limit: \'ltd\', closePro: true })" class="firwall_place_of_attribution"></span>目录详情</span>',
        width:120,
        type: 'text',
        template:function(row,index,ev){
          return bt.files.dir_details_span(row.path);
        },
      },
      {
        fid: 'ps',
        title: '备注',
        type: 'input',
        blur: function (row, index, ev, key, that) {
          if (row.ps == ev.target.value) return false;
          bt.pub.set_data_ps(
            { id: row.id, table: 'sites', ps: ev.target.value },
            function (res) {
              bt_tools.msg(res, { is_dynamic: true });
            }
          );
        },
        keyup: function (row, index, ev) {
          if (ev.keyCode === 13) {
            $(this).blur();
          }
        },
      },
      {
        title: '操作',
        type: 'group',
        width: 100,
        align: 'right',
        group: [
          {
            title: '设置',
            event: function (row, index, ev, key, that) {
              _that.reanderProjectInfoView(row);
            },
          },
          {
            title: '删除',
            event: function (row, index, ev, key, that) {
              bt.input_confirm({
                  title: '删除项目 - [' + row.name + ']',
                  value: '删除项目',
                  msg: '<span class="color-org">风险操作，此操作不可逆</span>，删除' + _that.tips + '项目后您将无法管理该项目，是否继续操作？'},
                function () {
                  bt_tools.send({
                    url:'/project/proxy/DeleteSite',
                    data:{
                      path:'1',
                      id:row.id,
                      webname:row.name,
                    }
                  },function (res){
                    if(res!=null){
                      bt.msg({status:res.status,msg:res.msg})
                      site.model_table.$refresh_table_list(true);
                    }
                  })
                }
              );
            },
          },
        ],
      },
    ],
    // 渲染完成
    tootls: [
      {
        // 按钮组
        type: 'group',
        positon: ['left', 'top'],
        list: [
          {
            title: '添加' + _that.tips + '项目',
            active: true,
            event: function (ev) {
              _that.reanderAddProject(function (res) {
                site.model_table.$refresh_table_list(true);
              });
            },
          },
        ],
      },
      {
        // 搜索内容
        type: 'search',
        positon: ['right', 'top'],
        placeholder: '请输入项目名称或备注',
        searchParam: 'search', //搜索请求字段，默认为 search
        value: '', // 当前内容,默认为空
      },
      {
        // 批量操作
        type: 'batch', //batch_btn
        positon: ['left', 'bottom'],
        placeholder: '请选择批量操作',
        buttonValue: '批量操作',
        disabledSelectValue: '请选择需要批量操作的站点!',
        selectList: [
          {
            title: '设置分类',
            url: '/project/' + _that.type + '/set_project_site_type',
            paramName: 'site_ids', //列表参数名,可以为空
            paramId: 'type_id', // 需要传入批量的id
            refresh: true,
            beforeRequest: function (list) {
              var arry = [];
              $.each(list, function (index, item) {
                arry.push(item.id);
              });
              return JSON.stringify(arry);
            },
            confirm: {
              title: '批量设置分类',
              content:
                  '<div class="line"><span class="tname">站点分类</span><div class="info-r"><select class="bt-input-text mr5 site_types" name="site_types" style="width:150px"></select></span></div></div>',
              success: function () {
                bt_tools.send({url:'/project/' + _that.type + '/project_site_types'},function(res){
                  var html = '';
                  $.each(res, function (index, item) {
                    html += '<option value="' + item.id + '">' + item.name + '</option>';
                  });
                  $('[name="site_types"]').html(html);
                });
              },
              yes: function (index, layers, request) {
                request({ type_id: $('[name="site_types"]').val() });
              },
            },
            tips: false,
            success: function (res, list, that) {
              var html = '';
              $.each(list, function (index, item) {
                html += '<tr><td>' + item.name + '</td><td><div style="float:right;"><span style="color:' + (res.status ? '#20a53a' : 'red') + '">' + res.msg + '</span></div></td></tr>';
              });
              that.$batch_success_table({ title: '批量设置分类', th: '站点名称', html: html });
              that.$refresh_table_list(true);
            },
          },
          {
            title: '删除项目',
            url: '/project/proxy/DeleteSite',
            param: function (row) {
              return {
                  path: row.path,
                  id: row.id,
                  webname: row.name,
              };
            },
            refresh: true,
            callback: function (that) {
              bt.prompt_confirm(
                '批量删除项目',
                '您正在删除选中的' + _that.tips + '项目，继续吗？',
                function () {
                  that.start_batch({}, function (list) {
                    var html = '';
                    for (var i = 0; i < list.length; i++) {
                      var item = list[i];
                      html +=
                        '<tr><td><span>' +
                        item.name +
                        '</span></td><td><div style="float:right;"><span style="color:' +
                        (item.requests.status ? '#20a53a' : 'red') +
                        '">' +
                        (item.requests.status
                          ? item.requests.msg
                          : item.requests.msg) +
                        '</span></div></td></tr>';
                    }
                    site.model_table.$batch_success_table({
                      title: '批量删除项目',
                      th: '项目名称',
                      html: html,
                    });
                    site.model_table.$refresh_table_list(true);
                  });
                }
              );
            },
          }
        ],
      },
      {
        //分页显示
        type: 'page',
        positon: ['right', 'bottom'], // 默认在右下角
        pageParam: 'p', //分页请求字段,默认为 : p
        page: 1, //当前分页 默认：1
        numberParam: 'limit',
        //分页数量请求字段默认为 : limit
        number: 20,
        //分页数量默认 : 20条
        numberList: [10, 20, 50, 100, 200], // 分页显示数量列表
        numberStatus: true, //　是否支持分页数量选择,默认禁用
        jump: true, //是否支持跳转分页,默认禁用
      },
    ],
    success: function () {
      if(site.model_table){
        var elTable = site.model_table.config.el
        if($(elTable+' .tootls_top .pull-right #right_cate_select').length === 0){
          site.init_project_type(_that.type)
        }
      }

      // 服务状态事件
      site.server_status_event()
      // 详情事件
      bt.files.dir_details()
    }
  });
};

/**
 * @description 获取添加项目配置
 */
CreateWebsiteModel.prototype.getAddProjectConfig = function (data) {
  var that = this,
    data = data || {},
    config = [
      {
        label: '绑定域名',
        formLabelWidth: '110px',
        must: '*',
        group: {
          type: 'textarea', //当前表单的类型 支持所有常规表单元素、和复合型的组合表单元素
          name: 'domains', //当前表单的name
          style: { width: '440px', height: '120px', 'line-height': '22px' },
          tips: {
            //使用hover的方式显示提示
            text: '<span>如果需要绑定外网，请输入需要绑定的域名</span><br>如需填写多个域名，请换行填写，每行一个域名，默认为80端口<br>泛解析添加方法：先添加一个域名 domain.com，后换行添加*.domain.com<br>如另加端口格式为 www.domain.com:88',
            style: { top: '10px', left: '15px' },
          },
          input: function (value, form, thats, config, ev) {
            //键盘事件
            var array = value.domains.split('\n'),
              ress = array[0].split(':')[0],
              oneVal = bt.strim(ress.replace(new RegExp(/([-.])/g), '_')),
              defaultPath = $('#defaultPath').text(),
              is_oneVal = ress.length > 0;
            thats.$set_find_value(
              is_oneVal
                ? {
                  project_ps: oneVal,
                  project_ps: ress,
                  path: bt.rtrim(defaultPath, '/') + '/' + ress,
                }
                : {project_ps: '', path: bt.rtrim(defaultPath, '/') }
            );
          },
        },
      },
      {
        label: '根目录',
        must: '*',
        formLabelWidth: '110px',
        group: {
          type: 'text',
          width: '400px',
          name: 'path',
          icon: {
            type: 'glyphicon-folder-open',
            event: function (ev) {},
          },
          value: bt.get_cookie('sites_path') ? bt.get_cookie('sites_path') : '/www/wwwroot',
          placeholder: '请选择文件目录',
        },
      },
      {
        label: '备注',
        formLabelWidth: '110px',
        group: {
          type: 'text',
          name: 'project_ps',
          width: '400px',
          placeholder: '请输入项目备注',
          value: '',
        },
      },
    ];

  if (data.type == 'edit') {
    config.splice(7, 2);
    config.push({
      formLabelWidth: '110px',
      group: {
        type: 'button',
        name: 'submitForm',
        title: '保存配置',
        event: function (fromData) {
          // 编辑项目
          fromData.is_power_on = fromData.is_power_on ? 1 : 0;
          if (parseInt(fromData.port) < 0 || parseInt(fromData.port) > 65535) return layer.msg('项目端口格式错误，可用范围：1-65535',{icon:2})
          that.modifyProject(fromData, function (res) {
            bt.msg({ status: res.status, msg: res.data });
            that.simulatedClick(0);
          });
          // console.log(arguments, 'event');
        },
      },
    });
  }
  return config;
};

/**
 * @description 渲染添加项目表单
 */
CreateWebsiteModel.prototype.reanderAddProject = function (callback) {
  var that = this;

  var modelForm = bt_tools.open({
    title: '添加' + this.tips + '项目',
    area: ['720px','700px'],
    btn: ['提交', '取消'],
    content: {
      class: 'pd30',
      formLabelWidth: '120px',
      form: (function () {
        return that.getAddProjectConfig();
      })(),
    },
    success: function (layers, index) {
      var obj = { type: 1, cache: 0, proxyname: '', proxydir: '/', proxysite: 'http://', cachetime: 1, todomain: '$host', subfilter: [{ sub1: '', sub2: '' }] };
      var type = true;
      var sub_conter = '';
      if (typeof obj.subfilter === 'string') obj.subfilter = JSON.parse(obj.subfilter);
      for (var i = 0; i < obj.subfilter.length; i++) {
        if (i == 0 || obj.subfilter[i]['sub1'] != '') {
          sub_conter +=
            "<div class='sub-groud'>" +
            "<input name='rep" +
            ((i + 1) * 2 - 1) +
            "' class='bt-input-text mr10' placeholder='被替换的文本,可留空' type='text' style='width:200px' value='" +
            obj.subfilter[i]['sub1'] +
            "'>" +
            "<input name='rep" +
            (i + 1) * 2 +
            "' class='bt-input-text ml10' placeholder='替换为,可留空' type='text' style='width:200px' value='" +
            obj.subfilter[i]['sub2'] +
            "'>" +
            "<a href='javascript:;' class='proxy_del_sub' style='color:red;'>删除</a>" +
            '</div>';
        }
        if (i == 2) $('.add-replace-prosy').attr('disabled', 'disabled');
      }
      var helps = [
        '代理目录：访问这个目录时将会把目标URL的内容返回并显示(需要开启高级功能)',
        '目标URL：可以填写你需要代理的站点，目标URL必须为可正常访问的URL，否则将返回错误',
        '发送域名：将域名添加到请求头传递到代理服务器，默认为目标URL域名，若设置不当可能导致代理无法正常运行',
        '内容替换：只能在使用nginx时提供，最多可以添加3条替换内容,如果不需要替换请留空',
      ];
      $(layers).find('.bt-form').after(
        "<form id='form_proxy' class='divtable '>" +
                  "<div class='line' style='overflow:hidden'>" +
                    "<span class='tname' style='position: relative;top: -5px;'>开启代理</span>" +
                    "<div class='info-r  ml0 mt5' >" +
                      "<input class='btswitch btswitch-ios' id='openVpn' type='checkbox' name='type' checked><label class='btswitch-btn phpmyadmin-btn' for='openVpn' style='float:left'></label>" +
                      "<div style='display:" +
                      (bt.get_cookie('serverType') == 'nginx' ? ' inline-block' : 'none') +
                      "'>" +
                        "<span class='tname' style='margin-left:15px;position: relative;top: -5px;'>开启缓存</span>" +
                        "<input class='btswitch btswitch-ios' id='openNginx' type='checkbox' name='cache' " +
                        (obj.cache == 1 ? 'checked="checked"' : '') +
                        "><label class='btswitch-btn phpmyadmin-btn' for='openNginx'></label>" +
                      "</div>" +
                      "<div style='display: inline-block;'>" +
                        "<span class='tname' style='margin-left:10px;position: relative;top: -5px;'>高级功能</span>" +
                        "<input class='btswitch btswitch-ios' id='openAdvanced' type='checkbox' name='advanced' " +
                        (obj.advanced == 1 ? 'checked="checked"' : '') +
                        "><label class='btswitch-btn phpmyadmin-btn' for='openAdvanced'></label>" +
                      "</div>" +
                    "</div>" +
                  "</div>" +
        "<div class='line' style='clear:both;'>" +
        "<span class='tname'><span class=\"color-red mr5\">*</span>代理名称</span>" +
        "<div class='info-r  ml0'><input name='proxyname'" +
        (type ? '' : "readonly='readonly'") +
        " class='bt-input-text mr5 " +
        (type ? '' : ' disabled') +
        "' type='text' style='width:200px' value='" +
        obj.proxyname +
        "'></div>" +
        '</div>' +
        "<div class='line cachetime' style='display:" +
        (obj.cache == 1 ? 'block' : 'none') +
        "'>" +
        "<span class='tname'><span class=\"color-red mr5\">*</span>缓存时间</span>" +
        "<div class='info-r  ml0'><input name='cachetime' class='bt-input-text mr5' type='text' style='width:200px' type='number' value='" +
        obj.cachetime +
        "'>分钟</div>" +
        '</div>' +
        "<div class='line advanced'  style='display:" +
        (obj.advanced == 1 ? 'block' : 'none') +
        "'>" +
        "<span class='tname'>代理目录</span>" +
        "<div class='info-r  ml0'><input id='proxydir' name='proxydir' class='bt-input-text mr5' type='text' style='width:200px' value='" +
        obj.proxydir +
        "'>" +
        '</div>' +
        '</div>' +
        "<div class='line'>" +
        "<span class='tname'><span class=\"color-red mr5\">*</span>目标URL</span>" +
        "<div class='info-r  ml0'>" +
        "<input name='proxysite' class='bt-input-text mr10' type='text' style='width:200px' value='" +
        obj.proxysite +
        "'>" +
        "<span class='mlr15'><span class=\"color-red mr5\">*</span>发送域名</span><input name='todomain' class='bt-input-text ml10' type='text' style='width:200px' value='" +
        obj.todomain +
        "'>" +
        '</div>' +
        '</div>' +
        "<div class='line replace_conter' style='display:" +
        (bt.get_cookie('serverType') == 'nginx' ? 'block' : 'none') +
        "'>" +
        "<span class='tname'>内容替换</span>" +
        "<div class='info-r  ml0 '>" +
        sub_conter +
        '</div>' +
        '</div>' +
        "<div class='line' style='display:" +
        (bt.get_cookie('serverType') == 'nginx' ? 'block' : 'none') +
        "'>" +
        "<div class='info-r  ml0'>" +
        "<button class='btn btn-success btn-sm btn-title add-replace-prosy' type='button'><span class='glyphicon cursor glyphicon-plus  mr5' ></span>添加内容替换</button>" +
        '</div>' +
        '</div>' +
        "<ul class='help-info-text c7'>" +
        bt.render_help(helps) +
        '</form>',
      )
      $('.add-replace-prosy').click(function () {
        var length = $('.replace_conter .sub-groud').length;
        if (length == 2) $(this).attr('disabled', 'disabled');
        var conter =
          "<div class='sub-groud'>" +
          "<input name='rep" +
          (length * 2 + 1) +
          "' class='bt-input-text mr10' placeholder='被替换的文本,可留空' type='text' style='width:200px' value=''>" +
          "<input name='rep" +
          (length * 2 + 2) +
          "' class='bt-input-text ml10' placeholder='替换为,可留空' type='text' style='width:200px' value=''>" +
          "<a href='javascript:;' class='proxy_del_sub' style='color:red;'>删除</a>" +
          '</div>';
        $('.replace_conter .info-r').append(conter);
      });
      $('[name="proxysite"]').keyup(function () {
        var val = $(this).val(),
          ip_reg = /^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$/;
        val = val.replace(/^http[s]?:\/\//, '');
        // val = val.replace(/:([0-9]*)$/, '');
        val = val.replace(/(:|\?|\/|\\)(.*)$/, '');
        if (ip_reg.test(val)) {
          $("[name='todomain']").val('$host');
        } else {
          $("[name='todomain']").val(val);
        }
      });
      $('#openVpn').click(function () {
       $(this).prop('checked',true)
      })
      $('#openAdvanced').click(function () {
        if ($(this).prop('checked')) {
          $('.advanced').show();
        } else {
          $('.advanced').hide();
        }
      });
      $('#openNginx').click(function () {
        if ($(this).prop('checked')) {
          $('.cachetime').show();
        } else {
          $('.cachetime').hide();
        }
      });
      $('.replace_conter').on('click', '.proxy_del_sub', function () {
        $(this).parent().remove();
        $('.add-replace-prosy').removeAttr('disabled');
      });
    },
    yes: function (formData, indexs, layero) {
      if (formData.domains != '') {
        var arry = formData.domains.replace(/\n/g, '').split('\r'),
          newArry = [];
        for (var i = 0; i < arry.length; i++) {
          var item = arry[i];
          if (bt.check_domain_port(item)) {
            newArry.push(item.indexOf(':') > -1 ? item : item + ':80');
          } else {
            bt.msg({ status: false, msg: '【' + item + '】 绑定域名格式错误' });
            return false;
          }
        }
        formData.bind_extranet = 1;
        formData.domains = newArry;
      } else {
        bt.msg({ status: false, msg: '【绑定域名】 不能为空' });
        return
      }
      var cache = $(layero).find('[name="cache"]');
      if (cache.prop('checked')==true) {
        formData.cache = cache.prop('checked') ? 1 : 0;
        var cachetime = $(layero).find('[name="cachetime"]');
        if (cachetime.length > 0) {
          formData.cachetime = cachetime.val();
            var val =cachetime.val();
            if(!bt.isInteger(Number.parseInt(val))){
              bt.msg({ status: false, msg: '【缓存时间】 必须为整数' });
              $(this).val(1);
              return
            }
            if (val < 1) {
              $(this).val(1);
            }
        }else {
          bt.msg({ status: false, msg: '【缓存时间】 不能为空' });
          return
        }
      }else {
        formData.cache = 0;
      }
      var advanced = $(layero).find('[name="advanced"]');
      if (advanced.length > 0) {
        formData.advanced = advanced.prop('checked') ? 1 : 0;
      }
      var proxyname = $(layero).find('[name="proxyname"]');
      if (proxyname.val()!= '') {
        formData.proxyname = proxyname.val();
      }else {
        bt.msg({ status: false, msg: '【代理名称】 不能为空' });
        return
      }
      if(formData.proxyname.length<3){
        bt.msg({ status: false, msg: '【代理名称】 不能小于3位' });
        return
      }
      if(formData.proxyname.length>40){
        bt.msg({ status: false, msg: '【代理名称】 不能大于40位' });
        return
      }
      var proxysite = $(layero).find('[name="proxysite"]');
      if (proxysite.val() !='') {
        formData.proxysite = proxysite.val();
      }else {
        bt.msg({ status: false, msg: '【目标URL】 不能为空' });
        return
      }
      function isValidUrl(url) {
        var pattern = new RegExp('^(https?:\\/\\/)?'+ // protocol
          '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|'+ // domain name and extension
          '((\\d{1,3}\\.){3}\\d{1,3}))'+ // OR ip (v4) address
          '(\\:\\d+)?'+ // port
          '(\\/[-a-z\\d%@_.~+&:]*)*'+ // path
          '(\\?[;&a-z\\d%@_.,~+&:=-]*)?'+ // query string
          '(\\#[-a-z\\d_]*)?$','i'); // fragment locator
        return pattern.test(url);
      }
      if (!isValidUrl(formData.proxysite)) {
        bt.msg({ status: false, msg: '【目标URL】 格式错误' });
        return
      }


      var todomain = $(layero).find('[name="todomain"]');
      if (todomain.val() != '') {
        formData.todomain = todomain.val();
      }else {
        bt.msg({ status: false, msg: '【发送域名】 不能为空' });
        return
      }
      var proxydir = $(layero).find('[name="proxydir"]');
      var openAdvanced = $(layero).find('[name="openAdvanced"]');
      if(openAdvanced.prop('checked')==true){
        formData.advanced= 1;
        if (proxydir.length > 0) {
          formData.proxydir = proxydir.val();
        }else {
          bt.msg({ status: false, msg: '【代理目录】 不能为空' });
          return
        }
      }else {
        formData.advanced= 0;
        formData.proxydir= '/';
      }
      var form_proxy_data = {};
      $.each($('#form_proxy').serializeArray(), function () {
        if (form_proxy_data[this.name]) {
          if (!form_proxy_data[this.name].push) {
            form_proxy_data[this.name] = [form_proxy_data[this.name]];
          }
          form_proxy_data[this.name].push(this.value || '');
        } else {
          form_proxy_data[this.name] = this.value || '';
        }
      });
      form_proxy_data['type'] = form_proxy_data['type'] == undefined ? 0 : 1;
      form_proxy_data['cache'] = form_proxy_data['cache'] == undefined ? 0 : 1;
      form_proxy_data['advanced'] = form_proxy_data['advanced'] == undefined ? 0 : 1;
      form_proxy_data['subfilter'] = JSON.stringify([
        { sub1: form_proxy_data['rep1'] || '', sub2: form_proxy_data['rep2'] || '' },
        { sub1: form_proxy_data['rep3'] || '', sub2: form_proxy_data['rep4'] || '' },
        { sub1: form_proxy_data['rep5'] || '', sub2: form_proxy_data['rep6'] || '' },
      ]);
      for (var i in form_proxy_data) {
        if (i.indexOf('rep') != -1) {
          delete form_proxy_data[i];
        }
      }
      var domainList = $(layero).find('[name="domains"]').val().split('\n');
      formData.domains.shift()
      bt_tools.send({
        url:'/project/proxy/AddSite',
        data:{
          path:formData.path,
          port:domainList[0].split(':')[1] || 80,
          ps:formData.project_ps,
          webname:JSON.stringify({
            domain:domainList[0],
            domainlist:formData.domains,
            count:formData.domains.length,
          }),
        }
      },function (res){
        if(res!=null){
          bt_tools.send({
            url:'/project/proxy/CreateProxy',
            data:{
              type:1,
              proxyname:formData.proxyname,
              cachetime:formData.cachetime ||1,
              proxydir:formData.proxydir,
              cache:formData.cache,
              subfilter:form_proxy_data.subfilter,
              sitename:res.sitename,
              advanced:formData.advanced,
              proxysite:formData.proxysite,
              todomain:formData.todomain,
            }
          },function (rdata){
            layer.closeAll();
            bt.msg({status:rdata.status,msg:rdata.msg})
            callback && callback(rdata)

          })
        }
      })
    },
  });
};

/**
 * @description 模拟点击
 */
CreateWebsiteModel.prototype.simulatedClick = function (num) {
  $('.bt-w-menu p:eq(' + num + ')').click();
};

/**
 * @description
 * @param {string} name 站点名称
 */
CreateWebsiteModel.prototype.reanderProjectInfoView = function (row) {
  var that = this;
  var item = row;
  bt.open({
    type: 1,
    area: ['836px', '725px'],
    title: lan.site.website_change + '[' + item.name + ']  --  ' + lan.site.addtime + '[' + item.addtime + ']',
    closeBtn: 2,
    shift: 0,
    content:
      "<div class='bt-tabs'>\
        <div class='bt-w-menu proxy-menu pull-left' style='height: 100%;width: 126px;'></div>\
        <div id='webedit-con' class='bt-w-con webedit-con pd15' style='margin-left: 126px;'></div>\
      </div>",
  });
  setTimeout(function () {
    // var webcache = bt.get_cookie('serverType') == 'openlitespeed' ? { title: 'LS-Cache', callback: site.edit.ols_cache } : '';
    var menus = [
      { title: '域名管理', callback: site.edit.set_domains },

			{ title: '流量限制', callback: CreateWebsiteModel.prototype.limit_network },
      { title: '伪静态', callback: site.edit.get_rewrite_list },
      { title: '配置文件', callback: site.edit.set_config },
      { title: '防盗链', callback: site.edit.set_security },

      { title: '反向代理', callback: CreateWebsiteModel.prototype.set_proxy },
      { title: 'SSL', callback: site.set_ssl },
      { title: '重定向', callback: function(web){ that.reander_project_redirect(web,that)} },
      { title: 'IP限制', callback:function(web){ that.set_ip_limit(web,that)} },

      { title: '文件限制', callback: CreateWebsiteModel.prototype.set_file_limit },

      { title: '网站日志', callback: CreateWebsiteModel.prototype.get_site_logs },
    ];
    // if (webcache !== '') menus.splice(3, 0, webcache);
    for (var i = 0; i < menus.length; i++) {
      var men = menus[i];
      var _p = $('<p>' + men.title + '</p>');
      _p.data('callback', men.callback);
      $('.proxy-menu').append(_p);
    }
    $('.proxy-menu p').css('padding-left', '36px');
    $('.proxy-menu p').click(function () {
      $('#webedit-con').html('');
      $(this).addClass('bgw').siblings().removeClass('bgw');
      var callback = $(this).data('callback');
      if (callback) callback(item);
    });
    var _sel = $('.proxy-menu p.bgw');
    if (_sel.length == 0) _sel = $('.proxy-menu p').eq(0);
    _sel.trigger('click');
  }, 100);
};
/**
 * @description 获取日志
 */
CreateWebsiteModel.prototype.get_site_logs = function (web) {
  $('#webedit-con').append('<div id="tabLogs" class="tab-nav"></div><div class="tab-con" style="padding:10px 0px;"></div>');
  var _tab = [
    {
      title: '网站日志',
      on: true,
      callback: function (robj) {
        bt.site.get_site_logs(web.name, function (rdata) {
          var _logs_info = $('<div></div>').text(rdata.msg);
          var logs = { class: 'bt-logs site_log_hover', items: [{ name: 'site_logs', height: '590px', value: _logs_info.html(), width: '100%', type: 'textarea' }] },
            _form_data = bt.render_form_line(logs);
          robj.append(_form_data.html);
          bt.render_clicks(_form_data.clicks);
          $('textarea[name="site_logs"]').attr('readonly', true);
          $('textarea[name="site_logs"]').scrollTop(100000000000);
          $('textarea[name="site_logs"]').parent().css('position', 'relative');
          $('textarea[name="site_logs"]').parent().append(
            '<button class="hide full btn btn-sm btn-success"\
                         style="position:absolute;top:10px;right:10px">全屏展示</button>'
          );
          $('.site_log_hover')
            .unbind('hover')
            .hover(
              function (e) {
                $('.full').removeClass('hide');
                e.stopPropagation();
                e.preventDefault();
              },
              function (e) {
                $('.full').addClass('hide');
                e.stopPropagation();
                e.preventDefault();
              }
            );
          bt.site.fullScreenLog(_logs_info, web, '网站');
        },'proxy');
      },
    },
    {
      title: '错误日志',
      callback: function (robj) {
        bt.site.get_site_error_logs(web.name, function (rdata) {
          var _logs_info = $('<div></div>').text(rdata.msg);
          var logs = { class: 'bt-logs error_log_hover', items: [{ name: 'site_logs', height: '590px', value: _logs_info.html(), width: '100%', type: 'textarea' }] },
            _form_data = bt.render_form_line(logs);
          robj.append(_form_data.html);
          bt.render_clicks(_form_data.clicks);
          $('textarea[name="site_logs"]').attr('readonly', true);
          $('textarea[name="site_logs"]').scrollTop(100000000000);
          $('textarea[name="site_logs"]').parent().css('position', 'relative');
          $('textarea[name="site_logs"]').parent().append(
            '<button class="hide full btn btn-sm btn-success"\
            style="position:absolute;top:10px;right:10px">全屏展示</button>'
          );
          $('.error_log_hover')
            .unbind('hover')
            .hover(
              function (e) {
                $('.full').removeClass('hide');
                e.stopPropagation();
                e.preventDefault();
              },
              function (e) {
                $('.full').addClass('hide');
                e.stopPropagation();
                e.preventDefault();
              }
            );
          bt.site.fullScreenLog(_logs_info, web, '错误');
        },'proxy');
      },
    },
  ];
  bt.render_tab('tabLogs', _tab);
  $('#tabLogs span:eq(0)').click();
};
/**
 * @description 流量限制
 */
CreateWebsiteModel.prototype.limit_network = function (web) {
  $('#webedit-con').append('<div id="limit-network-box" class="tab-nav"></div><div class="tab-con" style="padding:10px 0px;"></div>');
			var _tab = [{
					title: '流量控制',
					callback: function (robj) {
						robj.removeClass('limit_network2');
						// $('#webedit-con').html('<div class="limit_network"></div><div class="limit_network2"></div>')
						bt.site.get_limitnet(web.id, function (rdata) {
							if (!rdata.limit_rate && !rdata.perip && !rdata.perserver) rdata.value = 1;
							var limits = [
								{ title: '论坛/博客', value: 1, items: { perserver: 300, perip: 25, limit_rate: 512 } },
								{ title: '图片站', value: 2, items: { perserver: 200, perip: 10, limit_rate: 1024 } },
								{ title: '下载站', value: 3, items: { perserver: 50, perip: 3, limit_rate: 2048 } },
								{ title: '商城', value: 4, items: { perserver: 500, perip: 10, limit_rate: 2048 } },
								{ title: '门户', value: 5, items: { perserver: 400, perip: 15, limit_rate: 1024 } },
								{ title: '企业', value: 6, items: { perserver: 60, perip: 10, limit_rate: 512 } },
								{ title: '视频', value: 7, items: { perserver: 150, perip: 4, limit_rate: 1024 } },
								{ title: '自定义', value: 0, items: { perserver: '', perip: '', limit_rate: '' } },
							];
							var datas = [
								{
									items: [
										{
											name: 'status',
											type: 'checkbox',
											value: rdata.perserver != 0 ? true : false,
											text: '启用流量控制',
											callback: function (ldata) {
												if (ldata.status) {
													if (!$('input[name=perip]').val() && !$('input[name=limit_rate]').val() && !$('input[name=perserver]').val()) {
														layer.msg('您的输入为空，请重新填写', { icon: 2 });
														$('#status').prop('checked', rdata.perserver != 0 ? true : false);
														return;
													}
													bt.site.set_limitnet(web.id, ldata.perserver, ldata.perip, ldata.limit_rate, function (ret) {
														layer.msg(ret.msg, { icon: ret.status ? 1 : 2 });
														if (ret.status) site.reload(4);
													});
												} else {
													bt.site.close_limitnet(web.id, function (ret) {
														layer.msg(ret.msg, { icon: ret.status ? 1 : 2 });
														if (ret.status) site.reload(4);
													});
												}
											},
										},
									],
								},
								{
									items: [
										{
											title: '限制方案  ',
											width: '200px',
											name: 'limit',
											type: 'select',
											value: rdata.value,
											items: limits,
											callback: function (obj) {
												var data = limits.filter(function (p) {
													return p.value === parseInt(obj.val());
												})[0];
												for (var key in data.items) {
													$('input[name="' + key + '"]').val(data.items[key]);
												}
											},
										},
									],
								},
								{
									items: [{ title: '并发限制   ', type: 'number', width: '200px', value: rdata.perserver, name: 'perserver', unit: '<span style="margin-left: 5px;">* 限制当前站点最大并发数</span>' }],
								},
								{ items: [{ title: '单IP限制   ', type: 'number', width: '200px', value: rdata.perip, name: 'perip', unit: '<span style="margin-left: 5px;">* 限制单个IP访问最大并发数</span>' }] },
								{
									items: [
										{
											title: '流量限制   ',
											type: 'number',
											width: '200px',
											value: rdata.limit_rate,
											name: 'limit_rate',
											unit: '<span style="margin-left: 5px;">* 限制每个请求的流量上限（单位：KB）</span>',
										},
									],
								},
								{
									name: 'btn_limit_get',
									text: rdata.perserver != 0 ? '保存' : '保存并启用',
									type: 'button',
									callback: function (ldata) {
										if (ldata.perserver <= 0 || ldata.perip <= 0 || ldata.limit_rate <= 0) {
											return layer.msg('并发限制，IP限制，流量限制必需大于0且不为空值！', { icon: 2 });
										}
										bt.site.set_limitnet(web.id, ldata.perserver, ldata.perip, ldata.limit_rate, function (ret) {
											layer.msg(ret.msg, { icon: ret.status ? 1 : 2 });
											if (ret.status) site.reload(4);
										});
									},
								},
							];
							var _html = $("<div class='webedit-box soft-man-con'></div>");
							var clicks = [];
							for (var i = 0; i < datas.length; i++) {
								var _form_data = bt.render_form_line(datas[i]);
								_html.append(_form_data.html);
								clicks = clicks.concat(_form_data.clicks);
							}
							_html.find('input[type="checkbox"]').parent().addClass('label-input-group ptb10');
							// _html.append(bt.render_help(['限制当前站点最大并发数', '限制单个IP访问最大并发数', '限制每个请求的流量上限（单位：KB）']));
							robj.append(_html);
							bt.render_clicks(clicks);
							if (rdata.perserver == 0) $("select[name='limit']").trigger('change');
							$('.soft-man-con').on('keyup', '.perserver, .perip, .limit_rate', function () {
								var val = $(this).val();
								if (val == '') return;
								// 判断不是正整数
								if (!/(^[1-9]\d*$)/.test(val)) {
									$(this).val(Math.floor(val));
								}
							});
							$('select[name=limit]').attr('autocomplete', 'off');

							var timer = 0;
							$('input[name=perip],input[name=perserver],input[name=limit_rate]').change(function () {
								clearTimeout(timer);
								timer = setTimeout(function () {
									var limit_perserver_val = $('input[name=perserver]').val();
									var limit_perip_val = $('input[name=perip]').val();
									var limit_rate_val = $('input[name=limit_rate]').val();
									for (var i = 0; i < limits.length; i++) {
										var limit_item = limits[i].items;
										var flag_1 = limit_perserver_val == limit_item.perserver && limit_perip_val == limit_item.perip && limit_rate_val == limit_item.limit_rate;
										$('select[name=limit]').children().prop('selected', false);
										if (flag_1) {
											$('select[name=limit]')
												.find('option[value=' + limits[i].value + ']')
												.prop('selected', true);
											break;
										} else {
											$('select[name=limit]').find('option[value=0]').prop('selected', true);
										}
									}
								}, 500);
							});
						});
					},
				},
				{
					title: '流量限额',
					active: true,
					callback: function (robj) {
						robj.addClass('limit_network2');
						robj.html(
							'<div class="current-box">\
						<div class="current-box-item">\
							<div>当前流量</div>\
							<div class="current-flow-num">-</div>\
						</div>\
						<div class="current-box-item">\
							<div>当前请求数</div>\
							<div class="current-request-num">-</div>\
						</div>\
						</div><div id="flow-config-table" class="mt20"></div>'
						);

						var ltd_end = bt.get_cookie('ltd_end') > 0;
						if (ltd_end) {
							bt.soft.get_soft_find('total', function (dataRes) {
								if (dataRes.setup && dataRes.endtime > 0) {
									check_total_install_info();
								} else {
									render_table([]);
									is_no_pay(true);
								}
							});
						} else {
							render_table([]);
							is_no_pay(false);
						}

						// 未购买未安装提示
						function is_no_pay(pay) {
							robj.prepend(
								'<div class="mask_layer php-pro-box">\
								<div class="sn-home--open-condition" style="margin-top: 20px;margin-left: 0;height:32px;line-height:32px">\
									<i class="sn-home--important-note1"></i>' +
									(pay ? '未安装网站监控报表' : '未开通，此功能为企业版专享功能') +
									'，<a href="javascript:;" class="btlink totalClick">点击' +
									(pay ? '安装' : '购买') +
									'</a>\
								</div>\
							</div>'
							);
							$('.limit_network2 .current-box').css('margin-top', '50px');
							$('.totalClick').click(function () {
								if (pay) {
									bt.soft.install('total');
								} else {
									product_recommend.pay_product_sign('ltd', 183, 'ltd');
								}
							});
						}
						// 检测监控报表版本、nginx版本
						function check_total_install_info() {
							bt_tools.send({ url: '/site?action=check_total_install_info' }, function (res) {
								if (res.total_status && res.nginx_status) {
									robj.prepend('<div class="alarm_tips mb20"><i></i>流量限额可设置多条规则，统计周期产生的流量/请求超过限额会告警</div>');
									$('.limit_network2 .current-box').removeAttr('style');
									get_limit_config(true);
								} else {
									render_table([]);
									robj.prepend(
										'<div class="mask_layer php-pro-box"><div class="alarm_tips mt20"><i></i>' +
											(res.total_status ? '' : '监控报表版本小于7.6.0 [<a data-name="total" class="btlink update_v">点击更新</a>]') +
											(!res.total_status && !res.nginx_status ? '、' : '') +
											(res.nginx_status ? '' : 'Nginx版本小于1.18 [<a data-name="nginx" class="btlink update_v">点击更新</a>]') +
											'，请更新后再使用该功能</div></div>'
									);
									$('.limit_network2 .current-box').css('margin-top', '50px');
									// 更新插件
									$('.update_v').click(function () {
										var name = $(this).data('name');
										bt.soft.get_soft_find(name, function (data_res) {
											if (data_res.versions.length > 1) {
												for (var j = 0; j < data_res.versions.length; j++) {
													var min_version = data_res.versions[j];
													var ret = bt.check_version(data_res.version, min_version.m_version + '.' + min_version.version);
													if (ret > 0) {
														if (ret == 2) {
															bt.soft.update_soft(data_res.name, data_res.title, min_version.m_version, min_version.version, min_version.update_msg.replace(/\n/g, '_bt_'), data_res.type);
														}
														break;
													}
												}
											} else {
												var min_version = data_res.versions[0],
													is_beta = min_version.beta;
												var cloud_version = min_version.m_version + '.' + min_version.version;
												if (data_res.version != cloud_version && is_beta == data_res.is_beta) {
													bt.soft.update_soft(data_res.name, data_res.title, min_version.m_version, min_version.version, min_version.update_msg.replace(/\n/g, '_bt_'), data_res.type);
												}
											}
										});
									});
								}
							});
						}
						// 获取流量限额规则
						function get_limit_config(load) {
							bt_tools.send({ url: '/site?action=get_limit_config', data: { site_name: web.name } }, function (res) {
								render_table(res);
								get_generated_flow_info();
							});
						}
						// 显示流量信息
						function get_generated_flow_info() {
							bt_tools.send({ url: '/site?action=get_generated_flow_info', data: { site_name: web.name } }, function (res) {
								$('.current-flow-num').html(bt.format_size(res.length));
								$('.current-request-num').html(res.request);
							});
						}
						// 渲染表格
						function render_table(data) {
							$('#flow-config-table').empty();
							bt_tools.table({
								el: '#flow-config-table',
								height: '450',
								data: data,
								column: [
									{
										fid: 'rule_type',
										title: '类型',
									},
									{
										fid: 'limit_value',
										title: '限额阈值',
										template: function (row) {
											return '<span>' + (row.limit_value.indexOf('frequency') !== -1 ? parseFloat(row.limit_value) + '次' : row.limit_value) + '</span>';
										},
									},
									{
										fid: 'time_period',
										title: '周期',
									},
									{
										fid: 'rule',
										title: '策略',
										fixed: true,
									},
									{
										fid: 'limit_status',
										title: '状态',
										type: 'switch',
										width: 40,
										event: function (row, index, ev, key, that) {
											var _status = row.limit_status;
											bt.simple_confirm(
												{
													title: (_status ? '停止' : '开启') + '选中配置',
													msg: _status ? '停止后，将不再接收该任务的告警通知，是否继续？' : '开启后，检测到问题时将会发送告警通知，是否继续？',
												},
												function () {
													bt_tools.send(
														{ url: '/site?action=set_limit_status', data: { site_name: web.name, id: row.id, limit_status: !row.limit_status } },
														function (rdata) {
															if (rdata.status) get_limit_config(true);
															bt_tools.msg(rdata);
														},
														(_status ? '停止' : '开启') + '限额规则'
													);
												},
												function () {
													$(ev.currentTarget).prop('checked', row.limit_status);
												}
											);
										},
									},
									{
										title: '操作',
										type: 'group',
										align: 'right',
										width: 100,
										group: [
											// {
											// 	title: '修改',
											// 	event: function (row, index, ev, key, that) {
											// 	}
											// },
											{
												title: '删除',
												event: function (row, index, ev, key, that) {
													bt_tools.send({ url: '/site?action=remove_flow_rule', data: { site_name: web.name, id: row.id } }, function (res) {
														bt_tools.msg(res);
														if (res.status) get_limit_config(true);
													});
												},
											},
										],
									},
								],
								methods: {
									edit_flow_rule: function (data) {
										var instant_cycle = [
												{ title: '10分钟', value: '10m' },
												{ title: '30分钟', value: '30m' },
											],
											total_cycle = [
												{ title: '1小时', value: '1h' },
												{ title: '1天', value: '1day' },
												{ title: '30天', value: '30day' },
												{ title: '自然月', value: 'month' },
											];
										bt_tools.open({
											title: '添加流量限额配置',
											area: '560px',
											btn: ['添加', '取消'],
											content: {
												class: 'pd20 add_flow_config',
												form: [
													{
														label: '限额',
														group: [
															{
																name: 'quota',
																type: 'select',
																width: '100px',
																list: [
																	{ title: '流量', value: 'flow' },
																	{ title: '请求数', value: 'request' },
																],
																change: function (formData, element, that) {
																	$('.form-radio:eq(0) input[name=rule_type]').click(); // 解决下拉后 radio第一次点击无效
																	if (formData.quota === 'request') {
																		that.config.form[0].group[2].display = false;
																		that.config.form[0].group[1].unit = '次数';
																	} else {
																		that.config.form[0].group[2].display = true;
																		that.config.form[0].group[1].unit = '';
																	}
																	that.config.form[0].group[0].value = formData.quota;
																	that.$replace_render_content(0);
																	that.config.form[3].group[2].label =
																		'<div class="mt4 c9">当访问【' +
																		(formData.quota === 'request' ? '请求次数' : '流量') +
																		'】超过限额阈值【' +
																		formData.threshold_percentage +
																		'%】时【' +
																		(formData.limit_action === 'alert' ? '告警' : '告警并停止网站') +
																		'】</div>';
																	that.$replace_render_content(3);
																	var time = that.config.form[2].group[0].list.filter(function (item) {
																		return item.value === formData.time_period;
																	})[0].title;
																	that.config.form[2].group[0].unit =
																		'<span class="c9">' +
																		(formData.rule_type === 'moment' ? '检测' + time + '内的' + (formData.quota === 'request' ? '' : '实时') : '检测' + time + '累计造成的') +
																		(formData.quota === 'request' ? '请求情况' : '流量') +
																		'</span>';
																	that.$replace_render_content(2);

																	that.config.form[1].group[0].list[0].title = formData.quota === 'request' ? '实时请求数' : '实时流量';
																	that.config.form[1].group[0].list[1].title = formData.quota === 'request' ? '累计请求数' : '累计流量';
																	that.config.form[1].group[0].unit =
																		'<div class="mt4 c9">当前网站运行' + (formData.rule_type === 'moment' ? '实时' : '累计') + (formData.quota === 'request' ? '请求数' : '流量') + '</div>';
																	that.$replace_render_content(1);
																},
															},
															{
																name: 'limit_value',
																type: 'number',
																min: 0,
																value: 100,
															},
															{
																class: 'hideBorder',
																name: 'limit_unit',
																type: 'select',
																list: [
																	{ title: 'MB', value: 'MB' },
																	{ title: 'GB', value: 'GB' },
																],
																change: function (formData, element, that) {
																	$('.form-radio:eq(0) input[name=rule_type]').click(); // 解决下拉后 radio第一次点击无效
																},
															},
														],
													},
													{
														label: '类型',
														class: 'mb5',
														group: [
															{
																name: 'rule_type',
																type: 'radio',
																value: 'moment',
																list: [
																	{ title: '实时流量', value: 'moment' },
																	{ title: '累计流量', value: 'total' },
																],
																unit: '<div class="mt4 c9">当前网站运行实时流量</div>',
																event: function (formData, element, that) {
																	if (formData.rule_type === 'moment') {
																		that.config.form[2].group[0].list = instant_cycle;
																		that.config.form[2].group[0].value = instant_cycle.filter(function (item) {
																			return item.value === formData.rule_type;
																		}).length
																			? formData.rule_type
																			: instant_cycle[0].value;
																	} else {
																		that.config.form[2].group[0].list = total_cycle;
																		that.config.form[2].group[0].value = total_cycle.filter(function (item) {
																			return item.value === formData.rule_type;
																		}).length
																			? formData.rule_type
																			: total_cycle[0].value;
																	}
																	var time = that.config.form[2].group[0].list.filter(function (item) {
																		return item.value === that.config.form[2].group[0].value;
																	})[0].title;
																	that.config.form[2].group[0].unit =
																		'<span class="c9">' +
																		(formData.rule_type === 'moment' ? '检测' + time + '内的' + (formData.quota === 'request' ? '' : '实时') : '检测' + time + '累计造成的') +
																		(formData.quota === 'request' ? '请求情况' : '流量') +
																		'</span>';
																	that.$replace_render_content(2);

																	that.config.form[1].group[0].value = formData.rule_type;
																	that.config.form[1].group[0].unit =
																		'<div class="mt4 c9">当前网站运行' + (formData.rule_type === 'moment' ? '实时' : '累计') + (formData.quota === 'request' ? '请求数' : '流量') + '</div>';
																	that.$replace_render_content(1);
																},
															},
														],
													},
													{
														label: '周期',
														group: [
															{
																name: 'time_period',
																type: 'select',
																width: '100px',
																list: instant_cycle,
																unit: '<span class="c9">检测10分钟内的实时流量</span>',
																change: function (formData, element, that) {
																	$('.form-radio:eq(0) input[name=rule_type]').click(); // 解决下拉后 radio第一次点击无效
																	that.config.form[2].group[0].value = formData.time_period;
																	var time = that.config.form[2].group[0].list.filter(function (item) {
																		return item.value === formData.time_period;
																	})[0].title;
																	that.config.form[2].group[0].unit =
																		'<span class="c9">' +
																		(formData.rule_type === 'moment' ? '检测' + time + '内的' + (formData.quota === 'request' ? '' : '实时') : '检测' + time + '累计造成的') +
																		(formData.quota === 'request' ? '请求情况' : '流量') +
																		'</span>';
																	that.$replace_render_content(2);
																},
															},
														],
													},
													{
														label: '策略',
														class: 'mb5',
														group: [
															{
																class: 'group groupUnit',
																name: 'threshold_percentage',
																type: 'number',
																min: 10,
																max: 100,
																value: 60,
																unit: '%',
																input: function (formData, element, that) {
																	that.config.form[3].group[2].label =
																		'<div class="mt4 c9">当访问【' +
																		(formData.quota === 'request' ? '请求次数' : '流量') +
																		'】超过限额阈值【' +
																		formData.threshold_percentage +
																		'%】时【' +
																		(formData.limit_action === 'alert' ? '告警' : '告警并停止网站') +
																		'】</div>';
																	that.config.form[3].group[0].value = formData.threshold_percentage;
																	that.$replace_render_content(3);
																},
															},
															{
																name: 'limit_action',
																type: 'select',
																class: 'ml10',
																width: '145px',
																list: [
																	{ title: '告警', value: 'alert' },
																	{ title: '告警并停止网站', value: 'alert_stop' },
																],
																change: function (formData, element, that) {
																	$('.form-radio:eq(0) input[name=rule_type]').click(); // 解决下拉后 radio第一次点击无效
																	that.config.form[3].group[2].value = formData.limit_action;
																	that.config.form[3].group[2].label =
																		'<div class="mt4 c9">当访问【' +
																		(formData.quota === 'request' ? '请求次数' : '流量') +
																		'】超过限额阈值【' +
																		formData.threshold_percentage +
																		'%】时【' +
																		(formData.limit_action === 'alert' ? '告警' : '告警并停止网站') +
																		'】</div>';
																	that.$replace_render_content(3);
																},
															},
															{
																label: '<div class="mt4 c9">当访问【流量】超过限额阈值【60%】时【告警】</div>',
															},
														],
													},
													{
														label: '发送次数',
														group: [
															{
																type: 'number',
																name: 'cycle',
																class: 'group groupUnit',
																unit: '次',
																width: '58px',
																min: 0,
																value: 3,
															},
															{
																label: '<span class="ml10 c9">后将不再发送告警信息，如需发送多次请填写2次以上</span>',
															},
														],
													},
													{
														label: '告警方式',
														group: [
															{
																type: 'other',
																boxcontent: '<div class="installPush"></div>',
															},
														],
													},
													{
														group: [
															{
																type: 'help',
																list: ['点击配置告警方式后状态未更新，尝试点击【<a class="btlink handRefresh">手动刷新</a>】'],
															},
														],
													},
												],
											},
											success: function (layero) {
												$(layero).find('.layui-layer-content').css('overflow', 'inherit');
												$(layero).find('.bt-form').prepend('<div class="alarm_tips mb10"><i></i>通过设置流量限额，可以限制在特定时间段内允许网络传输的数据量</div>');
												renderConfigHTML();
												// 手动刷新
												$('.handRefresh').click(function () {
													renderConfigHTML();
												});
												// 获取配置
												function renderConfigHTML() {
													bt.site.get_msg_configs(function (rdata) {
														var html = '',
															unInstall = '';
														for (var key in rdata) {
															var item = rdata[key],
																_html = '',
																accountConfigStatus = false;
															if (key == 'sms') continue;
															if (key === 'wx_account') {
																if (!$.isEmptyObject(item.data) && item.data.res.is_subscribe && item.data.res.is_bound) {
																	accountConfigStatus = true; //安装微信公众号模块且绑定
																}
															}
															_html =
																'<div class="inlineBlock module-check ' +
																(!item.setup || $.isEmptyObject(item.data) ? 'check_disabled' : key == 'wx_account' && !accountConfigStatus ? 'check_disabled' : '') +
																'">' +
																'<div class="cursor-pointer form-checkbox-label mr10">' +
																'<i class="form-checkbox cust—checkbox cursor-pointer mr5 ' +
																(!$.isEmptyObject(data) && data.module && data.module.indexOf(item.name) > -1
																	? !item.setup || $.isEmptyObject(item.data)
																		? ''
																		: key == 'wx_account' && !accountConfigStatus
																		? ''
																		: 'active'
																	: '') +
																'" data-type="' +
																item.name +
																'"></i>' +
																'<input type="checkbox" class="form—checkbox-input hide mr10" name="' +
																item.name +
																'" ' +
																(item.setup || !$.isEmptyObject(item.data) ? (key == 'wx_account' && !accountConfigStatus ? '' : 'checked') : '') +
																'/>' +
																'<span class="vertical_middle" title="' +
																item.ps +
																'">' +
																item.title +
																(!item.setup || $.isEmptyObject(item.data)
																	? '[<a target="_blank" class="bterror installNotice" data-type="' + item.name + '">未配置</a>]'
																	: key == 'wx_account' && !accountConfigStatus
																	? '[<a target="_blank" class="bterror installNotice" data-type="' + item.name + '">未配置</a>]'
																	: '') +
																'</span>' +
																'</div>' +
																'</div>';
															if (!item.setup || $.isEmptyObject(item.data)) {
																unInstall += _html;
															} else {
																html += _html;
															}
														}
														$('.installPush').html(html + unInstall);
														if (!$('.installPush .active').length && html != '') {
															$('.installPush .module-check:eq(0) input').prop('checked', true).prev().addClass('active');
														}
													});
												}
												// 安装消息通道
												$('.installPush').on('click', '.form-checkbox-label', function () {
													var that = $(this).find('i');
													if (!that.parent().parent().hasClass('check_disabled')) {
														if (that.hasClass('active')) {
															that.removeClass('active');
															that.next().prop('checked', false);
														} else {
															that.addClass('active');
															that.next().prop('checked', true);
														}
													}
												});

												$('.installPush').on('click', '.installNotice', function () {
													var type = $(this).data('type');
													openAlertModuleInstallView(type);
												});
												//限额
												$('[name=limit_value]').on('input', function () {
													var val = $(this).val();
													layer.closeAll('tips');
													if (val <= 0 || val === '') {
														layer.tips('限额' + ($('select[name=quota]').val() === 'flow' ? '流量' : '请求数') + '必须大于0', $(this), { tips: [1, '#ff0000'], time: 3000 });
													}
												});
												$('[name=cycle]').on('input', function () {
													var val = $(this).val();
													layer.closeAll('tips');
													if (val === '' || val < 0) layer.tips('数值不能小于0', $(this), { tips: [1, '#ff0000'], time: 2000 });
												});
											},
											yes: function (form, indexs) {
												var arry = [];
												$('.installPush .active').each(function (item) {
													var item = $(this).attr('data-type');
													arry.push(item);
												});
												if (!arry.length) return layer.msg('请选择至少一种告警通知方式', { icon: 2 });
												var param = {
													site_name: web.name,
													time_period: form.time_period,
													rule_type: form.rule_type,
													limit_unit: form.quota === 'flow' ? form.limit_unit : 'frequency',
													limit_value: form.limit_value,
													threshold_percentage: form.threshold_percentage,
													limit_action: form.limit_action,
													module: arry.join(','),
													cycle: form.cycle,
												};
												if (param.cycle === '' || param.cycle <= -1) return layer.msg('发送次数不能小于0', { icon: 2 });
												if (param.limit_value <= 0 || param.limit_value === '') return layer.msg('限额' + (form.quota === 'flow' ? '流量' : '请求数') + '必须大于0', { icon: 2, time: 2000 });
												bt_tools.send({ url: '/site?action=create_flow_rule', data: param }, function (res) {
													bt_tools.msg(res);
													if (res.status) layer.close(indexs);
													get_limit_config(true);
												});
											},
										});
									},
								},
								tootls: [
									{
										type: 'group',
										positon: ['left', 'top'],
										list: [
											{
												title: '添加流量限额配置',
												active: true,
												class: 'btn-secondary-success',
												event: function (ev, that) {
													that.edit_flow_rule();
												},
											},
										],
									},
								],
							});
						}
					},
				},
							];
			bt.render_tab('limit-network-box', _tab);
			$('#limit-network-box span:eq(0)').click();
};
/**
 * @description 获取站点反向代理列表
 * @param web
 */
CreateWebsiteModel.prototype.set_proxy =  function (web) {
  $('#webedit-con').html('<div id="proxy_list" class="bt_table"></div>');
  String.prototype.myReplace = function (f, e) {
    //吧f替换成e
    var reg = new RegExp(f, 'g'); //创建正则RegExp对象
    return this.replace(reg, e);
  };
  var proxy_list_table = bt_tools.table({
    el: '#proxy_list',
    url: '/project/proxy/GetProxyList',
    param: { sitename: web.name },
    dataFilter: function (res) {
      return { data: res };
    },
    column: [
      { type: 'checkbox', width: 20 },
      { fid: 'proxyname', title: '名称', type: 'text' },
      { fid: 'proxydir', title: '代理目录', type: 'text' },
      {
        fid: 'proxysite',
        title: '目标url',
        type: 'link',
        href: true,
        template: function (row) {
          return '<span style="width: 160px;" class="fixed"><a class="btlink" href="' + row.proxysite + '" target="_blank" title="' + row.proxysite + '">' + row.proxysite + '</a></span>';
        },
      },
      bt.get_cookie('serverType') == 'nginx'
        ? {
          fid: 'cache',
          title: '缓存',
          config: {
            icon: false,
            list: [
              [1, '已开启', 'bt_success'],
              [0, '已关闭', 'bt_danger'],
            ],
          },
          type: 'status',
          event: function (row, index, ev, key, that) {
            row['cache'] = !row['cache'] ? 1 : 0;
            row['subfilter'] = JSON.stringify(row['subfilter']).replace(/[\\]/g, '').replace('"[', '[').replace(']"', ']');
            bt.site.modify_proxy(row, function (rdata) {
              if (rdata.status) {
                var _sel = $('.proxy-menu p.bgw');
                if (_sel.length == 0) _sel = $('.proxy-menu p').eq(1);
                _sel.trigger('click');
              }
              bt.msg(rdata);
            },'proxy');
          },
        }
        : {},
      {
        fid: 'type',
        title: '状态',
        config: {
          icon: true,
          list: [
            [1, '运行中', 'bt_success', 'glyphicon-play'],
            [0, '已暂停', 'bt_danger', 'glyphicon-pause'],
          ],
        },
        type: 'status',
        event: function (row, index, ev, key, that) {
          row['type'] = !row['type'] ? 1 : 0;
          row['subfilter'] = JSON.stringify(row['subfilter']).replace(/[\\]/g, '').replace('"[', '[').replace(']"', ']');
          bt.site.modify_proxy(row, function (rdata) {
            if (rdata.status) {
              var _sel = $('.proxy-menu p.bgw');
              if (_sel.length == 0) _sel = $('.proxy-menu p').eq(1);
              _sel.trigger('click');
            }
            bt.msg(rdata);
          },'proxy');
        },
      },
      {
        title: '操作',
        width: 150,
        type: 'group',
        align: 'right',
        group: [
          {
            title: '配置文件',
            event: function (row, index, ev, key, that) {
              var type = '';
              try {
                type = bt.get_cookie('serverType') || serverType;
              } catch (err) {}
              bt.site.get_proxy_config(
                {
                  sitename: web.name,
                  proxyname: row.proxyname,
                  webserver: type,
                },
                function (rdata) {
                  if ($.isPlainObject(rdata) && !rdata.status) {
                    bt_tools.msg(rdata);
                    return;
                  }
                  if (Array.isArray(rdata) && !rdata[0].status) {
                    bt_tools.msg(rdata[0]);
                    return;
                  }
                  // if (typeof rdata == 'object' && rdata.constructor == Array) {
                  //   if (!rdata[0].status) bt.msg(rdata)
                  // } else {
                  //   if (!rdata.status) bt.msg(rdata)
                  // }
                  bt.open({
                    type: 1,
                    area: ['550px', '550px'],
                    title: '编辑配置文件[' + row.proxyname + ']',
                    closeBtn: 2,
                    shift: 0,
                    content:
                      "<div class='bt-form pd15'>" +
                      '<p style="color: #666; margin-bottom: 7px">提示：Ctrl+F 搜索关键字，Ctrl+S 保存，Ctrl+H 查找替换</p>' +
                      '<div id="redirect_config_con" class="bt-input-text ace_config_editor_scroll" style="height:350px;line-height: 18px;"></div>' +
                      '<button id="OnlineEditFileBtn" class="btn btn-success btn-sm" style="margin-top:10px;">保存</button>' +
                      '<ul class="help-info-text c7"><li>此处为该负载均衡的配置文件，若您不了解配置规则,请勿随意修改。</li></ul>' +
                      '</div>',
                    success: function (layers, indexs) {
                      var editor = bt.aceEditor({
                        el: 'redirect_config_con',
                        content: rdata[0].data,
                        mode: 'nginx',
                        saveCallback: function (val) {
                          bt.site.save_redirect_config({ path: rdata[1], data: val, encoding: rdata[0].encoding }, function (ret) {
                            if (ret.status) {
                              site.reload(11);
                              layer.close(indexs);
                            }
                            bt.msg(ret);
                          });
                        },
                      });
                      $('#OnlineEditFileBtn').click(function () {
                        bt.saveEditor(editor);
                      });
                    },
                  });
                }
              );
            },
          },
          {
            title: '编辑',
            event: function (row, index, ev, key, that) {
              row['subfilter'] = JSON.stringify(row['subfilter']).replace(/[\\]/g, '').replace('"[', '[').replace(']"', ']');
              site.edit.templet_proxy(web.name, false, row,'proxy');
            },
          },
          {
            title: '删除',
            event: function (row, index, ev, key, that) {
              bt.site.remove_proxy(web.name, row.proxyname, function (rdata) {
                if (rdata.status) that.$delete_table_row(index);
              },'proxy');
            },
          },
        ],
      },
    ],
    tootls: [
      {
        //按钮组
        type: 'group',
        positon: ['left', 'top'],
        list: [
          {
            title: '添加反向代理',
            active: true,
            event: function (ev) {
              site.edit.templet_proxy(web.name, true, null,'proxy');
            },
          },
        ],
      },
      {
        //批量操作
        type: 'batch',
        positon: ['left', 'bottom'],
        placeholder: '请选择批量操作',
        buttonValue: '批量操作',
        disabledSelectValue: '请选择需要批量操作的任务!',
        selectList: [
          {
            title: '启用反向代理规则',
            url: '/project/proxy/ModifyProxy',
            param: function (row) {
              row.type = 1;
              row['subfilter'] = JSON.stringify(row['subfilter']).replace(/[\\]/g, '').replace('"[', '[').replace(']"', ']');
              return row;
            },
            callback: function (that) {
              // 手动执行,data参数包含所有选中的站点
              bt.simple_confirm({ title: '批量启用反向代理规则', msg: '批量启用当前选中的规则后，配置的反向代理规则将继续生效，是否继续操作？' }, function () {
                var param = {};
                that.start_batch(param, function (list) {
                  var html = '';
                  for (var i = 0; i < list.length; i++) {
                    var item = list[i];
                    html +=
                      '<tr><td>' +
                      item.proxyname +
                      '</td><td><div style="float:right;"><span style="color:' +
                      (item.request.status ? '#20a53a' : 'red') +
                      '">' +
                      item.request.msg +
                      '</span></div></td></tr>';
                  }
                  proxy_list_table.$batch_success_table({
                    title: '批量启用反向代理规则',
                    th: '反向代理名称',
                    html: html,
                  });
                  proxy_list_table.$refresh_table_list(true);
                });
              });
            },
          },
          {
            title: '停用反向代理规则',
            url: '/project/proxy/ModifyProxy',
            param: function (row) {
              row.type = 0;
              row['subfilter'] = JSON.stringify(row['subfilter']).replace(/[\\]/g, '').replace('"[', '[').replace(']"', ']');
              return row;
            },
            callback: function (that) {
              // 手动执行,data参数包含所有选中的站点
              bt.simple_confirm({ title: '批量停用反向代理规则', msg: '批量停用当前选中的规则后，配置的反向代理规则将会失效，是否继续操作？' }, function (index) {
                layer.close(index);
                var param = {};
                that.start_batch(param, function (list) {
                  var html = '';
                  for (var i = 0; i < list.length; i++) {
                    var item = list[i];
                    html +=
                      '<tr><td>' +
                      item.proxyname +
                      '</td><td><div style="float:right;"><span style="color:' +
                      (item.request.status ? '#20a53a' : 'red') +
                      '">' +
                      item.request.msg +
                      '</span></div></td></tr>';
                  }
                  proxy_list_table.$batch_success_table({
                    title: '批量停用反向代理规则',
                    th: '反向代理名称',
                    html: html,
                  });
                  proxy_list_table.$refresh_table_list(true);
                });
              });
            },
          },
          {
            title: '删除反向代理规则',
            url: '/project/proxy/RemoveProxy',
            param: { sitename: web.name, proxyname: web.proxyname },
            paramId: 'proxyname',
            paramName: 'proxyname',
            theadName: '反向代理名称',
            confirmVerify: false, // 是否提示验证方式
            refresh: true,
            callback: function (that) {
              // 手动执行,data参数包含所有选中的站点
              bt.simple_confirm({ title: '批量删除反向代理规则', msg: '批量删除当前选中的规则后，配置的反向代理规则将会彻底失效，是否继续操作？' }, function () {
                var param = {};
                that.start_batch(param, function (list) {
                  var html = '';
                  for (var i = 0; i < list.length; i++) {
                    var item = list[i];
                    html +=
                      '<tr><td>' +
                      item.proxyname +
                      '</td><td><div style="float:right;"><span style="color:' +
                      (item.request.status ? '#20a53a' : 'red') +
                      '">' +
                      item.request.msg +
                      '</span></div></td></tr>';
                  }
                  proxy_list_table.$batch_success_table({
                    title: '批量删除反向代理规则',
                    th: '反向代理名称',
                    html: html,
                  });
                  proxy_list_table.$refresh_table_list(true);
                });
              });
            },
          },
        ],
      },
    ],
    success: function () {
      $('#proxy_list .help-info-text').remove();
      $('#proxy_list').append(bt.render_help(['设置了反向代理后，【访问限制】中的相应路径的规则将会失效']));
    },
  });
};
/**
 * @description ip限制
 */
CreateWebsiteModel.prototype.set_ip_limit = function (web,_that) {
	// var _that = this;
  var isInit = true;
  $('#webedit-con').html('<div id="ip-mode-select"></div><div id="tabIpLimit"></div>');

  // var _tab = [
  //   {
  //     title: '白名单',
  //     on: true,
  //     callback: function (robj) {
  //       robj.html('<div id="proxy-ip-list"></div>');
  //       getProxyIpList(0);
  //     }
  //   },{
  //     title:'黑名单',
  //     callback:function(robj){
  //       robj.html('<div id="proxy-ip-list"></div>');
  //       getProxyIpList(1);
  //     }
  //   }]
  // 渲染反向代理ip黑白名单列表
  function renderProxyIpInfo(ipList){
    var activeOption = [
      {arr:'white_list',addApi:'add_white_ip_restrict',delApi:'remove_white_ip_restrict'},
      {arr:'black_list',addApi:'add_black_ip_restrict',delApi:'remove_black_ip_restrict'},
    ]
		var type = $('select[name=restrict_type]').val() == 'white' ? 0 : 1
		if($('select[name=restrict_type]').val() == undefined){
			type = 0
		}
    bt_tools.table({
      el: '#tabIpLimit',
      data: ipList[activeOption[type].arr],
      cancelRefresh:true,
			height: '500',
      column: [
        { title: 'IP', type: 'text',template:function(row){
            return '<span title="'+row+'">'+row+'</span>'
          }},
        {
          title: '操作',
          width: 100,
          type: 'group',
          align: 'right',
          group: [
            {
              title: '删除',
              event: function (row, index, ev, key, that) {
                bt_tools.send({url:'/project/'+ _that.type +'/'+activeOption[type].delApi,data:{site_name:web.name,value:row}},function(res){
                  bt_tools.msg(res);
                  if(res.status) getProxyIpList(type);
                },'删除IP')
              },
            },
          ],
        },
      ],
      tootls: [
        { // 按钮组
          type: 'group',
          positon: ['left', 'top'],
          list: [{
            title: '添加',
            active: true,
            event: function (ev, that) {
              var _ip = $('input[name=ip_address]').val()
              if(_ip == '') return layer.msg('请输入ip', {icon:2})
              bt_tools.send({url:'/project/'+ _that.type +'/'+activeOption[type].addApi,data:{site_name:web.name,value:_ip}}, function (rdata) {
                bt_tools.msg(rdata);
                if (rdata.status) {
                  $('input[name=ip_address]').val('')
                  if(rdata.status) getProxyIpList(type);
                }
              },'添加IP')
            }
          }]
        }
      ],
      success: function () {
        if($('input[name=ip_address]').length == 0){
          $('#tabIpLimit .tootls_top .pull-left .btn').before('<input type="text" name="ip_address" placeholder="支持IP和IP段【例：192.168.1.11/24】" class="bt-input-text mr10 " value="" style="width: 260px;">')
          $('#tabIpLimit').append(bt.render_help(['非IP内容的填写可能会导致Nginx无法启动']));
        }
      }
    });
		$('#tabIpLimit').show()
  }
  // 获取反向代理ip黑白名单列表
  function getProxyIpList(){
    bt_tools.send({url:'/project/'+ _that.type +'/get_ip_restrict',data:{site_name:web.name}},function(res){
      if($.isEmptyObject(res)) res = {white_list:[],black_list:[]}
      if(!res.hasOwnProperty('white_list')) res.white_list = []
      if(!res.hasOwnProperty('black_list')) res.black_list = []
			if(res.restrict_type == 'closed'){
				$('#tabIpLimit').hide()
			}else{
				renderProxyIpInfo(res)
			}
      if(isInit){
        isInit = false;
        renderProxyMode(res.restrict_type)
      }
    })
  }
	getProxyIpList()
  // bt.render_tab('tabIpLimit', _tab);
  // $('#tabIpLimit span:eq(0)').click();

  function renderProxyMode(val){
    bt_tools.form({
      el: '#ip-mode-select',
      class:'mb15',
      form: [{
        label: '访问控制模式',
        group: {
          type: 'select',
          name: 'restrict_type',
          width: '110px',
          value: val,
          list: [
            { title: '白名单', value: 'white' },
            { title: '黑名单', value: 'black' },
            { title: '关闭', value: 'closed' },
          ],
					unit:'仅支持同时生效一种模式。黑名单或白名单',
          placeholder: '请选择限制类型',
          change: function (formData) {
            bt_tools.send({url:'/project/'+ _that.type +'/set_ip_restrict',data:{site_name:web.name,set_type:formData.restrict_type}},function(res){
              bt_tools.msg(res);
							getProxyIpList()
            })
          }
        }
      }
      ]
    })
  }
};
 /**
         * @description 项目重定向
         */
 CreateWebsiteModel.prototype.reander_project_redirect = function (row,_that) {
	var el = $('#webedit-con');
	el.empty();
	// if (row.project_config.bind_extranet === 0) {
	// 		$('.mask_module').removeClass('hide').find('.node_mask_module_text:eq(1)').hide().prev().show();
	// 		return false;
	// }
	el.html(
			'<div>\
			<div id="website_redirect"></div>\
			<ul class="help-info-text c7">\
					<li>设置域名重定向后，该域名的404重定向将失效</li>\
			</ul>\
	</div>'
	);
	site.edit.redirect_table = bt_tools.table({
			el: '#website_redirect',
			url: '/project/'+ _that.type +'/get_project_redirect_list',
			param: { sitename: row.name },
			height: 500,
			dataFilter: function (res) {
					$.each(res, function (i, item) {
							if (!item.hasOwnProperty('errorpage')) {
									item.errorpage = 0;
							}
					});
					return { data: res };
			},
			column: [
					// { type: 'checkbox', width: 20 },
					{
							fid: 'sitename',
							title: '被重定向',
							type: 'text',
							width: 120,
							template: function (row, index) {
									var conter = '空';
									if (row.domainorpath == 'path' && row.errorpage !== 1) {
											conter = row.redirectpath || '空';
									} else {
											conter = row.redirectdomain ? row.redirectdomain.join('、') : '空';
									}
									return '<span style="width:100px;" title="' + conter + '">' + conter + '</span>';
							},
					},
					{
							fid: 'method',
							title: '重定向类型',
							type: 'text',
							width: 90,
							template: function (row, index) {
									var str = '';
									if (row.errorpage == 1) {
											str = '错误';
									} else if (row.domainorpath == 'path') {
											str = '路径';
									} else if (row.domainorpath == 'domain') {
											str = '域名';
									}
									return '<span>' + str + '</span>';
							},
					},
					{
							fid: 'path',
							title: '重定向到',
							type: 'text',
							template: function (row, index) {
									var path = row.tourl ? row.tourl : row.topath;
									return (
											'<span title="' +
											path +
											'" style="display: flex;">\
											<span class="size_ellipsis" style="flex: 1; width: 0;">' +
											(row.topath && path == '/' ? '首页' : path) +
											'</span>\
									</span>'
									);
							},
					},
					{
							fid: 'type',
							title: '状态',
							width: 70,
							config: {
									icon: true,
									list: [
											[1, '运行中', 'bt_success', 'glyphicon-play'],
											[0, '已停止', 'bt_danger', 'glyphicon-pause'],
									],
							},
							type: 'status',
							event: function (row, index, ev, key, that) {
									row.type = !row.type ? 1 : 0;
									row.redirectdomain = JSON.stringify(row['redirectdomain']);

									modify_node_refirect(row, function (res) {
											row.redirectdomain = JSON.parse(row['redirectdomain']);
											that.$modify_row_data({ status: row.type });
											bt.msg(res);
									});
							},
					},
					{
							title: '操作',
							width: 150,
							type: 'group',
							align: 'right',
							group: [
									{
											title: '配置文件',
											event: function (row, index, ev, key, that) {
													if(row.type == 0){
															return layer.msg('重定向已暂停',{icon:2})
													}
													var type = '';
													try {
															type = bt.get_cookie('serverType') || serverType;
													} catch (err) {}
													bt.open({
															type: 1,
															area: ['550px', '550px'],
															title: '编辑配置文件[' + row.redirectname + ']',
															closeBtn: 2,
															shift: 0,
															content:
																	'\
													<div class="bt-form pd15">\
															<p style="color: #666; margin-bottom: 7px">提示：Ctrl+F 搜索关键字，Ctrl+S 保存，Ctrl+H 查找替换</p>\
															<div id="redirect_config_con" class="bt-input-text ace_config_editor_scroll" style="height: 350px; line-height: 18px;"></div>\
															<button id="OnlineEditFileBtn" class="btn btn-success btn-sm" style="margin-top:10px;">保存</button>\
															<ul class="help-info-text c7">\
																	<li>此处为该负载均衡的配置文件，若您不了解配置规则,请勿随意修改。</li>\
															</ul>\
													"</div>',
															success: function (layers, indexs) {
																	bt_tools.send(
																			{ url: '/files?action=GetFileBody', data: { path: row.redirect_conf_file } },function (res) {
																					var editor = bt.aceEditor({
																							el: 'redirect_config_con',
																							content: res.data,
																							mode: 'nginx',
                                              path: row.redirect_conf_file,
																							// saveCallback: function (val) {
																							// 	bt.site.save_redirect_config({ path: rdata[1], data: val, encoding: rdata[0].encoding }, function (ret) {
																							// 		if (ret.status) {
																							// 			site.reload(11);
																							// 			layer.close(indexs);
																							// 		}
																							// 		bt.msg(ret);
																							// 	});
																							// },
																					});
																					$('#OnlineEditFileBtn').click(function () {
																							bt.saveEditor(editor);
																					});
																			})
															},
													});
											},
									},
									{
											title: '编辑',
											event: function (crow, index, ev, key, that) {
													node_refirect_301(row.name, row.id, crow);
											},
									},
									{
											title: '删除',
											event: function (row, index, ev, key, that) {
													bt_tools.send({url:'/project/'+ _that.type +'/remove_project_redirect',data:{sitename:row.sitename,redirectname:row.redirectname}},function(rdata){
															bt.msg(rdata);
															if (rdata.status) that.$delete_table_row(index);
													});
											},
									},
							],
					},
			],
			tootls: [
					{
							// 按钮组
							type: 'group',
							positon: ['left', 'top'],
							list: [
									{
											title: '添加重定向',
											active: true,
											event: function (ev) {
													node_refirect_301(row.name, row.id);
											},
									}
							],
					},
					// {
					// 	//批量操作
					// 	type: 'batch',
					// 	positon: ['left', 'bottom'],
					// 	placeholder: '请选择批量操作',
					// 	buttonValue: '批量操作',
					// 	disabledSelectValue: '请选择需要批量操作的任务!',
					// 	selectList: [
					// 		{
					// 			title: '启用重定向规则',
					// 			url: '/site?action=ModifyRedirect',
					// 			param: function (row) {
					// 				row.type = 1;
					// 				row.redirectdomain = JSON.stringify(row['redirectdomain']);
					// 				return row;
					// 			},
					// 			callback: function (that) {
					// 				bt.simple_confirm({ title: '批量启用重定向规则', msg: '批量启用当前选中的规则后，配置的重定向域名/目录将重新指向目标地址，是否继续操作？' }, function (index) {
					// 					layer.close(index);
					// 					var param = {};
					// 					that.start_batch(param, function (list) {
					// 						var html = '';
					// 						for (var i = 0; i < list.length; i++) {
					// 							var item = list[i];
					// 							var name = '';
					// 							if (item.domainorpath == 'path' && item.errorpage !== 1) {
					// 								name = item.redirectpath;
					// 							} else {
					// 								item.redirectdomain = JSON.parse(item.redirectdomain);
					// 								name = item.redirectdomain ? item.redirectdomain.join('、') : '空';
					// 							}
					// 							html +=
					// 								'<tr><td>' + name + '</td><td><div class="text-right"><span style="color:' + (item.request.status ? '#20a53a' : 'red') + '">' + item.request.msg + '</span></div></td></tr>';
					// 						}
					// 						site.edit.redirect_table.$batch_success_table({
					// 							title: '批量开启服务',
					// 							th: '被重定向',
					// 							html: html,
					// 						});
					// 						site.edit.redirect_table.$refresh_table_list(true);
					// 					});
					// 				});
					// 			},
					// 		},
					// 		{
					// 			title: '停用重定向规则',
					// 			url: '/site?action=ModifyRedirect',
					// 			param: function (row) {
					// 				row.type = 0;
					// 				row.redirectdomain = JSON.stringify(row['redirectdomain']);
					// 				return row;
					// 			},
					// 			callback: function (that) {
					// 				bt.simple_confirm({ title: '批量停用重定向规则', msg: '批量停用当前选中的规则后，配置的重定向域名/目录将指向源地址，是否继续操作？' }, function (index) {
					// 					layer.close(index);
					// 					var param = {};
					// 					that.start_batch(param, function (list) {
					// 						var html = '';
					// 						for (var i = 0; i < list.length; i++) {
					// 							var item = list[i];
					// 							var name = '';
					// 							if (item.domainorpath == 'path' && item.errorpage !== 1) {
					// 								name = item.redirectpath;
					// 							} else {
					// 								item.redirectdomain = JSON.parse(item.redirectdomain);
					// 								name = item.redirectdomain ? item.redirectdomain.join('、') : '空';
					// 							}
					// 							html +=
					// 								'<tr><td>' + name + '</td><td><div class="text-right"><span style="color:' + (item.request.status ? '#20a53a' : 'red') + '">' + item.request.msg + '</span></div></td></tr>';
					// 						}
					// 						site.edit.redirect_table.$batch_success_table({
					// 							title: '批量停止服务',
					// 							th: '被重定向',
					// 							html: html,
					// 						});
					// 						site.edit.redirect_table.$refresh_table_list(true);
					// 					});
					// 				});
					// 			},
					// 		},
					// 		{
					// 			title: '删除重定向规则',
					// 			url: '/site?action=del_redirect_multiple',
					// 			// param: { site_id: web.id },
					// 			// paramId: 'redirectname',
					// 			// paramName: 'redirectnames',
					// 			// theadName: '重定向名称',
					// 			// confirmVerify: false, // 是否提示验证方式
					// 			// refresh: true,
					// 			param: function (row) {
					// 				return {
					// 					site_id: web.id,
					// 					redirectnames: row.redirectname,
					// 				};
					// 			},
					// 			callback: function (that) {
					// 				bt.simple_confirm(
					// 					{
					// 						title: '批量删除重定向规则',
					// 						msg: '批量删除当前选中的规则后，配置的重定向域名/目录将会彻底失效，是否继续操作？',
					// 					},
					// 					function (index) {
					// 						layer.close(index);
					// 						var param = {};
					// 						that.start_batch(param, function (list) {
					// 							var html = '';
					// 							for (var i = 0; i < list.length; i++) {
					// 								var item = list[i];
					// 								var name = '';
					// 								if (item.domainorpath == 'path' && item.errorpage !== 1) {
					// 									name = item.redirectpath;
					// 								} else {
					// 									name = item.redirectdomain ? item.redirectdomain.join('、') : '空';
					// 								}
					// 								html +=
					// 									'<tr><td>' +
					// 									name +
					// 									'</td><td><div class="text-right"><span style="color:' +
					// 									(item.request.status ? '#20a53a' : 'red') +
					// 									'">' +
					// 									(item.request.status ? '删除成功' : '删除失败') +
					// 									'</span></div></td></tr>';
					// 							}
					// 							site.edit.redirect_table.$batch_success_table({
					// 								title: '批量删除操作完成！',
					// 								th: '被重定向',
					// 								html: html,
					// 							});
					// 							site.edit.redirect_table.$refresh_table_list(true);
					// 						});
					// 					}
					// 				);
					// 			},
					// 		},
					// 	],
					// },
			],
	});
	function modify_node_refirect(obj,callback){
			bt_tools.send({url:'/project/'+ _that.type +'/modify_project_redirect',data:obj},function(res){
					if(callback) callback(res)
			},'设置重定向')
	}
	function node_refirect_301(sitename, id, nrow){
			var isEdit = !!nrow;
			var form = isEdit
					? nrow
					: {
							redirectname: new Date().valueOf(),
							tourl: 'http://',
							redirectdomain: [],
							redirectpath: '',
							redirecttype: '',
							type: 1,
							domainorpath: 'domain',
							holdpath: 1,
					};
			var helps = [
					'重定向类型：表示访问选择的“域名”或输入的“路径”时将会重定向到指定URL',
					'目标URL：可以填写你需要重定向到的站点，目标URL必须为可正常访问的URL，否则将返回错误',
					'重定向方式：使用301表示永久重定向，使用302表示临时重定向',
					'保留URI参数：表示重定向后访问的URL是否带有子路径或参数如设置访问http://b.com 重定向到http://a.com',
					'保留URI参数：  http://b.com/1.html ---> http://a.com/1.html',
					'不保留URI参数：http://b.com/1.html ---> http://a.com',
			];
			bt_tools.send({url:'/data?action=getData',data:{table:'domain',list:'True',search:id}},function(rdata){
				// bt_tools.send({url:'/project/'+ _that.type +'/GetProjectDomain',data:{data:JSON.stringify({name:sitename})}},function(rdata){
					var flag = true;
					var domain_html = '';
					var select_list = [];
					var table_data = site.edit.redirect_table.data;
					for (var i = 0; i < rdata.length; i++) {
							flag = true;
							for (var j = 0; j < table_data.length; j++) {
									var con1 = site.edit.get_list_equal(table_data[j].redirectdomain, rdata[i].name);
									var con2 = !site.edit.get_list_equal(form.redirectdomain, rdata[i].name);
									if (con1 && con2) {
											flag = false;
											break;
									}
							}
							if (flag) {
									select_list.push(rdata[i]);
									var selected = site.edit.get_list_equal(form.redirectdomain, rdata[i].name);
									domain_html += '<li ' + (selected ? 'class="selected"' : '') + '><a><span class="text">' + rdata[i].name + '</span><span class="glyphicon glyphicon-ok check-mark"></span></a></li>';
							}
					}
					if (!domain_html) {
							domain_html = '<div style="padding: 14px 0; color: #999; text-align: center; font-size: 12px;">暂无域名可选</div>';
					}

					var content =
							'<style>select.bt-input-text { width: 100px; }</style>\
					<div id="form_redirect" class="bt-form-new pd20">\
							<div class="form-inline">\
									<div class="form-item">\
											<div class="form-label">开启重定向</div>\
											<div class="form-value">\
													<input class="btswitch btswitch-ios" id="type" type="checkbox" name="type" checked />\
													<label class="btswitch-btn phpmyadmin-btn" for="type"></label>\
											</div>\
									</div>\
									<div class="form-item">\
											<div class="form-label">保留URI参数</div>\
											<div class="form-value">\
													<input class="btswitch btswitch-ios" id="holdpath" type="checkbox" name="holdpath" checked />\
													<label class="btswitch-btn phpmyadmin-btn" for="holdpath"></label>\
											</div>\
									</div>\
							</div>\
							<div class="form-inline">\
									<div class="form-item">\
											<div class="form-label">重定向类型</div>\
											<div class="form-value">\
													<select class="bt-input-text" name="domainorpath">\
															<option value="domain">域名</option>\
															<option value="path">路径</option>\
													</select>\
											</div>\
									</div>\
									<div class="form-item">\
											<div class="form-label" style="width: 90px;">重定向方式</div>\
											<div class="form-value">\
													<select class="bt-input-text" style="width: 150px;" name="redirecttype">\
															<option value="301">301（永久重定向）</option>\
															<option value="302">302（临时重定向）</option>\
													</select>\
											</div>\
									</div>\
							</div>\
							<div class="form-inline redirectdomain" style="flex-wrap: nowrap;">\
									<div class="form-item">\
											<div class="form-label">重定向域名</div>\
											<div class="form-value">\
													<div class="btn-group bootstrap-select show-tick redirect_domain" style="width: 200px;">\
															<button type="button" class="btn dropdown-toggle btn-default" style="height: 32px; line-height: 18px; font-size: 12px">\
																	<span class="filter-option pull-left"></span>\
																	<span class="bs-caret"><span class="caret"></span></span>\
															</button>\
															<div class="dropdown-menu open">\
																	<div class="bs-actionsbox">\
																			<div class="btn-group btn-group-sm btn-block">\
																					<button type="button" class="actions-btn bs-select-all btn btn-default">全选</button>\
																					<button type="button" class="actions-btn bs-deselect-all btn btn-default">取消全选</button>\
																			</div>\
																	</div>\
																	<div class="dropdown-menu inner">' +
							domain_html +
							'</div>\
															</div>\
													</div>\
											</div>\
									</div>\
									<div class="form-item">\
											<div class="form-label" style="width: 80px;">目标URL</div>\
											<div class="form-value">\
													<input class="bt-input-text" name="tourl" type="text" style="width: 200px;" value="http://" />\
											</div>\
									</div>\
							</div>\
							<div class="form-inline redirectpath" style="display: none; flex-wrap: nowrap;">\
									<div class="form-item">\
											<div class="form-label">重定向路径</div>\
											<div class="form-value">\
													<input class="bt-input-text" name="redirectpath" placeholder="如: http://' +
							sitename +
							' " type="text" style="width: 200px;" />\
											</div>\
									</div>\
									<div class="form-item">\
											<div class="form-label" style="width: 80px;">目标URL</div>\
											<div class="form-value">\
													<input class="bt-input-text" name="tourl1" type="text" style="width: 200px;" value="http://" />\
											</div>\
									</div>\
							</div>\
							<div style="height: 15px;"></div>\
							' +
							bt.render_help(helps) +
							'\
					</div>';
					var redirectdomain = form.redirectdomain;

					var form_redirect = bt.open({
							type: 1,
							skin: 'demo-class',
							area: '650px',
							title: !isEdit ? '添加重定向' : '修改重定向',
							closeBtn: 2,
							shift: 5,
							shadeClose: false,
							btn: ['提交', '取消'],
							content: content,
							success: function () {
									var show_domain_name = function () {
											var text = '';
											if (redirectdomain.length > 0) {
													text = [];
													for (var i = 0; i < redirectdomain.length; i++) {
															text.push(redirectdomain[i]);
													}
													text = text.join(', ');
											} else {
													text = '请选择站点';
											}
											$('.redirect_domain .btn .filter-option').text(text);
									};

									show_domain_name();

									$('.redirect_domain .btn').click(function (e) {
											var $parent = $(this).parent();
											$parent.toggleClass('open');
											$(document).one('click', function () {
													$parent.removeClass('open');
											});
											e.stopPropagation();
									});

									// 单选
									$('.redirect_domain .dropdown-menu li').click(function (e) {
											var $this = $(this);
											var index = $this.index();
											var name = select_list[index].name;
											$this.toggleClass('selected');
											if ($this.hasClass('selected')) {
													redirectdomain.push(name);
											} else {
													var remove_index = -1;
													for (var i = 0; i < redirectdomain.length; i++) {
															if (redirectdomain[i] == name) {
																	remove_index = i;
																	break;
															}
													}
													if (remove_index != -1) {
															redirectdomain.splice(remove_index, 1);
													}
											}
											show_domain_name();
											e.stopPropagation();
									});

									// 全选
									$('.redirect_domain .bs-select-all').click(function () {
											redirectdomain = [];
											for (var i = 0; i < select_list.length; i++) {
													redirectdomain.push(select_list[i].name);
											}
											$('.redirect_domain .dropdown-menu li').addClass('selected');
											show_domain_name();
									});

									// 取消全选
									$('.redirect_domain .bs-deselect-all').click(function () {
											redirectdomain = [];
											$('.redirect_domain .dropdown-menu li').removeClass('selected');
											show_domain_name();
									});

									// 重定向类型
									$('[name="domainorpath"]').change(function () {
											var path = $(this).val();
											$('.redirect_domain .bs-deselect-all').click();
											$('[name="redirectpath"]').val('');
											$('.redirectpath, .redirectdomain').hide();
											switch (path) {
													case 'path':
															$('.redirectpath').show();
															break;
													case 'domain':
															$('.redirectdomain').show();
															break;
											}
									});

									if (isEdit) {
											$('[name="type"]').prop('checked', form.type == 1);
											$('[name="holdpath"]').prop('checked', form.holdpath == 1);
											$('[name="domainorpath"]').val(form.domainorpath);
											$('[name="redirecttype"]').val(form.redirecttype);
											$('[name="' + (form.domainorpath == 'path' ? 'tourl1' : 'tourl') + '"]').val(form.tourl);
											$('[name="redirectpath"]').val(form.redirectpath);
											$('.redirectpath, .redirectdomain').hide();
											switch (form.domainorpath) {
													case 'path':
															$('.redirectpath').show();
															break;
													case 'domain':
															$('.redirectdomain').show();
															break;
											}
									}

									$('#form_redirect').parent().css('overflow', 'inherit');
							},
							yes: function () {
									form.type = $('[name="type"]').prop('checked') ? 1 : 0;
									form.holdpath = $('[name="holdpath"]').prop('checked') ? 1 : 0;
									form.redirecttype = $('[name="redirecttype"]').val();
									form.domainorpath = $('[name="domainorpath"]').val();
									form.redirectpath = $('[name="redirectpath"]').val();
									form.tourl = $('[name="' + (form.domainorpath == 'path' ? 'tourl1' : 'tourl') + '"]').val();
									form.redirectdomain = JSON.stringify(redirectdomain);
									bt_tools.send({url:'/project/'+ _that.type +'/'+(isEdit?'modify':'create')+'_project_redirect',data:$.extend(form,{sitename: sitename})},function(rdata){
											if (rdata.status) {
													form_redirect.close();
													site.edit.redirect_table.$refresh_table_list();
											}
											bt.msg(rdata);
									})
							},
					});

			},'获取域名列表')
	}
};
/**
 * @description 文件限制
 */
CreateWebsiteModel.prototype.set_file_limit = function (web) {
  var isInit = true;
  $('#webedit-con').html('<div id="file-mode-select"></div><div id="file-restrict-table"></div>');
  
  bt_tools.table({
    el: '#file-restrict-table',
    url:'/project/proxy/get_file_restrict',
    param:{site_name:web.name},
    dataFilter:function(res){
      if(isInit){
        isInit = false;
        renderProxyMode(res.status)
      }
      return {data:res.file_list}
    },
    column: [
      { title: '后缀类型', type: 'text',template:function(row){
        return '<span title="'+row+'">'+row+'</span>'
      }},
      {
        title: '操作',
        width: 100,
        type: 'group',
        align: 'right',
        group: [
          {
            title: '删除',
            event: function (row, index, ev, key, that) {
              bt_tools.send({url:'/project/proxy/remove_file_restrict',data:{site_name:web.name,file_ext:row}},function(res){
                bt_tools.msg(res);
                if (res.status) that.$refresh_table_list(true);
              },'删除文件后缀')
            },
          },
        ],
      },
    ],
    tootls: [
      { // 按钮组
        type: 'group',
        positon: ['left', 'top'],
        list: [{
            title: '添加',
            active: true,
            event: function (ev, that) {
                var extType = $('input[name=file_ext_type]').val()
                if(extType == '') return layer.msg('请输入文件后缀', {icon:2})
                bt_tools.send({url:'/project/proxy/add_file_restrict',data:{site_name:web.name,file_ext:extType}}, function (rdata) {
                    bt_tools.msg(rdata);
                    if (rdata.status) {
                        $('input[name=file_ext_type]').val('')
                        if(rdata.status) that.$refresh_table_list(true);
                    }
                },'添加文件后缀')
            }
        }]
    }],
    success: function () {
      if($('input[name=file_ext_type]').length == 0){
          $('#file-restrict-table .tootls_top .pull-left .btn').before('<input type="text" name="file_ext_type" placeholder="请输入文件后缀" class="bt-input-text mr10 " value="" style="width: 260px;">')
      }
    }
  });

  function renderProxyMode(val){
    bt_tools.form({
      el: '#file-mode-select',
      class:'mb15',
      form: [{
          label: '文件后缀控制',
          group: {
            type: 'select',
            name: 'restrict_type',
            width: '110px',
            value: val,
            list: [
              { title: '开启', value: 'open' },
              { title: '关闭', value: 'closed' },
            ],
            placeholder: '请选择限制状态',
            change: function (formData) {
              bt_tools.send({url:'/project/proxy/set_file_restrict',data:{site_name:web.name,set_status:formData.restrict_type}},function(res){
                  bt_tools.msg(res);
              })
            }
          }
        }
      ]
    })
  }
};
/**
 * @description 绑定请求
 */
CreateWebsiteModel.prototype.bindHttp = function () {
  var that = this;
  for (const item in this.methods) {
    if (Object.hasOwnProperty.call(this.methods, item)) {
      const element = that.methods[item];
      (function (element) {
        CreateWebsiteModel.prototype[item] = function (param, callback) {
          bt_tools.send(
            {
              url: '/project/' + that.type + '/' + element[0],
              data: { data: JSON.stringify(param) },
            },
            function (data) {
              if (callback) callback(data);
            },
            { load: element[1] }
          );
        };
      })(element);
    }
  }
};
CreateWebsiteModel.prototype.layerFrom = null;
/**
 * @description 项目配置
 * @param {object} row 项目信息
 */
CreateWebsiteModel.prototype.reanderProjectConfigView = function (el, row) {
  var that = this,
    projectConfig = row.project_config,
    param = $.extend(projectConfig, { project_ps: row.ps, listen:row.listen });
  CreateWebsiteModel.prototype.layerFrom = bt_tools.form({
    el: '#webedit-con',
    data: param,
    class: 'ptb15',
    form: that.getAddProjectConfig({ type: 'edit' }),
  });
  setTimeout(function () {
    $('[name="project_cmd"]').val(param.project_cmd);
  },50)
  if (row.listen.length && !(row.listen.indexOf(parseInt($('input[name=port]').val())) > -1)) {
    $('.error_port').remove()
    $('input[name=port]').next().after('<div class="error_port" style="margin-top: 10px;color: red;">项目端口可能有误，检测到当前项目监听了以下端口'+ row.listen +'</div>')
  }
};

/**
 * @description 域名管理
 * @param {object} row 项目信息
 */
CreateWebsiteModel.prototype.reanderDomainManageView = function (el, row) {
  var that = this,
    list = [
      {
        class: 'mb0',
        items: [
          {
            name: 'modeldomain',
            width: '430px',
            type: 'textarea',
            placeholder:
              '如果需要绑定外网，请输入需要映射的域名<br>多个域名，请换行填写，每行一个域名，默认为80端口<br>泛解析添加方法：先添加一个域名 domain.com，后换行添加*.domain.com<br>如另加端口格式为 www.domain.com:88',
          },
          {
            name: 'btn_model_submit_domain',
            text: '添加',
            type: 'button',
            callback: function (sdata) {
              var arrs = sdata.modeldomain.split('\n');
              var domins = [];
              for (var i = 0; i < arrs.length; i++) domins.push(arrs[i]);
              if (domins[0] == '')
                return layer.msg('域名不能为空', { icon: 0 });
              that.addProjectDomain(
                { project_name: row.name, domains: domins },
                function (res) {
                  if (typeof res.status == 'undefined') {
                    $('[name=modeldomain]').val('');
                    $('.placeholder').css('display', 'block');
                    site.render_domain_result_table(res)
                    project_domian.$refresh_table_list(true);
                  }else{
                    bt.msg({
                      status: res.status,
                      msg: res.msg || res.error_msg,
                    });
                  }

                }
              );
            },
          },
        ],
      },
    ];
  var _form_data = bt.render_form_line(list[0]),
    loadT = null,
    placeholder = null;
  el.html(_form_data.html + '<div id="project_domian_list"></div>');
  bt.render_clicks(_form_data.clicks);
  // domain样式
  $('.btn_model_submit_domain')
    .addClass('pull-right')
    .css('margin', '30px 35px 0 0');
  $('textarea[name=modeldomain]').css('height', '120px');
  placeholder = $('.placeholder');
  placeholder
    .click(function () {
      $(this).hide();
      $('.modeldomain').focus();
    })
    .css({
      width: '340px',
      heigth: '120px',
      left: '0px',
      top: '0px',
      'padding-top': '10px',
      'padding-left': '15px',
    });
  $('.modeldomain')
    .focus(function () {
      placeholder.hide();
      loadT = layer.tips(placeholder.html(), $(this), {
        tips: [1, '#20a53a'],
        time: 0,
        area: $(this).width(),
      });
    })
    .blur(function () {
      if ($(this).val().length == 0) placeholder.show();
      layer.close(loadT);
    });
  var project_domian = bt_tools.table({
    el: '#project_domian_list',
    url: '/project/' + that.type + '/project_get_domain',
    default: '暂无域名列表',
    param: { project_name: row.name },
    height: 375,
    beforeRequest: function (params) {
      if (params.hasOwnProperty('data') && typeof params.data === 'string')
        return params;
      return { data: JSON.stringify(params) };
    },
    column: [
      { type: 'checkbox', class: '', width: 20 },
      {
        fid: 'name',
        title: '域名',
        type: 'text',
        template: function (row) {
          return (
            '<a href="http://' +
            row.name +
            ':' +
            row.port +
            '" target="_blank" class="btlink">' +
            row.name +
            '</a>'
          );
        },
      },
      {
        fid: 'port',
        title: '端口',
        type: 'text',
      },
      {
        title: '操作',
        type: 'group',
        width: '100px',
        align: 'right',
        group: [
          {
            title: '删除',
            template: function (row, that) {
              return that.data.length === 1 ? '<span>不可操作</span>' : '删除';
            },
            event: function (rowc, index, ev, key, rthat) {
              if (ev.target.tagName == 'SPAN') return;
              if (rthat.data.length === 1) {
                return bt.msg({ status: false, msg: '最后一个域名不能删除!' });
              }
              that.removeProjectDomain(
                { project_name: row.name, domain: rowc.name + ':' + rowc.port },
                function (res) {
                  bt.msg({
                    status: res.status,
                    msg: res.data || res.error_msg,
                  });
                  rthat.$refresh_table_list(true);
                }
              );
            },
          },
        ],
      },
    ],
    tootls: [
      {
        // 批量操作
        type: 'batch',
        positon: ['left', 'bottom'],
        placeholder: '请选择批量操作',
        buttonValue: '批量操作',
        disabledSelectValue: '请选择需要批量操作的站点!',
        selectList: [
          {
            title: '删除域名',
            load: true,
            url: '/project/' + that.type + '/project_remove_domain',
            param: function (crow) {
              return {
                data: JSON.stringify({
                  project_name: row.name,
                  domain: crow.name + ':' + crow.port,
                }),
              };
            },
            callback: function (that) {
              // 手动执行,data参数包含所有选中的站点
              bt.show_confirm(
                '批量删除域名',
                "<span style='color:red'>同时删除选中的域名，是否继续？</span>",
                function () {
                  var param = {};
                  that.start_batch(param, function (list) {
                    var html = '';
                    for (var i = 0; i < list.length; i++) {
                      var item = list[i];
                      html +=
                        '<tr><td>' +
                        item.name +
                        '</td><td><div style="float:right;"><span style="color:' +
                        (item.request.status ? '#20a53a' : 'red') +
                        '">' +
                        (item.request.status ? '成功' : '失败') +
                        '</span></div></td></tr>';
                    }
                    project_domian.$batch_success_table({
                      title: '批量删除',
                      th: '删除域名',
                      html: html,
                    });
                    project_domian.$refresh_table_list(true);
                  });
                }
              );
            },
          },
        ],
      },
    ],
  });
  setTimeout(function () {
    $(el).append(
      '<ul class="help-info-text c7">' +
      '<li>如果您的是HTTP项目，且需要映射到外网，请至少绑定一个域名</li>' +
      '<li>建议所有域名都使用默认的80端口</li>' +
      '</ul>'
    );
  }, 100);
};

/**
 * @description 渲染项目外网映射
 * @param el {object} 当前element节点
 * @param row {object} 当前项目数据
 */
CreateWebsiteModel.prototype.reanderProjectMapView = function (el, row) {
  var that = this;
  el.html(
    '<div class="pd15"><div class="ss-text mr50" style="display: block;height: 35px;">' +
    '   <em title="外网映射">外网映射</em>' +
    '       <div class="ssh-item">' +
    '           <input class="btswitch btswitch-ios" id="model_project_map" type="checkbox">' +
    '           <label class="btswitch-btn" for="model_project_map" name="model_project_map"></label>' +
    '       </div>' +
    '</div><ul class="help-info-text c7"><li>如果您的是HTTP项目，且需要外网通过80/443访问，请开启外网映射</li><li>开启外网映射前，请到【域名管理】中至少添加1个域名</li></ul></div>'
  );
  $('#model_project_map').attr(
    'checked',
    row['project_config']['bind_extranet'] ? true : false
  );
  $('[name=model_project_map]').click(function () {
    var _check = $('#model_project_map').prop('checked'),
      param = { project_name: row.name };
    if (!_check) param['domains'] = row['project_config']['domains'];
    layer.confirm(
      (!_check ? '开启外网映射后，可以通过绑定域名进行访问' : '关闭外网映射后，已绑定域名将取消关联访问') + '，是否继续操作？',
      {
        title: '外网映射',
        icon: 0,
        closeBtn: 2,
        cancel: function () {
          $('#model_project_map').prop('checked', _check);
        },
      },
      function () {
        that[_check ? 'unbindExtranet' : 'bindExtranet'](param, function (res) {
          if (!res.status) $('#model_project_map').prop('checked', _check);
          bt.msg({
            status: res.status,
            msg: typeof res.data != 'string' ? res.error_msg : res.data,
          });
          row['project_config']['bind_extranet'] = _check ? 0 : 1;
        });
      },
      function () {
        $('#model_project_map').prop('checked', _check);
      }
    );
  });
};

/**
 * @description 渲染项目伪静态视图
 * @param el {object} 当前element节点
 * @param row {object} 当前项目数据
 */
CreateWebsiteModel.prototype.reanderProjectRewriteView = function (el, row) {
  el.empty();
  if (row.project_config.bind_extranet === 0) {
    $('.mask_module')
      .removeClass('hide')
      .find('.node_mask_module_text:eq(1)')
      .hide()
      .prev()
      .show();
    return false;
  }
  site.edit.get_rewrite_list({ name: this.type + '_' + row.name }, function () {
    $('.webedit-box .line:first').remove();
    $('[name=btn_save_to]').remove();
    $('.webedit-box .help-info-text li:first').remove();
  });
};

/**
 * @description 渲染项目配置文件
 * @param el {object} 当前element节点
 * @param row {object} 当前项目数据
 */
CreateWebsiteModel.prototype.reanderFileConfigView = function (el, row) {
  el.empty();
  if (row.project_config.bind_extranet === 0) {
    $('.mask_module')
      .removeClass('hide')
      .find('.node_mask_module_text:eq(1)')
      .hide()
      .prev()
      .show();
    return false;
  }
  site.edit.set_config({ name: this.type + '_' + row.name });
};

/**
 * @description 渲染项目使用情况
 * @param el {object} 当前element节点
 * @param row {object} 当前项目数据
 */
CreateWebsiteModel.prototype.reanderServiceCondition = function (el, row) {
  if (!row.run) {
    el.html('').next().removeClass('hide');
    if (el.next().find('.node_mask_module_text').length === 1) {
      el.next()
        .find('.node_mask_module_text')
        .hide()
        .parent()
        .append(
          '<div class="node_mask_module_text">请先启动服务后重新尝试，<a href="javascript:;" class="btlink" onclick="site.node.simulated_click(7)">设置服务状态</a></div'
        );
    } else {
      el.next().find('.node_mask_module_text:eq(1)').show().prev().hide();
    }
    return false;
  }
  el.html(
    '<div class="line" style="padding-top: 0;"><span class="tname" style="width: 30px;text-align:left;padding-right: 5px;">PID</span><div class="info-r"><select class="bt-input-text mr5" name="node_project_pid"></select></div></div><div class="node_project_pid_datail"></div>'
  );
  var _option = '',
    tabelCon = '';
  for (var load in row.load_info) {
    if (row.load_info.hasOwnProperty(load)) {
      _option += '<option value="' + load + '">' + load + '</option>';
    }
  }
  var node_pid = $('[name=node_project_pid]');
  node_pid.html(_option);
  node_pid
    .change(function () {
      var _pid = $(this).val(),
        rdata = row['load_info'][_pid],
        fileBody = '',
        connectionsBody = '';
      for (var i = 0; i < rdata.open_files.length; i++) {
        var itemi = rdata.open_files[i];
        fileBody +=
          '<tr>' +
          '<td>' +
          itemi['path'] +
          '</td>' +
          '<td>' +
          itemi['mode'] +
          '</td>' +
          '<td>' +
          itemi['position'] +
          '</td>' +
          '<td>' +
          itemi['flags'] +
          '</td>' +
          '<td>' +
          itemi['fd'] +
          '</td>' +
          '</tr>';
      }
      for (var k = 0; k < rdata.connections.length; k++) {
        var itemk = rdata.connections[k];
        connectionsBody +=
          '<tr>' +
          '<td>' +
          itemk['client_addr'] +
          '</td>' +
          '<td>' +
          itemk['client_rport'] +
          '</td>' +
          '<td>' +
          itemk['family'] +
          '</td>' +
          '<td>' +
          itemk['fd'] +
          '</td>' +
          '<td>' +
          itemk['local_addr'] +
          '</td>' +
          '<td>' +
          itemk['local_port'] +
          '</td>' +
          '<td>' +
          itemk['status'] +
          '</td>' +
          '</tr>';
      }

      //     tabelCon = reand_table_config([
      //         [{"名称":rdata.name},{"PID":rdata.pid},{"状态":rdata.status},{"父进程":rdata.ppid}],
      //         [{"用户":rdata.user},{"Socket":rdata.connects},{"CPU":rdata.cpu_percent},{"线程":rdata.threads}],
      //         [{"内存":rdata.user},{"io读":rdata.connects},{"io写":rdata.cpu_percent},{"启动时间":rdata.threads}],
      //         [{"启动命令":rdata.user}],
      //     ])
      //
      // console.log(tabelCon)
      //
      //
      //     function reand_table_config(conifg){
      //         var html = '';
      //         for (var i = 0; i < conifg.length; i++) {
      //             var item = conifg[i];
      //             html += '<tr>';
      //             for (var j = 0; j < item; j++) {
      //                 var items = config[j],name = Object.keys(items)[0];
      //                 console.log(items,name)
      //                 html += '<td>'+  name +'</td><td>'+ items[name] +'</td>'
      //             }
      //             console.log(html)
      //             html += '</tr>'
      //         }
      //         return '<div class="divtable"><table class="table"><tbody>'+ html  +'</tbody></tbody></table></div>';
      //     }

      tabelCon =
        '<div class="divtable">' +
        '<table class="table">' +
        '<tbody>' +
        '<tr>' +
        '<th width="50">名称</th><td  width="100">' +
        rdata.name +
        '</td>' +
        '<th width="50">状态</th><td  width="90">' +
        rdata.status +
        '</td>' +
        '<th width="60">用户</th><td width="100">' +
        rdata.user +
        '</td>' +
        '<th width="80">启动时间</th><td width="150">' +
        getLocalTime(rdata.create_time) +
        '</td>' +
        '</tr>' +
        '<tr>' +
        '<th>PID</th><td  >' +
        rdata.pid +
        '</td>' +
        '<th>PPID</th><td >' +
        rdata.ppid +
        '</td>' +
        '<th>线程</th><td>' +
        rdata.threads +
        '</td>' +
        '<th>Socket</th><td>' +
        rdata.connects +
        '</td>' +
        '</tr>' +
        '<tr>' +
        '<th>CPU</th><td>' +
        rdata.cpu_percent +
        '%</td>' +
        '<th>内存</th><td>' +
        ToSize(rdata.memory_used) +
        '</td>' +
        '<th>io读</th><td>' +
        ToSize(rdata.io_read_bytes) +
        '</td>' +
        '<th>io写</th><td>' +
        ToSize(rdata.io_write_bytes) +
        '</td>' +
        '</tr>' +
        '<tr>' +
        '</tr>' +
        '<tr>' +
        '<th width="50">命令</th><td colspan="7" style="word-break: break-word;width: 570px">' +
        rdata.exe +
        '</td>' +
        '</tr>' +
        '</tbody>' +
        '</table>' +
        '</div>' +
        '<h3 class="tname">网络</h3>' +
        '<div class="divtable" >' +
        '<div style="height:160px;overflow:auto;border:#ddd 1px solid" id="nodeNetworkList">' +
        '<table class="table table-hover" style="border:none">' +
        '<thead>' +
        '<tr>' +
        '<th>客户端地址</th>' +
        '<th>客户端端口</th>' +
        '<th>协议</th>' +
        '<th>FD</th>' +
        '<th>本地地址</th>' +
        '<th>本地端口</th>' +
        '<th>状态</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        connectionsBody +
        '</tbody>' +
        '</table>' +
        '</div>' +
        '</div>' +
        '<h3 class="tname">打开的文件列表</h3>' +
        '<div class="divtable" >' +
        '<div style="height:160px;overflow:auto;border:#ddd 1px solid" id="nodeFileList">' +
        '<table class="table table-hover" style="border:none">' +
        '<thead>' +
        '<tr>' +
        '<th>文件</th>' +
        '<th>mode</th>' +
        '<th>position</th>' +
        '<th>flags</th>' +
        '<th>fd</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        fileBody +
        '</tbody>' +
        '</table>' +
        '</div>' +
        '</div>';
      $('.node_project_pid_datail').html(tabelCon);
      bt_tools.$fixed_table_thead('#nodeNetworkList');
      bt_tools.$fixed_table_thead('#nodeFileList');
    })
    .change()
    .html(_option);
};

/**
 * @description 项目SSL
 * @param el {object} 当前element节点
 * @param row {object} 当前项目数据
 */
CreateWebsiteModel.prototype.reanderProjectSslView = function (el, row) {
  el.empty();
  if (row.project_config.bind_extranet === 0) {
    $('.mask_module')
      .removeClass('hide')
      .find('.node_mask_module_text:eq(1)')
      .hide()
      .prev()
      .show();
    return false;
  }
  site.set_ssl({ name: row.name, ele: el, id: row.id });
  site.ssl.reload();
};

/**
 * @description 渲染项目服务状态
 * @param el {object} 当前element节点
 * @param row {object} 当前项目数据
 */
CreateWebsiteModel.prototype.reanderServiceStatusView = function (el, row) {
  var _this = this
  var arry = [
      { title: '启动', event: this.startProject },
      { title: '停止', event: this.stopProject },
      { title: '重启', event: this.restartProject },
    ],
    that = this,
    html = $(
      '<div class="soft-man-con bt-form"><p class="status"></p><div class="sfm-opt"></div></div>'
    );
  function reander_service(status) {
    var status_info = status
      ? ['开启', '#20a53a', 'play']
      : ['停止', 'red', 'pause'];
    return (
      '当前状态：<span>' +
      status_info[0] +
      '</span><span style="color:' +
      status_info[1] +
      '; margin-left: 3px;" class="glyphicon glyphicon glyphicon-' +
      status_info[2] +
      '"></span>'
    );
  }
  html.find('.status').html(reander_service(row.run));
  el.html(html);
  for (var i = 0; i < arry.length; i++) {
    var item = arry[i],
      btn = $('<button class="btn btn-default btn-sm"></button>');
    (function (btn, item, indexs) {
      !(row.run && indexs === 0) || btn.addClass('hide');
      !(!row.run && indexs === 1) || btn.addClass('hide');
      btn
        .on('click', function () {
          bt.simple_confirm(
            {
              title: item.title +_this.tips+ '项目【' + row.name + '】',
              msg: item.title + '项目后'+ (item.title === '停止' ? '将无法正常访问项目' : (item.title === '启动' ? '，用户可以正常访问项目内容' : '将重新加载项目')) + '，是否继续操作？',
            },
            function (index) {
              layer.close(index);
              item.event.call(that, { project_name: row.name }, function (res) {
                row.run = indexs === 0 ? true : indexs === 1 ? false : row.run;
                html.find('.status').html(reander_service(row.run));
                $('.sfm-opt button').eq(0).addClass('hide');
                $('.sfm-opt button').eq(1).addClass('hide');
                $('.sfm-opt button')
                  .eq(row.run ? 1 : 0)
                  .removeClass('hide');
                bt.msg({ status: res.status, msg: res.data || res.error_msg });
              });
            }
          );
        })
        .text(item.title);
    })(btn, item, i);
    el.find('.sfm-opt').append(btn);
  }
};
/**
 * @description 渲染项目日志
 * @param el {object} 当前element节点
 * @param row {object} 当前项目数据
 */
CreateWebsiteModel.prototype.reanderProjectLogsView = function (el, row) {
  el.html('<div class="model_project_log"></div>');
  var that = this;
  this.getProjectLog({ project_name: row.name }, function (res) {
    $('#webedit-con .model_project_log').html(
      '<pre class="command_output_pre" style="height:640px;">' +
      (typeof res == 'object' ? res.msg : res) +'</pre>');
    $('#webedit-con .model_project_log').html(
      '<div class="mb10">日志路径<input type="text" name="model_log_path" id="model_log_path" value="'+res.path+'" placeholder="日志路径" class="ml10 bt-input-text mr10" style="width:350px" />\
					<span class="glyphicon glyphicon-folder-open cursor mr10" onclick="bt.select_path(\'model_log_path\',\'dir\')"></span>\
					<button class="btn btn-success btn-sm" name="submitLogConfig">保存</button>\</div>\
					<div class="mb10" style="line-height: 32px;">日志大小<span class="ml10">'+ res.size +'</span></div><pre class="command_output_pre" style="height:500px;">' +
      res.data+
      '</pre>'
    );
    $.post({url: '/project/'+ that.type +'/get_log_split', data: { name: row.name }}, function (rdata) {
      var html = '',configInfo = {}
      if(rdata.status) configInfo = rdata.data
      html = '开启后' + (rdata.status ? rdata.data.log_size ? '日志文件大小超过'+ bt.format_size(rdata.data.log_size,true,2,'MB') +'时进行切割日志文件' : '每天'+ rdata.data.hour +'点' + rdata.data.minute + '分进行切割日志文件' : '默认每天2点0分进行切割日志文件')
      $('#webedit-con .model_project_log .command_output_pre').before('<div class="inlineBlock log-split mb20" style="line-height: 32px;">\
					<label>\
						<div class="bt-checkbox '+ (rdata.status && rdata.data.status ? 'active':'') +'"></div>\
						<span>日志切割</span>\
					</label>\
					<span class="unit">'+html+'，如需修改请点击<a href="javascript:;" class="btlink mamger_log_split">编辑配置</a></span>\
					</div>')
      $('#webedit-con .model_project_log .log-split').hover(function(){
        layer.tips('当日志文件过大时，读取和搜索时间会增加，同时也会占用存储空间，因此需要对日志进行切割以方便管理和维护。', $(this), {tips: [3, '#20a53a'], time: 0});
      },function(){
        layer.closeAll('tips');
      })
      $('#webedit-con .model_project_log label').click(function(){
        if(rdata['is_old']){
          bt_tools.msg(rdata)
          return;
        }
        bt.confirm({title:'设置日志切割任务',msg: !rdata.status || (rdata.status && !rdata.data.status) ? '开启后对该项目日志进行切割，是否继续操作？' : '关闭后将无法对该项目日志进行切割，是否继续操作？'},function(){
          if(rdata.status){
            that.set_log_split({name: row.name},function(res){
              bt_tools.msg(res)
              if(res.status) {
                that.reanderProjectLogsView(el, row);
              }
            })
          }else{
            that.mamger_log_split({name: row.name},function(res){
              bt_tools.msg(res)
              if(res.status) {
                that.reanderProjectLogsView(el, row);
              }
            })
          }
        })
      })
      $('.mamger_log_split').click(function(){
        if(rdata['is_old']){
          bt_tools.msg(rdata)
          return;
        }
        bt_tools.open({
          type: 1,
          area: '460px',
          title: '配置日志切割任务',
          closeBtn: 2,
          btn: ['提交', '取消'],
          content: {
            'class': 'pd20 mamger_log_split_box',
            form: [{
              label: '执行时间',
              group: [{
                type: 'text',
                name: 'day',
                width: '44px',
                value: '每天',
                disabled: true
              },{
                type: 'number',
                name: 'hour',
                'class': 'group',
                width: '70px',
                value: configInfo.hour || '2',
                unit: '时',
                min: 0,
                max: 23
              }, {
                type: 'number',
                name: 'minute',
                'class': 'group',
                width: '70px',
                min: 0,
                max: 59,
                value: configInfo.minute || '0',
                unit: '分'
              }]
            },{
              label: '日志大小',
              group:{
                type: 'text',
                name: 'log_size',
                width: '220px',
                value: configInfo.log_size ? bt.format_size(configInfo.log_size,true,2,'MB').replace(' MB','') : '',
                unit: 'MB',
                placeholder: '请输入日志大小',
              }
            }, {
              label: '保留最新',
              group:{
                type: 'number',
                name: 'num',
                'class': 'group',
                width: '70px',
                min: 1,
                value: configInfo.num || '180',
                unit: '份'
              }
            }]
          },
          success: function (layero, index) {
            $(layero).find('.mamger_log_split_box .bt-form').prepend('<div class="line">\
								<span class="tname">切割方式</span>\
								<div class="info-r">\
									<div class="replace_content_view" style="line-height: 32px;">\
										<div class="checkbox_config">\
											<i class="file_find_radio '+ (configInfo.log_size ? 'active' : '') +'"></i>\
											<span class="laberText" style="font-size: 12px;">按日志大小</span>\
										</div>\
										<div class="checkbox_config">\
											<i class="file_find_radio '+ (configInfo.log_size ? '' : 'active') +'"></i>\
											<span class="laberText" style="font-size: 12px;">按执行时间</span>\
										</div>\
									</div>\
								</div>')
            $(layero).find('.mamger_log_split_box .bt-form').append('<div class="line"><div class=""><div class="inlineBlock  "><ul class="help-info-text c7"><li>每5分钟执行一次</li><li>【日志大小】：日志文件大小超过指定大小时进行切割日志文件</li><li>【保留最新】：保留最新的日志文件，超过指定数量时，将自动删除旧的日志文件</li></ul></div></div></div>')
            $(layero).find('.replace_content_view .checkbox_config').click(function(){
              var index = $(this).index()
              $(this).find('i').addClass('active').parent().siblings().find('i').removeClass('active')
              if(index){
                $(layero).find('[name=hour]').parent().parent().parent().show()
                $(layero).find('[name=log_size]').parent().parent().parent().hide()
                $(layero).find('.help-info-text li').eq(0).hide().next().hide()
              }else{
                $(layero).find('[name=hour]').parent().parent().parent().hide()
                $(layero).find('[name=log_size]').parent().parent().parent().show()
                $(layero).find('.help-info-text li').eq(0).show().next().show()
              }
            })
            if(configInfo.log_size) {
              $(layero).find('[name=hour]').parent().parent().parent().hide()
            }else{
              $(layero).find('[name=log_size]').parent().parent().parent().hide()
              $(layero).find('.help-info-text li').eq(0).hide().next().hide()
            }
            $(layero).find('[name=log_size]').on('input', function(){
              if($(this).val() < 1 || !bt.isInteger(parseFloat($(this).val()))) {
                layer.tips('请输入日志大小大于0的的整数', $(this), { tips: [1, 'red'], time: 2000 })
              }
            })
            $(layero).find('[name=hour]').on('input', function(){
              if($(this).val() > 23 || $(this).val() < 0 || !bt.isInteger(parseFloat($(this).val()))) {
                layer.tips('请输入小时范围0-23的整数时', $(this), { tips: [1, 'red'], time: 2000 })
              }
              $(layero).find('.hour').text($(this).val())
            })
            $(layero).find('[name=minute]').on('input', function(){
              if($(this).val() > 59 || $(this).val() < 0 || !bt.isInteger(parseFloat($(this).val()))) {
                layer.tips('请输入正确分钟范围0-59分的整数', $(this), { tips: [1, 'red'], time: 2000 })
              }
              $(layero).find('.minute').text($(this).val())
            })
            $(layero).find('[name=num]').on('input', function(){
              if($(this).val() < 1 || $(this).val() > 1800 || !bt.isInteger(parseFloat($(this).val()))) {
                layer.tips('请输入保留最新范围1-1800的整数', $(this), { tips: [1, 'red'], time: 2000 })
              }
            })
          },
          yes: function (formD,indexs) {
            formD['name'] = row.name
            delete formD['day']
            if($('.mamger_log_split_box .file_find_radio.active').parent().index()) {
              if (formD.hour < 0 || formD.hour > 23 || isNaN(formD.hour) || formD.hour === '' || !bt.isInteger(parseFloat(formD.hour))) return layer.msg('请输入小时范围0-23时的整数')
              if (formD.minute < 0 || formD.minute > 59 || isNaN(formD.minute) || formD.minute === '' || !bt.isInteger(parseFloat(formD.minute))) return layer.msg('请输入正确分钟范围0-59分的整数')
              formD['log_size'] = 0
            }else{
              if(formD.log_size == '' || !bt.isInteger(parseFloat(formD.log_size))) return layer.msg('请输入日志大小大于0的的整数')
            }
            if(formD.num < 1 || formD.num > 1800 || !bt.isInteger(parseFloat(formD.num))) return layer.msg('请输入保留最新范围1-1800的整数')
            if(!rdata.status || (rdata.status && !rdata.data.status)) {
              if(rdata.status){
                that.set_log_split({name: row.name},function(res){
                  if(res.status) {
                    pub_open()
                  }
                })
              }else{
                pub_open()
              }
            }else{
              pub_open()
            }
            function pub_open() {
              that.mamger_log_split(formD,function(res){
                bt.msg(res)
                if(res.status) {
                  that.reanderProjectLogsView(el, row);
                  layer.close(indexs)
                }
              })
            }
          }
        })
      })
    })
    // 保存按钮
    $('[name="submitLogConfig"]').unbind('click').click(function () {
      var path = $('#model_log_path').val();
      if (!path) {
        bt.msg({ status: false, msg: '日志路径不能为空' });
        return;
      }
      that.change_log_path({ project_name: row.name, path: path }, function (res) {
        bt.msg(res);
        that.reanderProjectLogsView(el, row);
      });
    })
    $('.command_output_pre').scrollTop(
      $('.command_output_pre').prop('scrollHeight')
    );
  });
};

/**
 * @description 渲染项目日志
 * @param el {object} 当前element节点
 * @param row {object} 当前项目数据
 */
CreateWebsiteModel.prototype.reanderSiteLogsView = function (el, row) {
  el.empty();
  if (row.project_config.bind_extranet === 0) {
    $('.mask_module')
      .removeClass('hide')
      .find('.node_mask_module_text:eq(1)')
      .hide()
      .prev()
      .show();
    return false;
  }
  site.edit.get_site_logs({ name: row.name });
};

/**
 * 第一次开打go项目的SDK管理渲染模块
 * @param {Object} options 参数里面有sdk的类型，和是否重新刷新
 */
CreateWebsiteModel.prototype.firstRenderSDKTable  = function (options) {
  var _that = options._that;
  var type = options.type || 'all';
  var used = ''
  // 生成表格
  var versionTable = bt_tools.table({
    el: '#versionManagement',
    url: '/project/go/list_go_sdk',
    height: '500px',
    load: '正在获取版本信息...',
    dataFilter: function (res) {
      _that.goSDKVersionList = res.sdk;
      used = res.used // 获取正在使用的sdk版本
      res.sdk[type].sort((a,b)=> b.installed - a.installed)   // 排序，已安装的先显示
      return { data: res.sdk[type] };
    },
    column: [
      // { type: 'text', fid: 'version', title: 'GoSDK版本' },
      {
        type: 'text',
        title: 'SDK版本',
        template: function (row) {
          const version = row.version.slice(2);
          return '<span class="version">'+ version + (row.type === "stable" ? "(稳定版)" : "") +('go'+version === used?'<span style="color: #333;font-weight: bold;">【正在使用】</span>':'')+'</span>'
          // return row.type === 'stable' ? '<span class="stable">'+version+'(稳定版)</span>' : '<span>'+ version+'</span>';
        },
      },
      {
        type: 'text',
        title: '安装状态',
        template: function (row) {
          return row.installed ? '<span style="color:#20a53a;cursor:pointer;">已安装</span>' : '<span style="color:#d9534f;cursor:pointer;">未安装</span>';
        },
      },
      {
        type: 'text',
        align: 'right',
        title: '操作',
        template: function (row) {
          return row.installed ? '<a class="bterror">卸载</a>' : '<a class="btlink">安装</a>';
        },
        event: function (row) {
          if(this.classList.contains('version')) return;
          var is_installed = row.installed;
          bt.confirm(
            {
              title: (is_installed ? '卸载' : '安装') + 'SDK版本',
              msg: is_installed ? '卸载[' + row.version + ']版本后，相关项目将无法启动，是否继续？' : '是否安装[' + row.version + ']版本？',
            },
            function () {
              if(is_installed){
                //卸载
                bt_tools.send({url:'/project/go/uninstall_go_sdk',data:{version:row.version}},function (data){
                  // bt.msg({status:data.status,msg:data.msg})
                  // console.log(_that.clickUpdateHandle);
                  _that.clickUpdateHandle(_that)()

                },'正在卸载请稍候...')
              }else{
                //安装
                bt_tools.send({url:'/project/go/install_go_sdk',data:{version:row.version}},function (data){
                  // bt.msg({status:data.status,msg:data.msg})
                  _that.clickUpdateHandle(_that)()
                },'正在安装请稍候...')
              }
            }
          );
        },
      },
    ],
  });
}


//渲染表格的函数
CreateWebsiteModel.prototype.renderTable = function  (data)  {
  data.sort((a,b)=> b.installed - a.installed)   // 排序，已安装的先显示
  //根据数据渲染表格
  bt_tools.table({
    el: '#versionManagement',
    data:data,
    height: '500px',
    load: '正在获取版本信息...',
    column: [
      {
        type: 'text',
        title: 'SDK版本',
        template: function (row) {
          const version = row.version.slice(2);
          return '<span class="version">'+ version + (row.type === "stable" ? "(稳定版)" : "") +'</span>'
        },
      },
      {
        type: 'text',
        title: '安装状态',
        template: function (row) {
          return row.installed ? '<span style="color:#20a53a">已安装</span>' : '<span style="color:#d9534f">未安装</span>';
        },
      },
      {
        type: 'text',
        align: 'right',
        title: '操作',
        template: function (row) {
          return row.installed ? '<a class="bterror">卸载</a>' : '<a class="btlink">安装</a>';
        },
      }]
  })
}


//sdk版本管理里面的下拉框事件处理函数
CreateWebsiteModel.prototype.changeSelectHandle = function (that,index) {
  localStorage.setItem('currentSDKType', index);
  var type = index == 0 ? 'all' : 'streamline';
  var data = that.goSDKVersionList[type];
  //更新表格渲染。
  that.renderTable(data)
}


//sdk版本管理里面的更新列表点击处理函数
CreateWebsiteModel.prototype.clickUpdateHandle = function (that) {
  return function () {
    var type = localStorage.currentSDKType == 0 ? 'all' : 'streamline';
    var loadT = layer.msg('正在获取版本列表，请稍侯...', {
      icon: 16,
      time: 0,
      shade: 0.3,
    })
    bt_tools.send({url:'/project/go/list_go_sdk'},function (data) {
      that.goSDKVersionList = data.sdk;
      var data = that.goSDKVersionList[type];
      //更新表格渲染。
      // 加载中的loading效果
      // ??????
      that.renderTable(data)
      layer.close(loadT);
    })
  };
}
