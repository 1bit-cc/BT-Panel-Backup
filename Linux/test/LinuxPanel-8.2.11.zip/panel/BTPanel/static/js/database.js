$('.database-pos .tabs-item').click(function () {
	var index = $(this).index();
	$(this).addClass('active').siblings().removeClass('active');
	$('.db_table_view .tab-con .tab-con-block').eq(index).removeClass('hide').siblings().addClass('hide');
	clearInterval(redis.timer); // 清除redis定时器
	db_public_fn.showDatabase(true);
});

var database_table = null,
	dbCloudServerTable = null, //远程服务器视图
	cloudDatabaseList = [], //远程服务器列表
	mongoDBAccessStatus = false;

var database = {
	backuptoList: [
		{ title: '服务器磁盘', value: 'localhost' },
		{ title: '阿里云OSS', value: 'alioss' },
		{ title: '腾讯云COS', value: 'txcos' },
		{ title: '七牛云存储', value: 'qiniu' },
		{ title: '华为云存储', value: 'obs' },
		{ title: '百度云存储', value: 'bos' },
		{ title: 'FTP存储', value: 'ftp' },
	],
	database_table_view: function (search) {
		var _this = this
		var param = {
			table: 'databases',
			search: search || '',
		};
		$('#bt_database_table').empty();
		database_table = bt_tools.table({
			el: '#bt_database_table',
			url: '/data?action=getData',
			param: param, //参数
			minWidth: '1000px',
			autoHeight: true,
			default: '数据库列表为空', // 数据为空时的默认提示
			pageName: 'database',
			load: '获取数据库列表，可能需要较长时间，请耐心等待...',
			clickInto:'您的数据库列表为空，您可以<a class="btlink" onClick="$(\'#bt_database_table .pull-left button\').eq(0).click()">添加一个数据库</a>',
			beforeRequest: function () {
				var db_type_val = $('.database_type_select_filter').val();
				switch (db_type_val) {
					case 'all':
						delete param['db_type'];
						delete param['sid'];
						break;
					case 0:
						param['db_type'] = 0;
						break;
					default:
						delete param['db_type'];
						param['sid'] = db_type_val;
				}
				param.search = $('#bt_database_table .pull-right .bt_search').find('[placeholder="请输入数据库名称/备注"]').val();
				return param;
			},
			dataFilter:function(res){
				_this.search_hi = res
				return res
			},
			column: [
				{
					type: 'checkbox',
					width: 20,
				},
				{
					fid: 'name',
					title: '数据库名',
					type: 'text',
				},
				{
					fid: 'username',
					title: '用户名',
					type: 'text',
					sort: true,
				},
				{
					fid: 'password',
					title: '密码',
					type: 'password',
					copy: true,
					eye_open: true,
					template: function (row) {
						if (row.password === '')
							return (
								'<span class="c9 cursor" onclick="database.set_data_pass(\'' +
								row.id +
								"','" +
								row.username +
								"','" +
								row.password +
								'\')">无法获取密码，请点击<span style="color:red">改密</span>重置密码!</span>'
							);
						return true;
					},
				},
				bt.public.get_quota_config('database'),
				{
					fid: 'backup',
					title: '备份',
					width: 130,
					template: function (row) {
						var backup = '点击备份',
							_class = 'bt_warning';
						if (row.backup_count > 0) (backup = lan.database.backup_ok), (_class = 'bt_success');
						return (
							'<span><a href="javascript:;" class="btlink ' +
							_class +
							'" onclick="database.database_detail(' +
							row.id +
							",'" +
							row.name +
							"','" +
							row.db_type +
							'\')">' +
							backup +
							(row.backup_count > 0 ? '(' + row.backup_count + ')' : '') +
							'</a> | ' +
							'<a href="javascript:database.input_database(\'' +
							row.name +
							'\')" class="btlink">' +
							lan.database.input +
							'</a></span>'
						);
					},
				},
				{
					title: '数据库位置',
					type: 'text',
					width: 116,
					template: function (row) {
						var type_column = '-';
						switch (row.db_type) {
							case 0:
								type_column = '本地数据库';
								break;
							case 1:
								type_column = ('远程库(' + row.conn_config.db_host + ':' + row.conn_config.db_port + ')').toString();
								break;
							case 2:
								$.each(cloudDatabaseList, function (index, item) {
									if (row.sid == item.id) {
										if (item.ps !== '') {
											// 默认显示备注
											type_column = item.ps;
										} else {
											type_column = ('远程服务器(' + item.db_host + ':' + item.db_port + ')').toString();
										}
									}
								});
								break;
						}
						return '<span class="flex" style="width:100px" title="' + type_column + '"><span class="size_ellipsis" style="width: 0; flex: 1;">' + type_column + '</span></span>';
					},
				},
				{
					fid: 'ps',
					title: '备注',
					type: 'input',
					blur: function (row, index, ev) {
						bt.pub.set_data_ps(
							{
								id: row.id,
								table: 'databases',
								ps: ev.target.value,
							},
							function (res) {
								layer.msg(res.msg, { icon: res.status ? 1 : 2 });
							}
						);
					},
					keyup: function (row, index, ev) {
						if (ev.keyCode === 13) {
							$(this).blur();
						}
					},
				},
				{
					type: 'group',
					title: '操作',
					width: 220,
					align: 'right',
					group: [
						{
							title: '管理',
							tips: '数据库管理',
							hide: function (rows) {
								return rows.db_type != 0;
							}, // 远程数据库和远程服务器
							event: function (row) {
								bt.database.open_phpmyadmin(row.name, row.username, row.password);
							},
						},
						{
							title: '权限',
							tips: '设置数据库权限',
							hide: function (rows) {
								return rows.db_type == 1;
							}, //远程数据库
							event: function (row) {
								bt.database.set_data_access(row.username);
							},
						},
						{
							title: '工具',
							tips: 'MySQL优化修复工具',
							event: function (row) {
								database.rep_tools(row.name);
							},
						},
						{
							title: '改密',
							tips: '修改数据库密码',
							hide: function (rows) {
								return rows.db_type == 1;
							},
							event: function (row) {
								database.set_data_pass(row.id, row.username, row.password);
							},
						},
						{
							title: '删除',
							tips: '删除数据库',
							event: function (row) {
								var list = [];
								list.push(row);
								database.del_database(list, row.name, row, function (res) {
									if (res.status) database_table.$refresh_table_list(true);
									layer.msg(res.msg, {
										icon: res.status ? 1 : 2,
									});
								});
							},
						},
					],
				},
			],
			sortParam: function (data) {
				return {
					order: data.name + ' ' + data.sort,
				};
			},
			tootls: [
				{
					// 按钮组
					type: 'group',
					positon: ['left', 'top'],
					list: [
						{
							title: '添加数据库',
							active: true,
							event: function () {
								open_add();
								function open_add() {
									var cloudList = [];
									$.each(cloudDatabaseList, function (index, item) {
										var _tips = item.ps != '' ? item.ps + ' (' + item.db_host + ')' : item.db_host;
										cloudList.push({ title: _tips, value: item.id, name: item.db_host });
									});
									bt.database.add_database(cloudList, function (res) {
										if (res.status) database_table.$refresh_table_list(true);
									});
								}
							},
						},
						{
							title: 'root密码',
							event: function () {
								bt.database.set_root('root');
							},
						},
						{
							title: 'phpMyAdmin',
							event: function () {
								soft.set_soft_config('phpmyadmin')
							}
						},
						{
							title: '回收站',
							icon: 'trash',
							event: function () {
								// bt.recycle_bin.open_recycle_bin(6)
								fileManage.recycle_bin_view();
							},
						},
						{
							title: 'mysql',
							event: function () {},
						},
					],
				},
				{
					type: 'batch', //batch_btn
					positon: ['left', 'bottom'],
					placeholder: '请选择批量操作',
					buttonValue: '批量操作',
					disabledSelectValue: '请选择需要批量操作的数据库!',
					selectList: [
						{
							title: '设置权限',
							url: '/database?action=SetDatabaseAccess',
							paramName: 'name', //列表参数名,可以为空
							paramId: 'username',
							theadName: '数据库名称',
							refresh: true,
							confirm: {
								title: '批量设置数据库权限',
								area: '450px',
								content:'<div class="bt-form bt-form pd20 database_access">\
								<div class="line " style="display:none;">\
								<span class="tname">name</span>\
								<div class="info-r ">\
								<input name="name" class="bt-input-text mr5" type="text" style="width:330px" value="">\
								</div>\
								</div>\
								<div class="line ">\
								<span class="tname">访问权限</span>\
								<div class="info-r ">\
								<select class="bt-input-text mr5" name="dataAccess" style="width:200px">\
								<option value="127.0.0.1">本地服务器</option>\
								<option value="%">所有人(不安全)</option>\
								<option value="ip">指定IP</option>\
								</select>\
								<textarea id="dataAccess_subid" class="bt-input-text mr5 hide" type="text" name="address" placeholder="多个IP使用逗号(,)分隔" style="line-height: 20px;width: 200px;height: 70px; display: block;margin-top: 10px;"></textarea>\
								</div></div>\
								</div>',
								success: function (res, list, that) {
									// 选中指定ip时显示文本域
									$('.database_access').find('select[name="dataAccess"]').change(function () {
										if ($(this).val() == 'ip') {
											$(this).next().removeClass('hide');
										}else{
											$(this).next().addClass('hide');
										}
									})
								},
								yes: function (index, layers, request) {
									var params = {
										dataAccess: $('.database_access').find('select[name="dataAccess"]').val(),
										access: $('.database_access').find('select[name="dataAccess"]').val() == 'ip'?$('#dataAccess_subid').val():$('.database_access').find('select[name="dataAccess"]').val(),
									}
									if(params.dataAccess == 'ip' && params.address == ''){
										layer.msg('请填写指定IP', { icon: 2 });
									}
									if(params.dataAccess == 'ip'){
										params.address = $('#dataAccess_subid').val()
									}
									request(params);
								},
							},
						},
						{
							title: '同步数据库',
							url: '/database?action=SyncToDatabases&type=1',
							param: function (row) {
								var arry = [];
								arry.push(row.id);
								return { ids: JSON.stringify(arry) };
							},
							callback: function (that) {
								// 手动执行,data参数包含所有选中的站点
								bt.simple_confirm({ title: '批量同步数据库', msg: '批量同步选中的数据库，同步过程中可能存在风险，请在闲置时间段同步数据库，是否继续操作？' }, function () {
									var param = {};
									that.start_batch(param, function (list) {
										var html = '';
										for (var i = 0; i < list.length; i++) {
											var item = list[i];
											html +=
												'<tr><td>' +
												item.name +
												'</td><td><div style="float:right;"><span style="color:' +
												(item.request.status ? '#20a53a' : 'red') +
												'">' +
												item.request.msg +
												'</span></div></td></tr>';
										}
										database_table.$batch_success_table({ title: '批量同步数据库', th: '数据库名', html: html });
										database_table.$refresh_table_list(true);
									});
								});
							},
						},

						{
							title: '备份数据库',
							url: bt.data.db_tab_name == 'mysql' ? 'database?action=ToBackup' : '/database/' + bt.data.db_tab_name + '/ToBackup',
							load: true,
							param: function (row) {
								return bt.data.db_tab_name == 'mysql' ? { id: row.id } : { data: JSON.stringify({ id: row.id }) };
							},
							callback: function (that) {
								// 手动执行,data参数包含所有选中的站点
								that.start_batch({}, function (list) {
									var html = '';
									for (var i = 0; i < list.length; i++) {
										var item = list[i];
										html +=
											'<tr><td>' +
											item.name +
											'</td><td><div style="float:right;"><span style="color:' +
											(item.request.status ? '#20a53a' : 'red') +
											'">' +
											item.request.msg +
											'</span></div></td></tr>';
									}
									database_table.$batch_success_table({ title: '批量备份数据库', th: '数据库名', html: html });
									database_table.$refresh_table_list(true);
								});
							},
						},
						{
							title: '删除数据库',
							url: '/database?action=DeleteDatabase',
							load: true,
							param: function (row) {
								return {
									id: row.id,
									name: row.name,
								};
							},
							callback: function (config) {
								// 手动执行,data参数包含所有选中的站点
								var ids = [];
								for (var i = 0; i < config.check_list.length; i++) {
									ids.push(config.check_list[i].id);
								}
								database.del_database(config.check_list, function (param) {
									config.start_batch(param, function (list) {
										layer.closeAll();
										var html = '';
										for (var i = 0; i < list.length; i++) {
											var item = list[i];
											html +=
												'<tr><td>' +
												item.name +
												'</td><td><div style="float:right;"><span style="color:' +
												(item.request.status ? '#20a53a' : 'red') +
												'">' +
												item.request.msg +
												'</span></div></td></tr>';
										}
										database_table.$batch_success_table({
											title: '批量删除',
											th: '数据库名称',
											html: html,
										});
										database_table.$refresh_table_list(true);
									});
								});
							},
						},
					],
				},
				{
					type: 'search',
					positon: ['right', 'top'],
					placeholder: '请输入数据库名称/备注',
					searchParam: 'search', //搜索请求字段，默认为 search
					value: '', // 当前内容,默认为空
				},
				{
					//分页显示
					type: 'page',
					positon: ['right', 'bottom'], // 默认在右下角
					pageParam: 'p', //分页请求字段,默认为 : p
					page: 1, //当前分页 默认：1
					numberParam: 'limit', //分页数量请求字段默认为 : limit
					number: 20, //分页数量默认 : 20条
					numberList: [10, 20, 50, 100, 200], // 分页显示数量列表
					numberStatus: true, //　是否支持分页数量选择,默认禁用
					jump: true, //是否支持跳转分页,默认禁用
				},
			],
			success: function (config) {
				// $('.pull-left button')
				// 	.eq(4)
				// 	.html('<span style="position:relative"><span class="new-file-icon new-ltd-icon" style="position:absolute;top:-2px"></span><span style="margin-left:22px">企业增量备份</span></span>');
				//搜索前面新增数据库位置下拉
				if ($('.database_type_select_filter').length == 0) {
					var _option = '<option value="all">全部</option>';
					$.each(cloudDatabaseList, function (index, item) {
						var _tips = item.ps != '' ? item.ps : item.db_host;
						_option += '<option value="' + item.id + '">' + _tips + '</option>';
					});
					$('#bt_database_table .bt_search').before('<select class="bt-input-text mr5 database_type_select_filter" style="width:110px" name="db_type_filter">' + _option + '</select>');

					//事件
					$('.database_type_select_filter').change(function () {
						database_table.config.page.page = 1;
						database_table.$refresh_table_list(true);
					});
				}
				//搜索历史
				var show = true
				var advancedSetUpHtml = '\
					<div class="btn-group advancedSetUpHtml" style="margin-right: 30px">\
    				<button type="button" class="btn btn-default base-btn advanced_set_up_click" style="height: 100%;font-size: 12px" ">高级设置</button>\
    				<button type="button" class="btn btn-default dropdown-toggle advanced_set_up_hover" style="display: flex;align-items: center;justify-content: center;height: 100%;">\
    				    <svg width="12.000000" height="12.000000" viewBox="0 0 12 5" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
    				        <desc>\
    				            Created with Pixso.\
    				        </desc>\
    				        <defs></defs>\
    				        <path id="path" d="M0.123291 0.809418L4.71558 5.84385C4.8786 6.02302 5.16846 6.04432 5.33038 5.86389L9.87927 0.783104C10.0412 0.602676 10.04 0.311989 9.87701 0.132816C9.79626 0.0446892 9.68945 0 9.58374 0C9.47693 0 9.36938 0.0459404 9.28827 0.136574L5.02881 4.89284L0.708618 0.15662C0.627869 0.0684967 0.522217 0.0238075 0.415405 0.0238075C0.307434 0.0238075 0.20105 0.0697479 0.119873 0.160381C-0.041626 0.338303 -0.0393677 0.630241 0.123291 0.809418Z" fill-rule="nonzero" fill="' + (show ? '#20A53A' : '#999999') + '"></path>\
    				    </svg>\
    				</button>\
    				<ul class="dropdown-menu bt_select_list advanced_set_up" >\
    				    <li>\
    				        <a id="database">远程数据库管理</a>\
    				    </li>\
    				    <li>\
    				        <a >全量备份</a>\
    				    </li>\
    				    <li>\
    				        <a >增量备份</a>\
    				    </li>\
    				    <li>\
    				        <a >MySQL执行日志</a>\
    				    </li>\
    				    <li>\
    				        <a >MySQL用户管理</a>\
    				    </li>\
						<li>\
							<a >MySQL全文搜索</a>\
						</li>\
						<li>\
							<a >关联网站</a>\
						</li>\
    				</ul>\
					</div>\
				'

				$('#bt_database_table .pull-left').css({'display': 'flex'})
				var syncHoverTime
				if ($('#bt_database_table .pull-left').find('.btn-group').length == 0) {
					$($('#bt_database_table .pull-left').find('button')[2]).after(advancedSetUpHtml)

					if(bt.get_storage("database_advanced")!='true'){
						var layerIndex = layer.tips('<span style="color: #F0AD4E;">更多功能已合并至高级设置</span>', $('.advanced_set_up_click'), {
							tips: [1, '#FDF6EC'],
							time:0
						})
						$('.advancedSetUpHtml').hover(function(){
							layer.close(layerIndex)
							bt.set_storage('database_advanced',true)
						})
					}

					if($('#bt_database_table .db_sync_setting').length == 0){
						db_public_fn.get_sync_all_server('#bt_database_table','.advancedSetUpHtml')
					}
					$('.advanced_set_up_hover').find('svg').find('path').attr('fill', '#999999')
					$('.advanced_set_up_hover').hover(function () {
						$(this).find('svg').find('path').attr('fill', '#20A53A')
					},function () {
						$(this).find('svg').find('path').attr('fill', '#999999')
					})

					var advancedSetUpHoverTime
					$('.advanced_set_up_hover').hover(function () {
						$('.advanced_set_up').addClass('show')
					}, function () {
						advancedSetUpHoverTime = setTimeout(function () {
							$('.advanced_set_up').removeClass('show')
						}, 100)
					})
					$('.advanced_set_up').mouseenter(function () {
						clearTimeout(advancedSetUpHoverTime)
					})
					$('.advanced_set_up').mouseleave(function () {
						$('.advanced_set_up').removeClass('show')
					})
					$('.advanced_set_up li').off().click(function () {
						var that = this
						openAdvancedSetUp($(that).index())

					})
				}
				$('.advanced_set_up_click').off().click(function () {
					openAdvancedSetUp()
				})

				function openAdvancedSetUp(type) {
					var _this = this;
					bt.open({
						type: 1,
						area: ['950px', '700px'],
						title: 'MySQL 高级设置',
						closeBtn: 2,
						shift: 0,
						content:
							"<div class='bt-tabs'><div class='bt-w-menu site-menu pull-left' style='height: 100%;width: 126px;display: flex;    flex-direction: column;'></div><div id='advance-con' class='bt-w-con webedit-con pd15' style='margin-left: 126px;'></div></div>",
					});
					setTimeout(function () {
						var menus = [
							{ title: '远程数据库', callback: function () { return db_public_fn.get_cloud_server_list(true) } },
							{ title: '全量备份', callback: function () { return database.backup_all(true) } },
							{ title: '增量备份', callback: function () { return database.get_backup(true) } },
							{ title: 'MySQL执行日志', callback: function () { return dbBinlogAnalysis.init() } },
							{ title: 'MySQL用户管理', callback: function () { return database.user_management(true) } },
							{ title: 'MySQL全文搜索', callback: function () { return db_public_fn.sensitive_words.init() } },
							{ title: '关联网站', callback: function () { return database.set_associated_service(true) } },
						];
						for (var i = 0; i < menus.length; i++) {
							var men = menus[i];
							var _p = $('<p style="display:flex;flex-direction: row;align-items: center;">' + men.title + '</p>');
							_p.data('callback', men.callback);
							$('.site-menu').append(_p);
						}
						$('.site-menu p').css('padding-left', '25px');
						$('.site-menu p').click(function () {
							$('#advance-con').html('');
							$(this).addClass('bgw').siblings().removeClass('bgw');
							var callback = $(this).data('callback');
							if (callback) callback();
						});
						if (type) {
							$('.site-menu p').eq(type).click();
						}else {
							$('.site-menu p').eq(0).click();
						}

					}, 100);
				}
				if($('#bt_database_table .tootls_top .pull-left .bt-desired').length === 0){
					$('#bt_database_table .tootls_top .pull-left').append('<span class="bt-desired ml10" style="background-size: 16px;background-position: left;"><a href="javascript:;" class="btlink ml5 npsFeedback">需求反馈</a></span>')
					// 数据库nps入口
					$('.npsFeedback').on('click',function(){
						bt_tools.nps({name:'数据库',type:12})
					})
				}
			},
		});

		$('#bt_database_table .pull-right .bt_search .search_input').css('width', '300px');
		var recomList = ['增量备份', '远程数据库', 'MySQL执行日志', 'MySQL全文搜索', 'MySQL用户管理', 'MySQL容量限制'],_recomHtml = ''
		for(var i = 0; i<recomList.length;i++){
			_recomHtml += '<div><span class="item_box">'+recomList[i]+'</span></div>'
		}
		$('#bt_database_table .pull-right .bt_search').append(
			'<div id="search_history" style="width:400px;margin-left: -100px;position:absolute;z-index:99;background:#fff;display:none;transitoin:all .3s;box-shadow: 4px 4px 8px rgba(0, 0, 0, .1), -4px -4px 8px rgba(0, 0, 0, .1);top:35px;border-radius:5px"><div class="history_list_box"><div style="display:flex;flex-direction:row;align-items:center;justify-content:space-between;border-bottom:1px solid #EBEEF5;padding:5px 10px"><span style="font-size: 12px;color:#999">搜索历史</span><div id="all_delete" style="width:52px;height:24px;border:1px solid #DCDFE6;color:#999;font-size:12px;display:flex;align-items:center;cursor:pointer;border-radius:2px;justify-content:space-evenly;flex-direction:row"><img class="all_img" style="width:14px;height:14px" src="/static/img/soft_ico/deletes.png" alt="清除">清空</div></div>\
			<div class="list_box_bottom"><div class="list_box_body"></div></div>\
        <div class="list_box_recom">\
          <div>\
            <span>您可能感兴趣</span>\
            <img class="ml5" style="width:14px;height:14px;vertical-align: -2px;" src="/static/images/hots.png">\
          </div>\
          <div class="list_box_recom_body">'+ _recomHtml +'</div>\
        </div>\
			</div></div>'
		);
		$('#bt_database_table .pull-right .bt_search .item_box').unbind('click').click(function(){
			var idx = $(this).parent().index()
			// 获取表格tbody第一行最后一个td下的a标签长度
			if(idx !== 5) $('#bt_database_table .advanced_set_up_click').click()
			else {
				// 获取表格tbody第一行最后一个td下的a标签长度
				var tdLen = $('#bt_database_table tbody tr:eq(0) td').length
				if(tdLen <= 2) {
					return layer.msg('暂无数据库，请先添加数据库',{icon:2})
				}
			}
			setTimeout(function(){
				switch(idx){
					case 0:// 增量备份
						$('.site-menu p').eq(2).click()
						break;
					case 2:// MySQL执行日志
						$('.site-menu p').eq(3).click()
						break;
					case 3:// MySQL全文搜索
						$('.site-menu p').eq(5).click()
						break;
					case 4:// MySQL用户管理
						$('.site-menu p').eq(4).click()
						break;
					case 5:// MySQL容量限制
						$('#bt_database_table tbody tr:eq(0) td:eq(4) a').click()
						break;
				}
			},100)
		})
		$('#bt_database_table .pull-right .bt_search')
			.find('[placeholder="请输入数据库名称/备注"]')
			.focus(function () {
				$(document).click(function (event) {
					if (!$(event.target).closest('#search_history').length) {
						if (!$(event.target).is(':input')) {
							$('#search_history').css('display', 'none');
							$(this).unbind('click');
						}
					}
				});
				$('#search_history').css('display', 'block');
				$('.list_box_body').empty();
				if (_this.search_hi.search_history.length > 0) {
					$.each(_this.search_hi.search_history, function (index, item) {
						$('#bt_database_table .pull-right .bt_search')
							.find('.list_box_body')
							.append(
								'<div class="body_item" style="color:#999;cursor:pointer;display:flex;justify-content:space-between;align-items:center;padding-left:10px;padding-right:5px;border-radius:3px" data-name="' +
								item.val +
								'"><span id="history_text">' +
								item.val +
								'</span><div class="delete_single" data-name="' +
								item.val +
								'" style="width:20px;text-align:center"></div></div>'
							);
					});
					$('#bt_database_table .pull-right .bt_search')
						.find('#search_history')
						.find('.history_list_box')
						.find('.list_box_body')
						.find('.body_item')
						.click(function () {
							$('#bt_database_table .pull-right .bt_search').find('[placeholder="请输入数据库名称/备注"]').val($(this).data('name'));
							// database_table.$refresh_table_list(true);
						});
					$('#bt_database_table .pull-right .bt_search')
						.find('#search_history')
						.find('.history_list_box')
						.find('.list_box_body')
						.find('.body_item')
						.hover(
							function () {
								$(this).css('color', '#333');
								$(this).find('.delete_single').append('<img class="delete_img" style="width:8px;height:8px" src="/static/images/delete_single.png" />');
								$(this).css('background', 'rgb(245, 245, 245)');
							},
							function () {
								$(this).css('color', '#999');
								$(this).find('.delete_single').find('.delete_img').remove();
								$(this).css('background', 'none');
							}
						);
				} else {
					$('#bt_database_table .pull-right .bt_search').find('.list_box_body').append('<span style="color:#999">暂无数据</span>');
				}
				$('.delete_single').click(function (event) {
					event.stopPropagation();
					var names = $(this).data('name')
					var cload = layer.msg('正在删除中...', { icon: 16 })
					bt.confirm({ msg: '是否删除改记录？', title: '删除历史记录' }, function () {
						bt_tools.send({ url: '/panel/history/remove_search_history', data: { name: 'databases', key: 'get_list', val: names } }, function (ress) {
							layer.close(cload);
							layer.msg(ress.msg, { icon: ress.status ? 1 : 2 });
							_this.search_hi.search_history = _this.search_hi.search_history.filter(function(obj) {
								return obj.val !== names;
							});
						});
					});
				})
			});
		$('#all_delete').hover(
			function () {
				$(this).css({
					color: '#20a53a',
					border: '1px solid #20a53a',
				});
				$(this).find('.all_img').attr('src', '/static/img/soft_ico/deletes_hover.png');
				$(this).find('.all_img').css('width', '14px');
				$(this).find('.all_img').css('height', '14px');
				$(this).css('background', '#F1F9F3');
			},
			function () {
				$(this).css({
					color: '#999',
					border: '1px solid #DCDFE6',
				});
				$(this).find('.all_img').attr('src', '/static/img/soft_ico/deletes.png');
				$(this).find('.all_img').css('width', '14px');
				$(this).find('.all_img').css('height', '14px');
				$(this).css('background', 'none');
			}
		);
		$('#all_delete').click(function () {
			var dload = layer.msg('正在清空中...', { icon: 16 });
			bt.confirm({ msg: '是否清空所有历史记录？', title: '清空历史记录' }, function () {
				bt_tools.send({ url: '/panel/history/clear_search_history', data: { name: 'databases', key: 'get_list' } }, function (ress) {
					layer.close(dload);
					layer.msg(ress.msg, { icon: ress.status ? 1 : 2 });
					_this.search_hi.search_history = [];
				});
			});
		});
		// 运行环境
		db_public_fn.show_run_panel();
	},
	//用户管理
	user_management:function(type){
		var searchList = []
		function createTable(){
			var user_table = bt_tools.table({
				el: '#allUser',
				url: '/database?action=GetMysqlUser',
				height:'325',
				default: '用户列表为空', //数据为空时的默认提示
				dataFilter:function(res){
					var data = res
					var a = $('#allUser .pull-right .search_input')
					if(a.val() != ''){
						data = searchList
					}
					return {data:data}
				},
				column: [
					// { type: 'checkbox', class: '', width: 20 },
					{
						title: '用户名',
						width:150,
						template: function (row) {
							return '<span style="width:150px;display:block;overflow:hidden;white-space:nowrap;text-overflow:ellipsis" title="' + row.user + '">' + row.user + '</span>';
						},
					},
					{
						width:50,
						title: '用户密码',
						fid: 'password',
						type: 'text',
						template: function (row) {
							return '<span style="width:50px;display:block;overflow:hidden;white-space:nowrap;text-overflow:ellipsis">' + (row.password == 'yes'? '有':'无') + '</span>';
						},
					},
					{
						fid: 'host',
						title: '访问权限',
						type: 'text',
						template: function (row) {
							return '<span style="display:block;overflow:hidden;white-space:nowrap;text-overflow:ellipsis">' + (row.host == '%'? '所有人':row.host) + '</span>';
						},
					},
					{
						fid: 'database',
						title: '关联数据库',
						width:100,
						type: 'link',
						template: function (row, index) {
							if(row.database_access.length == 0){
								return '<span class="noDatabase">无</span>'
							}
							return '<span class="clickShow"><a href="javascript:;" class="btlink">点击查看</a></span>'
						},
						event: function (row, index, ev) {
							//点击链接时
							ev.stopPropagation()
							if($(ev.target).hasClass('noDatabase')){
								return
							}
							bt_tools.table({
								el:'#showDatabase',
								default:'暂无数据',
								height: '150px',
								data:row.database_access,
								column:[
									{
										fid: 'database',
										title: '数据库名',
										width:100,
										type: 'text',
										template: function (item) {
											return '<span class="name" title="'+ (item.database) +'">'+ (item.database) +'</span>'
										},
									},
									{
										fid: 'access',
										title: '权限',
										type: 'text',
										width:220,
										template: function (item) {
											return '<span title="'+ (item.access) +'">'+ (item.access) +'</span>'
										},
									},
								]
							})
							$('#showDatabase').css({top:(ev.pageY - $('#allUser').offset().top) + 'px',left:'65px'})
							$('#showDatabase').show()
							setTimeout(function(){
								$(document).one('click',function(){
									$('#showDatabase').hide()
								})
							},200)
						},
					},
					{
						fid: 'gloal_access',
						title: '全局权限',
						type: 'text',
					},
					{
						title: '操作',
						type: 'group',
						width: 140,
						align: 'right',
						group: [
							// {
							// 	title: '编辑',
							// 	event: function (row) {
							// 			// window.open('/download?filename=' + row.path + '&amp;name=' + row.name);

							// 	},
							// },
							{
								title: '改密',
								event: function (row, index, ev, key, that) {
									if(row.user == 'root' && row.host == 'localhost'){
										return bt_tools.msg('该用户无法改密',{icon:2})
									}
									bt_tools.open({
										title:'标题',
										area:['450px','330px'],
										btn:['确定','取消'],
										content:{//配置请查看表单form方法中的类型
											class:'pd20 setPwd',
											form:[{
												label:'用户名',
												group:{
													name: 'username',
													type: 'text',
													width:'260px',
													value:row.user,
													disabled:true,
												}
											},{
												label:'访问权限',
												group:{
													name: 'host',
													type: 'text',
													width:'260px',
													value:row.host == '%'? '所有人':(row.host == 'localhost'? '本地服务器':row.host),
													disabled:true,
												}
											},{
												label:'新密码',
												group:{
													name: 'password',
													type: 'text',
													width:'260px',
													icon: { type: 'glyphicon-repeat'},
												}
											},]
										},
										success:function(){
											//打开弹窗后执行的事件
											$('.setPwd').append('<ul class="help-info-text c7" style="margin: 26px 0 0 37px;"><li>此处改密不会同步至 数据库-密码展示界面 请注意更改</li></ul>')
											$('.setPwd input[name=password]').addClass('pwd')
											bt.refresh_pwd(12, 'pwd')
											$('.setPwd .glyphicon-repeat').off('click').on('click',function(){
												bt.refresh_pwd(12, 'pwd')
											})
										},
										yes:function(formD,indexs){
											//formD会获取配置中name的集合数据
											//indexs可用于完成操作后关闭弹窗layer.close(indexs)
											if(formD.password == ''){
												return bt_tools.msg('请输入密码',{iocn:2})
											}
											bt_tools.send({url:'/database?action=ChangeUserPass',data:{username:row.user,password:formD.password,host:row.host,}},function(ress){
												//请求回调
												bt_tools.msg(ress)
												if(ress.status){
													$('#allUser .pull-right .search_input').val('')
													that.$refresh_table_list()
													layer.close(indexs)
												}
											},'修改密码')
										},
										btn2:function(){
											// 取消按钮
										}
									})
								},
							},
							{
								title: '导出',
								event: function (row, index, ev, key, that) {
									that.output(row,function (res) {
										var arr = res.split('\n')
										var div = ''
										$.each(arr,function(index,item){
											div += '<div>'+ item +'</div>'
										})
										bt_tools.open({
											title:'导出【' + row.user + '】数据',
											area:['540px','360px'],
											btn:false,
											content:'<div id="">\
														<div class="batch_title"><span class=""><span class="batch_icon"></span><span class="batch_text">导出成功！</span></span></div>\
														<div class=" batch_tabel divtable" style="margin: 15px 30px 15px 30px;overflow: auto;height: 200px;">\
														<table class="table table-hover"><thead>\
														<tr><th>用户权限</th><th style="text-align:right;width:50px;">操作</th></tr></thead><tbody><tr>\
														<td title="'+ res +'">'+ div +'</td>\
														<td style="text-align: right;"><span style="width: 50px;"><a class="btlink copyOut" title="复制">复制</a></span></td>\
														</tr></tbody></table></div>\
														</div>',
											success:function(){
												$('.copyOut').off('click').on('click',function(){
													bt.pub.copy_pass(res)
												})
											}
										})
									})
								},
							},
							{
								title: '删除',
								event: function (row, index, ev, key, that) {
									if(row.user == 'root' && row.host == 'localhost'){
										return bt_tools.msg('该用户无法删除',{icon:2})
									}
									that.del_site_backup(row, function (rdata) {
										bt_tools.msg(rdata);
										if (rdata.status) {
											$('#allUser .pull-right .search_input').val('')
											that.$refresh_table_list();
										}
									});
								},
							},
						],
					},
				],
				methods: {
					/**
					 * @description 删除
					 * @param {object} config
					 * @param {function} callback
					 */
					del_site_backup: function (config, callback) {
						bt.confirm(
							{ title: '删除Mysql用户[' + config.user + ']', msg: '删除选中用户后，<span class="color-red">该用户将无法访问数据库</span>，是否继续操作？' },
							function () {
								bt_tools.send(
									'database/DelMysqlUser',
									{ username:config.user,host:config.host },
									function (rdata) {
										if (callback) callback(rdata);
									},
									true
								);
							}
						);
					},
					/**
					 * @description 导出
					 * @param {object} row
					 * @param {function} callback
					 */
					output: function (row, callback) {
						bt_tools.send(
							'database/GetUserGrants',
							{ username:row.user,host:row.host },
							function (rdata) {
								if (callback) callback(rdata);
							},
							{load:'导出',verify:false}
						);
					},
				},
				success: function () {
					$('#allUser').parent().css({overflow:'inherit'})
					$('ul.c7','#allUser').remove()
					$('#allUser').append('<ul class="help-info-text c7" style="position: absolute;top:388px;left:28px;">\
							<li>说明：此处用户数据为连接mysql直接获取，未与面板数据库连接，建议仅对此处新建的用户进行操作，以防出现意外</li>\
							<li>访问权限：localhost/127.0.0.1:仅限本机访问 %：允许任何人访问 IP地址：仅限此IP地址访问（不含本机）</li>\
							<li>全局权限：全局权限是指对所有数据库拥有的权限  ALL PRIVILEGES即root最高权限，USAGE为普通用户，拥有指定数据库指定权限（关联数据库权限）</li>\
							</ul>')
					$('.dividing-line','#allUser').remove()
					$('#showDatabase').remove()
					$('#allUser .pull-left button:eq(1)').after('<div class="inlineBlock dividing-line" style="margin: 0 10px 0 5px;"></div>')
					$('#allUser').append('<div id="showDatabase"></div>')
					$('#showDatabase').off('click').on('click',function(e){
						e.stopPropagation()
						e.preventDefault()
					})
				},
				tootls: [
					{
						// 按钮组
						type: 'group',
						positon: ['left', 'top'],
						list: [
							{
								title: '添加用户',
								active: true,
								event: function (ev, that) {
									var table = that
									var auth = null
									// 全局权限
									var allPermissions = [
										[{ name: "数据权限", description: "数据权限" },{ name: "SELECT", description: "允许用户查询（读取）数据库中的数据。",msg:'读取数据' },
											{ name: "INSERT", description: "允许用户向数据库表中插入新数据。",msg:'插入/替换数据' },
											{ name: "UPDATE", description: "允许用户修改数据库表中的数据。",msg:'修改数据' },
											{ name: "DELETE", description: "允许用户从数据库表中删除数据。",msg:'删除数据' },
											{ name: "FILE", description: "允许用户读取或写入文件。",msg:'文件读取/写入' }],
										[{ name: "结构权限", description: "结构权限" },{ name: "CREATE", description: "允许用户创建新的数据库、表格或索引。",msg:'创建数据库/表' },
											{ name: "ALTER", description: "允许用户修改数据库表的结构（例如，添加、删除列）。",msg:'修改表结构' },
											{ name: "INDEX", description: "允许用户创建和删除索引，以提高查询性能。",msg:'创建/删除索引' },
											{ name: "DROP", description: "允许用户删除数据库、表格或索引。",msg:'删除数据库/表' },
											{ name: "CREATE TEMPORARY TABLES", description: "允许用户创建临时表格，这些表格在会话结束后会自动删除。",msg:'创建临时表格' },
											{ name: "SHOW VIEW", description: "允许用户查看数据库中的视图。",msg:'查看视图' },
											{ name: "CREATE ROUTINE", description: "允许用户创建存储过程和函数。",msg:'创建存储过程/函数' },
											{ name: "ALTER ROUTINE", description: "允许用户修改存储过程和函数。",msg:'修改存储过程/函数' },
											{ name: "EXECUTE", description: "允许用户执行存储过程和函数。",msg:'执行存储过程/函数' },
											{ name: "CREATE VIEW", description: "允许用户创建数据库中的视图。",msg:'创建视图' },
											{ name: "EVENT", description: "允许用户创建、修改和删除数据库事件。",msg:'创建/修改/删除事件' },
											{ name: "TRIGGER", description: "允许用户创建和管理数据库触发器。",msg:'创建/管理触发器' }],
										[{ name: "管理权限", description: "管理权限" },{ name: "GRANT", description: "允许用户授予、撤销或管理其他用户的权限。",msg:'添加用户/权限,不重载权限' },
											{ name: "SUPER", description: "允许用户执行特殊操作，如启动或停止数据库服务器。",msg:'达到最大连接数时,杀死其他用户进程' },
											{ name: "PROCESS", description: "允许用户查看其他用户的数据库连接进程。",msg:'查看其他用户的连接进程' },
											{ name: "RELOAD", description: "允许用户重新加载数据库服务器的配置。",msg:'重载数据库的配置' },
											{ name: "SHUTDOWN", description: "允许用户关闭数据库服务器。",msg:'关闭数据库服务器' },
											{ name: "SHOW DATABASES", description: "允许用户查看可用的数据库列表。",msg:'查看可用的数据库列表' },
											{ name: "LOCK TABLES", description: "允许用户锁定表格，以控制并发访问。",msg:'锁定表格' },
											{ name: "REFERENCES", description: "允许用户创建和使用外键，以维护数据完整性。",msg:'创建/使用外键' },
											{ name: "REPLICATION CLIENT", description: "允许用户作为复制客户端连接到主从复制系统。",msg:'作为复制客户端连接到主从复制系统' },
											{ name: "REPLICATION SLAVE", description: "允许用户作为复制从属连接到主从复制系统。",msg:'作为复制从属连接到主从复制系统' },
											{ name: "CREATE USER", description: "允许用户创建、更改和删除数据库用户账户。",msg:'创建/更改/删除数据库用户' }]
									];
									// 关联数据库权限
									var permissions = [
										[{ name: "数据权限", description: "数据权限",select:true },{ name: "SELECT", description: "允许用户查询（读取）数据库中的数据。",select:true,msg:'读取数据' },
											{ name: "INSERT", description: "允许用户向数据库表中插入新数据。",select:true,msg:'插入/替换数据' },
											{ name: "UPDATE", description: "允许用户修改数据库表中的数据。",select:true,msg:'修改数据' },
											{ name: "DELETE", description: "允许用户从数据库表中删除数据。",select:true,msg:'删除数据' }],
										[{ name: "结构权限", description: "结构权限",select:true },{ name: "CREATE", description: "允许用户创建新的数据库、表格或索引。",select:true,msg:'创建数据库/表' },
											{ name: "ALTER", description: "允许用户修改数据库表的结构（例如，添加、删除列）。",select:true,msg:'修改表结构' },
											{ name: "INDEX", description: "允许用户创建和删除索引，以提高查询性能。",select:true,msg:'创建/删除索引' },
											{ name: "DROP", description: "允许用户删除数据库、表格或索引。",select:true,msg:'删除数据库/表' },
											{ name: "CREATE TEMPORARY TABLES", description: "允许用户创建临时表格，这些表格在会话结束后会自动删除。",select:true,msg:'创建临时表格' },
											{ name: "SHOW VIEW", description: "允许用户查看数据库中的视图。",select:true,msg:'查看视图' },
											{ name: "CREATE ROUTINE", description: "允许用户创建存储过程和函数。",select:true,msg:'创建存储过程/函数' },
											{ name: "ALTER ROUTINE", description: "允许用户修改存储过程和函数。",select:true,msg:'修改存储过程/函数' },
											{ name: "EXECUTE", description: "允许用户执行存储过程和函数。",select:true,msg:'执行存储过程/函数' },
											{ name: "CREATE VIEW", description: "允许用户创建数据库中的视图。",select:true,msg:'创建视图' },
											{ name: "EVENT", description: "允许用户创建、修改和删除数据库事件。",select:true,msg:'创建/修改/删除事件' },
											{ name: "TRIGGER", description: "允许用户创建和管理数据库触发器。",select:true,msg:'创建/管理触发器' }],
										[{ name: "管理权限", description: "管理权限",include:true },{ name: "GRANT", description: "允许用户授予、撤销或管理其他用户的权限。",msg:'添加用户/权限,不重载权限' },
											{ name: "LOCK TABLES", description: "允许用户锁定表格，以控制并发访问。",select:true,msg:'锁定表格' },
											{ name: "REFERENCES", description: "允许用户创建和使用外键，以维护数据完整性。",select:true,msg:'创建/使用外键' }]
									];
									var tabConfig = bt_tools.tab({
										class: 'pd20',
										type: 0,
										theme: { nav: 'ml0'},
										active: 1, //激活TAB下标
										list:[{
											title: '添加用户',
											name: 'add',
											content: '<div id="add_user"></div>',
											success: function () {
												auth = bt_tools.form({
													el:'#add_user',
													form:[
														{
															label: '用户名',
															group: {
																type: 'text',
																name: 'username',
																width: '390px',
																placeholder:'请填写用户名'
															}
														},
														{
															label: '密码',
															group: {
																type: 'text',
																name: 'password',
																width: '390px',
																placeholder:'请填写密码',
																icon: { type: 'glyphicon-repeat'},
															},
														},
														{
															label: '访问权限',
															group:[{
																type: 'select',
																name: 'auth',
																width: '150px',
																list: [{title:'本地服务器',value:'localhost'},{title:'所有人',value:'%'},{title:'指定ip',value:'ip'},],
																change: function (formData, element, that) {
																	// 选中下拉项后
																	if(formData.auth == 'ip'){
																		that.config.form[2].group[1].display = true
																	}else{
																		that.config.form[2].group[1].display = false
																	}
																	that.$replace_render_content(2);
																}
															},{
																type: 'text',
																name: 'host',
																width: '230px',
																style: 'margin-right:0px;height:30px;',
																placeholder:'请填写ip',
																display:false
															}]
														},
														{
															label: '数据库权限关联',
															group:[{
																type: 'select',
																name: 'type',
																width: '150px',
																list: [{title:'数据库',value:'permissions'},{title:'全局权限',value:'allPermissions'},],
																change: function (formData, element, that) {
																	// 选中下拉项后
																	if(formData.type == 'permissions'){
																		that.config.form[3].group[1].display = true
																		that.config.form[3].group[1].value = that.config.form[3].group[1].list[0].value
																		renderAuthList(permissions)
																	}else{
																		that.config.form[3].group[1].display = false
																		renderAuthList(allPermissions)
																	}
																	that.$replace_render_content(3);
																}
															},{
																type: 'select',
																name: 'dbname',
																width: '230px',
																list: {
																	url: '/database?action=GetDatabasesList',
																	dataFilter: function (res, that) {
																		var arr = []
																		$.each(res,function(index,item){
																			arr.push({title:item,value:item})
																		})
																		return arr
																	},
																},
																change: function (formData, element, that) {
																	// 选中下拉项后

																}
															}]
														},
														{
															label: '基础权限',
															group:{
																name: '',
																type: 'other',
																boxcontent:'<div id="selectAuth"></div>'
															}
														},
													]
												})
												// 随机刷新密码
												$('#add_user input[name=password]').addClass('pwd')
												bt.refresh_pwd(12, 'pwd')
												$('#add_user .glyphicon-repeat').off('click').on('click',function(){
													bt.refresh_pwd(12, 'pwd')
												})
												renderAuthList(permissions)
												//渲染权限列表
												function renderAuthList(list){
													var str = ''
													$.each(list,function(index,item){
														str += '<div class="type">'
														$.each(item,function(i,items){
															if(i == 0){
																str += '<div class="all box '+ (items.include? 'include':'') +' '+ (items.select? 'select':'') +'" title="'+ items.description +'"><span class="glyphicon check-mark '+ (items.select? 'glyphicon-ok':'') +'"></span>'+ items.name +'</div>'
															}else{
																str += '<div class="box '+ (items.select? 'select':'') +'" title="'+ items.description +'" data-value="'+ items.name +'"><span class="glyphicon check-mark '+ (items.select? 'glyphicon-ok':'') +'"></span>'+ (items.name + '-- 【' + items.msg + '】') +'</div>'
															}
														})
														str += '</div>'
													})
													var selectAuth = $('#selectAuth')
													selectAuth.html(str)
													selectAuth.find('.box:not(.all)').css({marginLeft:'40px'})
													selectAuth.find('.box').off('click').on('click',function(){
														if($(this).hasClass('all')){// 选择的是all
															$(this).removeClass('include')
															if($(this).hasClass('select')){// 取消全选
																$(this).siblings().removeClass('select')
																$(this).siblings().find('span').removeClass('glyphicon-ok')
															}else{// 全选
																$(this).siblings().addClass('select')
																$(this).siblings().find('span').addClass('glyphicon-ok')
															}
														}else{// 选择的是其它
															$(this).siblings('.all').addClass('include')
															if($(this).hasClass('select')){// 取消选择,检验是否全空
																$(this).siblings('.all').removeClass('select')
																$(this).siblings('.all').find('span').removeClass('glyphicon-ok')
																var isEmpty = true
																if($(this).siblings('.box:not(.all)').hasClass('select')){
																	isEmpty = false
																}
																if(isEmpty){
																	$(this).siblings('.all').removeClass('include')
																	$(this).siblings('.all').removeClass('select')
																	$(this).siblings('.all').find('span').removeClass('glyphicon-ok')
																}
															}else{// 选择,检验是否全选
																var allClass = true; // 假设所有节点都有 select

																$(this).siblings('.box:not(.all)').each(function() {
																	if (!$(this).hasClass("select")) {
																		allClass = false;
																		return false; // 如果有一个节点没有 "select" 类，立即退出循环
																	}
																});
																if(allClass){
																	$(this).siblings('.all').removeClass('include')
																	$(this).siblings('.all').addClass('select')
																	$(this).siblings('.all').find('span').addClass('glyphicon-ok')
																}
															}
														}
														$(this).toggleClass('select')
														$(this).find('span').toggleClass('glyphicon-ok')
													})
												}


											}
										},
											// {
											// 		title: '快速添加',
											// 		name: 'quick',
											// 		content: '<div id="quick"></div>',
											// 		success: function () {
											// 		}
											// }
										]
									})
									bt_tools.open({
										title:'添加Mysql用户',
										area:['600px','590px'],
										btn:['确认','取消'],
										content:'<div id="add_user" class="pd20" style="padding-left:39px;"></div>',
										// content:tabConfig.$reader_content(),
										success:function(){
											//打开弹窗后执行的事件
											// tabConfig.$init(); //初始化
											//以下代码之后优化要去掉，换成上面的tab页形式
											auth = bt_tools.form({
												el:'#add_user',
												form:[
													{
														label: '用户名',
														group: {
															type: 'text',
															name: 'username',
															width: '390px',
															placeholder:'请填写用户名'
														}
													},
													{
														label: '密码',
														group: {
															type: 'text',
															name: 'password',
															width: '390px',
															placeholder:'请填写密码',
															icon: { type: 'glyphicon-repeat'},
														},
													},
													{
														label: '访问权限',
														group:[{
															type: 'select',
															name: 'auth',
															width: '150px',
															list: [{title:'本地服务器',value:'localhost'},{title:'所有人',value:'%'},{title:'指定ip',value:'ip'},],
															change: function (formData, element, that) {
																// 选中下拉项后
																if(formData.auth == 'ip'){
																	that.config.form[2].group[1].display = true
																}else{
																	that.config.form[2].group[1].display = false
																}
																that.$replace_render_content(2);
															}
														},{
															type: 'text',
															name: 'host',
															width: '230px',
															style: 'margin-right:0px;height:30px;',
															placeholder:'请填写ip',
															display:false
														}]
													},
													{
														label: '数据库权限关联',
														group:[{
															type: 'select',
															name: 'type',
															width: '150px',
															list: [{title:'数据库',value:'permissions'},{title:'全局权限',value:'allPermissions'},],
															change: function (formData, element, that) {
																// 选中下拉项后
																if(formData.type == 'permissions'){
																	that.config.form[3].group[1].display = true
																	that.config.form[3].group[1].value = that.config.form[3].group[1].list[0].value
																	renderAuthList(permissions)
																}else{
																	that.config.form[3].group[1].display = false
																	renderAuthList(allPermissions)
																}
																that.$replace_render_content(3);
															}
														},{
															type: 'select',
															name: 'dbname',
															width: '230px',
															list: {
																url: '/database?action=GetDatabasesList',
																dataFilter: function (res, that) {
																	var arr = []
																	$.each(res,function(index,item){
																		arr.push({title:item,value:item})
																	})
																	return arr
																},
															},
															change: function (formData, element, that) {
																// 选中下拉项后

															}
														}]
													},
													{
														label: '基础权限',
														group:{
															name: '',
															type: 'other',
															boxcontent:'<div id="selectAuth"></div>'
														}
													},
												]
											})
											// 随机刷新密码
											$('#add_user input[name=password]').addClass('pwd')
											bt.refresh_pwd(12, 'pwd')
											$('#add_user .glyphicon-repeat').off('click').on('click',function(){
												bt.refresh_pwd(12, 'pwd')
											})
											renderAuthList(permissions)
											//渲染权限列表
											function renderAuthList(list){
												var str = ''
												$.each(list,function(index,item){
													str += '<div class="type">'
													$.each(item,function(i,items){
														if(i == 0){
															str += '<div class="all box '+ (items.include? 'include':'') +' '+ (items.select? 'select':'') +'" title="'+ items.description +'"><span class="glyphicon check-mark '+ (items.select? 'glyphicon-ok':'') +'"></span>'+ items.name +'</div>'
														}else{
															str += '<div class="box '+ (items.select? 'select':'') +'" title="'+ items.description +'" data-value="'+ items.name +'"><span class="glyphicon check-mark '+ (items.select? 'glyphicon-ok':'') +'"></span>'+ (items.name + '-- 【' + items.msg + '】') +'</div>'
														}
													})
													str += '</div>'
												})
												var selectAuth = $('#selectAuth')
												selectAuth.html(str)
												selectAuth.find('.box:not(.all)').css({marginLeft:'40px'})
												selectAuth.find('.box').off('click').on('click',function(){
													if($(this).hasClass('all')){// 选择的是all
														$(this).removeClass('include')
														if($(this).hasClass('select')){// 取消全选
															$(this).siblings().removeClass('select')
															$(this).siblings().find('span').removeClass('glyphicon-ok')
														}else{// 全选
															$(this).siblings().addClass('select')
															$(this).siblings().find('span').addClass('glyphicon-ok')
														}
													}else{// 选择的是其它
														$(this).siblings('.all').addClass('include')
														if($(this).hasClass('select')){// 取消选择,检验是否全空
															$(this).siblings('.all').removeClass('select')
															$(this).siblings('.all').find('span').removeClass('glyphicon-ok')
															var isEmpty = true
															if($(this).siblings('.box:not(.all)').hasClass('select')){
																isEmpty = false
															}
															if(isEmpty){
																$(this).siblings('.all').removeClass('include')
																$(this).siblings('.all').removeClass('select')
																$(this).siblings('.all').find('span').removeClass('glyphicon-ok')
															}
														}else{// 选择,检验是否全选
															var allClass = true; // 假设所有节点都有 select

															$(this).siblings('.box:not(.all)').each(function() {
																if (!$(this).hasClass("select")) {
																	allClass = false;
																	return false; // 如果有一个节点没有 "select" 类，立即退出循环
																}
															});
															if(allClass){
																$(this).siblings('.all').removeClass('include')
																$(this).siblings('.all').addClass('select')
																$(this).siblings('.all').find('span').addClass('glyphicon-ok')
															}
														}
													}
													$(this).toggleClass('select')
													$(this).find('span').toggleClass('glyphicon-ok')
												})
											}

										},
										yes:function(indexs){
											//点击确定时,如果btn:false,当前事件将无法使用
											var add_user = $('#add_user')
											var username = add_user.find('input[name=username]').val()
											var password = add_user.find('input[name=password]').val()
											var auth = add_user.find('select[name=auth]').val()
											var host = add_user.find('input[name=host]').val()
											var dbname = '*'
											var access = ''
											if(username == ''){
												return bt_tools.msg('请输入用户名',{icon:2})
											}
											if(password == ''){
												return bt_tools.msg('请输入密码',{icon:2})
											}
											if(auth == 'ip'){
												if(host == ''){
													return bt_tools.msg('请输入ip',{icon:2})
												}
											}else{
												host = auth
											}

											if(add_user.find('select[name=type]').val()=='permissions'){
												dbname = add_user.find('select[name=dbname]').val()
											}
											var arr = []
											$('#selectAuth').find('.select').each(function(index,item){
												if(!($(this).hasClass('all'))){
													arr.push($(this).data('value'))
												}
											})
											access = arr.join(',')
											bt_tools.send({url:'/database?action=AddMysqlUser',data:{username:username,password:password,host:host,dbname:dbname,access:access,}},function(ress){
												//请求回调
												if(ress.status){
													bt_tools.msg(ress)
													//重置列表
													$('#allUser .pull-right .search_input').val('')
													table.$refresh_table_list()
													layer.close(indexs)
												}
											},'添加Mysql用户')
										},
										cancel: function () {
											//点击右上角关闭时,如果btn:false,当前事件将无法使用
										}
									})
								},
							},
						],
					},
				],
			});

			// 表格搜索
			$('#allUser .pull-right').html('<div class="bt_search"><input type="text" class="search_input " style="" placeholder="请输入用户名"><span class="glyphicon glyphicon-search search_btn" aria-hidden="true"></span></div>')
			// 任务列表搜索事件绑定
			$('#allUser .pull-right .glyphicon-search')
				.off('click')
				.on('click', function () {
					searchUser($('#allUser .pull-right .search_input').val())
				});
			$('#allUser .pull-right  .search_input')
				.off('focus')
				.on('focus', function () {
					$(document)
						.off('keydown')
						.on('keydown', function (e) {
							if (e.keyCode === 13) {
								searchUser($('#allUser .pull-right .search_input').val())
							}
						});
				});
			$('#allUser .pull-right  .search_input')
				.off('blur')
				.on('blur', function () {
					$(document).off('keydown');
				});
			function searchUser(value){
				bt_tools.send({url:'/database?action=GetUserInfo',data:{username:value}},function(ress){
					//请求回调
					searchList = ress
					user_table.$refresh_table_list()
				},'搜索')
			}
		}

		if (type) {
			$('#advance-con').html('<div id="allUser"></div>')
			createTable()
		} else {
			bt_tools.open({
				title: 'Mysql数据库用户管理',
				area: ['880px', '537px'],
				btn:false,
				content: '<div id="allUser" style="padding:20px;position: relative;"></div>',
				success:function(){
					//打开弹窗后执行的事件
					createTable()
				}
			})
		}
	},
	set_associated_service: function (type) {
		bt.render_associated_service({name: 'database',el: '#advance-con'})
	},
	// 全部备份
	backup_all:function (type){
		function  init(){
			var backup_table = bt_tools.table({
				el: type ? '#advance-con' : '#backupAll',
				url: '/database?action=GetAllBackup',
				height:'325',
				default: '备份列表为空', //数据为空时的默认提示
				column: [
					{ type: 'checkbox', class: '', width: 20 },
					{
						title: '文件名称',
						width: 220,
						template: function (row) {
							return '<span style="width:220px;display:block;overflow:hidden;white-space:nowrap;text-overflow:ellipsis" title="' + row.path + '">' + row.name + '</span>';
						},
					},
					{
						width: 150,
						title: '备份时间',
						type: 'text',
						template: function (row, index) {
							return  '<span>' + bt.format_data(row.mtime) + '</span>'
						},
					},
					{
						fid: 'size',
						title: '文件大小',
						width: 80,
						type: 'text',
						template: function (row, index) {
							return bt.format_size(row.size);
						},
					},
					{
						title: '操作',
						type: 'group',
						width: 140,
						align: 'right',
						group: [
							{
								title: '详情',
								event: function (row, index, ev, key, that) {
									bt_tools.open({
										title:'数据库备份',
										area:'600px',
										btn:false,
										content:'<div id="DetailBackup" style="padding:20px;"></div>',
										success:function(){
											//打开弹窗后执行的事件
											bt_tools.table({
												el:'#DetailBackup',
												url:'/database?action=GetBackupInfo',
												param:{
													file:row.path
												},
												default:'暂无数据',
												height: '350px',
												column:[
													{
														title: '数据库名称',
														width: 220,
														template: function (row) {
															return '<span style="width:220px;display:block;overflow:hidden;white-space:nowrap;text-overflow:ellipsis" title="' + row.name + '">' + row.name + '</span>';
														},
													},
													{
														fid: 'size',
														title: '大小',
														width: 80,
														type: 'text',
														template: function (row, index) {
															return bt.format_size(row.size);
														},
													},
												]
											})
										},
									})
								},
							},
							{
								title: '恢复',
								event: function (row, index, ev, key, that) {
									layer.open({
										type: 1,
										title: '恢复【' + row.name + '】数据',
										icon: 0,
										skin: 'delete_site_layer',
										area: '530px',
										closeBtn: 2,
										shadeClose: true,
										content:
											"<div class='bt-form webDelete hint_confirm' style='padding: 10px 20px 20px;'>" +
											"<div id='DetailBackup'></div>" +
											"<div class='hint_title'>\
                          <i class='hint-confirm-icon'></i>\
                          <div class='hint_con'>" +
											'恢复后会<span style="color:red;font-size:14px;font-weight: bold;">覆盖当前数据库数据</span>，此操作不可逆，是否继续操作？' +
											'</div>\
                        </div>' +
											"<div class='confirm-info-box' style='margin-top: 10px;'>\
                        <div>请手动输入“<span class='color-red'>我已知晓</span>”，完成验证</div>\
                        <input onpaste='return false;' id='prompt_input_box' type='text' value='' autocomplete='off' style='width: 440px;'>\
                      </div>" +
											'</div>',
										btn: ['确认恢复', '取消恢复'],
										yes: function (indexs) {
											var result = bt.replace_all($('#prompt_input_box').val(), ' ', '');
											if (result == '我已知晓') {
												bt_tools.send({url:'/database?action=InputSqlAll',data:{file:row.path}},function(res){
													if(res.status){
														res['code']=-1
														bt.msg(rdata)
														layer.close(indexs)
													}
												},'恢复' + '【' + row.name + '】数据')
											} else {
												$('#prompt_input_box').focus();
												return layer.msg('验证失败，请重新输入', { icon: 2 });
											}
										},
										success: function () {
											$(':focus').blur();
											bt_tools.table({
												el:'#DetailBackup',
												url:'/database?action=GetBackupInfo',
												param:{
													file:row.path
												},
												default:'暂无数据',
												height: '200px',
												column:[
													{
														title: '数据库名称',
														width: 220,
														template: function (row) {
															return '<span style="width:220px;display:block;overflow:hidden;white-space:nowrap;text-overflow:ellipsis" title="' + row.name + '">' + row.name + '</span>';
														},
													},
													{
														fid: 'size',
														title: '大小',
														width: 80,
														type: 'text',
														template: function (row, index) {
															return bt.format_size(row.size);
														},
													},
												]
											})
										},
									});
								},
							},
							{
								title: '下载',
								event: function (row) {
									window.open('/download?filename=' + row.path + '&amp;name=' + row.name);
								},
							},
							{
								title: '删除',
								event: function (row, index, ev, key, that) {
									that.del_site_backup(row, function (rdata) {
										bt_tools.msg(rdata);
										if (rdata.status) {
											that.$refresh_table_list();
										}
									});
								},
							},
						],
					},
				],
				methods: {
					/**
					 * @description 删除站点备份
					 * @param {object} config
					 * @param {function} callback
					 */
					del_site_backup: function (config, callback) {
						bt.confirm(
							{ title: '删除数据库备份[' + config.name + ']', msg: '删除选中数据库备份文件后，<span class="color-red">该数据库备份文件将永久消失</span>，是否继续操作？' },
							function () {
								bt_tools.send(
									'files/DeleteFile',
									{ path: config.path },
									function (rdata) {
										if (callback) callback(rdata);
									},
									true
								);
							}
						);
					},
				},
				success: function () {
					$('.bt_backup_table').css('top', ($(window).height() - $('.bt_backup_table').height()) / 2 + 'px');
					$('#backupAll tr:gt(0)').off('click').on('click',function(e){// 点击行选中
						if(!($(e.target).hasClass('cust—checkbox') || $(e.target).hasClass('cust—checkbox-input'))){
							$(this).find('i').click()
						}
					})

				},
				tootls: [
					{
						// 按钮组
						type: 'group',
						positon: ['left', 'top'],
						list: [
							{
								title: '数据库备份',
								active: true,
								event: function (ev, that) {
									var addBackup = null
									bt_tools.open({
										title:'数据库备份',
										skin:'databsebackup_mysql',
										area:['600px','450px'],
										btn:['备份','取消'],
										content:'<div id="AddBackup" style="padding:0px 20px 20px;"></div>',
										success:function(){
											//打开弹窗后执行的事件
											addBackup = bt_tools.table({
												el:'#AddBackup',
												url:'/database?action=GetBackupDatabase',
												param:{
													sid:0
												},
												default:'暂无数据',
												load:true,
												height: '250px',
												column:[
													{ type: 'checkbox', class: '', width: 20 },
													{
														title: '数据库名称',
														width: 220,
														template: function (row) {
															return '<span style="width:220px;display:block;overflow:hidden;white-space:nowrap;text-overflow:ellipsis" title="' + row.name + '">' + row.name + '</span>';
														},
													},
													{
														fid: 'table_num',
														title: '表数量'
													},
													{
														title: '数据库位置',
														type: 'text',
														width: 116,
														template: function (row) {
															var type_column = '-';
															switch (row.sid) {
																case 0:
																	type_column = '本地数据库';
																	break;
																default:
																	$.each(cloudDatabaseList, function (index, item) {
																		if (row.sid == item.id) {
																			if (item.ps !== '') {
																				// 默认显示备注
																				type_column = item.ps;
																			} else {
																				type_column = ('远程服务器(' + item.db_host + ':' + item.db_port + ')').toString();
																			}
																		}
																	});
																	break;
															}
															return '<span class="flex" style="width:100px" title="' + type_column + '"><span class="size_ellipsis" style="width: 0; flex: 1;">' + type_column + '</span></span>';
														},
													},
													{
														fid: 'size',
														title: '大小',
														width: 80,
														type: 'text',
													},
												],
												success:function(){
													$('#AddBackup tr:gt(0)').off('click').on('click',function(e){// 点击行选中
														if(!($(e.target).hasClass('cust—checkbox') || $(e.target).hasClass('cust—checkbox-input'))){
															$(this).find('i').click()
														}
													})
												}
											})
											//搜索前面新增数据库位置下拉
											var _option = '';
											$.each(cloudDatabaseList, function (index, item) {
												var _tips = item.ps != '' ? item.ps : item.db_host;
												_option += '<option value="' + item.id + '">' + _tips + '</option>';
											});
											$('#AddBackup').before('<select class="bt-input-text mr5 database_type_select_filter" style="width:110px;position: relative;right: -470px;margin-top:10px;" name="db_type_filter">' + _option + '</select>');

											//事件
											$('.database_type_select_filter').change(function () {
												if($(this).val() == ''){
													delete addBackup.config.param.sid
												}else{
													addBackup.config.param.sid = $(this).val()
												}
												addBackup.$refresh_table_list(true);
											});
										},
										yes:function(indexs){
											//点击确定时,如果btn:false,当前事件将无法使用
											var arr = []
											$.each(addBackup.checkbox_list,function(index,item){
												arr.push(addBackup.data[item].name)
											})

											if(arr.length == 0){
												return layer.msg('请选择需要备份的数据库',{icon:2})
											}
											bt_tools.send({url:'/database?action=ToBackupAll',data:{db_list:JSON.stringify(arr),sid:$('.databsebackup_mysql .database_type_select_filter').val()}},function(ress){
												//请求回调
												if(ress.status){
													layer.msg(ress.msg,{icon:1,time:0,shadeClose: true,shade: [0.3, '#000']})
													backup_table.$refresh_table_list();
													layer.close(indexs)
												}
											},'备份数据库')
										},
										cancel: function () {
											//点击右上角关闭时,如果btn:false,当前事件将无法使用
										}
									})
								},
							},
							{
								title: '从本地上传',
								active: false,
								event: function (ev, that) {
									var path = bt.get_cookie('backup_path') + '/database/mysql/all_backup';
									bt_upload_file.open(path,'.sql,.zip,.bak,.gz', '请上传.sql,.zip,.bak,.gz文件', function () {
										backup_table.$refresh_table_list();
									});
									// uploadFiles.init_upload_path(path);
									// uploadFiles.upload_layer();
									// $('.dropdown-toggle').remove()
									// $('.upload_btn_groud .dropdown-menu').remove()
								},
							},
						],
					},
					{
						type: 'batch',
						positon: ['left', 'bottom'],
						config: {
							title: '删除',
							url: '/files?action=DeleteFile',
							param: function (row) {
								return { path: row.path };
							},
							load: true,
							callback: function (that) {
								bt.confirm({ title: '批量删除数据库备份', msg: '批量删除选中的数据库备份，<span class="color-red">备份文件将永久消失</span>，是否继续操作？', icon: 0 }, function (index) {
									layer.close(index);
									that.start_batch({}, function (list) {
										var html = '';
										for (var i = 0; i < list.length; i++) {
											var item = list[i];
											html +=
												'<tr><td><span class="text-overflow" title="' +
												item.name +
												'">' +
												item.name +
												'</span></td><td><div style="float:right;"><span style="color:' +
												(item.request.status ? '#20a53a' : 'red') +
												'">' +
												item.request.msg +
												'</span></div></td></tr>';
										}
										backup_table.$batch_success_table({ title: '批量删除数据库备份', th: '文件名', html: html });
										backup_table.$refresh_table_list(true);
										database_table.$refresh_table_list(true);
									});
								});
							},
						}, //分页显示
					},
					{
						type: 'page',
						positon: ['right', 'bottom'], // 默认在右下角
						pageParam: 'p', //分页请求字段,默认为 : p
						page: 1, //当前分页 默认：1
						numberParam: 'limit',//分页数量请求字段默认为 : limit
						number: 20, //分页数量默认 : 20条
						numberList: [10, 20, 50], // 分页显示数量列表
						numberStatus: true, //　是否支持分页数量选择,默认禁用
						jump: true, //是否支持跳转分页,默认禁用
					},
				],
			});
		}
		if(type){
			init()
		}else {
			bt_tools.open({
				title:'全部备份',
				area:['880px','492px'],
				btn:false,
				content:'<div id="backupAll" style="padding:20px;"></div>',
				success:function(){
					//打开弹窗后执行的事件
					init()
				}
			})
		}

	},
	// 同步所有
	sync_to_database: function (obj, callback) {
		bt.database.sync_to_database(
			{
				type: obj.type,
				ids: JSON.stringify(obj.data),
			},
			function (rdata) {
				if (callback) callback(rdata);
			}
		);
	},
	// 同步数据库
	database_detail: function (id, dataname, db_type) {
		if (bt.data.db_tab_name == 'mysql') {
			var cloud_list = {
				//云存储列表名
				alioss: '阿里云OSS',
				ftp: 'FTP',
				sftp: 'SFTP',
				msonedrive: '微软OneDrive',
				qiniu: '七牛云',
				txcos: '腾讯COS',
				upyun: '又拍云',
				jdcloud: '京东云',
				aws_s3: '亚马逊存储',
				'Google Cloud': '谷歌云',
				'Google Drive': '谷歌网盘',
				bos: '百度云',
				obs: '华为云',
			};
			function getType(name) {
				var type = 'localhost'; // 当前云存储类型
				if (name.indexOf('|') != -1) {
					type = name.match(/\|(.+)\|/, '$1')[1];
				}
				return type;
			}
			var web_tab = bt_tools.tab({
				class: 'pd20',
				type: 0,
				theme: { nav: 'ml0' },
				active: 1, //激活TAB下标
				list: [
					{
						title: '常规备份',
						name: 'conventionalBackup',
						content: '<div id="bt_backup_table"></div>',
						success: function () {
							var bt_backup_table = $('#bt_backup_table');
							bt_backup_table.html('<div class="database-pro-box"><div class="sn-home--open-condition"><i class="sn-home--important-note">!</i>请注意：手动备份的文件默认存储在本地。如需更改存储位置，请在【<a class="btlink " href="/crontab">计划任务</a>】模块的数据库备份任务中设置。</div></div>');
							var backup_table = bt_tools.table({
								el: '#bt_backup_table',
								url: '/data?action=getData',
								param: { table: 'backup', search: id, type: '1', limit: 5 },
								default: '[' + dataname + '] 数据库备份列表为空', //数据为空时的默认提示
								column: [
									{ type: 'checkbox', class: '', width: 20 },
									{
										title: '文件名称',
										width: 220,
										template: function (row) {
											return '<span style="width:220px;display:block;overflow:hidden;white-space:nowrap;text-overflow:ellipsis" title="' + row.filename + '">' + row.name + '</span>';
										},
									},
									{
										fid: 'storage_type',
										title: '存储位置',
										type: 'text',
										width: 70,
										template: function (row) {
											var is_cloud = false,
												cloud_name = ''; //当前云存储类型
											if (row.filename.indexOf('|') != -1) {
												var _path = row.filename;
												is_cloud = true;
												cloud_name = _path.match(/\|(.+)\|/, '$1');
											} else {
												is_cloud = false;
											}
											return is_cloud ? cloud_list[cloud_name[1]] : '本地';
										},
									},
									{
										fid: 'size',
										title: '文件大小',
										width: 80,
										type: 'text',
										template: function (row, index) {
											return bt.format_size(row.size);
										},
									},
									{ fid: 'addtime', width: 150, title: '备份时间' },
									{
										fid: 'ps',
										title: '备注',
										type: 'input',
										blur: function (row, index, ev, key, that) {
											if (row.ps == ev.target.value) return false;
											bt.pub.set_data_ps({ id: row.id, table: 'backup', ps: ev.target.value }, function (res) {
												bt_tools.msg(res, { is_dynamic: true });
											});
										},
										keyup: function (row, index, ev) {
											if (ev.keyCode === 13) $(this).blur();
										},
									},
									{
										title: '操作',
										type: 'group',
										width: 140,
										align: 'right',
										group: [
											{
												title: '恢复',
												event: function (row, index, ev, key, that) {
													var type = getType(row.filename);
													// if (type != 'alioss' && type != 'bos' && type != 'txcos' && type != 'obs' && type != 'localhost') {
													// 	layer.msg('暂不支持存储对象【' + cloud_list[type] + '】恢复功能', { icon: 2, closeBtn: 1, time: 0, shadeClose: true });
													// 	return;
													// }
													var _id = row.id;
													(num1 = bt.get_random_num(3, 15)),
														(num2 = bt.get_random_num(5, 9)),
														(taskID = 0),
														(taskStatus = 0), //0未开始  1正在下载   2下载完成
														(intervalTask = null);
													// 根据id获取对象数据
													var obj = that.data.filter(function (x) {
														return x.id === _id;
													});
													obj = obj[0]; //由于filter返回数组所以取第一位
													var _path = obj.filename,
														cloud_name = _path.match(/\|(.+)\|/, '$1'),
														isYun = _path.indexOf('|') != -1;
													if (!isYun) {
														bt.database.input_sql(_path, dataname);
														return;
													}
													layer.open({
														type: 1,
														title: '从云存储恢复',
														area: ['500px', '350px'],
														closeBtn: 2,
														shadeClose: false,
														skin: 'db_export_restore',
														content:
															"<div style='padding: 20px 20px 0 20px;'>" +
															"<div class='db_export_content'><ul>" +
															'<li>此备份文件存储在云存储，需要通过以下步骤才能完成恢复：</li>' +
															"<li class='db_export_txt'>" +
															'<span>1</span>' +
															'<div>' +
															'<p>从[' +
															cloud_list[cloud_name[1]] +
															']下载备份文件到服务器。</p>' +
															"<p class='btlink'></p>" +
															'</div>' +
															'</li>' +
															"<li class='db_export_txt2'>" +
															'<span>2</span>' +
															'<div>' +
															'<p>恢复备份</p>' +
															"<p class='btlink'></p>" +
															'</div>' +
															'</li>' +
															'</ul>' +
															"<p class='db_confirm_txt'style='color:red;margin-bottom: 10px;'>数据库将被覆盖，是否继续？</p>" +
															'</div>' +
															"<div class='db_export_vcode db_two_step' style='margin:0'>" +
															lan.bt.cal_msg +
															'' +
															"<span class='text'>" +
															num1 +
															' + ' +
															num2 +
															"</span>=<input type='number' id='vcodeResult' value=''>" +
															'</div>' +
															"<div class='bt-form-submit-btn'>" +
															"<button type='button' class='btn btn-danger btn-sm db_cloud_close'>取消</button>" +
															"<button type='button' class='btn btn-success btn-sm db_cloud_confirm'>确认</button></div>" +
															'</div>',
														success: function (layers, indexs) {
															// 确认按钮
															$('.db_export_restore').on('click', '.db_cloud_confirm', function () {
																var vcodeResult = $('#vcodeResult');
																if (vcodeResult.val() === '') {
																	layer.tips('计算结果不能为空', vcodeResult, {
																		tips: [1, 'red'],
																		time: 3000,
																	});
																	vcodeResult.focus();
																	return false;
																} else if (parseInt(vcodeResult.val()) !== num1 + num2) {
																	layer.tips('计算结果不正确', vcodeResult, {
																		tips: [1, 'red'],
																		time: 3000,
																	});
																	vcodeResult.focus();
																	return false;
																}
																$('.db_two_step,.db_confirm_txt').remove(); //删除计算
																$('.db_export_restore .db_export_content li:first').animate(
																	{
																		'margin-bottom': '35px',
																	},
																	600
																);
																$('.db_export_restore .db_cloud_confirm').addClass('hide'); //隐藏确认按钮
																//请求云储存链接
																var loading = bt.load(lan.database.input_the)
																bt_tools.send({url: 'database?action=InputSql'}, { file: _path, name: dataname }, function (rdata) {
																	loading.close();
																	layer.close(indexs);
																	rdata['code']=-1
																	bt.msg(rdata)
																});
																// $.post(
																// 	'/cloud',
																// 	{
																// 		toserver: true,
																// 		filename: obj.filename,
																// 		name: obj.name,
																// 	},
																// 	function (res) {
																// 		taskID = res.task_id;
																// 		if (res.status === false) {
																// 			layer.msg(res.msg, {
																// 				icon: 2,
																// 			});
																// 			return false;
																// 		} else {
																// 			// 获取下载进度
																// 			function downloadDBFile() {
																// 				$.post(
																// 					'/task?action=get_task_log_by_id',
																// 					{
																// 						id: res.task_id,
																// 						task_type: 1,
																// 					},
																// 					function (task) {
																// 						if (task.status == 1) {
																// 							clearInterval(intervalTask);
																// 							taskStatus = 2;
																// 							$('.db_export_txt p:eq(1)').html('下载完成!');
																// 							$('.db_export_txt2 p:eq(1)').html('请稍等，正在恢复数据库 <img src="/static/img/ing.gif">');
																// 							bt.send(
																// 								'InputSql',
																// 								'database/InputSql',
																// 								{
																// 									file: res.local_file,
																// 									name: dataname,
																// 								},
																// 								function (rdata) {
																// 									layer.close(indexs);
																// 									bt.msg(rdata);
																// 								}
																// 							);
																// 						} else {
																// 							taskStatus = 1;
																// 							//更新下载进度
																// 							$('.db_export_txt p:eq(1)').html('正在下载文件:已下载 ' + task.used + '/' + ToSize(task.total));
																// 						}
																// 					}
																// 				);
																// 			}
																// 			downloadDBFile();
																// 			intervalTask = setInterval(function () {
																// 				downloadDBFile();
																// 			}, 1500);
																// 		}
																// 	}
																// );
															});
															// 取消按钮
															$('.db_export_restore').on('click', '.db_cloud_close', function () {
																switch (taskStatus) {
																	case 1:
																		layer.confirm(
																			'正在执行从云存储中下载，是否取消',
																			{
																				title: '下载取消',
																			},
																			function () {
																				clearInterval(intervalTask); //取消轮询下载进度
																				layer.close(indexs);
																				database.cancel_cloud_restore(taskID);
																			}
																		);
																		break;
																	case 2:
																		layer.msg('数据正在恢复中，无法取消', {
																			icon: 2,
																		});
																		return false;
																	default:
																		layer.close(indexs);
																		break;
																}
															});
														},
														cancel: function (layers) {
															switch (taskStatus) {
																case 0:
																	layer.close(layers);
																	break;
																case 1:
																	layer.confirm(
																		'正在执行从云存储中下载，是否取消',
																		{
																			title: '下载取消',
																		},
																		function () {
																			clearInterval(intervalTask); //取消轮询下载进度
																			layer.close(layers);
																			database.cancel_cloud_restore(taskID);
																		},
																		function () {
																			return false;
																		}
																	);
																	break;
																case 2:
																	layer.msg('数据正在恢复中，无法取消', {
																		icon: 2,
																	});
																	return false;
															}
															return false;
														},
													});
												},
											},
											{
												title: '下载',
												event: function (row) {
													if (row.filename.indexOf('|') !== -1 && row.localexist === 1) {
														layer.msg('暂不支持云存储下载', { icon: 2 });
													} else {
														window.open('/download?filename=' + row.local + '&amp;name=' + row.name);
													}
												},
											},
											{
												title: '删除',
												event: function (row, index, ev, key, that) {
													that.del_site_backup(row, function (rdata) {
														bt_tools.msg(rdata);
														if (rdata.status) {
															that.$refresh_table_list();
															database_table.$refresh_table_list(true);
														}
													});
												},
											},
										],
									},
								],
								methods: {
									/**
									 * @description 删除站点备份
									 * @param {object} config
									 * @param {function} callback
									 */
									del_site_backup: function (config, callback) {
										bt.confirm(
											{ title: '删除数据库备份[' + config.addtime + ']', msg: '删除选中数据库备份文件后，<span class="color-red">该数据库备份文件将永久消失</span>，是否继续操作？' },
											function () {
												bt_tools.send(
													'database/DelBackup',
													{ id: config.id },
													function (rdata) {
														if (callback) callback(rdata);
													},
													true
												);
											}
										);
									},
								},
								success: function () {
									$('.bt_backup_table').css('top', ($(window).height() - $('.bt_backup_table').height()) / 2 + 'px');
								},
								tootls: [
									{
										// 按钮组
										type: 'group',
										positon: ['left', 'top'],
										list: [
											{
												title: '备份数据库',
												active: true,
												event: function (ev, that) {
													var allLoad = layer.msg('正在备份中,请稍后......', { icon: 16, shade: [0.3, '#000'], time: 0 });
													bt_tools.send(
														{ url: '/database?action=ToBackup', data: { id: id } },
														function (ress) {
															backup_table.$refresh_table_list();
															layer.msg(ress.msg, { icon: ress.status ? 1 : 2, time: 0, shadeClose: true, shade: [0.3, '#000'] });
														},
														allLoad
													);
												},
											},
											{
												title: '自定义备份',
												active: false,
												event: function (ev, that) {
													var btn_Type = 'db';
													var mysqlTable = null;
													bt_tools.open({
														title: '自定义备份 - [ ' + dataname + ' ]',
														area: ['600px', '560px'],
														class: 'p15',
														btn: ['备份', '取消'],
														// btn-success
														content:
															'<div id="mysqlForm"></div>\
																			<div id="dataBaseTableMysql"></div><style type="text/css">#dataBaseTableMysql thead th{background-color:#fff}</style>',
														success: function () {
															var mysqlForm = bt_tools.form({
																el: '#mysqlForm',
																class: 'pd20',
																form: [
																	{
																		group: {
																			type: 'other',
																			boxcontent: '<div><div><p>数据表</p></div><div id="dataBaseTableMysql"></div></div>',
																		},
																	},
																	{
																		formLabelWidth: '71px',
																		label: '备份方式',
																		group: {
																			type: 'radio',
																			name: 'radioValue',
																			width: '150px',
																			value: 'db',
																			list: [
																				{ title: '合并导出', value: 'db' },
																				{ title: '分表导出', value: 'table' },
																			],
																			event: function (formData, element, that) {
																				btn_Type = formData.radioValue;
																			},
																		},
																	},
																	{
																		group: {
																			type: 'help',
																			list: ['合并导出：将选中的表导出到一个SQL文件内。', '分表导出：一张表存储为一个SQL文件。'],
																		},
																	},
																],
															});
															mysqlTable = bt_tools.table({
																el: '#dataBaseTableMysql',
																url: '/database?action=GetInfo',
																default: '暂无数据',
																param: { db_name: dataname },
																height: '250px',
																dataVerify: false, //为false可跳过异常处理
																load: true,
																tips: '正在获取数据...',
																dataFilter: function (rdata) {
																	return { data: rdata.tables };
																},
																column: [
																	{ type: 'checkbox', class: 'checkBoxs', width: 20 },
																	{
																		fid: 'table_name',
																		fixed: true,
																		width: 300,
																		title: '全选',
																	},
																	{
																		fid: 'rows_count',
																		width: 100,
																		title: '行数',
																	},
																	{
																		fid: 'data_size',
																		width: 80,
																		title: '大小',
																	},
																],
															});
														},
														yes: function (formD, indexs) {
															if (mysqlTable.checkbox_list.length < 1) {
																layer.msg('请至少选择一项', { icon: 2 });
																return;
															}
															var table_list = [];
															$.each(mysqlTable.checkbox_list, function (index, value) {
																table_list.push(mysqlTable.data[value].table_name);
															});
															var mysql_Backup_load = layer.msg('正在备份中，请稍后...', { icon: 16, time: 0, shade: [0.3, '#000'] });
															bt_tools.send(
																{ url: '/database?action=ToBackup', data: { storage_type: btn_Type, table_list: JSON.stringify(table_list), id: id } },
																function (ress) {
																	backup_table.$refresh_table_list();
																	layer.msg(ress.msg, { icon: ress.status ? 1 : 2, time: 0, shadeClose: true, shade: [0.3, '#000'] });
																},
																mysql_Backup_load
															);
														},
														cancel: function () {},
													});
													$('#dataBaseTableMysql').css('width', '560px');
													// 			var htmlForm =
													// 				'<input type="checkbox" name="check" class="checkboxFormMysql" id="checkMysql" value="db" style="margin-right:5px;margin-top:20px;width:16px;height:16px;" /><label style="vertical-align:middle;font-weight:normal;color:#666">存储为一个文件(默认)</label>\
													// <input type="checkbox" name="check" class="checkboxFormMysql" id="checkMysql2" value="table" style="margin-right:5px;margin-left:20px;margin-top:20px;width:16px;height:16px;"/><label style="vertical-align:middle;font-weight:normal;color:#666">分表存储</label>\
													// ';
													// 			$('#dataBaseFormMysql').html(htmlForm);
													// 			$('#checkMysql').attr('checked', true);
													// 			$('.checkboxFormMysql').on('click', function () {
													// 				$(this).attr('checked', true).siblings().attr('checked', false);
													// selectTable($(this).val())
													// });
												},
											},
										],
									},
									{
										type: 'batch',
										positon: ['left', 'bottom'],
										config: {
											title: '删除',
											url: '/site?action=DelBackup',
											paramId: 'id',
											load: true,
											callback: function (that) {
												bt.confirm({ title: '批量删除数据库备份', msg: '批量删除选中的数据库备份，<span class="color-red">备份文件将永久消失</span>，是否继续操作？', icon: 0 }, function (index) {
													layer.close(index);
													that.start_batch({}, function (list) {
														var html = '';
														for (var i = 0; i < list.length; i++) {
															var item = list[i];
															html +=
																'<tr><td><span class="text-overflow" title="' +
																item.name +
																'">' +
																item.name +
																'</span></td><td><div style="float:right;"><span style="color:' +
																(item.request.status ? '#20a53a' : 'red') +
																'">' +
																item.request.msg +
																'</span></div></td></tr>';
														}
														backup_table.$batch_success_table({ title: '批量删除数据库备份', th: '文件名', html: html });
														backup_table.$refresh_table_list(true);
														database_table.$refresh_table_list(true);
													});
												});
											},
										}, //分页显示
									},
									{
										type: 'page',
										positon: ['right', 'bottom'], // 默认在右下角
										pageParam: 'p', //分页请求字段,默认为 : p
										page: 1, //当前分页 默认：1
										numberParam: 'limit',
										//分页数量请求字段默认为 : limit
										defaultNumber: 10,
										//分页数量默认 : 20条
									},
								],
							});
						},
					},
					{
						title: '<p style="height:16px;padding:0;border:none;margin-right:2px;background-color: transparent;vertical-align: sub;" class="firwall_place_of_attribution"></p>增量备份',
						name: 'incrementalBackup',
						content:"<div id='webedit-con-database' class='bt-w-con webedit-con pd15' style='margin-left:0;height:495px;'></div>",
						success:function(){
							database.backupList(1,dataname);
						}
					},
				],
			});
			bt_tools.open({
				area: '880px',
				title: '备份数据库&nbsp;-&nbsp;[&nbsp;' + dataname + '&nbsp;]',
				btn: false,
				skin: 'bt_backup_table',
				content: web_tab.$reader_content(),
				success: function () {
					web_tab.$init();
					$('.bt_backup_table .tab-nav span')
						.eq(1)
						.click(function () {
							if (db_type != 0) {
								$('.bt_backup_table .tab-nav span').eq(0).click();
								layer.msg('远程数据库不支持增量备份',{icon:2,closeBtn:2})
								return false;
							}
							if (database.isLtdBackAndCap()) return false;
						});
				},
			});
			$('#bt_backup_table').css('height', '495px');
		} else {
			if (bt.data.db_tab_name == 'mongodb') {
				// mgdb弹窗渲染
				// bt.pub.get_data('table=backup&search=' + id + '&type=1&tojs=database.database_detail', function (frdata) {
				// frdata.page = frdata.page.replace(/'/g, '"').replace(/database.database_detail\(/g, "database.database_detail(" + id + ",'" + dataname + "',");
				bt_tools.open({
					area: ['880px', '633px'],
					title: '备份数据库&nbsp;-&nbsp;[&nbsp;' + dataname + '&nbsp;]',
					btn: false,
					content:
						"<div class='divtable pd15 style='padding-bottom: 0'><button id='btn_data_backupMgdb_All' class='btn btn-success btn-sm' type='button' style='margin-bottom:10px;margin-right:5px'>备份数据库</button><button id='btn_data_backupMgdb' class='btn btn-default btn-sm' type='button' style='margin-bottom:10px'>自定义备份</button><div id='DataBackupListMgdb'></div></div>",
					success: function () {
						var mgdbTableFh = bt_tools.table({
							el: '#DataBackupListMgdb',
							url: '/data?action=getData',
							param: { table: 'backup', search: id, limit: 10, p: 1, type: 1 },
							default: '暂无数据',
							dataVerify: false, //为false可跳过异常处理
							tips: '正在获取数据，请稍后...',
							load: true,
							dataFilter: function (rdata) {
								//return rdata  //不做处理
								return { data: rdata.data, page: rdata.page }; //处理好数据后返回
							},
							column: [
								{ type: 'checkbox', class: '', width: 20 },
								{
									title: '文件名称',
									width: 200,
									template: function (row) {
										return '<span title="' + row.filename + '" style="width:200px;display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + row.name + '</span>';
									},
								},
								{
									title: '存储位置',
									width: 70,
									template: function (row) {
										var cloud_list = {
											//云存储列表名
											alioss: '阿里云OSS',
											ftp: 'FTP',
											sftp: 'SFTP',
											msonedrive: '微软OneDrive',
											qiniu: '七牛云',
											txcos: '腾讯COS',
											upyun: '又拍云',
											jdcloud: '京东云',
											aws_s3: '亚马逊存储',
											'Google Cloud': '谷歌云',
											'Google Drive': '谷歌网盘',
											bos: '百度云',
											obs: '华为云',
										};
										var is_cloud = false,
											cloud_name = ''; //当前云存储类型
										if (row.filename.indexOf('|') != -1) {
											var _path = row.filename;
											is_cloud = true;
											cloud_name = _path.match(/\|(.+)\|/, '$1');
										} else {
											is_cloud = false;
										}
										return is_cloud ? '<span>' + cloud_list[cloud_name[1]] + '</span>' : '<span>本地</span>';
									},
								},
								{
									title: '文件大小',
									width: 70,
									template: function (row) {
										return '<span>' + bt.format_size(row.size) + '</span>';
									},
								},
								{ fid: 'addtime', title: '备份时间', width: 140 },
								{
									fid: 'ps',
									title: '备注',
									type: 'input',
									blur: function (row, index, ev, key, that) {
										if (row.ps == ev.target.value) return false;
										bt.pub.set_data_ps({ id: row.id, table: 'backup', ps: ev.target.value }, function (res) {
											bt_tools.msg(res, { is_dynamic: true });
										});
									},
									keyup: function (row, index, ev) {
										if (ev.keyCode === 13) $(this).blur();
									},
								},
								// {
								//   title:'操作',
								//   width:140,
								//   template:function(row){
								//     var _opt = '<a class="btlink" herf="javascrpit:;" onclick="bt.database.input_sql(\'' + row.filename + '\',\'' + dataname + '\')">恢复</a> | \
								//      <a class="btlink" href="/download?filename=' + row.filename + '&amp;name=' + row.name + '" target="_blank">下载</a> | \
								//     <a class="btlink" herf="javascrpit:;" onclick="bt.database.del_backup(\'' + row.id + '\',\'' + id + '\',\'' + dataname + '\',\'' + row.addtime + '\')">删除</a>'
								//     return '<span>'+ _opt +'</span>';
								//   }
								// },
								{
									title: '操作',
									type: 'group',
									align: 'right',
									group: [
										{
											title: '恢复',
											event: function (row, index, ev, key, that) {
												bt.database.input_sql(row.filename, dataname);
											},
										},
										{
											title: '下载',
											event: function (row, index, ev, key, that) {
												window.open('/download?filename=' + row.filename + '&amp;name=' + row.name + '');
											},
										},
										{
											title: '删除',
											event: function (row, index, ev, key, that) {
												bt.simple_confirm(
													{ title: '删除备份文件-' + row.addtime + '', msg: '删除选中备份文件后，<span class="color-red">该备份文件将永久消失</span>，是否继续操作？' },
													function (index) {
														bt_tools.send({ url: '/database/mongodb/DelBackup', data: { data: JSON.stringify({ id: row.id }) } }, function (ress) {
															mgdbTableFh.$refresh_table_list();
															database_table.$refresh_table_list();
															layer.msg(ress.msg, { icon: ress.status ? 1 : 2 });
														});
													}
												);
											},
										},
									],
								},
							],
							tootls: [
								{
									type: 'batch',
									positon: ['left', 'bottom'],
									config: {
										title: '删除',
										url: '/site?action=DelBackup',
										paramId: 'id',
										load: true,
										callback: function (that, index) {
											layer.close(index);
											bt.confirm({ title: '批量删除数据库备份', msg: '批量删除选中的数据库备份，<span class="color-red">备份文件将永久消失</span>，是否继续操作？', icon: 0 }, function (index) {
												that.start_batch({}, function (list) {
													var html = '';
													for (var i = 0; i < list.length; i++) {
														var item = list[i];
														html +=
															'<tr><td><span class="text-overflow" title="' +
															item.name +
															'">' +
															item.name +
															'</span></td><td><div style="float:right;"><span style="color:' +
															(item.request.status ? '#20a53a' : 'red') +
															'">' +
															item.request.msg +
															'</span></div></td></tr>';
													}
													mgdbTableFh.$batch_success_table({ title: '批量删除数据库备份', th: '文件名', html: html });
													mgdbTableFh.$refresh_table_list();
												});
											});
										},
									},
								},
								{
									//分页显示
									type: 'page',
									positon: ['right', 'bottom'], // 默认在右下角
									pageParam: 'p', //分页请求字段,默认为 : p
									page: 1, //当前分页 默认：1
									numberParam: 'limit', //分页数量请求字段默认为 : limit
									number: 10, //分页数量默认 : 20条
									numberList: [10, 20, 50, 100, 200], // 分页显示数量列表
									numberStatus: false, //　是否支持分页数量选择,默认禁用
									jump: false, //是否支持跳转分页,默认禁用
								},
							],
						});
						$('#btn_data_backupMgdb_All').click(function () {
							var allLoad = layer.msg('正在备份中,请稍后......', { icon: 16, shade: [0.3, '#000'], time: 0 });
							bt_tools.send(
								{ url: '/database/mongodb/ToBackup', data: { data: JSON.stringify({ id: id }) } },
								function (ress) {
									mgdbTableFh.$refresh_table_list();
									layer.msg(ress.msg, { icon: ress.status ? 1 : 2, shade: [0.3, '#000'], time: 0, shadeClose: true });
								},
								allLoad
							);
						});
						$('#btn_data_backupMgdb')
							.unbind('click')
							.click(function () {
								var mgdbTable = null,
									btn_Type = 'bson';
								bt_tools.open({
									title: '自定义备份 - [ ' + dataname + ' ]',
									area: ['600px', '560px'],
									class: 'p15',
									btn: ['备份', '取消'],
									content:
										'<div id="mgdbForm"></div>\
																			<div id="dataBaseTableMgdb"></div><style type="text/css">#dataBaseTableMgdb thead th{background-color:#fff}</style>',
									success: function () {
										var mgdbForm = bt_tools.form({
											el: '#mgdbForm',
											class: 'pd20',
											form: [
												{
													group: {
														type: 'other',
														boxcontent: '<div><p>数据表</p><div id="dataBaseTableMgdb"></div></div>',
													},
												},
												{
													label: '备份格式',
													formLabelWidth: '71px',
													group: {
														type: 'radio',
														name: 'radioValue',
														width: '150px',
														value: 'bson',
														list: [
															{ title: 'bson', value: 'bson' },
															{ title: 'json', value: 'json' },
														],
														event: function (formData, element, that) {
															btn_Type = formData.radioValue;
														},
													},
												},
												{
													group: {
														type: 'help',
														list: ['备份格式：打包后压缩包内的文件格式'],
													},
												},
											],
										});
										mgdbTable = bt_tools.table({
											el: '#dataBaseTableMgdb',
											url: '/database/mongodb/GetInfo',
											default: '暂无数据',
											param: { data: JSON.stringify({ db_name: dataname }) },
											height: '250px',
											dataVerify: false, //为false可跳过异常处理
											tips: '正在获取数据，请稍后...',
											load: true,
											dataFilter: function (rdata) {
												return { data: rdata.data.collection_list };
											},
											column: [
												{ type: 'checkbox', class: 'checkBoxs', width: 20 },
												{
													fid: 'collection_name',
													fixed: true,
													width: 300,
													title: '全选',
												},
												{
													fid: 'count',
													width: 100,
													title: '文档数量',
												},
												{
													title: '存储大小',
													width: 80,
													template: function (row) {
														return '<span>' + ToSize(row.storage_size) + '</span>';
													},
												},
											],
										});
									},
									yes: function (formD, indexs) {
										if (mgdbTable.checkbox_list.length < 1) {
											layer.msg('请至少选择一项', { icon: 2 });
											return;
										}
										var table_list = [];
										$.each(mgdbTable.checkbox_list, function (index, value) {
											table_list.push(mgdbTable.data[value].collection_name);
										});
										var mgdb_Backup_load = layer.msg('正在备份中，请稍后...', { icon: 16, time: 0, shade: [0.3, '#000'] });
										bt_tools.send(
											{ url: '/database/mongodb/ToBackup', data: { data: JSON.stringify({ file_type: btn_Type, collection_list: table_list, id: id }) } },
											function (ress) {
												mgdbTableFh.$refresh_table_list();
												layer.msg(ress.msg, { icon: ress.status ? 1 : 2, time: 0, shadeClose: true, shade: [0.3, '#000'] });
											},
											mgdb_Backup_load
										);
									},
									cancel: function () {},
								});
								$('#dataBaseTableMgdb').css('width', '560px');
							});
					},
				});
				$('#DataBackupListMgdb').css('height', '462px');
			} else if ((bt.data.db_tab_name = 'pgsql')) {
				// pgsql弹窗渲染
				var loadT = bt.load(lan.public.the_get);
				bt.pub.get_data('table=backup&search=' + id + '&type=1&tojs=database.database_detail', function (frdata) {
					loadT.close();
					frdata.page = frdata.page.replace(/'/g, '"').replace(/database.database_detail\(/g, 'database.database_detail(' + id + ",'" + dataname + "',");
					if ($('#DataBackupListPgsql').length <= 0) {
						bt_tools.open({
							type: 1,
							area: ['880px', '633px'],
							title: '备份数据库&nbsp;-&nbsp;[&nbsp;' + dataname + '&nbsp;]',
							btn: false,
							content:
								"<div class='divtable pd15 style='padding-bottom: 0'><button id='btn_data_backupPgsql_All' class='btn btn-success btn-sm' type='button' style='margin-bottom:10px;margin-right:5px'>备份数据库</button><button id='btn_data_backupPgsql' class='btn btn-default btn-sm' type='button' style='margin-bottom:10px'>自定义备份</button><div id='DataBackupListPgsql'></div></div>",
							success: function () {
								var pgSql = bt_tools.table({
									el: '#DataBackupListPgsql',
									url: '/data?action=getData',
									param: { table: 'backup', search: id, limit: 10, p: 1, type: 1 },
									default: '暂无数据',
									height: '',
									tips: '正在获取数据，请稍后...',
									load: true,
									dataVerify: false, //为false可跳过异常处理
									dataFilter: function (rdata) {
										//return rdata  //不做处理
										return { data: rdata.data, page: rdata.page }; //处理好数据后返回
									},
									column: [
										{ type: 'checkbox', class: '', width: 20 },
										{
											title: '文件名称',
											width: 200,
											template: function (row) {
												return '<span title="' + row.filename + '" style="width:200px;display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + row.name + '</span>';
											},
										},
										{
											title: '存储位置',
											width: 70,
											template: function (row) {
												var cloud_list = {
													//云存储列表名
													alioss: '阿里云OSS',
													ftp: 'FTP',
													sftp: 'SFTP',
													msonedrive: '微软OneDrive',
													qiniu: '七牛云',
													txcos: '腾讯COS',
													upyun: '又拍云',
													jdcloud: '京东云',
													aws_s3: '亚马逊存储',
													'Google Cloud': '谷歌云',
													'Google Drive': '谷歌网盘',
													bos: '百度云',
													obs: '华为云',
												};
												var is_cloud = false,
													cloud_name = ''; //当前云存储类型
												if (row.filename.indexOf('|') != -1) {
													var _path = row.filename;
													is_cloud = true;
													cloud_name = _path.match(/\|(.+)\|/, '$1');
												} else {
													is_cloud = false;
												}
												return is_cloud ? '<span>' + cloud_list[cloud_name[1]] + '</span>' : '<span>本地</span>';
											},
										},
										{
											title: '文件大小',
											width: 80,
											template: function (row) {
												return '<span>' + bt.format_size(row.size) + '</span>';
											},
										},
										{ fid: 'addtime', title: '备份时间', width: 150 },
										{
											fid: 'ps',
											title: '备注',
											type: 'input',
											blur: function (row, index, ev, key, that) {
												if (row.ps == ev.target.value) return false;
												bt.pub.set_data_ps({ id: row.id, table: 'backup', ps: ev.target.value }, function (res) {
													bt_tools.msg(res, { is_dynamic: true });
												});
											},
											keyup: function (row, index, ev) {
												if (ev.keyCode === 13) $(this).blur();
											},
										},
										// {
										//   title:'操作',
										//   width:140,
										//   template:function(row){
										//     var _opt = '<a class="btlink" herf="javascrpit:;" onclick="bt.database.input_sql(\'' + row.filename + '\',\'' + dataname + '\')">恢复</a> | ';
										//          _opt += '<a class="btlink" href="/download?filename=' + row.filename + '&amp;name=' + row.name + '" target="_blank">下载</a> | ';
										//         _opt += '<a class="btlink" herf="javascrpit:;" onclick="bt.database.del_backup(\'' + row.id + '\',\'' + id + '\',\'' + dataname + '\',\'' + row.addtime + '\')">删除</a>'
										//         return '<span>'+ _opt +'</span>';
										//   }
										// }
										{
											title: '操作',
											type: 'group',
											align: 'right',
											group: [
												{
													title: '恢复',
													event: function (row, index, ev, key, that) {
														bt.database.input_sql(row.filename, dataname);
													},
												},
												{
													title: '下载',
													event: function (row, index, ev, key, that) {
														window.open('/download?filename=' + row.filename + '&amp;name=' + row.name + '');
													},
												},
												{
													title: '删除',
													event: function (row, index, ev, key, that) {
														bt.simple_confirm(
															{ title: '删除备份文件-' + row.addtime + '', msg: '删除选中备份文件后，<span class="color-red">该备份文件将永久消失</span>，是否继续操作？' },
															function (index) {
																bt_tools.send({ url: '/database/pgsql/DelBackup', data: { data: JSON.stringify({ id: row.id }) } }, function (ress) {
																	pgSql.$refresh_table_list();
																	database_table.$refresh_table_list();
																	layer.msg(ress.msg, { icon: ress.status ? 1 : 2 });
																});
															}
														);
													},
												},
											],
										},
									],
									tootls: [
										{
											type: 'batch',
											positon: ['left', 'bottom'],
											config: {
												title: '删除',
												url: '/site?action=DelBackup',
												paramId: 'id',
												load: true,
												callback: function (that, index) {
													layer.close(index);
													bt.confirm({ title: '批量删除数据库备份', msg: '批量删除选中的数据库备份，<span class="color-red">备份文件将永久消失</span>，是否继续操作？', icon: 0 }, function (index) {
														that.start_batch({}, function (list) {
															var html = '';
															for (var i = 0; i < list.length; i++) {
																var item = list[i];
																html +=
																	'<tr><td><span class="text-overflow" title="' +
																	item.name +
																	'">' +
																	item.name +
																	'</span></td><td><div style="float:right;"><span style="color:' +
																	(item.request.status ? '#20a53a' : 'red') +
																	'">' +
																	item.request.msg +
																	'</span></div></td></tr>';
															}
															pgSql.$batch_success_table({ title: '批量删除数据库备份', th: '文件名', html: html });
															pgSql.$refresh_table_list();
														});
													});
												},
											},
										},
										{
											//分页显示
											type: 'page',
											positon: ['right', 'bottom'], // 默认在右下角
											pageParam: 'p', //分页请求字段,默认为 : p
											page: 1, //当前分页 默认：1
											numberParam: 'limit', //分页数量请求字段默认为 : limit
											number: 10, //分页数量默认 : 20条
											numberList: [10, 20, 50, 100, 200], // 分页显示数量列表
											numberStatus: false, //　是否支持分页数量选择,默认禁用
											jump: false, //是否支持跳转分页,默认禁用
										},
									],
								});
								$('#btn_data_backupPgsql_All').click(function () {
									var allLoad = layer.msg('正在备份中,请稍后......', { icon: 16, shade: [0.3, '#000'], time: 0 });
									bt_tools.send(
										{ url: '/database/pgsql/ToBackup', data: { data: JSON.stringify({ id: id }) } },
										function (ress) {
											pgSql.$refresh_table_list();
											layer.msg(ress.msg, { icon: ress.status ? 1 : 2, shade: [0.3, '#000'], time: 0, shadeClose: true });
										},
										allLoad
									);
								});
								$('#btn_data_backupPgsql')
									.unbind('click')
									.click(function () {
										var pgsqlTable = null,
											btn_Type = 'db';
										bt_tools.open({
											title: '自定义备份 - [ ' + dataname + ' ]',
											area: ['600px', '560px'],
											class: 'p15',
											btn: ['备份', '取消'],
											content:
												'<div id="pgsqlForm"></div>\
																			<div id="dataBaseTablePgsql"></div><style type="text/css">#dataBaseTablePgsql thead th{background-color:#fff}</style>',
											success: function () {
												var pgsqlForm = bt_tools.form({
													el: '#pgsqlForm',
													class: 'pd20',
													form: [
														{
															group: {
																type: 'other',
																boxcontent: '<div><p>数据表</p><div id="dataBaseTablePgsql"></div></div>',
															},
														},
														{
															label: '备份方式',
															formLabelWidth: '71px',
															group: {
																type: 'radio',
																name: 'radioValue',
																width: '150px',
																value: 'db',
																list: [
																	{ title: '合并导出', value: 'db' },
																	{ title: '分表导出', value: 'table' },
																],
																event: function (formData, element, that) {
																	btn_Type = formData.radioValue;
																},
															},
														},
														{
															group: {
																type: 'help',
																list: ['合并导出：将选中的表导出到一个SQL文件内。', '分表导出：一张表存储为一个SQL文件。'],
															},
														},
													],
												});
												pgsqlTable = bt_tools.table({
													el: '#dataBaseTablePgsql',
													url: '/database/pgsql/GetInfo',
													default: '暂无数据',
													param: { data: JSON.stringify({ db_name: dataname }) },
													height: '250px',
													dataVerify: false, //为false可跳过异常处理
													tips: '正在获取数据，请稍后...',
													load: true,
													dataFilter: function (rdata) {
														return { data: rdata.data.table_list };
													},
													column: [
														{ type: 'checkbox', class: 'checkBoxs', width: 20 },
														{
															fid: 'table_name',
															fixed: true,
															width: 300,
															title: '全选',
														},
														{
															fid: 'rows_count',
															width: 100,
															title: '行数',
														},
														{
															fid: 'total_size',
															title: '总大小',
															width: 80,
														},
													],
												});
											},
											yes: function (formD, indexs) {
												if (pgsqlTable.checkbox_list.length < 1) {
													layer.msg('请至少选择一项', { icon: 2 });
													return;
												}
												var table_list = [];
												$.each(pgsqlTable.checkbox_list, function (index, value) {
													table_list.push(pgsqlTable.data[value].table_name);
												});
												var pgsql_Backup_load = layer.msg('正在备份中，请稍后...', { icon: 16, time: 0, shade: [0.3, '#000'] });
												bt_tools.send(
													{ url: '/database/pgsql/ToBackup', data: { data: JSON.stringify({ storage_type: btn_Type, table_list: table_list, id: id }) } },
													function (ress) {
														// layer.close(pgsql_Backup_load);
														pgSql.$refresh_table_list();
														layer.msg(ress.msg, { icon: ress.status ? 1 : 2, time: 0, shadeClose: true, shade: [0.3, '#000'] });
													},
													pgsql_Backup_load
												);
											},
											cancel: function () {},
										});
										$('#dataBaseTablePgsql').css('width', '560px');
									});
							},
						});
					}
				});
				$('#DataBackupListPgsql').css('min-height', '462px');
			}
		}
	},
	/**
	 * @description 日志
	 * @param {object}
	 */

	backupLogs: function (row, index, ev, key, that) {
		var _that = this;
		_that.getCrontabLogs(row, function (rdata) {
			layer.open({
				type: 1,
				title: lan.crontab.task_log_title,
				area: ['700px', '490px'],
				shadeClose: false,
				closeBtn: 2,
				content:
					'<div class="setchmod bt-form">\
          <pre class="crontab-log" style="overflow: auto; border: 0 none; line-height:23px;padding: 15px; margin: 0;white-space: pre-wrap; height: 405px; background-color: rgb(51,51,51);color:#f1f1f1;border-radius:0;"></pre>\
            <div class="bt-form-submit-btn" style="margin-top: 0">\
            <button type="button" class="btn btn-danger btn-sm btn-title" id="clearLogs" style="margin-right:15px;">' +
					lan['public']['empty'] +
					'</button>\
            <button type="button" class="btn btn-success btn-sm btn-title">' +
					lan['public']['close'] +
					'</button>\
          </div>\
        </div>',
				success: function (layers, index) {
					$(':focus').blur();
					var log_body = rdata.msg === '' ? '当前日志为空' : rdata.msg,
						setchmod = $('.setchmod pre'),
						crontab_log = $('.crontab-log')[0];
					setchmod.text(log_body);
					crontab_log.scrollTop = crontab_log.scrollHeight;
					$('#clearLogs').on('click', function () {
						_that.clearCrontabLogs(row, function () {
							setchmod.text('');
						});
					});
					$('.setchmod .bt-form-submit-btn .btn-success').click(function () {
						layer.close(index);
					});
				},
			});
		});
	},
	/**
	 * @description 执行备份任务
	 * @param {object} param 参数对象
	 * @param {function} callback 回调函数
	 */
	startCrontabTask: function (param, callback) {
		bt_tools.send(
			{
				url: '/crontab?action=StartTask',
				data: param,
			},
			function (res) {
				bt.msg(res);
				if (res.status && callback) callback(res);
			},
			'执行备份任务'
		);
	},
	/**
	 * @description 获取执行日志
	 * @param {object} param 参数对象
	 * @param {function} callback 回调函数
	 */
	getCrontabLogs: function (param, callback) {
		bt_tools.send(
			{
				url: '/crontab?action=GetLogs',
				data: param,
			},
			function (res) {
				if (res.status) {
					if (callback) callback(res);
				} else {
					bt.msg(res);
				}
			},
			'获取执行日志'
		);
	},
	/**
	 * @description 清空执行日志
	 * @param {object} param 参数对象
	 * @param {function} callback 回调函数
	 */
	clearCrontabLogs: function (param, callback) {
		bt_tools.send(
			{
				url: '/crontab?action=DelLogs',
				data: param,
			},
			function (res) {
				bt.msg(res);
				if (res.status && callback) callback(res);
			},
			'清空执行日志'
		);
	},
	/**
	 * @descripttion 消息推送下拉
	 */
	pushChannelMessage: {
		//获取通道状态
		getChannelSwitch: function (data, type) {
			var arry = [{ title: '全部通道', value: '' }],
				info = [];
			for (var resKey in data) {
				if (data.hasOwnProperty(resKey)) {
					var value = resKey,
						item = data[resKey];
					if (!item['setup'] || $.isEmptyObject(item['data'])) continue;
					info.push(value);
					arry.push({ title: item.title, value: value });
				}
			}
			arry[0].value = info.join(',');
			if (type === 'webshell') arry.shift();
			if (arry.length === (type === 'webshell' ? 0 : 1)) return [];
			return arry;
		},
	},
	// 备份导入》本地导入
	upload_files: function (name, callabcks) {
		var path = bt.get_cookie('backup_path') + '/database/';
		var type = $('.database-pos .tabs-item.active').data('type')
		var is_pgsql = (type === 'pgsql');
		if(type == 'pgsql' || type == 'mysql' || type == 'mongodb'){
			path +=type
		}
		bt_upload_file.open(path, is_pgsql ? '.sql' : '.sql,.zip,.bak,.gz', is_pgsql ? '请上传sql' : lan.database.input_up_type, function () {
			callabcks.$refresh_table_list();
			// database.input_database(name);
		});
	},
	//备份数据库
	backupList: function (type,db,type2) {
		var _that = this;
		$('#webedit-con-database').html('<div id="dbbackup_list"></div>');
		var arry1 = [],
			arry = [],
			tbObj = {};
		var url = '',
			params = {},
			alldbname = [],
			alltablesname = [];
		var search = {};
		dataBaseName(true);
		function dataBaseName(flag) {
			(database.databaseName = []), (alldbname = []), (arry1 = []),(tbObj = {});
			bt_tools.send({ url: 'project/binlog/get_databases' }, function (res) {
				if (res.data.length == 0) {
					database.databaseName = [{ title: '当前没有数据库', value: '' }];
					arry1 = database.databaseName;
				} else {
					database.databaseName = res.data;
					for (var i = 0; i < database.databaseName.length; i++) {
						alldbname.push(database.databaseName[i]);
					}
					$.each(alldbname, function (index, item) {
						arry1.push({ title: item.name + (item.cron_id == null || item.cron_id.length == 0 ? ' [无备份任务]' : ''), value: item.value });
						tbObj[item.value] = [];
						$.each(item.table_list, function (indexs, tb) {
							tbObj[item.value].push({ title: tb.tb_name + (tb.cron_id == null || tb.cron_id.length == 0 ? '[无备份任务]' : ''), value: tb.value })
						})
					});
				}
				// if (type === 1 && database.databaseName.length > 0) getTables(database.databaseName[0].name);
				if (flag) {
					if (type === 0) {
						url = 'project/binlog/get_databases_info';
						table();
					} else {
						if (database.databaseName.length == 0) {
							// $('.databaseBackup .database-menu p:eq(0)').click();
							return layer.msg('当前没有数据库!');
							// return layer.msg('当前没有数据库，不可查看备份表');
						}
						if(db){
							refresh(db)
						}else{
							refresh('全部数据库');
						}

					}
				}
			});
		}
		function refresh(res) {
			url = 'project/binlog/get_increment_crontab';
			// url = 'project/binlog/get_specified_database_info';
			// params = { datab_name: res, type: 'tables' };
			if(res == '全部数据库') {
				params = { db_name: '', };
			}else{
				params = { db_name: res, };
			}
			if (type == 1) {
				search = {
					type: 'search',
					positon: ['right', 'top'],
					placeholder: '请输入数据库名称',
					searchParam: 'datab_name', //搜索请求字段，默认为 search
					value: res, // 当前内容,默认为空
				};
			}
			table(res);
			var $dom = type2?$('#advance-con .tootls_group.tootls_top .pull-right'):$('#dbbackup_list .tootls_group.tootls_top .pull-right');
			$dom.prepend(
				'\
      <div class="selects_conter" style="position: relative;display: inline-block;">\
        <span class="select_text">数据库</span>\
        <div class="select_conter">\
        <span style="display: none;" class="database_hide_value"></span>\
        <input type="text" placeholder="请选择" autocomplete="off" class="inbox_input database_input"\
            name="inbox_input" style="border: none;" value="' +
				(res ? res : '') +
				'">\
      <ul class="database_list" id="database_select_list"></ul>\
      <span class="select_down"></span>\
    </div>\
    '
			);
			$('.select_conter input').on('focus', function (e) {
				var _that = $(this),
					database_list = $(this).next(),
					_list = database_list.find('li'),
					database_default = $(this).prev(),
					html = '';
				_list.siblings().removeClass('active');
				html += '<li ' + (_that.val() == '全部数据库' ? 'class="active"' : '') + '>全部数据库</li>';
				for (var i = 0; i < arry1.length; i++) {
					var item = arry1[i];
					html += '<li ' + (_that.val() == item.value ? 'class="active"' : '') + '>' + item.value + '</li>';
				}
				$('.database_list').html(html);
				database_list.width($(this)[0].clientWidth);
				$(document)
					.unbind('click')
					.on('click', function (ev) {
						if (ev.target.className.indexOf('inbox_input') == -1 && ev.target.className.indexOf('select_down') == -1) {
							if (_that.val() == '' || _that.val() != database_default.text()) {
								_that.val(database_default.text());
							}
							database_list.hide();
						} else {
							if (ev.target.className == 'select_down') {
								if (database_list.css('display') == 'block') {
									database_list.hide();
								} else {
									database_list.show();
								}
							} else {
								database_list.show();
							}
						}
						ev.stopPropagation();
					});
				return false;
			});
			$('.select_conter .select_down').on('click', function () {
				$('.select_conter input').focus();
			});
			$('.select_conter input').on('input', function (e) {
				var html = '',
					_that = $(this);
				if (_that.val() == '') {
					html += '<li class=" " >全部数据库</li>';
				}
				for (var i = 0; i < arry1.length; i++) {
					var item = arry1[i];
					if (_that.val() != '') {
						if (item.value.indexOf(_that.val()) > -1) {
							html += '<li ' + (_that.val() == item.value ? 'class="active"' : '') + '>' + item.value + '</li>';
						} else {
							html += '';
						}
					} else {
						html += '<li>' + item.value + '</li>';
					}
					$('.database_list').html(html);
				}
			});
			$('.select_conter input').on('keydown', function (e) {
				if (e.keyCode == 13) {
					if(type2){
						$('#advance-con').html('');
					}else{
						$('#dbbackup_list').html('');
					}

					refresh($(this).val());
				}
			});
			$('.select_conter').on('click', 'li', function (e) {
				var item_val = $(this).text(),
					input = $(this).parent().prev();
				$(this).addClass('active').siblings().removeClass('active').parent().hide();
				$(this).parent().siblings('.database_hide_value').html(item_val);
				$(this).parent().siblings('.database_input').text(item_val);
				if(type2){
					$('#advance-con').html('');
				}else{
					$('#dbbackup_list').html('');
				}
				refresh(item_val);
				input.val(item_val);
			});
		}
		function getTables(res, callabck) {
			(alltablesname = []), (arry = []);
			//获取指定数据库表名
			bt_tools.send({ url: 'project/binlog/get_tables', data: { db_name: res } }, function (res) {
				if (res.length == 0) {
					alltablesname = [{ title: '当前数据库下没有表', value: '' }];
					arry = alltablesname;
				} else {
					for (var i = 0; i < res.length; i++) {
						alltablesname.push(res[i]);
					}
					$.each(alltablesname, function (index, item) {
						arry.push({ title: item.name + (item.cron_id == null || item.cron_id.length == 0 ? ' [无备份任务]' : ''), value: item.name });
					});
				}
				if (callabck) callabck(arry);
			});
		}
		/**
		 * @description 删除计划任务
		 * @param {object} param 参数对象
		 * @param {function} callback 回调函数
		 */
		function delCrontab(param, callback) {
			bt.input_confirm(
				{ title: '删除备份任务【' + param.name + '】', value: '删除备份任务', msg: "删除备份任务后，<span class='color-org'>备份数据将永久消失</span>，是否继续操作？" },
				function () {
					bt_tools.send({
						url: '/crontab?action=DelCrontab',
						data: { id: param.id }
					}, function (res) {
						bt.msg(res)
						if (res.status && callback) callback(res)
					}, '删除计划任务');
				}
			);

		}
		function formatType(config, formData) {
			var formConfig = config;
			switch (formData.type) {
				case 'day-n':
				case 'month':
				case 'day':
					formConfig.group[1].display = false
					$.extend(formConfig.group[2], {
						display: formData.type !== 'day',
						unit: formData.type === 'day-n' ? '天' : '日'
					})
					formConfig.group[3].display = true
					break;
				case 'hour-n':
				case 'hour':
				case 'minute-n':
					formConfig.group[1].display = false
					formConfig.group[2].display = false
					formConfig.group[3].display = formData.type === 'hour-n'
					formConfig.group[4].value = formData.type === 'minute-n' ? 3 : 30
					break;
				case 'week':
					formConfig.group[1].display = true
					formConfig.group[1].value = parseInt(formData.week)
					formConfig.group[2].display = false
					formConfig.group[3].display = true
					break;

			}
			var num = formData.sType == 'logs' ? 0 : 1;
			var hour = formData.hour ? formData.hour : num;
			var minute = formData.minute ? formData.minute : 30;
			formConfig.group[3].value = parseInt(hour).toString();
			formConfig.group[4].value = parseInt(minute).toString()
			formConfig.group[0].value = formData.type;
			return config;
		}
		/**
		 * 获取告警设置
		 */
		function getAlarmSetting(value){
			// 获取告警列表
			bt_tools.send({
				url: '/config?action=get_msg_configs',
			}, function (alarms) {
				var html = '',alarmType = -1,accountConfigStatus = false,isConfig = []
				var channelType = ['mail','dingding','feishu','weixin','wx_account','sms']
				var channelName = ['邮箱','钉钉','飞书','企业微信','微信公众号','短信']
				var sendChannel = []
				var all = database.pushChannelMessage.getChannelSwitch(alarms, 'enterpriseBackup')
				$.each(all,function(index,item){
					isConfig.push(item.value)
					sendChannel.push({name: item.title,value: item.value})
				})
				$.each(channelType,function(index,item){
					if(isConfig.indexOf(item) == -1){
						sendChannel.push({name: channelName[index],value: item})
					}
				})
				sendChannel[0].name = '全部已安装通道'
				for(var i=0; i<sendChannel.length; i++){
					// if(rdata.msg == sendChannel[i].value) alarmType = i
					// if (sendChannel[i].value === 'wx_account') {
					// 	var item = alarms[sendChannel[i].value]
					// 	if (!$.isEmptyObject(item.data) && item.data.res.is_subscribe && item.data.res.is_bound) {
					// 		accountConfigStatus = true;
					// 	}
					// }
					var is_config = false
					if(sendChannel[i].value !='all' && sendChannel[i].value !=all[0].value){
						is_config = $.isEmptyObject(alarms[sendChannel[i].value].data)
					}
					html += '<li class="sn-alarm--item '+ (is_config ? ' disabled' : '') +'" name="'+sendChannel[i].value+'">'+sendChannel[i].name+ (is_config ? ' [<a target="_blank" class="bterror installNotice" data-type="' + sendChannel[i].value + '">未配置</a>]' : '') +'</li>'
				}
				$('.sn-alarm--list').html(html)
				$('.sn-alarm--channel').html(alarmType != -1 ? $('.sn-alarm--list .sn-alarm--item.active').hasClass('disabled') ? '请选择告警方式' : sendChannel[alarmType].name :'请选择告警方式')
				// 告警方式选择
				$('.sn-alarm--selectBox').off('click').on('click',function(e){
					var _ul = $(this).find('.sn-alarm--list');
					if(_ul.hasClass('show')){
						_ul.removeClass('show');
					}else{
						_ul.addClass('show');
					}
					$(document).one('click',function(){
						_ul.removeClass('show');
					})
					e.stopPropagation();
				})
				// 告警方式选择
				$('.sn-alarm--list').off('click').on('click','li',function(){
					if($(this).hasClass('disabled')) return
					var name = $(this).attr('name'),that = this;
					$('.sn-alarm--list li').removeClass('active')
					$(that).addClass('active')
					$('.sn-alarm--channel').text($(that).text())
					$('.sn-alarm--list').hide();
				})
				$('.sn-alarm--selectBox').find('.installNotice').unbind('click').click(function (ev) {
					ev.stopPropagation()
					var el = $(ev.currentTarget), type = $(el).data('type');
					openAlertModuleInstallView(type,null,function(){
						getAlarmSetting()
					});
				});
				if(value){
					$('.sn-alarm--list li').each(function(index,item){
						if(value == $(item).attr('name')){
							$(item).click()
							$('.sn-alarm--list').removeClass('show');
						}
					})
				}else{
					$('.sn-alarm--list li').eq(0).click();
					$('.sn-alarm--list').removeClass('show');
				}
			})
		}
		function table(db) {
			if(type2){
				$('#advance-con').html('');
			}else{
				$('#dbbackup_list').html('');
			}
			var backup_databases = bt_tools.table({
				el: type2? '#advance-con' : '#dbbackup_list',
				url: url,
				param: params,
				load: true,
				default: type === 0 ? '数据库备份列表为空' : '备份列表为空', //数据为空时的默认提示
				height: 260,
				column: [
					{ fid: 'db_name', title: '数据库名', type: 'text'},
					{ title: '表名', type: 'text',template:function(row){
							return '<span style="display:inline-block;max-width:200px;white-space: nowrap; text-overflow: ellipsis; overflow: hidden;" title="'+ row.tb_name +'">'+ row.tb_name +'</span>'
						} },
					{ fid: 'full_size', title: '备份大小', width: 80, type: 'text' },
					{ fid: 'last_backup_time', title: '备份时间', width: 150, type: 'text' },
					{
						title: '操作',
						type: 'group',
						width: 270,
						align: 'right',
						group: [
							{
								title: '执行',
								hide: function (row) {
									return row.cron_id == [] || row.cron_id.length == 0 ? true : false;
								},
								event: function (row, index, ev, key, that) {
									database.startCrontabTask({ id: row.cron_id }, function () {
										that.$refresh_table_list();
										database_table.$refresh_table_list(true);
									});
								},
							},
							{
								title: '日志',
								hide: function (row) {
									return row.cron_id == [] || row.cron_id.length == 0 ? true : false;
								},
								event: function (row, index, ev, key, that) {
									database.backupLogs({ id: row.cron_id }, index, ev, key, that);
								},
							},
							{
								title: '记录',
								event: function (row, index, ev, key, that) {
									that.new_resume_download_backup({ gp_type: 0, title: '恢复', datab_name: row.db_name,url:'/project/binlog/restore_time_database',params:{cron_id:row.cron_id} });
								},
							},
							// {
							// 	title: '导出',
							// 	event: function (row, index, ev, key, that) {
							// 		that.new_resume_download_backup({ gp_type: 1, title: '导出', datab_name: row.db_name,url:'/project/binlog/export_time_database',params:{cron_id:row.cron_id} });
							// 	},
							// },
							{
								title: '编辑',
								hide: function (row) {
									return row.cron_id == [] || row.cron_id.length == 0 ? true : false;
								},
								event: function (row, index, ev, key, that) {
									if (database.isLtdBackAndCap()) return;
									var editBackup = null;
									layer.open({
										type: 1,
										title: '编辑' + '[' + row.db_name + ']增量备份',
										closeBtn: 2,
										shadeClose: false,
										area: '590px',
										btn: ['提交', '取消'],
										skin: 'addDbbackup',
										content: '<div id="addDbbackup"></div>',
										success: function (layers, indexs) {
											$(':focus').blur();
											var mulpValues = [],
												mulpTitles = [];
											for (var i = 0; i < database.backuptoList.length; i++) {
												if (row['upload_' + database.backuptoList[i].value] == '') continue;
												mulpValues.push(row['upload_' + database.backuptoList[i].value]);
												mulpTitles.push(database.backuptoList[i].title);
											}
											editBackup = bt_tools.form({
												el: '#addDbbackup',
												data: row,
												class: 'pd15',
												form: [
													{
														label: '数据备份到',
														group: {
															type: 'multipleSelect',
															name: 'backupTo',
															width: '390px',
															value: row.backupTo,
															list: database.backuptoList,
															placeholder: '请选择数据备份到',
														},
													},
													{
														label: '压缩密码',
														group: {
															type: 'text',
															disabled: true,
															name: 'zip_password',
															width: '390px',
															value: row.zip_password,
														},
													},
													{
														label: '执行周期',
														group: [{
															type: 'select',
															name: 'type',
															value: 'week',
															width:'100px',
															list: [
																{ title: '每天', value: 'day' },
																{ title: 'N天', value: 'day-n' },
																{ title: '每小时', value: 'hour' },
																{ title: 'N小时', value: 'hour-n' },
																{ title: 'N分钟', value: 'minute-n' },
																{ title: '每星期', value: 'week' },
																{ title: '每月', value: 'month' }
															],
															change: function (formData, element, that) {
																formatType(that.config.form[2], formData)
																that.$replace_render_content(2)
															}
														}, {
															type: 'select',
															name: 'week',
															width: '70px',
															value: '1',
															list: [
																{ title: '周一', value: '1' },
																{ title: '周二', value: '2' },
																{ title: '周三', value: '3' },
																{ title: '周四', value: '4' },
																{ title: '周五', value: '5' },
																{ title: '周六', value: '6' },
																{ title: '周日', value: '0' }
															]
														}, {
															type: 'number',
															display: false,
															name: 'where1',
															'class': 'group',
															width: '50px',
															value: '3',
															unit: '日',
															min: 1,
															max: 31
														}, {
															type: 'number',
															name: 'hour',
															'class': 'group',
															width: '50px',
															value: '1',
															unit: '小时',
															min: 0,
															max: 23
														}, {
															type: 'number',
															name: 'minute',
															'class': 'group',
															width: '50px',
															min: 0,
															max: 59,
															value: '30',
															unit: '分钟'
														}]
													},
													{
														label: '备份提醒',
														group: [
															{
																type: 'select',
																name: 'notice',
																value: parseInt(row.notice),
																list: [
																	{ title: '不接收任何消息通知', value: 0 },
																	{ title: '任务执行失败接收通知', value: 1 },
																],
																change: function (formData, element, that) {
																	that.config.form[3].group[1].display = formData.notice == 0 ? false : true;
																	that.config.form[3].group[0].value = parseInt(formData.notice);
																	that.$replace_render_content(3);
																	if(formData.notice == 1) getAlarmSetting()
																},
															},
															{
																label: '消息通道',
																name: 'notice_channel',
																type: 'other',
																display: false,
																boxcontent:'<div class="sn-alarm--selectBox">\
																<span class="sn-alarm--channel">请选择告警方式</span>\
																<i class="sn-alram--selectIcon glyphicon glyphicon-menu-down"></i>\
																<ul class="sn-alarm--list"></ul>\
																</div>'
															},
														],
													},
												],
											});
											formatType(editBackup.config.form[2], row)
											editBackup.$replace_render_content(2)
											if(row.notice == 1) {
												editBackup.config.form[3].group[1].display = true;
												editBackup.$replace_render_content(3);
												getAlarmSetting(row.notice_channel)
											}
										},
										yes: function (indexs) {
											var formData = editBackup.$get_form_value();
											var _where1 = $('input[name=where1]'), _hour = $('input[name=hour]'), _minute = $('input[name=minute]')
											if (_where1.length > 0) {
												if (_where1.val() > 31 || _where1.val() < 1 || _where1.val() == '') {
													_where1.focus();
													layer.msg('请输入正确的周期范围[1-31]', { icon: 2 });
													return false;
												}
											}
											if (_hour.length > 0) {
												if (_hour.val() > 23 || _hour.val() < 0 || _hour.val() == '') {
													_hour.focus();
													layer.msg('请输入正确的小时范围[0-23]', { icon: 2 });
													return false;
												}
											}
											if (_minute.length > 0) {
												if (_minute.val() > 59 || _minute.val() < 0 || _minute.val() == '') {
													_minute.focus();
													layer.msg('请输入正确的分钟范围[0-59]', { icon: 2 });
													return false;
												}
											}
											switch (formData.type) {
												case "minute-n":
													formData.where1 = formData.minute;
													formData.minute = '';
													if(formData.where1 < 1) return bt.msg({ status: false, msg: '分钟不能小于1！' })
													break;
												case "hour-n":
													formData.where1 = formData.hour;
													formData.hour = '';
													if(formData.minute <= 0 && formData.where1 <= 0) return bt.msg({ status: false, msg: '小时、分钟不能同时小于1！' })
													break;
												// 天/日默认最小为1
											}
											formData['cron_type'] = 'hour-n';
											formData['backup_type'] = row.type;
											// formData['datab_name'] = type == 0 ? row.name : $('input[name=inbox_input]').val();
											formData['cron_id'] = row.cron_id;
											formData['backup_id'] = row.backup_id;
											formData['notice_channel'] = formData.notice == 0 ? '' : formData.notice_channel;
											var multipleValues = $('select[name=backupTo]').val();
											if (multipleValues == null) return layer.msg('请最少选择一个备份类型');
											(formData['notice_channel'] = formData.notice == 0 ? '' : $('.sn-alarm--list .active').attr('name'));
											(formData['name'] = 'MySQL数据库增量备份['+ row.db_name +']');
											(formData['db_name'] = row.db_name);
											(formData['tb_name'] = row.tb_name == '所有' ? '' : row.tb_name);
											(formData['backupTo'] = multipleValues.join('|'));
											(formData['sType'] = '');
											(formData['sBody'] = '');
											(formData['sName'] = '');
											(formData['urladdress'] = '');
											(formData['save'] = '');
											(formData['save_local'] = 1);
											(formData['id'] = row.cron_id);

											//编辑
											bt_tools.send(
												{ url: '/project/binlog/modify_mysql_increment_crontab', data: formData },
												function (res) {
													bt_tools.msg(res);
													if (res.status) {
														layer.close(indexs);
														that.$refresh_table_list();
														database_table.$refresh_table_list(true);
													}
												},
												'编辑备份任务'
											);
										},
									});
								},
							},
							{
								title: '删除',
								event: function (row, index, ev, key, that) {
									delCrontab({ id: row.cron_id,name:row.name }, function (rdata) {
										bt_tools.msg(rdata);
										if (rdata.status) {
											that.$refresh_table_list();
											database_table.$refresh_table_list(true);
											dataBaseName(false);
										}
									})
								},
							},
						],
					},
				],
				methods: {
					/**
					 * @description 恢复 导出
					 * @param {object} config
					 */
					new_resume_download_backup: function (config) {
						var open = bt_tools.open({
							title:'【' + config.datab_name + '】备份记录',
							area:['750px','430px'],
							btn:false,
							content:"<div id='showBackupTable' style='margin:0 20px;'></div>",
							success:function(el,indexs){
								//打开弹窗后执行的事件
								bt_tools.table({
									el:'#showBackupTable',
									url:'/project/binlog/get_backup',
									default:'暂无数据',
									height: '335px',
									param:config.params,
									dataVerify: false,  //为false可跳过异常处理
									dataFilter: function (rdata) {
										return {data: rdata.data}  //处理好数据后返回
									},
									column:[
										{
											fid: 'name',
											title: '备份名称',
											template:function(row){
												return "<span style='display:inline-block;width:310px;overflow:hidden;white-space: nowrap;text-overflow: ellipsis;' title='" + (row.localhost) +"'>" + (row.name) +"</span>"
											}
										},{
											fid: 'size',
											title: '备份大小',
											width:'120px',
											template:function(row){
												return "<span style='width:120px;'>" + (bt.format_size(row.size, true, 2)) +"</span>"
											}
										},{
											fid: 'type',
											title: '类型',
											width:'80px',
											template:function(row){
												return "<span style='width:100px;'>" + (row.type == 0? '增量':'全量') +"</span>"
											}
										},{
											fid: 'addtime',
											title: '时间点',
											width:'230px',
										},{
											title: "操作",
											type: 'group',
											align: 'right',
											width:'120px',
											group: [{
												title: '恢复',
												event: function (row, index, ev, key, that) {
													layer.open({
														type: 1,
														title: '恢复' + config.datab_name + '数据',
														icon: 0,
														skin: 'delete_site_layer',
														area: '530px',
														closeBtn: 2,
														shadeClose: true,
														content:
															"<div class='bt-form webDelete hint_confirm pd30' id='site_delete_form'>" +
															"<div class='hint_title'>\
                                  <i class='hint-confirm-icon'></i>\
                                  <div class='hint_con'>" +
															'恢复后会<span style="color:red;font-size:14px;font-weight: bold;">覆盖当前数据库数据</span>，此操作不可逆，是否继续操作？' +
															'</div>\
                                </div>' +
															"<div >" +
															'<br>' +
															"</div>\
                                  <div class='confirm-info-box'>\
                                    <div>请手动输入“<span class='color-red'>我已知晓</span>”，完成验证</div>\
                                    <input onpaste='return false;' id='prompt_input_box' type='text' value='' autocomplete='off' style='width: 440px;'>\
                                  </div>" +
															'</div>',
														btn: ['确认恢复', '取消恢复'],
														yes: function (indexs) {
															var result = bt.replace_all($('#prompt_input_box').val(), ' ', '');
															if (result == '我已知晓') {
																bt_tools.send({url:'/project/binlog/restore_time_database',data:{cron_id:config.params.cron_id,node_time:row.addtime}},function(res){
																	if(res.status){
																		layer.msg(res.msg,{icon:1})
																		layer.close(indexs)
																	}
																},'恢复' + '【' + config.datab_name + '】数据')
															} else {
																$('#prompt_input_box').focus();
																return layer.msg('验证失败，请重新输入', { icon: 2 });
															}
														},
														success: function () {
															$(':focus').blur();
														},
													});

												}
											},{
												title: '导出',
												event: function (row, index, ev, key, that) {
													bt_tools.send({url:'/project/binlog/export_time_database',data:{cron_id:config.params.cron_id,node_time:row.addtime}},function(res){
														if(res.status){
															if(res.data){
																bt_tools.open({
																	title:'导出【' + config.datab_name + '】数据',
																	area:['540px','360px'],
																	btn:false,
																	content:'<div id="">\
																			<div class="batch_title"><span class=""><span class="batch_icon"></span><span class="batch_text">导出成功！</span></span></div>\
																			<div class=" batch_tabel divtable" style="margin: 15px 30px 15px 30px;overflow: auto;height: 200px;">\
																			<table class="table table-hover"><thead>\
																			<tr><th>文件名称</th><th style="text-align:right;">文件大小</th><th style="text-align:right;width:150px;">操作</th></tr></thead><tbody><tr>\
																			<td title="'+ res.data.path +'">'+ res.data.name +'</td><td><div style="float:right;"><span>'+ bt.format_size(res.data.size, true, 2) +'</span></div></td>\
																			<td style="text-align: right;"><span style="width: 150px;"><a onclick="bt.pub.copy_pass(\''+ res.data.path +'\')" class="btlink group_1_srk5n" title="复制路径">复制路径</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="/download?filename=' + res.data.path +'" class="btlink group_2_srk5n" title="下载">下载</a></span></td>\
																			</tr></tbody></table></div>\
																			</div>',
																})
															}else{
																layer.msg(res.msg,{icon:1})
															}
															layer.close(indexs)
														}
													},'导出' + '【' + config.datab_name + '】数据')

												}
											}]
										}
									],
									success:function(){
										$('#showBackupTable').find('.tips').remove()
										$('#showBackupTable').append('<span class="tips" style="color:#ef0808">恢复：会从最早【全量备份】开始恢复至选择的【增量备份】时间点</span>')
									}
								})
							},
							btn2:function(){
								// 取消按钮
							}
						})
					},
					/**
					 * @description 旧 恢复 下载
					 * @param {object} config
					 */
					resume_download_backup: function (config) {
						layer.open({
							type: 1,
							title: config.title + (type === 0 ? '数据库' : '表') + '【' + config.datab_name + '】数据',
							closeBtn: 2,
							shadeClose: false,
							area: ['350px', config.backup_id == null ? '220px' : '170px'],
							skin: 'restore',
							content:
								'<div id="restore" class="bt-form pd15">\
                <div class="line" style="display: ' +
								(config.backup_id == null ? 'block' : 'none') +
								'">\
                  <span class="tname">解压密码</span>\
                  <div class="info-r">\
                    <input type="text" class="bt-input-text mr5 showPwd" name="zip_password" placeholder="请输入解压密码" />\
                  </div>\
                </div>\
                <div class="line">\
                  <span class="tname">' +
								config.title +
								'截止时间</span>\
                  <div class="info-r">\
                    <input id="calendar" type="text" class="bt-input-text mr5" name="calendar" placeholder="请输入' +
								config.title +
								'截止时间" readOnly />\
                  </div>\
                </div>\
              </div>',
							btn: ['确定' + config.title, '关闭'],
							success: function () {
								$(':focus').blur();
								laydate.render({
									elem: '#calendar',
									show: true, //直接显示
									closeStop: '#test1',
									theme: '#20a53a',
									trigger: 'click', //采用click弹出
									min: config.start_time,
									max: config.end_time,
									vlue: bt.get_date(365),
									type: 'datetime',
									format: 'yyyy-MM-dd HH:mm:ss',
									btns: ['clear', 'confirm'],
								});
							},
							yes: function (indexs) {
								var url = '',
									title = '';
								var params = {
									end_time: $('input[name=calendar]').val(),
								};
								if (params.end_time == '') return layer.msg('截止时间不能为空');
								if (config.backup_id == null) {
									if ($('input[name=zip_password]').val() == '') {
										return layer.msg('解压密码不能为空');
									} else {
										params['zip_password'] = $('input[name=zip_password]').val();
									}
								}
								if (type == 0) {
									params['datab_name'] = config.datab_name;
								} else {
									params['datab_name'] = $('input[name=inbox_input]').val();
									params['table_name'] = config.datab_name;
								}
								if (config.gp_type == 0) {
									//恢复
									url = 'project/binlog/restore_to_database';
									params['backup_id'] = config.backup_id;
									title = '恢复备份任务';
								} else {
									//下载
									params['backup_type'] = type == 0 ? 'databases' : 'tables';
									url = 'project/binlog/export_data';
									title = '下载备份任务';
								}
								bt_tools.send(
									{ url: url, data: params },
									function (res) {
										if (config.gp_type == 0) {
											layer.msg(res.msg, { icon: res.status ? 1 : 2 });
											if (res.status) layer.close(indexs);
										} else {
											if (typeof res.name == 'undefined') {
												if (!res.status) {
													layer.msg(res.msg, { icon: 2 });
												}
											} else {
												layer.close(indexs);
												window.location.href = '/download?filename=' + res.name;
											}
										}
									},
									title
								);
							},
						});
					},
					/**
					 * @description 删除站点备份
					 * @param {object} config
					 * @param {function} callback
					 */
					del_database_backup: function (config, callback) {
						bt.input_confirm(
							{ title: '删除备份任务【' + config.name + '】', value: '删除备份任务', msg: "删除备份任务后，<span class='color-org'>备份数据将永久消失</span>，是否继续操作？" },
							function () {
								bt_tools.send(
									{ url: 'project/binlog/delete_mysql_binlog_setting', data: { cron_id: config.cron_id, backup_id: config.backup_id, type: 'manager' } },
									function (rdata) {
										if (callback) callback(rdata);
									},
									'删除备份任务'
								);
							}
						);
					},
				},
				tootls: [
					{
						// 按钮组
						type: 'group',
						positon: ['left', 'top'],
						list: [
							{
								title: '添加备份任务',
								active: true,
								event: function (ev, that) {
									if (database.isLtdBackAndCap()) return;
									var addDBbackup = null;
									layer.open({
										type: 1,
										title: '添加备份任务',
										closeBtn: 2,
										shadeClose: false,
										area: '590px',
										btn: ['提交', '取消'],
										skin: 'addDbbackup',
										content: '<div id="addDbbackup"></div>',
										success: function (layers, indexs) {
											$('.addDbbackup').css('top', '410px');
											$(':focus').blur();
											addDBbackup = bt_tools.form({
												el: '#addDbbackup',
												class: 'pd15',
												form: [
													{
														label: '选择数据库',
														group: {
															type: 'select',
															name: 'db_name',
															width: '390px',
															list: arry1,
															value: db ? db : undefined,
															change: function (formData, element, that) {
																if (type == 1) {
																	// getTables(formData.datab_name, function (res) {
																	that.config.form[1].group.list = tbObj[formData.db_name];
																	that.config.form[1].group.value = that.config.form[1].group.list[0].value;
																	that.$replace_render_content(1);
																	var html = '<span class="tbName" style="white-space: nowrap; text-overflow: ellipsis; overflow: hidden;">所有</span>'
																	$('[data-name=tb_name] .bt_select_value').find('.bt_select_content').remove()
																	$('[data-name=tb_name] .bt_select_value').append(html)
																	$('[data-name=tb_name] .bt_select_list li').addClass('active')
																	// });
																}
															},
														},
													},
													{
														label: '选择表',
														hide: type === 1 ? false : true,
														group: {
															type: 'multipleSelect',
															name: 'tb_name',
															width: '390px',
															list: tbObj[arry1[0].value],
															value:[''],
															change: function (formData, element, that) {
																var li = $(this)
																var con = $('[data-name=tb_name] .bt_select_value')
																var value = $('select[name=tb_name]').val()
																if(!value){
																	layer.msg('至少选择1个！')
																	var oldValue = li.attr('title').split('[')[0]
																	value = [oldValue]
																	$('select[name=tb_name]').val([oldValue])
																	li.addClass('active')
																}
																if(li.attr('title')=='所有'){
																	//点击所有
																	if(li.hasClass('active')){
																		li.siblings().addClass('active')
																		$('select[name=tb_name]').val([''])
																		value = ['所有']
																	}else{
																		li.siblings().removeClass('active')
																		$('select[name=tb_name]').val([])
																		value = ['请选择表']
																	}
																}else{
																	if(li.hasClass('active')){
																		//其它选项选中
																		var isALL=true
																		li.siblings().not(':first').each(function(i){
																			if(!($(this).hasClass('active'))){
																				isALL=false
																				return
																			}
																		})
																		if(isALL){
																			$(li.siblings()[0]).addClass('active')
																			value = ['所有']
																			$('select[name=tb_name]').val([''])
																		}
																	}else{
																		//其它选项取消
																		$(li.siblings()[0]).removeClass('active')
																		$('select[name=tb_name]').val($('select[name=tb_name]').val()?.filter(item => item !== ''))
																		value = $('select[name=tb_name]').val()
																		// if(li.parent().prev().find('.bt_select_content').first().children().first().html()=='所有'){
																		// 	li.parent().prev().find('.bt_select_content').first().remove()
																		// }
																	}
																}
																$('.tbName').remove()
																$('.moreTips').remove()
																con.find('.bt_select_content_def').remove()
																var html = '<span class="tbName" style="width:280px;white-space: nowrap; text-overflow: ellipsis; overflow: hidden;">'+ value.join(',') +'</span>'
																var more = '<span class="moreTips">...等'+ value.length +'个表</span>'
																con.find('.bt_select_content').remove()
																con.append(html)
																if(value.length > 3){
																	con.append(more)
																}
																con.attr('title',value.join(','))
																con.parents('.info-r').siblings('.tname').css({'height':'35px','line-height':'35px'})
																con.siblings('.bt_select_list').css('top','47px')
																con.siblings('.bt_select_list_arrow').css('top','31px')
																con.siblings('.bt_select_list_arrow_fff').css('top','32px')
															}
														},
													},
													{
														label: '数据备份到',
														group: {
															type: 'multipleSelect',
															name: 'upload_alioss',
															width: '390px',
															value: ['localhost'],
															list: database.backuptoList,
															placeholder: '请选择数据备份到',
														},
													},
													{
														label: '压缩密码',
														group: {
															type: 'text',
															name: 'zip_password',
															width: '390px',
															placeholder: '请输入压缩密码，可为空',
															unit: '<span class="glyphicon glyphicon-repeat cursor mr5"></span>',
														},
													},
													// {
													// 	label: '备份周期',
													// 	group: [
													// 		{
													// 			type: 'number',
													// 			name: 'backup_cycle',
													// 			class: 'group_span',
													// 			width: '346px',
													// 			value: '3',
													// 			unit: '小时',
													// 			min: 0,
													// 			max: 23,
													// 		},
													// 	],
													// },
													{
														label: '执行周期',
														group: [{
															type: 'select',
															name: 'type',
															value: 'week',
															width:'100px',
															value:'hour-n',
															list: [
																{ title: '每天', value: 'day' },
																{ title: 'N天', value: 'day-n' },
																{ title: '每小时', value: 'hour' },
																{ title: 'N小时', value: 'hour-n' },
																{ title: 'N分钟', value: 'minute-n' },
																{ title: '每星期', value: 'week' },
																{ title: '每月', value: 'month' }
															],
															change: function (formData, element, that) {
																formatType(that.config.form[4], formData)
																that.$replace_render_content(4)
															}
														}, {
															type: 'select',
															name: 'week',
															width: '70px',
															display: false,
															value: '1',
															list: [
																{ title: '周一', value: '1' },
																{ title: '周二', value: '2' },
																{ title: '周三', value: '3' },
																{ title: '周四', value: '4' },
																{ title: '周五', value: '5' },
																{ title: '周六', value: '6' },
																{ title: '周日', value: '0' }
															]
														}, {
															type: 'number',
															display: false,
															name: 'where1',
															'class': 'group',
															width: '50px',
															value: '3',
															unit: '日',
															min: 1,
															max: 31
														}, {
															type: 'number',
															name: 'hour',
															'class': 'group',
															width: '50px',
															value: '1',
															unit: '小时',
															min: 0,
															max: 23
														}, {
															type: 'number',
															name: 'minute',
															'class': 'group',
															width: '50px',
															min: 0,
															max: 59,
															value: '30',
															unit: '分钟'
														}]
													},
													{
														label: '备份提醒',
														group: [
															{
																type: 'select',
																name: 'notice',
																value: 0,
																list: [
																	{ title: '不接收任何消息通知', value: 0 },
																	{ title: '任务执行失败接收通知', value: 1 },
																],
																change: function (formData, element, that) {
																	that.config.form[5].group[1].display = formData.notice == 0 ? false : true;
																	that.config.form[5].group[0].value = parseInt(formData.notice);
																	that.$replace_render_content(5);
																	if(formData.notice == 1) getAlarmSetting()
																},
															},
															{
																label: '消息通道',
																name: 'notice_channel',
																type: 'other',
																display: false,
																boxcontent:'<div class="sn-alarm--selectBox">\
																<span class="sn-alarm--channel">请选择告警方式</span>\
																<i class="sn-alram--selectIcon glyphicon glyphicon-menu-down"></i>\
																<ul class="sn-alarm--list"></ul>\
														</div>'
																// width: '100px',
																// placeholder: '未配置消息通道',
																// list: {
																// 	url: '/config?action=get_msg_configs',
																// 	dataFilter: function (res, that) {
																// 		return database.pushChannelMessage.getChannelSwitch(res, 'enterpriseBackup');
																// 	},
																// },
															},
															// {
															// 	type: 'link',
															// 	class: 'mr5',
															// 	title: '设置消息通道',
															// 	event: function (formData, element, that) {
															// 		open_three_channel_auth();
															// 	},
															// },
														],
													},
												],
											});
											var html = '<span class="tbName" style="white-space: nowrap; text-overflow: ellipsis; overflow: hidden;">所有</span>'
											$('[data-name=tb_name] .bt_select_value').find('.bt_select_content').remove()
											$('[data-name=tb_name] .bt_select_value').append(html)
											$('[data-name=tb_name] .bt_select_list li').addClass('active')
											$('#addDbbackup .pd15').append(
												"<ul class='help-info-text c7 mlr20'>\
                      <li style='color:red;'>注意：请牢记压缩密码，以免因压缩密码导致无法恢复和下载数据</li>\
                  </ul>"
											);
											$('#addDbbackup .unit .glyphicon-repeat').click(function () {
												$('#addDbbackup input[name=zip_password]').val(bt.get_random(bt.get_random_num(6, 10)));
											});
										},
										yes: function (indexs) {
											var formData = addDBbackup.$get_form_value();
											var _where1 = $('input[name=where1]'), _hour = $('input[name=hour]'), _minute = $('input[name=minute]')
											// if (formData.backup_cycle == '') return layer.msg('备份周期不能为空！');
											// if (formData.backup_cycle < 0) return layer.msg('备份周期不能小于0！');
											if (_where1.length > 0) {
												if (_where1.val() > 31 || _where1.val() < 1 || _where1.val() == '') {
													_where1.focus();
													layer.msg('请输入正确的周期范围[1-31]', { icon: 2 });
													return false;
												}
											}
											if (_hour.length > 0) {
												if (_hour.val() > 23 || _hour.val() < 0 || _hour.val() == '') {
													_hour.focus();
													layer.msg('请输入正确的小时范围[0-23]', { icon: 2 });
													return false;
												}
											}
											if (_minute.length > 0) {
												if (_minute.val() > 59 || _minute.val() < 0 || _minute.val() == '') {
													_minute.focus();
													layer.msg('请输入正确的分钟范围[0-59]', { icon: 2 });
													return false;
												}
											}
											switch (formData.type) {
												case "minute-n":
													formData.where1 = formData.minute;
													formData.minute = '';
													if(formData.where1 < 1) return bt.msg({ status: false, msg: '分钟不能小于1！' })
													break;
												case "hour-n":
													formData.where1 = formData.hour;
													formData.hour = '';
													if(formData.minute <= 0 && formData.where1 <= 0) return bt.msg({ status: false, msg: '小时、分钟不能同时小于1！' })
													break;
												// 天/日默认最小为1
											}
											formData['cron_type'] = 'hour-n';
											formData['backup_type'] = type === 0 ? 'databases' : 'tables';
											// if (formData.backup_type == 'tables') {
											// 	if (formData.table_name == '') return layer.msg('当前数据库下没有表，不能添加');
											// } else {
											// 	delete formData['table_name'];
											// }
											// if (formData.notice == 1) {
											// 	if (formData.notice_channel == undefined) return layer.msg('请设置消息通道');
											// }
											var multipleValues = $('select[name=upload_alioss]').val();
											if (multipleValues == null) return layer.msg('请最少选择一个备份类型');
											// (formData['upload_localhost'] = multipleValues.indexOf('localhost') > -1 ? 'localhost' : ''),
											// 	(formData['upload_alioss'] = multipleValues.indexOf('alioss') > -1 ? 'alioss' : ''),
											// 	(formData['upload_txcos'] = multipleValues.indexOf('txcos') > -1 ? 'txcos' : ''),
											// 	(formData['upload_qiniu'] = multipleValues.indexOf('qiniu') > -1 ? 'qiniu' : ''),
											// 	(formData['upload_obs'] = multipleValues.indexOf('obs') > -1 ? 'obs' : ''),
											// 	(formData['upload_bos'] = multipleValues.indexOf('bos') > -1 ? 'bos' : ''),
											(formData['notice_channel'] = formData.notice == 0 ? '' : $('.sn-alarm--list .active').attr('name'));
											(formData['name'] = 'MySQL数据库增量备份['+ formData['db_name'] +']');
											(formData['backupTo'] = multipleValues.join('|'));
											(formData['sType'] = 'enterpriseBackup');
											(formData['sBody'] = '');
											(formData['sName'] = 'tables');
											(formData['urladdress'] = '');
											(formData['save'] = '');
											(formData['save_local'] = 1);
											var tb_name = $('select[name=tb_name]').val()
											if(!tb_name) return layer.msg('请最少选择一个备份表');
											(formData['tb_name'] = tb_name.join(','));
											//添加
											bt_tools.send({ url: 'project/binlog/add_mysql_increment_crontab', data: formData }, function (res) {
												// bt_tools.msg(res);
												if (res.status) {
													layer.close(indexs);
													that.$refresh_table_list();
													database_table.$refresh_table_list(true);
													dataBaseName(false);
												}
											});
											// bt_tools.send({ url: 'project/binlog/add_mysqlbinlog_backup_setting', data: formData }, function (res) {
											// 	bt_tools.msg(res);
											// 	if (res.status) {
											// 		layer.close(indexs);
											// 		that.$refresh_table_list();
											// 		database_table.$refresh_table_list(true);
											// 		dataBaseName(false);
											// 	}
											// });
										},
									});
								},
							},
						],
					},
					//分页显示
					{
						type: 'page',
						positon: ['right', 'bottom'], // 默认在右下角
						pageParam: 'p', //分页请求字段,默认为 : p
						page: 1, //当前分页 默认：1
						// numberParam: 'limit',
						//分页数量请求字段默认为 : limit
						// defaultNumber: 10
						//分页数量默认 : 20条
					},
				],
			});
			if(type2){
				$('#advance-con').append(
					"<ul class='help-info-text c7'>\
            <li>备份大小：备份大小包含完全备份数据大小和增量备份数据大小</li>\
            <li>备份会保留一个星期的备份数据，当备份时，检测到完全备份为一个星期前，会重新完全备份</li>\
            <li>请勿同一时间添加多个备份任务，否则可能因同一时间执行多个备份任务导致文件句柄数打开过多或者爆内存</li>\
        </ul>"
				);
			}else{
				$('#dbbackup_list').append(
					"<ul class='help-info-text c7'>\
            <li>备份大小：备份大小包含完全备份数据大小和增量备份数据大小</li>\
            <li>备份会保留一个星期的备份数据，当备份时，检测到完全备份为一个星期前，会重新完全备份</li>\
            <li>请勿同一时间添加多个备份任务，否则可能因同一时间执行多个备份任务导致文件句柄数打开过多或者爆内存</li>\
        </ul>"
				);
			}

		}
	},
	isLtdBackAndCap: function () {
		var ltd = parseInt(bt.get_cookie('ltd_end') || -1);
		if (ltd <= 0) {
			var item = {
				name: 'enterprise_backup',
				pluginName: '企业增量备份',
				ps: '指定数据库或指定表增量备份，支持InnoDB和MyISAM两种存储引擎，可增量备份至服务器磁盘、阿里云OSS、腾讯云COS、七牛云存储、华为云存储、百度云存储',
				preview: false,
				description: ['快速恢复数据', '支持数据安全保护', '支持增量备份', '支持差异备份'],
				imgSrc: 'https://www.bt.cn/Public/new/plugin/introduce/database/backup.png',
			};
			bt.soft.product_pay_view({
				totalNum: 54,
				limit: 'ltd',
				closePro: true,
				pluginName: '企业增量备份',
				fun: function () {
					product_recommend.recommend_product_view(
						item,
						{
							imgArea: ['890px', '620px'],
						},
						'ltd',
						54,
						item.name,
						true
					);
				},
			});

			return true;
		}
		return false;
	},
	get_backup: function (type) {
		var that = this;
		if (bt.get_cookie('ltd_end')<0){
			var html='<div class="thumbnail-introduce-new" style="margin:0;padding:0px 0">\
              <div class="thumbnail-introduce-title-new" style="width:100%;justify-content:normal;flex-direction:column;padding-left: 24px;">\
                  <div class="thumbnail-title-left-new" style="width:100%;">\
                      <div class="thumbnail-title-text-new">\
                          <p>企业增量备份-功能介绍</p>\
                          <p>增量备份，保证数据库完整性，节约磁盘空间，提高备份效率，可恢复备份时间点.</p>\
                      </div>\
                  </div>\
                   <div class="thumbnail-title-button-new daily-product-buy"  style="margin:16px 0 0 0">\
                      <button class="btn btn-success btn-sm" style="width:80px" onclick="product_recommend.pay_product_sign(\'ltd\',301,\'ltd\')">立即购买</button>\
                  </div>\
            </div>\
              <div class="thumbnail-introduce-hr" style="margin:22px 0"></div>\
              <div class="thumbnail-introduce-ul-new" style="margin-bottom:20px">\
                <ul></ul>\
  					</div>\
  					<div class="img_view" style="position: relative;">\
  					  <img class="product_view_img thumbnail-box" src="https://www.bt.cn/Public/new/plugin/introduce/byDegreesBackup.png" style="width:auto;margin-top:10px;height:410px"/>\
  					</div>\
					</div>'
			$('#advance-con').html(html)
			return
		}
		bt_tools.send(
			{ url: 'project/binlog/get_binlog_status' },
			function (res) {
				if (type) {
					database.backupList(1, null, type);
				} else {
					if (res.status) {
						bt.open({
							type: 1,
							area: ['890px', '620px'],
							title: '企业增量备份',
							closeBtn: 2,
							skin: 'databaseBackup',
							shift: 0,
							content:
								"<div id='webedit-con-database' class='bt-w-con webedit-con pd15' style='margin-left:0;'></div>",
							success: function () {
								database.backupList(1);
							},
						});
					} else {
						soft.set_soft_config('mysql');
						setTimeout(function () {
							layer.msg('请检查数据库是否正常运行或二进制日志是否开启！', { time: 0, shadeClose: true, shade: 0.3 });
						}, 500);
					}
				}
			},
			'检测是否开启二进制日志'
		);
	},
	/**
	 * @name 删除导入的文件
	 * @author hwliang<2021-09-09>
	 * @param {string} filename
	 * @param {string} name
	 */
	rm_input_file: function (filename, name, callabckFn) {
		bt.files.del_file(filename, function (rdata) {
			bt.msg(rdata);
			callabckFn.$refresh_table_list();
			// database.input_database(name);
		});
	},
	// 备份导入
	input_database: function (name, mType) {
		bt_tools.open({
			title: lan.database.input_title_file,
			area: ['800px', '620px'],
			btn: false,
			content:
				'<div class="pd15 bt_table">\
                  <button class="btn btn-default btn-sm" id="uploadB" style="position:absolute;z-index:23">' +
				lan.database.input_local_up +
				'</button>\
                  <div id="DataInputMysql"></div>\
                  ' +
				bt.render_help(
					$('.database-pos .tabs-item.active').data('type') === 'pgsql'
						? ['仅支持：zip、gz、sql', bt.os != 'Linux' ? lan.database.input_ps3.replace(/\/www.*\/database/, path) : lan.database.input_ps3]
						: [lan.database.input_ps1, lan.database.input_ps2, bt.os != 'Linux' ? lan.database.input_ps3.replace(/\/www.*\/database/, path) : lan.database.input_ps3]
				) +
				'</div>',
			success: function () {},
			yes: function () {},
			cancel: function () {},
		});
		$('.help-info-text').css('margin-top', '0');
		$('#uploadB').click(function () {
			database.upload_files(name, dataInputMysql);
		});
		var listUrl =
				bt.data.db_tab_name == 'mysql'
					? '/database?action=GetBackup'
					: bt.data.db_tab_name == 'mongodb'
						? '/database/mongodb/GetBackup'
						: bt.data.db_tab_name == 'pgsql'
							? '/database/pgsql/GetBackup'
							: '',
			actionUrl =
				bt.data.db_tab_name == 'mysql'
					? '/database?action=InputSql'
					: bt.data.db_tab_name == 'mongodb'
						? '/database/mongodb/InputSql'
						: bt.data.db_tab_name == 'pgsql'
							? '/database/pgsql/InputSql'
							: '';
		var dataInputMysql = bt_tools.table({
			el: '#DataInputMysql',
			url: listUrl,
			default: '暂无数据',
			height: '400px',
			dataVerify: false, //为false可跳过异常处理
			dataFilter: function (rdata) {
				//return rdata  //不做处理
				return { data: rdata.data, page: rdata.page }; //处理好数据后返回
			},
			beforeRequest: function (beforeData) {
				if (beforeData.hasOwnProperty('data') && typeof beforeData.data === 'string') {
					delete beforeData['data'];
					return { data: JSON.stringify(beforeData) };
				}
				if (bt.data.db_tab_name == 'mysql') {
					return beforeData;
				}
				return { data: JSON.stringify(beforeData) };
			},
			column: [
				{
					title: lan.files.file_name,
					template: function (row) {
						return '<span title="' + row.path + '">' + row.name + '</span>';
					},
				},
				{
					fid: 'mtime',
					title: lan.files.file_etime,
					template: function (item) {
						return '<span>' + bt.format_data(item.mtime) + '</span>';
					},
				},
				{
					fid: 'size',
					title: '大小',
					template: function (item) {
						return '<span>' + bt.format_size(item.size) + '</span>';
					},
				},
				{
					title: '操作',
					type: 'group',
					align: 'right',
					group: [
						{
							title: '导入',
							event: function (row, index, ev, key, that) {
								var loadE = layer.msg('正在导入中', { icon: 16, time: 0, shadeClose: true, shade: [0.3, '#000'] });
								bt_tools.send(
									{ url: actionUrl, data: bt.data.db_tab_name == 'mysql' ? { file: row.path, name: name } : { data: JSON.stringify({ file: row.path, name: name }) } },
									function (ress) {
										layer.msg(ress.msg, { icon: ress.status ? 1 : 2,time: 0, shadeClose: true, shade: [0.3, '#000']});
									},
									loadE
								);
							},
						},
						{
							title: '删除',
							event: function (row, index, ev, key, that) {
								var callBack = dataInputMysql;
								database.rm_input_file(row.path, name, callBack);
							},
						},
					],
				},
			],
			tootls: [
				{
					// 搜索内容
					type: 'search',
					positon: ['right', 'top'],
					placeholder: '请输入文件名',
					searchParam: 'search', //搜索请求字段，默认为 search
					value: '', // 当前内容,默认为空
				},
				{
					//分页显示
					type: 'page',
					positon: ['right', 'bottom'], // 默认在右下角
					pageParam: 'p', //分页请求字段,默认为 : p
					page: 1, //当前分页 默认：1
					numberParam: 'limit',
					//分页数量请求字段默认为 : limit
					number: 10,
					//分页数量默认 : 20条
					numberList: [10, 20, 50, 100, 200], // 分页显示数量列表
					numberStatus: false, //　是否支持分页数量选择,默认禁用
					jump: false, //是否支持跳转分页,默认禁用
				},
			],
		});
		// for (var i = 0; i < rdata.FILES.length; i++) {
		//   if (rdata.FILES[i] == null) continue;
		//   var fmp = rdata.FILES[i].split(";");
		//   var ext = bt.get_file_ext(fmp[0]);
		//   if(mType == 'mongodb'){
		//     var intactExt = fmp[0].match(/\.(.*)/)[1]
		//     var mdbFileType = ["zip","gz","json","csv","json.zip","json.gz","csv.zip","csv.gz"]
		//     if($.inArray(intactExt,mdbFileType) == -1) continue;
		//   }else{
		//     if (ext != 'sql' && ext != 'zip' && ext != 'gz' && ext != 'tgz' && ext != 'bak') continue;
		//   }
		//   data.push({
		//     name: fmp[0],
		//     size: fmp[1],
		//     etime: fmp[2],
		//   })
		// }
		// if ($('#DataInputList').length <= 0) {
		//   bt.open({
		//     type: 1,
		//     skin: 'demo-class',
		//     area: ["600px", "478px"],
		//     title: lan.database.input_title_file,
		//     closeBtn: 2,
		//     shift: 5,
		//     shadeClose: false,
		//     content: '\
		//       <div class="pd15 bt_table">\
		//         <div class="clearfix">\
		//           <button class="btn btn-default btn-sm" onclick="database.upload_files(\'' + name + '\')">' + lan.database.input_local_up + '</button>\
		//           <div class="pull-right">\
		//             \
		//           </div>\
		//         </div>\
		//         <div class="divtable mtb15" style="max-height:274px; overflow:auto; border: 1px solid #ddd;">\
		//           <table id="DataInputList" class="table table-hover" style="border: none;"></table>\
		//         </div>' +
		//         bt.render_help($('.database-pos .tabs-item.active').data('type') === 'pgsql' ? ['仅支持：zip、gz、sql',(bt.os != 'Linux' ? lan.database.input_ps3.replace(/\/www.*\/database/, path) : lan.database.input_ps3)] : [lan.database.input_ps1, lan.database.input_ps2, (bt.os != 'Linux' ? lan.database.input_ps3.replace(/\/www.*\/database/, path) : lan.database.input_ps3)]) +
		//         '</div>\
		//       ',
		//     success:function(){
		// 			$(':focus').blur();
		//       if(mType == 'mongodb')$('.demo-class').find('.help-info-text').html('<li>仅支持zip、gz、json、csv、（.json.zip|.json.gz|.csv.zip|.csv.gz）</li><li>bson 格式需压缩成 zip|gz 压缩包结构：目录/目录/*.bson文件（目录名无要求）</li>')
		//     }
		//   });
		// }
		// setTimeout(function () {
		//   bt.fixed_table('DataInputList');
		//   bt.render({
		//     table: '#DataInputList',
		//     columns: [{
		//       field: 'name',
		//       title: lan.files.file_name,
		//       width: 240,
		//       fixed: true
		//     },
		//       {
		//         field: 'etime',
		//         title: lan.files.file_etime,
		//         templet: function (item) {
		//           return bt.format_data(item.etime);
		//         }
		//       },
		//       {
		//         field: 'size',
		//         title: lan.files.file_size,
		//         templet: function (item) {
		//           return bt.format_size(item.size)
		//         }
		//       },
		//       {
		//         field: 'opt',
		//         title: '操作',
		//         align: 'right',
		//         templet: function (item) {
		//           return '<a class="btlink" herf="javascrpit:;" onclick="bt.database.input_sql(\'' + bt.rtrim(rdata.PATH, '/') + "/" + item.name + '\',\'' + name + '\')">导入</a>  | <a class="btlink" herf="javascrpit:;" onclick="database.rm_input_file(\'' + bt.rtrim(rdata.PATH, '/') + "/" + item.name + '\',\'' + name + '\')">删除</a>';
		//         }
		//       },
		//     ],
		//     data: data
		//   });
		// }, 100)
	},
	// 工具
	rep_tools: function (db_name, res) {
		var loadT = layer.msg('正在获取数据,请稍候...', {
			icon: 16,
			time: 0,
		});
		bt.send(
			'GetInfo',
			'database/GetInfo',
			{
				db_name: db_name,
			},
			function (rdata) {
				layer.close(loadT);
				if (rdata.status === false) {
					layer.msg(rdata.msg, {
						icon: 2,
					});
					return;
				}
				var types = {
					InnoDB: 'MyISAM',
					MyISAM: 'InnoDB',
				};
				var tbody = render_body(rdata);

				function render_body(data) {
          var _tbody = ''
          for (var i = 0; i < data.tables.length; i++) {
            if (!types[data.tables[i].type]) continue;
            _tbody +=
              '<tr>\
                          <td><input value="dbtools_' +
                          data.tables[i].table_name +
              '" class="check" onclick="database.selected_tools(null,\'' +
              db_name +
              '\');" type="checkbox"></td>\
                          <td><span style="width:100px;"> ' +
                          data.tables[i].table_name +
              '</span></td>\
              <td><span><input type="text" style="width:120px;" title="点击编辑内容，按回车或失去焦点自动保存" class="table-input update-ps" data-name="'+ data.tables[i].table_name +'" data-value="'+ data.tables[i].comment +'" value="'+ data.tables[i].comment +'"></span></td>\
                          <td>' +
                          data.tables[i].type +
              '</td>\
                          <td><span style="width:90px;"> ' +
                          data.tables[i].collation +
              '</span></td>\
                          <td>' +
                          data.tables[i].rows_count +
              '</td>\
                          <td>' +
                          data.tables[i].data_size +
              '</td>\
                          <td style="text-align: right;">\
                              <a class="btlink" onclick="database.rep_database(\'' +
              db_name +
              "','" +
              data.tables[i].table_name +
              '\')">修复</a> |\
                              <a class="btlink" onclick="database.op_database(\'' +
              db_name +
              "','" +
              data.tables[i].table_name +
              '\')">优化</a> |\
                              <a class="btlink" onclick="database.to_database_type(\'' +
              db_name +
              "','" +
              data.tables[i].table_name +
              "','" +
              types[data.tables[i].type] +
              '\')">转为' +
              types[data.tables[i].type] +
              '</a>\
                          </td>\
                      </tr> ';
          }
          return _tbody;
				}

				if (res) {
					$('.gztr').html(tbody);
					$('#db_tools').html('');
					$("input[type='checkbox']").attr('checked', false);
					$('.tools_size').html('大小：' + rdata.data_size);
					return;
				}

				layer.open({
					type: 1,
					title: 'MySQL工具箱【' + db_name + '】',
					area: ['780px', '580px'],
					closeBtn: 2,
					shadeClose: false,
					content:
						'<div class="pd15 bt_table">\
                                <div class="db_list">\
                                    <span><a>数据库名称：' +
						db_name +
						'</a>\
                                    <a class="tools_size">大小：' +
						rdata.data_size +
						'</a></span>\
                                    <span id="db_tools" style="float: right;"></span>\
                                </div >\
                                <div class="divtable">\
                                <div  id="database_fix"  style="height:360px;overflow:auto;">\
                                <table class="table table-hover "style="border:none">\
                                    <thead>\
                                        <tr>\
                                            <th><input class="check" onclick="database.selected_tools(this,\'' +
						db_name +
						'\');" type="checkbox"></th>\
                                            <th>表名</th>\
																						<th>备注</th>\
                                            <th>引擎</th>\
                                            <th>字符集</th>\
                                            <th>行数</th>\
                                            <th>大小</th>\
                                            <th style="text-align: right;">操作</th>\
                                        </tr>\
                                    </thead>\
                                    <tbody class="gztr">' +
						tbody +
						'</tbody>\
                                </table>\
                                </div>\
                            </div>\
                            <ul class="help-info-text c7">\
                                <li>【修复】尝试使用REPAIR命令修复损坏的表，仅能做简单修复，若修复不成功请考虑使用myisamchk工具</li>\
                                <li>【优化】执行OPTIMIZE命令，可回收未释放的磁盘空间，建议每月执行一次</li>\
                                <li>【转为InnoDB/MyISAM】转换数据表引擎，建议将所有表转为InnoDB</li>\
                            </ul></div>',
					success: function () {
						$(':focus').blur();
						event()
            function event() {
              $('.update-ps').unbind('blur').blur(function(){
                var ps = $(this).data('value'),val = $(this).val(),name = $(this).data('name');
                if(ps == val) return false;
                bt_tools.send({url: '/database?action=ModifyTableComment',data: {db_name: db_name,table_name: name,comment: val}},function(res){
                  bt_tools.msg(res);
                  if(res.status) {
                    bt.send(
                      'GetInfo',
                      'database/GetInfo',
                      {
                        db_name: db_name,
                      },
                      function (rdata) {
                        $('.gztr').html(render_body(rdata));
                        event()
                      })
                  }
                })
              })
              $('.update-ps').unbind('keyup').keyup(function(e){
                if(e.keyCode == 13) $(this).blur();
              })
            }
					},
				});
				tableFixed('database_fix');
				//表格头固定
				function tableFixed(name) {
					var tableName = document.querySelector('#' + name);
					tableName.addEventListener('scroll', scrollHandle);
				}

				function scrollHandle(e) {
					var scrollTop = this.scrollTop;
					//this.querySelector('thead').style.transform = 'translateY(' + scrollTop + 'px)';
					$(this)
						.find('thead')
						.css({
							transform: 'translateY(' + scrollTop + 'px)',
							position: 'relative',
							'z-index': '1',
						});
				}
			}
		);
	},
	selected_tools: function (my_obj, db_name) {
		var is_checked = false;
		if (my_obj) is_checked = my_obj.checked;
		var db_tools = $("input[value^='dbtools_']");
		var n = 0;
		for (var i = 0; i < db_tools.length; i++) {
			if (my_obj) db_tools[i].checked = is_checked;
			if (db_tools[i].checked) n++;
		}
		if (n > 0) {
			var my_btns =
				'<button class="btn btn-default btn-sm" onclick="database.rep_database(\'' +
				db_name +
				'\',null)">修复</button><button class="btn btn-default btn-sm" onclick="database.op_database(\'' +
				db_name +
				'\',null)">优化</button><button class="btn btn-default btn-sm" onclick="database.to_database_type(\'' +
				db_name +
				'\',null,\'InnoDB\')">转为InnoDB</button></button><button class="btn btn-default btn-sm" onclick="database.to_database_type(\'' +
				db_name +
				"',null,'MyISAM')\">转为MyISAM</button>";
			$('#db_tools').html(my_btns);
		} else {
			$('#db_tools').html('');
		}
	},
	rep_database: function (db_name, tables) {
		dbs = database.rep_checkeds(tables);
		var loadT = layer.msg('已送修复指令,请稍候...', {
			icon: 16,
			time: 0,
		});
		bt.send(
			'ReTable',
			'database/ReTable',
			{
				db_name: db_name,
				tables: JSON.stringify(dbs),
			},
			function (rdata) {
				layer.close(loadT);
				if (rdata.status) {
					database.rep_tools(db_name, true);
				}
				layer.msg(rdata.msg, {
					icon: rdata.status ? 1 : 2,
				});
			}
		);
	},
	op_database: function (db_name, tables) {
		dbs = database.rep_checkeds(tables);
		var loadT = layer.msg('已送优化指令,请稍候...', {
			icon: 16,
			time: 0,
		});
		bt.send(
			'OpTable',
			'database/OpTable',
			{
				db_name: db_name,
				tables: JSON.stringify(dbs),
			},
			function (rdata) {
				layer.close(loadT);
				if (rdata.status) {
					database.rep_tools(db_name, true);
				}
				layer.msg(rdata.msg, {
					icon: rdata.status ? 1 : 2,
				});
			}
		);
	},
	to_database_type: function (db_name, tables, type) {
		dbs = database.rep_checkeds(tables);
		var loadT = layer.msg('已送引擎转换指令,请稍候...', {
			icon: 16,
			time: 0,
			shade: [0.3, '#000'],
		});
		bt.send(
			'AlTable',
			'database/AlTable',
			{
				db_name: db_name,
				tables: JSON.stringify(dbs),
				table_type: type,
			},
			function (rdata) {
				layer.close(loadT);
				if (rdata.status) {
					database.rep_tools(db_name, true);
				}
				layer.msg(rdata.msg, {
					icon: rdata.status ? 1 : 2,
				});
			}
		);
	},
	rep_checkeds: function (tables) {
		var dbs = [];
		if (tables) {
			dbs.push(tables);
		} else {
			var db_tools = $("input[value^='dbtools_']");
			for (var i = 0; i < db_tools.length; i++) {
				if (db_tools[i].checked) dbs.push(db_tools[i].value.replace('dbtools_', ''));
			}
		}

		if (dbs.length < 1) {
			layer.msg('请至少选择一张表!', {
				icon: 2,
			});
			return false;
		}
		return dbs;
	},
	// 改密
	set_data_pass: function (id, username, password) {
		var that = this,
			bs = bt.database.set_data_pass(function (rdata) {
				if (rdata.status) database_table.$refresh_table_list(true);
				bt.msg(rdata);
			});
		$('.name' + bs).val(username);
		$('.id' + bs).val(id);
		$('.password' + bs).val(password);
	},
	// 删除
	del_database: function (wid, dbname, obj, callback) {
		var is_db_type = false,
			del_data = [];
		if (typeof wid === 'object') {
			del_data = wid;
			is_db_type = wid.some(function (item) {
				return item.db_type > 0;
			});
			var ids = [];
			for (var i = 0; i < wid.length; i++) {
				ids.push(wid[i].id);
			}
			wid = ids;
		}
		var type = $('.database-pos .tabs-item.active').data('type'),
			title = '',
			tips = '';
		title = typeof dbname === 'function' ? '批量删除数据库' : '删除数据库 - [ ' + dbname + ' ]';
		tips =
			is_db_type || !recycle_bin_db_open || type !== 'mysql'
				? '<span class="color-red">当前列表存在彻底删除后无法恢复的数据库</span>，请仔细查看列表，以防误删，是否继续操作？'
				: '当前列表数据库将迁移至数据库回收站，如需彻底删除请前往数据库回收站，是否继续操作？';
		var arrs = wid instanceof Array ? wid : [wid];
		var ids = JSON.stringify(arrs),
			countDown = 9;
		if (arrs.length == 1) countDown = 4;
		var loadT = bt.load('正在检测数据库数据信息，请稍候...'),
			param = { url: 'database/' + bt.data.db_tab_name + '/check_del_data', data: { data: JSON.stringify({ ids: ids }) } };
		if (bt.data.db_tab_name == 'mysql') param = { url: 'database?action=check_del_data', data: { ids: ids } };
		bt_tools.send(param, function (res) {
			loadT.close();
			layer.open({
				type: 1,
				title: title,
				area: '740px',
				skin: 'verify_site_layer_info active',
				closeBtn: 2,
				shadeClose: true,
				content:
					'<div class="check_delete_site_main hint_confirm pd30">' +
					"<div class='hint_title'>\
            <i class='hint-confirm-icon'></i>\
            <div class='hint_con'>" +
					tips +
					'</div>\
          </div>' +
					'<div id="check_layer_content" class="ptb15">' +
					'</div>' +
					'<div class="check_layer_message">' +
					(is_db_type ? '<span class="color-red">注意：远程数据库暂不支持数据库回收站，选中的数据库将彻底删除</span><br>' : '') +
					(!recycle_bin_db_open ? '<span class="color-red">风险操作：当前数据库回收站未开启，删除数据库将永久消失</span><br>' : '') +
					'<span class="message_count">请仔细阅读以上要删除信息，防止数据库被误删，下一步还有 <span class="count_down" style="color:red;font-weight: bold;">' +
					countDown +
					'</span> 秒可以操作。</span></div>' +
					'<div style="margin-top: 10px;"><span class="message_count" style="color:red;">注：数据库回收站仅适用于当前数据库，无法作用于切换数据库版本后还原，如有备份还原需求请进行数据备份<span></div>'+
					'</div>',
				// btn: ['下一步(' + countDown + '秒后继续操作)', lan.public.cancel],
				btn: ['下一步', lan.public.cancel],
				success: function (layers) {
					$(':focus').blur();
					setTimeout(function () {
						$(layers).css('top', ($(window).height() - $(layers).height()) / 2);
					}, 50);
					var rdata = res.data,
						newTime = parseInt(new Date().getTime() / 1000),
						t_icon = ' <span class="glyphicon glyphicon-info-sign" style="color: red;width:15px;height: 15px;;vertical-align: middle;"></span>';
					for (var j = 0; j < rdata.length; j++) {
						for (var i = 0; i < del_data.length; i++) {
							if (rdata[j].id == del_data[i].id) {
								var is_time_rule = newTime - rdata[j].st_time > 86400 * 30 && rdata[j].total > 1024 * 10,
									is_database_rule = res.db_size <= rdata[j].total,
									database_time = bt.format_data(rdata[j].st_time, 'yyyy-MM-dd'),
									database_size = bt.format_size(rdata[j].total);
								var f_size = database_size;
								var t_size = '注意：此数据库较大，可能为重要数据，请谨慎操作.\n数据库：' + database_size;
								if (rdata[j].total < 2048) t_size = '注意事项：当前数据库不为空，可能为重要数据，请谨慎操作.\n数据库：' + database_size;
								if (rdata[j].total === 0) t_size = '';
								rdata[j]['t_size'] = t_size;
								rdata[j]['f_size'] = f_size;
								rdata[j]['database_time'] = database_time;
								rdata[j]['is_time_rule'] = is_time_rule;
								rdata[j]['is_database_rule'] = is_database_rule;
								rdata[j]['db_type'] = del_data[i].db_type;
								rdata[j]['conn_config'] = del_data[i].conn_config;
							}
						}
					}
					var filterData = rdata.filter(function (el) {
						return ids.indexOf(el.id) != -1;
					});
					bt_tools.table({
						el: '#check_layer_content',
						data: filterData,
						height: '300px',
						column: [
							{ fid: 'name', title: '数据库名称' },
							{
								title: '数据库大小',
								template: function (row) {
									return (
										'<span class="' + (row.is_database_rule ? 'warning' : '') + '" style="width: 110px;" title="' + row.t_size + '">' + row.f_size + (row.is_database_rule ? t_icon : '') + '</span>'
									);
								},
							},
							{
								title: '数据库位置',
								template: function (row) {
									var type_column = '-';
									switch (row.db_type) {
										case 0:
											type_column = '本地数据库';
											break;
										case 1:
										case 2:
											type_column = '远程数据库';
											break;
									}
									return '<span style="width: 110px;" title="' + type_column + '">' + type_column + '</span>';
								},
							},
							{
								title: '创建时间',
								template: function (row) {
									return (
										'<span ' +
										(is_time_rule && row.total != 0 ? 'class="warning"' : '') +
										' title="' +
										(row.is_time_rule && row.total != 0 ? '重要：此数据库创建时间较早，可能为重要数据，请谨慎操作.' : '') +
										'时间：' +
										row.database_time +
										'">' +
										row.database_time +
										'</span>'
									);
								},
							},
							{
								title: '删除结果',
								align: 'right',
								template: function (row, index, ev, _that) {
									var _html = '';
									switch (row.db_type) {
										case 0:
											_html = type !== 'mysql' ? '彻底删除' : !recycle_bin_db_open ? '彻底删除' : '移至回收站';
											break;
										case 1:
										case 2:
											_html = '彻底删除';
											break;
									}
									return '<span style="width: 110px;" class="' + (_html === '彻底删除' ? 'warning' + (row.db_type > 0 ? ' remote_database' : '') : '') + '">' + _html + '</span>';
								},
							},
						],
						success: function () {
							$('#check_layer_content')
								.find('.glyphicon-info-sign')
								.click(function (e) {
									var msg = $(this).parent().prop('title');
									msg = msg.replace('数据库：', '<br>数据库：');
									layer.tips(msg, $(this).parent(), { tips: [1, 'red'], time: 3000 });
									$(document).click(function (ev) {
										layer.closeAll('tips');
										$(this).unbind('click');
										ev.stopPropagation();
										ev.preventDefault();
									});
									e.stopPropagation();
									e.preventDefault();
								});

							if ($('.remote_database').length) {
								$('.remote_database').each(function (index, el) {
									var id = $(el).parent().parent().parent().index();
									$('#check_layer_content tbody tr').eq(id).css('background-color', '#ff00000a');
								});
							}
						},
					});
					var is_once = false;
					$('#check_layer_content .divtable').scroll(function () {
						var top = $(this).scrollTop();
						if (top + 302 >= $(this)[0].scrollHeight) {
							is_once = true;
							$(layers).removeClass('on');
						}
					});
					var interVal = setInterval(function () {
						countDown--;
						// $(layers)
						// 	.find('.layui-layer-btn0')
						// 	.text('下一步(' + countDown + '秒后继续操作)');
						$(layers).find('.check_layer_message .count_down').text(countDown);
					}, 1000);
					setTimeout(function () {
						$(layers).find('.layui-layer-btn0').text('下一步');
						$(layers).find('.check_layer_message .message_count').html('<span style="color:red">请仔细阅读以上要删除信息，防止数据库被误删</span>');
						if ($('#check_layer_content table').height() > 300) {
							if (is_once == false) $(layers).addClass('on');
						}
						$(layers).removeClass('active');
						clearInterval(interVal);
					}, countDown * 1000);
				},
				yes: function (indes, layers) {
					if ($(layers).hasClass('on')) {
						layer.tips('请确认信息，将列表滚动到底部', $(layers).find('.layui-layer-btn0'), {
							tips: [1, 'red'],
							time: 3000,
						});
						return;
					}
					if ($(layers).hasClass('active')) {
						layer.tips('请确认信息，稍候再尝试，还剩' + countDown + '秒', $(layers).find('.layui-layer-btn0'), {
							tips: [1, 'red'],
							time: 3000,
						});
						return;
					}
					title = typeof dbname === 'function' ? '二次验证信息，批量删除数据库' : '二次验证信息，删除数据库 - [ ' + dbname + ' ]';
					if (type !== 'mysql') {
						tips = '<span class="color-red">当前数据库暂不支持数据库回收站，删除后将无法恢复</span>，此操作不可逆，是否继续操作？';
					} else {
						tips = is_db_type
							? '<span class="color-red">远程数据库不支持数据库回收站，删除后将无法恢复</span>，此操作不可逆，是否继续操作？'
							: recycle_bin_db_open
								? '删除后如需彻底删除请前往数据库回收站，是否继续操作？'
								: '删除后可能会影响业务使用，此操作不可逆，是否继续操作？';
					}
					layer.open({
						type: 1,
						title: title,
						icon: 0,
						skin: 'delete_site_layer',
						area: '530px',
						closeBtn: 2,
						shadeClose: true,
						content:
							"<div class='bt-form webDelete hint_confirm pd30' id='site_delete_form'>" +
							"<div class='hint_title'>\
                  <i class='hint-confirm-icon'></i>\
                  <div class='hint_con'>" +
							tips +
							'</div>\
                </div>' +
							"<div style='color:red;margin:18px 0 18px 18px;font-size:14px;font-weight: bold;'>注意：数据无价，请谨慎操作！！！" +
							(type === 'mysql' && !recycle_bin_db_open ? '<br>风险操作：当前数据库回收站未开启，删除数据库将永久消失！' : '') +
							"</div>\
                  <div class='confirm-info-box'>\
                    <div>请手动输入“<span class='color-red'>删除数据库</span>”，完成验证</div>\
                    <input onpaste='return false;' id='prompt_input_box' type='text' value='' autocomplete='off' style='width: 440px;'>\
                  </div>" +
							'</div>',
						btn: ['确认删除', '取消删除'],
						yes: function (indexs) {
							var data = {
								id: wid,
								name: dbname,
							};
							var result = bt.replace_all($('#prompt_input_box').val(), ' ', '');
							if (result == '删除数据库') {
								if (typeof dbname === 'function') {
									delete data.id;
									delete data.name;
								}
								layer.close(indexs);
								layer.close(indes);
								if (typeof dbname === 'function') {
									dbname(data);
								} else {
									data.id = data.id[0];
									bt.database.del_database(data, function (rdata) {
										layer.closeAll();
										if (callback) callback(rdata);
										bt.msg(rdata);
									});
								}
							} else {
								$('#prompt_input_box').focus();
								return layer.msg('验证失败，请重新输入', { icon: 2 });
							}
						},
						success: function () {
							$(':focus').blur();
						},
					});
				},
			});
		});
	},
};

var sql_server = {
	database_table_view: function (search) {
		var param = {
			table: 'databases',
			search: search || '',
		};
		$('#bt_sqldatabase_table').empty();
		database_table = bt_tools.table({
			el: '#bt_sqldatabase_table',
			url: 'database/sqlserver/get_list',
			param: param, //参数
			minWidth: '1000px',
			load: true,
			autoHeight: true,
			default: '数据库列表为空', // 数据为空时的默认提示
			pageName: 'database',
			clickInto:'您的数据库列表为空，您可以<a class="btlink" onClick="$(\'#bt_sqldatabase_table .pull-left button\').eq(0).click()">添加一个数据库</a>',
			beforeRequest: function (beforeData) {
				var db_type_val = $('.sqlserver_type_select_filter').val();
				switch (db_type_val) {
					case 'all':
						delete param['db_type'];
						delete param['sid'];
						break;
					case 0:
						param['db_type'] = 0;
						break;
					default:
						delete param['db_type'];
						param['sid'] = db_type_val;
				}
				if (beforeData.hasOwnProperty('data') && typeof beforeData.data === 'string') {
					delete beforeData['data'];
					return { data: JSON.stringify($.extend(param, beforeData)) };
				}
				return { data: JSON.stringify(param) };
			},
			column: [
				{ type: 'checkbox', width: 20 },
				{ fid: 'name', title: '数据库名', type: 'text' },
				{ fid: 'username', title: '用户名', type: 'text', sort: true },
				{ fid: 'password', title: '密码', type: 'password', copy: true, eye_open: true },
				{
					title: '数据库位置',
					type: 'text',
					width: 116,
					template: function (row) {
						var type_column = '-';
						switch (row.db_type) {
							case 0:
								type_column = '本地数据库';
								break;
							case 1:
								type_column = ('远程库(' + row.conn_config.db_host + ':' + row.conn_config.db_port + ')').toString();
								break;
							case 2:
								$.each(cloudDatabaseList, function (index, item) {
									if (row.sid == item.id) {
										if (item.ps !== '') {
											// 默认显示备注
											type_column = item.ps;
										} else {
											type_column = ('远程服务器(' + item.db_host + ':' + item.db_port + ')').toString();
										}
									}
								});
								break;
						}
						return '<span class="flex" style="width:100px" title="' + type_column + '"><span class="size_ellipsis" style="width: 0; flex: 1;">' + type_column + '</span></span>';
					},
				},
				{
					fid: 'ps',
					title: '备注',
					type: 'input',
					blur: function (row, index, ev) {
						bt.pub.set_data_ps(
							{
								id: row.id,
								table: 'databases',
								ps: ev.target.value,
							},
							function (res) {
								layer.msg(
									res.msg,
									res.status
										? {}
										: {
											icon: 2,
										}
								);
							}
						);
					},
					keyup: function (row, index, ev) {
						if (ev.keyCode === 13) {
							$(this).blur();
						}
					},
				},
				{
					type: 'group',
					title: '操作',
					width: 220,
					align: 'right',
					group: [
						{
							title: '改密',
							tips: '修改数据库密码',
							hide: function (rows) {
								return rows.db_type == 1;
							},
							event: function (row) {
								database.set_data_pass(row.id, row.username, row.password);
							},
						},
						{
							title: '删除',
							tips: '删除数据库',
							event: function (row) {
								var list = [];
								list.push(row);
								database.del_database(list, row.name, row, function (res) {
									if (res.status) database_table.$refresh_table_list(true);
									layer.msg(res.msg, {
										icon: res.status ? 1 : 2,
									});
								});
							},
						},
					],
				},
			],
			sortParam: function (data) {
				return {
					order: data.name + ' ' + data.sort,
				};
			},
			tootls: [
				{
					// 按钮组
					type: 'group',
					positon: ['left', 'top'],
					list: [
						{
							title: '添加数据库',
							active: true,
							event: function () {
								var cloudList = [];
								$.each(cloudDatabaseList, function (index, item) {
									var _tips = item.ps != '' ? item.ps + ' (' + item.db_host + ')' : item.db_host;
									cloudList.push({ title: _tips, value: item.id, name: item.db_host });
								});
								bt.database.add_database(cloudList, function (res) {
									if (res.status) database_table.$refresh_table_list(true);
								});
							},
						},
						{
							title: '远程服务器',
							event: function () {
								db_public_fn.get_cloud_server_list();
							},
						},
					],
				},
				{
					type: 'batch', //batch_btn
					positon: ['left', 'bottom'],
					placeholder: '请选择批量操作',
					buttonValue: '批量操作',
					disabledSelectValue: '请选择需要批量操作的数据库!',
					selectList: [
						{
							title: '同步数据库',
							url: '/database/' + bt.data.db_tab_name + '/SyncToDatabases',
							// paramName: 'data', //列表参数名,可以为空
							// th:'数据库名称',
							// beforeRequest: function(list) {
							//   var arry = [];
							//   $.each(list, function (index, item) {
							//     arry.push(item.id);
							//   });
							//   return JSON.stringify({ids:JSON.stringify(arry),type:1})
							// },
							// success: function (res, list, that) {
							//   layer.closeAll();
							//   var html = '';
							//   $.each(list, function (index, item) {
							//     html += '<tr><td>' + item.name + '</td><td><div style="float:right;"><span style="color:' + (res.status ? '#20a53a' : 'red') + '">' + res.msg + '</span></div></td></tr>';
							//   });
							//   that.$batch_success_table({
							//     title: '批量同步选中',
							//     th: '数据库名称',
							//     html: html
							//   });
							// }
							param: function (row) {
								var arry = [];
								arry.push(row.id);
								return { data: JSON.stringify({ ids: JSON.stringify(arry), type: 1 }) };
							},
							callback: function (that) {
								// 手动执行,data参数包含所有选中的站点
								bt.simple_confirm({ title: '批量同步数据库', msg: '批量同步选中的数据库，同步过程中可能存在风险，请在闲置时间段同步数据库，是否继续操作？' }, function () {
									var param = {};
									that.start_batch(param, function (list) {
										var html = '';
										for (var i = 0; i < list.length; i++) {
											var item = list[i];
											html +=
												'<tr><td>' +
												item.name +
												'</td><td><div style="float:right;"><span style="color:' +
												(item.request.status ? '#20a53a' : 'red') +
												'">' +
												item.request.msg +
												'</span></div></td></tr>';
										}
										database_table.$batch_success_table({ title: '批量同步数据库', th: '数据库名', html: html });
										database_table.$refresh_table_list(true);
									});
								});
							},
						},
						{
							title: '删除数据库',
							url: '/database/' + bt.data.db_tab_name + '/DeleteDatabase',
							load: true,
							param: function (row) {
								return {
									data: JSON.stringify({
										id: row.id,
										name: row.name,
									}),
								};
							},
							callback: function (that) {
								// 手动执行,data参数包含所有选中的站点
								var ids = [];
								for (var i = 0; i < that.check_list.length; i++) {
									ids.push(that.check_list[i].id);
								}
								database.del_database(that.check_list, function (param) {
									that.start_batch(param, function (list) {
										layer.closeAll();
										var html = '';
										for (var i = 0; i < list.length; i++) {
											var item = list[i];
											html +=
												'<tr><td>' +
												item.name +
												'</td><td><div style="float:right;"><span style="color:' +
												(item.request.status ? '#20a53a' : 'red') +
												'">' +
												item.request.msg +
												'</span></div></td></tr>';
										}
										database_table.$batch_success_table({
											title: '批量删除',
											th: '数据库名称',
											html: html,
										});
										database_table.$refresh_table_list(true);
									});
								});
							},
						},
					],
				},
				{
					type: 'search',
					positon: ['right', 'top'],
					placeholder: '请输入数据库名称/备注',
					searchParam: 'search', //搜索请求字段，默认为 search
					value: '', // 当前内容,默认为空
				},
				{
					//分页显示
					type: 'page',
					positon: ['right', 'bottom'], // 默认在右下角
					pageParam: 'p', //分页请求字段,默认为 : p
					page: 1, //当前分页 默认：1
					numberParam: 'limit', //分页数量请求字段默认为 : limit
					number: 20, //分页数量默认 : 20条
					numberList: [10, 20, 50, 100, 200], // 分页显示数量列表
					numberStatus: true, //　是否支持分页数量选择,默认禁用
					jump: true, //是否支持跳转分页,默认禁用
				},
			],
			success: function (config) {
				//搜索前面新增数据库位置下拉
				if ($('.sqlserver_type_select_filter').length == 0) {
					var _option = '<option value="all">全部</option>';
					$.each(cloudDatabaseList, function (index, item) {
						var _tips = item.ps != '' ? item.ps : item.db_host;
						_option += '<option value="' + item.id + '">' + _tips + '</option>';
					});
					$('#bt_sqldatabase_table .bt_search').before('<select class="bt-input-text mr5 sqlserver_type_select_filter" style="width:110px" name="db_type_filter">' + _option + '</select>');

					//事件
					$('.sqlserver_type_select_filter').change(function () {
						database_table.config.page.page = 1;
						database_table.$refresh_table_list(true);
					});
				}
				if($('#bt_sqldatabase_table .db_sync_setting').length == 0){
					db_public_fn.get_sync_all_server('#bt_sqldatabase_table','button:eq(1)')
				}
			},
		});
	},
};

var mongodb = {
	database_table_view: function (search) {
		var param = {
			table: 'databases',
			search: search || '',
		};
		$('#bt_mongodb_table').empty();
		database_table = bt_tools.table({
			el: '#bt_mongodb_table',
			url: 'database/mongodb/get_list',
			param: param, //参数
			minWidth: '1000px',
			load: true,
			autoHeight: true,
			default: '数据库列表为空', // 数据为空时的默认提示
			pageName: 'database',
			clickInto:'您的数据库列表为空，您可以<a class="btlink" onClick="$(\'#bt_mongodb_table .pull-left button\').eq(0).click()">添加一个数据库</a>',
			beforeRequest: function (beforeData) {
				var db_type_val = $('.mongodb_type_select_filter').val();
				switch (db_type_val) {
					case 'all':
						delete param['db_type'];
						delete param['sid'];
						break;
					case 0:
						param['db_type'] = 0;
						break;
					default:
						delete param['db_type'];
						param['sid'] = db_type_val;
				}
				if (beforeData.hasOwnProperty('data') && typeof beforeData.data === 'string') {
					delete beforeData['data'];
					return { data: JSON.stringify($.extend(param, beforeData)) };
				}
				return { data: JSON.stringify(param) };
			},
			column: [
				{ type: 'checkbox', width: 20 },
				{ fid: 'name', title: '数据库名', type: 'text' },
				{ fid: 'username', title: '用户名', type: 'text', sort: true },
				{ fid: 'password', title: '密码', type: 'password', copy: true, eye_open: true },
				{
					fid: 'backup',
					title: '备份数据库',
					width: 130,
					template: function (row) {
						var backup = '点击备份',
							_class = 'bt_warning';
						if (row.backup_count > 0) (backup = lan.database.backup_ok), (_class = 'bt_success');
						return (
							'<span><a href="javascript:;" class="btlink ' +
							_class +
							'" onclick="database.database_detail(' +
							row.id +
							",'" +
							row.name +
							"','mongodb')\">" +
							backup +
							(row.backup_count > 0 ? '(' + row.backup_count + ')' : '') +
							'</a> | <a href="javascript:database.input_database(\'' +
							row.name +
							'\',\'mongodb\')" class="btlink">' +
							lan.database.input +
							'</a></span>'
						);
					},
				},
				{
					title: '数据库位置',
					type: 'text',
					width: 116,
					template: function (row) {
						var type_column = '-';
						switch (row.db_type) {
							case 0:
								type_column = '本地数据库';
								break;
							case 1:
								type_column = ('远程库(' + row.conn_config.db_host + ':' + row.conn_config.db_port + ')').toString();
								break;
							case 2:
								$.each(cloudDatabaseList, function (index, item) {
									if (row.sid == item.id) {
										if (item.ps !== '') {
											// 默认显示备注
											type_column = item.ps;
										} else {
											type_column = ('远程服务器(' + item.db_host + ':' + item.db_port + ')').toString();
										}
									}
								});
								break;
						}
						return '<span class="flex" style="width:100px" title="' + type_column + '"><span class="size_ellipsis" style="width: 0; flex: 1;">' + type_column + '</span></span>';
					},
				},
				{
					fid: 'ps',
					title: '备注',
					type: 'input',
					blur: function (row, index, ev) {
						bt.pub.set_data_ps(
							{
								id: row.id,
								table: 'databases',
								ps: ev.target.value,
							},
							function (res) {
								layer.msg(
									res.msg,
									res.status
										? {}
										: {
											icon: 2,
										}
								);
							}
						);
					},
					keyup: function (row, index, ev) {
						if (ev.keyCode === 13) {
							$(this).blur();
						}
					},
				},
				{
					type: 'group',
					title: '操作',
					width: 220,
					align: 'right',
					group: [
						{
							title: '权限',
							tips: '设置数据库权限',
							hide: function (rows) {
								return rows.db_type == 1;
							}, //远程数据库
							event: function (row) {
								bt.database.set_mongo_data_access(row.username);
							},
						},
						{
							title: '工具',
							tips: 'mongodb工具',
							event: function (row) {
								mongodb.mongo_tools(row.name);
							},
						},
						{
							title: '改密',
							tips: '修改数据库密码',
							hide: function (rows) {
								return rows.db_type == 1;
							},
							event: function (row) {
								database.set_data_pass(row.id, row.username, row.password);
							},
						},
						{
							title: '删除',
							tips: '删除数据库',
							event: function (row) {
								var list = [];
								list.push(row);
								database.del_database(list, row.name, row, function (res) {
									if (res.status) database_table.$refresh_table_list(true);
									layer.msg(res.msg, {
										icon: res.status ? 1 : 2,
									});
								});
							},
						},
					],
				},
			],
			sortParam: function (data) {
				return {
					order: data.name + ' ' + data.sort,
				};
			},
			tootls: [
				{
					// 按钮组
					type: 'group',
					positon: ['left', 'top'],
					list: [
						{
							title: '添加数据库',
							active: true,
							event: function () {
								open_add();
								function open_add() {
									var cloudList = [];
									$.each(cloudDatabaseList, function (index, item) {
										var _tips = item.ps != '' ? item.ps + ' (' + item.db_host + ')' : item.db_host;
										cloudList.push({ title: _tips, value: item.id, name: item.db_host });
									});
									bt.database.add_database(cloudList, function (res) {
										if (res.status) database_table.$refresh_table_list(true);
									});
								}
							},
						},
						{
							title: 'root密码',
							event: function () {
								if (mongoDBAccessStatus) {
									bt.database.set_root('mongo');
								} else {
									layer.msg('请先开启安全认证', { icon: 0 });
								}
							},
						},
						{
							title: '安全认证',
							hover_tips:'设置后访问数据需要使用帐号和密码，提高安全性',
							event: function () {
								layer.open({
									title: '安全认证开关',
									area: '250px',
									btn: false,
									content:
										'<div class="bt-form">\
								<div class="line">\
									<span class="tname">安全认证</span>\
									<div class="info-r">\
										<div class="inlineBlock mr50" style="margin-top: 5px;vertical-align: -6px;">\
											<input class="btswitch btswitch-ios" id="mongodb_access" type="checkbox" name="monitor">\
											<label class="btswitch-btn" for="mongodb_access" style="margin-bottom: 0;"></label>\
										</div>\
									</div>\
								</div>\
								<div class="line">\
									<div class="">\
									<div class="inlineBlock  ">\
									<ul class="help-info-text c7" style="margin-top:0;">\
										<li>安全认证：开启后访问数据需要使用帐号和密码</li>\
									</ul>\
								</div></div></div>\
							</div>',
									success: function () {
										$('#mongodb_access').attr('checked', mongoDBAccessStatus);

										$('#mongodb_access').click(function () {
											var _status = $(this).prop('checked');
											bt_tools.send(
												{ url: 'database/' + bt.data.db_tab_name + '/set_auth_status', data: { data: JSON.stringify({ status: _status ? 1 : 0 }) }, verify: true },
												function (rdata) {
													if (rdata.status) {
														mongoDBAccessStatus = _status;
														layer.msg(rdata.msg, { icon: 1 });
													}
												},
												'设置密码访问状态'
											);
										});
									},
								});
							},
						},
						{
							title: '远程服务器',
							event: function () {
								db_public_fn.get_cloud_server_list();
							},
						},
					],
				},
				{
					type: 'batch', //batch_btn
					positon: ['left', 'bottom'],
					placeholder: '请选择批量操作',
					buttonValue: '批量操作',
					disabledSelectValue: '请选择需要批量操作的数据库!',
					selectList: [
						{
							title: '同步数据库',
							url: '/database/' + bt.data.db_tab_name + '/SyncToDatabases',
							// paramName: 'data', //列表参数名,可以为空
							// th:'数据库名称',
							// beforeRequest: function(list) {
							//   var arry = [];
							//   $.each(list, function (index, item) {
							//     arry.push(item.id);
							//   });
							//   return JSON.stringify({ids:JSON.stringify(arry),type:1})
							// },
							// success: function (res, list, that) {
							//   layer.closeAll();
							//   var html = '';
							//   $.each(list, function (index, item) {
							//     html += '<tr><td>' + item.name + '</td><td><div style="float:right;"><span style="color:' + (res.status ? '#20a53a' : 'red') + '">' + res.msg + '</span></div></td></tr>';
							//   });
							//   that.$batch_success_table({
							//     title: '批量同步选中',
							//     th: '数据库名称',
							//     html: html
							//   });
							// }
							param: function (row) {
								var arry = [];
								arry.push(row.id);
								return { data: JSON.stringify({ ids: JSON.stringify(arry), type: 1 }) };
							},
							callback: function (that) {
								// 手动执行,data参数包含所有选中的站点
								bt.simple_confirm({ title: '批量同步数据库', msg: '批量同步选中的数据库，同步过程中可能存在风险，请在闲置时间段同步数据库，是否继续操作？' }, function () {
									var param = {};
									that.start_batch(param, function (list) {
										var html = '';
										for (var i = 0; i < list.length; i++) {
											var item = list[i];
											html +=
												'<tr><td>' +
												item.name +
												'</td><td><div style="float:right;"><span style="color:' +
												(item.request.status ? '#20a53a' : 'red') +
												'">' +
												item.request.msg +
												'</span></div></td></tr>';
										}
										database_table.$batch_success_table({ title: '批量同步数据库', th: '数据库名', html: html });
										database_table.$refresh_table_list(true);
									});
								});
							},
						},
						{
							title: '备份数据库',
							url: bt.data.db_tab_name == 'mysql' ? 'database?action=ToBackup' : '/database/' + bt.data.db_tab_name + '/ToBackup',
							load: true,
							param: function (row) {
								return bt.data.db_tab_name == 'mysql' ? { id: row.id } : { data: JSON.stringify({ id: row.id }) };
							},
							callback: function (that) {
								// 手动执行,data参数包含所有选中的站点
								that.start_batch({}, function (list) {
									var html = '';
									for (var i = 0; i < list.length; i++) {
										var item = list[i];
										html +=
											'<tr><td>' +
											item.name +
											'</td><td><div style="float:right;"><span style="color:' +
											(item.request.status ? '#20a53a' : 'red') +
											'">' +
											item.request.msg +
											'</span></div></td></tr>';
									}
									database_table.$batch_success_table({ title: '批量备份数据库', th: '数据库名', html: html });
									database_table.$refresh_table_list(true);
								});
							},
						},
						{
							title: '删除数据库',
							url: '/database/' + bt.data.db_tab_name + '/DeleteDatabase',
							load: true,
							param: function (row) {
								return {
									data: JSON.stringify({
										id: row.id,
										name: row.name,
									}),
								};
							},
							callback: function (that) {
								// 手动执行,data参数包含所有选中的站点
								var ids = [];
								for (var i = 0; i < that.check_list.length; i++) {
									ids.push(that.check_list[i].id);
								}
								database.del_database(that.check_list, function (param) {
									that.start_batch(param, function (list) {
										layer.closeAll();
										var html = '';
										for (var i = 0; i < list.length; i++) {
											var item = list[i];
											html +=
												'<tr><td>' +
												item.name +
												'</td><td><div style="float:right;"><span style="color:' +
												(item.request.status ? '#20a53a' : 'red') +
												'">' +
												item.request.msg +
												'</span></div></td></tr>';
										}
										database_table.$batch_success_table({
											title: '批量删除',
											th: '数据库名称',
											html: html,
										});
										database_table.$refresh_table_list(true);
									});
								});
							},
						},
					],
				},
				{
					type: 'search',
					positon: ['right', 'top'],
					placeholder: '请输入数据库名称/备注',
					searchParam: 'search', //搜索请求字段，默认为 search
					value: '', // 当前内容,默认为空
				},
				{
					//分页显示
					type: 'page',
					positon: ['right', 'bottom'], // 默认在右下角
					pageParam: 'p', //分页请求字段,默认为 : p
					page: 1, //当前分页 默认：1
					numberParam: 'limit', //分页数量请求字段默认为 : limit
					number: 20, //分页数量默认 : 20条
					numberList: [10, 20, 50, 100, 200], // 分页显示数量列表
					numberStatus: true, //　是否支持分页数量选择,默认禁用
					jump: true, //是否支持跳转分页,默认禁用
				},
			],
			success: function (config) {
				//搜索前面新增数据库位置下拉
				if ($('.mongodb_type_select_filter').length == 0) {
					var _option = '<option value="all">全部</option>';
					$.each(cloudDatabaseList, function (index, item) {
						var _tips = item.ps != '' ? item.ps : item.db_host;
						_option += '<option value="' + item.id + '">' + _tips + '</option>';
					});
					$('#bt_mongodb_table .bt_search').before('<select class="bt-input-text mr5 mongodb_type_select_filter" style="width:110px" name="db_type_filter">' + _option + '</select>');

					//事件
					$('.mongodb_type_select_filter').change(function () {
						database_table.config.page.page = 1;
						database_table.$refresh_table_list(true);
					});
				}
				if($('#bt_mongodb_table .db_sync_setting').length == 0){
					db_public_fn.get_sync_all_server('#bt_mongodb_table','button:eq(3)')
				}
			},
		});
	},

	// mongodb工具
	mongo_tools: function (db_name, res) {
		var loadT = layer.msg('正在获取数据,请稍候...', {
			icon: 16,
			time: 0,
		});
		bt_tools.send({ url: 'database/mongodb/GetInfo', data: { data: JSON.stringify({ db_name: db_name }) } }, function (rdata) {
			layer.close(loadT);
			if (rdata.status === false) {
				layer.msg(rdata.msg, {
					icon: 2,
				});
				return;
			}
			// var types = {
			//   InnoDB: "MyISAM",
			//   MyISAM: "InnoDB"
			// };
			var tbody = '',
				tableList = rdata.data.collection_list;
			for (var i = 0; i < tableList.length; i++) {
				// if (!types[rdata.tables[i].type]) continue;
				tbody +=
					'<tr>\
                        <td><span style="width:150px;"> ' +
					tableList[i].collection_name +
					'</span></td>\
                        <td><span style="width:90px;"> ' +
					tableList[i].count +
					'</span></td>\
                        <td><span style="width:90px;"> ' +
					db_public_fn.compute_data_unit(tableList[i].size) +
					'</span></td>\
                        <td><span style="width:90px;"> ' +
					db_public_fn.compute_data_unit(tableList[i].avg_obj_size) +
					'</span></td>\
                        <td>' +
					db_public_fn.compute_data_unit(tableList[i].storage_size) +
					'</td>\
                        <td>' +
					tableList[i].nindexes +
					'</td>\
                        <td>' +
					db_public_fn.compute_data_unit(tableList[i].total_index_size) +
					'</td>\
                    </tr> ';
			}

			// if (res) {
			//   $(".gztr").html(tbody);
			//   $("#db_tools").html('');
			//   $("input[type='checkbox']").attr("checked", false);
			//   $(".tools_size").html('大小：' + rdata.data.storageSize);
			//   return;
			// }

			layer.open({
				type: 1,
				title: 'MongoDB工具箱【' + db_name + '】',
				area: ['780px', '480px'],
				closeBtn: 2,
				shadeClose: false,
				content:
					'<div class="pd15">\
                                <div class="db_list">\
                                    <span><a>数据库名称：' +
					db_name +
					'</a>\
                                    <a class="tools_size">集合数量：' +
					rdata.data.collections +
					'</a>\
																		<a class="tools_size">存储大小：' +
					db_public_fn.compute_data_unit(rdata.data.storageSize) +
					'</a>\
																		<a class="tools_size">索引大小：' +
					db_public_fn.compute_data_unit(rdata.data.indexSize) +
					'</a></span>\
                                </div >\
                                <div class="divtable">\
                                <div  id="database_fix"  style="height:360px;overflow:auto;border:#ddd 1px solid">\
                                <table class="table table-hover "style="border:none">\
                                    <thead>\
                                        <tr>\
                                            <th>集合名称</th>\
                                            <th>文档数量</th>\
                                            <th>内存中的大小</th>\
                                            <th>对象平均大小</th>\
                                            <th>存储大小</th>\
                                            <th>索引数量</th>\
                                            <th>索引大小</th>\
                                        </tr>\
                                    </thead>\
                                    <tbody class="gztr">' +
					tbody +
					'</tbody>\
                                </table>\
                                </div>\
                            </div>\
									</div>',
				success: function () {
					$(':focus').blur();
				},
			});
			tableFixed('database_fix');
			//表格头固定
			function tableFixed(name) {
				var tableName = document.querySelector('#' + name);
				tableName.addEventListener('scroll', scrollHandle);
			}

			function scrollHandle(e) {
				var scrollTop = this.scrollTop;
				//this.querySelector('thead').style.transform = 'translateY(' + scrollTop + 'px)';
				$(this)
					.find('thead')
					.css({
						transform: 'translateY(' + scrollTop + 'px)',
						position: 'relative',
						'z-index': '1',
					});
			}
		});
	},
};
var redis = {
	timer: null,
	formFactory: function(type,data,style){
		/**
		 * @description: 选择框
		 * @param data {} 数据
		 * @param style
		 */
		function selectForm (data,style){

			var databaseHtml = ''
			var fastItem = ''
			var list = []
			if(data.list == undefined || data.list.length == 0){
				fastItem	= '无数据'
				databaseHtml = `<li class="item" title="无匹配项" data-id="0" data-value="无数据">无数据</li>`
			}else {
				$.each(data.list,function(index,item){
					if(index==0) fastItem = item.value
					if(data.valueData == item.value){
						fastItem = item.value
						databaseHtml += `<li class="item active" style="overflow: hidden;white-space: nowrap;text-overflow: ellipsis;" title="${item.title}" data-id="${index}" data-value="${item.value}">${item.title}</li>`
					}else{
						databaseHtml += `<li class="item" style="overflow: hidden;white-space: nowrap;text-overflow: ellipsis;" title="${item.title}" data-id="${index}" data-value="${item.value}">${item.title}</li>`
					}
					list.push({title:item.title,value:item.value})
				})
			}

			var html = `
			<div style="display:flex;flex-direction: row;align-items: center;">
				<div class="bt_select_updown" style="width: ${data.width?data.width:'180px'};border:0" data-name="sType">
					<span type="text" style="border: 1px solid #DCDFE6;" class="bt_select_value " data-value="${fastItem}">${data.valueData}</span>
					<div class="icon-down" style="display: block;position: absolute;top: 0px;right: 5px;">
						<svg width="12.000000" height="12.000000" viewBox="0 0 12 5" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><desc>	Created with Pixso.</desc><defs></defs><path id="path" d="M0.123291 0.809418L4.71558 5.84385C4.8786 6.02302 5.16846 6.04432 5.33038 5.86389L9.87927 0.783104C10.0412 0.602676 10.04 0.311989 9.87701 0.132816C9.79626 0.0446892 9.68945 0 9.58374 0C9.47693 0 9.36938 0.0459404 9.28827 0.136574L5.02881 4.89284L0.708618 0.15662C0.627869 0.0684967 0.522217 0.0238075 0.415405 0.0238075C0.307434 0.0238075 0.20105 0.0697479 0.119873 0.160381C-0.041626 0.338303 -0.0393677 0.630241 0.123291 0.809418Z" fill-rule="nonzero" fill="#999999"></path></svg>
					</div>
					<div class="icon_up" style="display: none;position: absolute;top: 0px;right: 5px;">
						<svg width="12.000000" height="12.000000" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><desc>Created with Pixso.</desc><defs></defs><path id="path" d="M1.12328 8.19058L5.71558 3.15616C5.87862 2.97699 6.16847 2.95569 6.33038 3.13611L10.8793 8.21689C11.0412 8.39731 11.04 8.68802 10.877 8.86719C10.7962 8.95532 10.6894 9 10.5838 9C10.477 9 10.3694 8.95407 10.2883 8.86343L6.02883 4.10715L1.70864 8.84338C1.62788 8.93152 1.5222 8.9762 1.41539 8.9762C1.30746 8.9762 1.20103 8.93024 1.11988 8.83963C0.958351 8.66171 0.960617 8.36975 1.12328 8.19058Z" fill-rule="nonzero" fill="#999999"></path></svg>
					</div>
					<ul id="${data.id}" class="bt_select_list" style="display: none;width: 250px;">${databaseHtml}</ul>
					<div class="bt_select_list_arrow" ></div>
					<div class="bt_select_list_arrow_fff" ></div>
				</div>
			</div>`
			$('#'+data.el).html(html)
			if(data.callback) data.callback($('#'+data.el+' .bt_select_list li').data('id'))
			$('#'+data.el+' .bt_select_updown .bt_select_value').on('click',function(){
				var height = $(this).parent().height()
				$(this).nextAll('ul').css('top',(height+8)+'px')
				$('.bt_select_list_arrow_fff').not('#'+data.id).hide()
				$('.bt_select_list_arrow').not('#'+data.id).hide()
				$('.bt_select_updown .bt_select_value').nextAll('ul').not('#'+data.id).removeClass('show')
				$(this).nextAll('ul').toggleClass('show')
				$(this).nextAll('.icon-down').toggle()
				$(this).nextAll('.icon_up').toggle()
				if($(this).nextAll('ul').hasClass('show')){
					$('#'+data.el+' .bt_select_list_arrow_fff').css('top',(height-6)+'px').show()
					$('#'+data.el+' .bt_select_list_arrow').css('top',(height-7)+'px').show()
				}else {
					$('#'+data.el+' .bt_select_list_arrow_fff').hide()
					$('#'+data.el+' .bt_select_list_arrow').hide()
				}
			})
			$('#'+data.el+' .icon-down').click(function(){
				$('#'+data.el+' .bt_select_updown .bt_select_value').focus()
			})
			$('#'+data.el+' .icon_up').click(function(){
				$('#'+data.el+' .bt_select_updown .bt_select_value').focus()
			})
			$(document).click(function(e){
				if($(e.target).parents('.bt_select_updown').length==0){
					$('#'+data.el+' .bt_select_list').removeClass('show')
					$('#'+data.el+' .icon-down').show()
					$('#'+data.el+' .icon_up').hide()
					$('#'+data.el+' .bt_select_list_arrow_fff').hide()
					$('#'+data.el+' .bt_select_list_arrow').hide()
				}
			})
			/**
			 * @description: 选择列表
			 */
			function selectList() {
				var keyword = $('#binlog-table .bt_select_value').val()
				var keyword2 = $('#binlog-database .bt_select_value').val()
				$('#'+data.el+' .bt_select_list li').click(function () {
					var value = $(this).data('value')
					var name  = $(this).text()
					$(this).addClass('active').siblings().removeClass('active')
					$(this).parents('.bt_select_updown').find('.bt_select_value').html(name).attr('data-value',value).attr('title', value).attr('data-id', $(this).data('id'))
					$(this).parents('.bt_select_updown').find('.bt_select_list').removeClass('show')
					$(this).parents('.bt_select_updown').find('.icon-down').show()
					$(this).parents('.bt_select_updown').find('.icon_up').hide()
					$('.bt_select_list_arrow_fff').hide()
					$('.bt_select_list_arrow').hide()
					if(data.callback) data.callback($(this).data('id'))
				})
				$('#binlog-table .bt_select_value').attr('data-value',keyword).attr('title', keyword).attr('data-id', $(this).data('id'))
				$('#binlog-database .bt_select_value').attr('data-value',keyword2).attr('title', keyword2).attr('data-id', $(this).data('id'))
			}
			selectList()
			// $('#'+data.el+' .bt_select_list li').eq(0).click()
			$('#'+data.el+' .bt_select_updown .bt_select_value').on('input',function(){
				var keyword = $(this).val()
				if(keyword==''){
					$(this).nextAll('ul').empty();
					$(this).nextAll('ul').append(databaseHtml);
				}
				// 清空下拉列表
				$(this).nextAll('ul').empty();
				var res = list.filter(option => option.name.toLowerCase().includes(keyword.toLowerCase()));
				if(res.length==0){
					res.push({name:'无匹配项',value:''})
				}
				res.forEach(result=>{
					$(this).nextAll('ul').append(`<li class="item" style="overflow: hidden;white-space: nowrap;text-overflow: ellipsis;" title="${result.value}" data-value="${result.value}">${result.name}</li>`);
				})
				selectList()
			})
		}

		function searchForm(data,style){
			var html = `
				<div style="display:flex;flex-direction: row;align-items: center;">
					<span class="binglog-form-title" style="width: 90px;text-align: right;">${data.name}：</span>
					<input type="text" class="bt_select_value" style="border: 1px solid #DCDFE6;width: 300px;height: 30px" placeholder="请输入查询的语句或内容，该字段可以为空"/>
				</div>
				`
			$('#'+data.el).html(html)
		}
		switch(type){
			case 'select':
				selectForm(data)
				break
			case 'search':
				searchForm(data)
		}
	},
	redisDBList: [],
	redisDBOption: [],
	cloudInfo: {
		sid: 0,
		title: '本地服务器',
	}, //当前远程信息
	type_select:[
		{title:'string',value:'string'},
		{title:'hash',value:'hash'},
		{title:'list',value:'list'},
		{title:'set',value:'set'},
		{title:'zset',value:'zset'},
	],
	clusterModeConfig:{}, //集群模式配置
	database_table_view: function () {
		var that = this;
		this.cloudInfo.sid = cloudDatabaseList.length == 0 ? 0 : cloudDatabaseList[0].id;
		this.cloudInfo.title = cloudDatabaseList.length == 0 ? '本地数据库' : cloudDatabaseList[0].ps;
		$('#bt_redis_view').empty();

		$('#bt_redis_view').html('<div class="pull-right redis_cloud_server"></div>');

		// 远程服务器列表
		var _option = ''
		$.each(cloudDatabaseList,function(index,item){
			var _tips = item.ps != ''?item.ps:item.db_host
			_option +='<option value="'+item.id+'">'+_tips+'</option>'
		})
		$('#bt_redis_view .redis_cloud_server').html('<span class="mr5" style="color:#f0ad4e"><span class="glyphicon glyphicon-info-sign"></span>当前所有操作项都关联至</span><select class="bt-input-text mr5 redis_type_select_filter" style="width:110px" name="db_type_filter">'+_option+'</select>')
		$('.pull-right').css({'display':'flex','align-items':'center'})
		$('.redis_type_select_filter').after('<div class="db_status_row">\
		<span class="db_status_icon status_icon status_success"></span>\
		状态：\
		<span class="db_status_text">正常</span>\
		</div>')
		//远程服务器列表点击事件
		$('.redis_type_select_filter').change(function(){
			that.cloudInfo.sid = $(this).val();
			that.cloudInfo.title = $(this).find('option:selected').text();
			that.render_redis_content()
			if(parseInt($('#bt_redis_view .page .Pcurrent').text()) !== 1) $('.Pstart').click()
			$('.pull-right').css({'display':'flex','align-items':'center'})
			bt.database.check_single_other_status($(this).find('option:selected').attr('value'),false,$(this).find('option:selected').text(),'redis')
		})

		// 渲染redis列表
		this.render_redis_content();
	},
	isRefreshTime: false,
	refresh_second: 0,
	render_redis_content: function (id) {
		$('.redis_content_view').remove();
		var that = this;
		$('#bt_redis_view').append(
			'<div class="redis_content_view">\
		<button type="button" title="添加Key" class="btn btn-success btn-sm mr5 addRedisDB" style="margin-bottom:10px"><span>添加Key</span></button>\
		<button type="button" title="远程服务器" class="btn btn-default btn-sm mr5 RedisCloudDB" style="margin-bottom:10px"><span>远程服务器</span></button>\
		<button type="button" title="备份列表" class="btn btn-default btn-sm mr5 backupRedis" style="margin-bottom:10px;display:' +
			(this.cloudInfo.sid == 0 ? 'inline-block' : 'none') +
			'"><span>备份列表</span></button>\
		<button type="button" title="集群管理" class="btn btn-default btn-sm mr5 cluster_manage" style="margin:0 5px 10px 30px">集群管理</button>\
		<button type="button" title="清空数据库" class="btn btn-default btn-sm emptyRedisDB"><span>清空数据库</span></button>\
		<button type="button" title="信息全集" class="btn btn-default btn-sm informationComplete"><span>信息全集</span></button>\
		<div id="redis_content_tab"><div class="tab-nav"></div><div class="tab-con redis_table_content" style="padding:10px 0"></div></div></div>'
		);
		if($('.refreshSiteSunLogs').length==0) {
			$('#bt_redis_view .redis_cloud_server').prepend('<button type="button" title="定时刷新" class="btn btn-default btn-sm refreshSiteSunLogs relative mr10"><span>定时刷新</span><div class="refreshMenu"></div></button>')
		}


		$('.addRedisDB').click(function () {
			that.set_redis_library();
		});
		$('.backupRedis').click(function () {
			that.backup_redis_list();
		});
		$('.emptyRedisDB').click(function () {
			that.choose_redis_list();
		});
		$('.RedisCloudDB').click(function () {
			db_public_fn.get_cloud_server_list();
		});
		$('.cluster_manage').click(function () {
			that.cluster_manage_viwe();
		});


		// 刷新设置获取
		bt_tools.send({url:'/database/redis/get_redis_settings'},function(ress){
			that.isRefreshTime = ress.data.auto_refresh
			that.refresh_second = ress.data.refresh_second
			$('.refreshMenu .line').css('padding','0px')
			$('.refreshMenu .tname').css('width','90px')
			$('.refreshMenu .tname').css('padding-right','10px')
			$('.refreshMenu .tname').css('color','black')

			bt_tools.form({
				el:'.refreshMenu',
				class:'mt10 font-initial',
				form:[
					{
						label: '定时刷新',
						group:{
							name: 'timeRefresh',
							type: 'other',
							class:'mt5 refreshMenuFix',
							boxcontent:'<input class="btswitch btswitch-ios" id="setTimeRefresh" '+(that.isRefreshTime?'checked':'')+' type="checkbox"><label style="margin-left:6px;margin-right:6px" class="btswitch-btn phpmyadmin-btn" for="setTimeRefresh" ></label>'
						}
					},
					{
						label:'间隔',
						group:{
							type:'number',
							name:'time',
							style:'margin-left:-22px; color:#333;',
							width:'50px',
							value:that.refresh_second,
							unit:'秒',
						}
					}
				]
			})
			$('.refreshMenu').append('<div class="arrow_b" style=""></div><div class="arrow" style=""></div>')
		},{verify:false})
		$('.refreshSiteSunLogs').off('click').on('click',function (e) {
			$($('.refreshMenu .line')[1]).show()
			$('.refreshMenu').show()
			if($('#setTimeRefresh').prop('checked')){
				that.isRefreshTime = true
				$('#setTimeRefresh').off('change').on('change',function(){
					that.setRefreshLogs()
				})
				$('.refreshMenu [name=time]').off('blur').on('blur',function(){
					if($(this).val() < 1){
						layer.msg('刷新时间不能小于1',{icon:0})
						$('.refreshMenu [name=time]').val(bt.get_cookie('siteLogsRefreshTime')/1000)
						return false
					}
					that.refresh_second = $(this).val()
					that.setRefreshLogs()
				})

			}else {
				that.isRefreshTime = false
				$($('.refreshMenu .line')[1]).hide()
			}
			$(document).one('click',function(){
				$('.refreshMenu').hide()
			})

			e.stopPropagation();
		});

		$('.informationComplete').click(function () {
			bt_tools.open({
				title:'信息全集',
				area:['680px','720px'],
				btn:false,
				content:'<div class="pd20"><div id="informationComplete"></div></div>',
				success:function(){
					//打开弹窗后执行的事件
					bt_tools.table({
						el:'#informationComplete',
						url:'/database/redis/get_redis_info',
						default:'暂无数据',
						height: '580',
						beforeRequest:function(data){
							if(data.data){
								var params = {
									search:data.search,
									sid:Number(that.cloudInfo.sid)
								}
								return {data:JSON.stringify(params)};
							}else{
								return {data:JSON.stringify({sid:Number(that.cloudInfo.sid)})}
							}

						},
						column:[
							{
								fid: 'name',
								title: 'key',
							},
							{
								fid: 'value',
								title: 'value',
								template:function(row){
									if(row.value.keys){
										return '<span>'+JSON.stringify(row.value)+'</span>'
									}else{
										return '<span>'+row.value+'</span>'
									}
								}
							},
						],
						tootls:[
							{
								// 搜索内容
								type: 'search',
								positon: ['right', 'top'],
								placeholder: '请输入搜索内容',
								searchParam: 'search', //搜索请求字段，默认为 search
								value: '', // 当前内容,默认为空
							},
						]
					})
				},
			})
		})

		var tabHTML = '';
		bt_tools.send({ url: 'database/redis/get_list', data: { data: JSON.stringify({ sid: that.cloudInfo.sid }) } }, function (rdata) {
			if(typeof rdata.msg !== 'undefined' && !rdata.status){
				layer.msg(rdata.msg, {
					icon: 2,
					time: 0,
					closeBtn: 2
				});
				return false;
			}
			that.redisDBList = rdata;
			that.redisDBOption = [];
			$.each(rdata, function (index, item) {
				tabHTML += '<span data-id="' + item.id + '">' + item.name + '(' + item.keynum + ')</span>';
				var option_item = { title: item.name, value: item.id };
				that.redisDBOption.push(option_item);
			});
			$('#redis_content_tab .tab-nav').html(tabHTML);
			setTimeout(function () {
				if (id) {
					$('#redis_content_tab .tab-nav span:contains(DB' + id + ')').click();
				} else {
					if (that.redisDBList.length == 0) {
						$('#redis_content_tab .tab-nav').remove();
						that.render_redis_table(0);
					} else {
						$('#redis_content_tab .tab-nav span:eq(0)').click();
					}
				}
			}, 50);
			if(that.isRefreshTime){
				that.setRefreshLogs()
			}

			// redis数据库点击事件
			$('#redis_content_tab .tab-nav span').click(function () {
				var _id = $(this).data('id');
				$(this).addClass('on').siblings().removeClass('on');
				that.render_redis_table(_id);
			});
		},{load:'获取redis列表',verify:false});
	},
	render_redis_table: function (id,load) {
		var that = this;
		$('.redis_table_content').empty();
		database_table = bt_tools.table({
			el: '.redis_table_content',
			url: 'database/redis/get_db_keylist',
			param: { db_idx: id }, //参数
			minWidth: '1000px',
			load:load?false:true,
			dataVerify: false,
			dataFilter: function (rdata) {
				if (rdata.page) return rdata;
				if (!rdata.status) return { data: [] };
			},
			autoHeight: true,
			default: '数据库列表为空', // 数据为空时的默认提示
			pageName: 'redis_' + id,
			beforeRequest: function (beforeData) {
				var db_type_val = that.cloudInfo.sid,
					param = {};
				switch (db_type_val) {
					case 0:
						break;
					default:
						delete param['db_type'];
						param['sid'] = db_type_val;
				}
				if (
					beforeData.hasOwnProperty('data') &&
					typeof beforeData.data === 'string'
				) {
					delete beforeData['data'];
					return {
						data: JSON.stringify($.extend(param, { db_idx: id,sid:Number(db_type_val) }, beforeData)),
					};
				}
				return {
					data: JSON.stringify(
						$.extend(param, { db_idx: id, limit: beforeData.limit,p:beforeData.p,search:beforeData.search,sid:Number(db_type_val) })
					),
				};
			},
			column: [
				{ type: 'checkbox', width: 20 },
				{ fid: 'name', title: '键', type: 'text',width: 500,template:function(row){
						return '<span class="size_ellipsis" style="width: 500px;overflow: hidden;" title="'+row.name+'">'+row.name+'</span>'
					}
				},
				{ fid: 'type', title: '数据类型', type: 'text' },
				{ fid: 'len', title: '数据长度', type: 'text' },
				{
					fid: 'ttl',
					title: '有效期',
					type: 'text',
					template: function (row) {
						if(row.ttl < 0){
							return '<span>永久</span>'
						}else{
							return '<span>'+that.reset_time_format(row.ttl)+'</span>'
						}
					},
				},
				{
					type: 'group',
					title: '操作',
					width: 220,
					align: 'right',
					group: [
						{
							title: '编辑',
							tips: '编辑数据',
							// hide: function (rows) {
							//   return rows.type == 'string' || rows.type == 'int'
							//     ? false
							//     : true;
							// },
							event: function (row) {
								row.db_idx = id;
								var gerRedisValueParams = {
									sid:Number(that.cloudInfo.sid),
									db_idx:row.db_idx,
									key:row.name,
								}
								bt_tools.send({url:'/database/redis/get_redis_value',data:{data:JSON.stringify(gerRedisValueParams)}},function(ress){
									ress.data.db_idx = id
									that.open_edit_key(ress.data,ress)
								})
							},
						},
						{
							title: '删除',
							tips: '删除数据',
							event: function (row) {
								layer.confirm(
									'是否删除【' + row.name + '】',
									{
										title: '删除key值',
										closeBtn: 2,
										icon: 0,
									},
									function (index) {
										bt_tools.send(
											{
												url: 'database/redis/del_redis_value',
												data: {
													data: JSON.stringify({
														db_idx: id,
														key: row.name,
														sid: that.cloudInfo.sid,
													}),
												},
											},
											function (rdata) {
												if (rdata.status) {
													that.render_redis_table(id);
													that.change_tabs_num();
												}
												bt_tools.msg(rdata);
												layer.close(index);
											}
										);
									}
								);
							},
						},
					],
				},
			],
			tootls: [
				{
					type: 'search',
					positon: ['right', 'top'],
					placeholder: '请输入键名称',
					searchParam: 'search', //搜索请求字段，默认为 search
					value: '', // 当前内容,默认为空
				},
				{
					type: 'batch',
					positon: ['left', 'bottom'],
					config: {
						title: '删除',
						url: 'database/redis/del_redis_value',
						param: function (row) {
							return {
								data: JSON.stringify({
									db_idx: id,
									key: row.name,
									sid: that.cloudInfo.sid,
								}),
							};
						},
						load: true,
						callback: function (that) {
							bt.confirm(
								{
									title: '批量删除key值',
									msg: '是否批量删除选中的key值，是否继续？',
									icon: 0,
								},
								function (index) {
									layer.close(index);
									that.start_batch({}, function (list) {
										var html = '';
										for (var i = 0; i < list.length; i++) {
											var item = list[i];
											html +=
												'<tr><td><span class="text-overflow" title="' +
												item.name +
												'">' +
												item.name +
												'</span></td><td><div style="float:right;"><span style="color:' +
												(item.request.status ? '#20a53a' : 'red') +
												'">' +
												item.request.msg +
												'</span></div></td></tr>';
										}
										database_table.$batch_success_table({
											title: '批量删除key值',
											th: '键',
											html: html,
										});
										database_table.$refresh_table_list(true);
									});
								}
							);
						},
					},
				},
				{
					//分页显示
					type: 'page',
					positon: ['right', 'bottom'], // 默认在右下角
					pageParam: 'p', //分页请求字段,默认为 : p
					page: 1, //当前分页 默认：1
					numberParam: 'limit', //分页数量请求字段默认为 : limit
					number: 20, //分页数量默认 : 20条
					numberList: [10, 20, 50, 100, 200], // 分页显示数量列表
					numberStatus: true, //　是否支持分页数量选择,默认禁用
					jump: true, //是否支持跳转分页,默认禁用
				},
			],
			success: function () {
				var arry = [],
					maxWidth = '';
				for (var i = 0; i < $('.size_ellipsis').length; i++) {
					arry.push($('.size_ellipsis').eq(i).width());
				}
				maxWidth = Math.max.apply(null, arry);
				$('.size_ellipsis').width(maxWidth + 5);
			},
		});
	},
	// 设置tabs的数量
	change_tabs_num: function () {
		var text = $('#redis_content_tab .tab-nav .on').text();
		var num = text.match(/\((.*?)\)/g);
		num = RegExp.$1;
		if (!isNaN(num)) {
			num--;
			$('#redis_content_tab .tab-nav .on').text(text.replace(/\([0-9]\)/gi, '(' + num + ')'));
		}
	},
	// redis备份列表
	backup_redis_list: function () {
		var that = this,
			redisBackupTable = null;
		bt_tools.open({
			title: 'Redis备份列表',
			area: ['927px', '633px'],
			btn: false,
			skin: 'redisBackupList',
			content: '<div id="redisBackupTable" class="pd20" style="padding-bottom:40px;"></div>',
			success: function () {
				redisBackupTable = bt_tools.table({
					el: '#redisBackupTable',
					default: '备份列表为空',
					height: 478,
					url: 'database/redis/get_backup_list',
					param: { data: JSON.stringify({ sort: 'desc' }) },
					column: [
						{
							fid: 'name',
							title: '名称',
							width: 170,
							template: function (item) {
								return '<span class="flex" style="width:154px" title="' + item.name + '"><span class="size_ellipsis" style="width: 0; flex: 1;">' + item.name + '</span></span>';
							},
						},
						{
							fid: 'path',
							title: '路径',
							template: function (item) {
								return '<span class="flex" style="width:280px" title="' + item.path + '"><span class="size_ellipsis" style="width: 0; flex: 1;">' + item.path + '</span></span>';
							},
						},
						{
							fid: 'mtime',
							width: 137,
							title: '备份时间',
							template: function (row) {
								return '<span>' + bt.format_data(row.mtime) + '</span>';
							},
						},
						{
							fid: 'size',
							title: '大小',
							template: function (row) {
								return '<span>' + bt.format_size(row.size) + '</span>';
							},
						},
						{
							type: 'group',
							title: '操作',
							align: 'right',
							group: [
								{
									title: '恢复',
									event: function (row) {
										bt.prompt_confirm('覆盖数据', '即将使用【' + row.name + '】对数据进行覆盖，是否继续?', function () {
											bt_tools.send(
												{ url: 'database/redis/InputSql', data: { data: JSON.stringify({ file: row.path, sid: 0 }) } },
												function (rdata) {
													if (rdata.status) that.render_redis_content();
													rdata['code']=-1
													bt.msg(rdata)
												},
												'恢复数据'
											);
										});
									},
								},
								{
									title: '删除',
									event: function (row) {
										layer.confirm(
											'是否删除【' + row.name + '】备份',
											{
												title: '删除备份',
												closeBtn: 2,
												icon: 0,
											},
											function (index) {
												bt_tools.send(
													{ url: 'files?action=DeleteFile', data: { path: row.path} },
													function (rdata) {
														if (rdata.status) redisBackupTable.$refresh_table_list(true);
														bt_tools.msg(rdata);
														layer.close(index);
													},
													'删除备份'
												);
											}
										);
									},
								},
							],
						},
					],
					tootls: [
						{
							type: 'group',
							positon: ['left', 'top'],
							list: [
								{
									title: '立即备份',
									active: true,
									event: function () {
										bt_tools.send({ url: 'database/redis/ToBackup' }, function (rdata) {
											if (rdata.status) redisBackupTable.$refresh_table_list(true);
											bt_tools.msg(rdata);
										},'备份数据');
									},
								},
								{
									title: '指定备份',
									event: function () {
										bt_tools.open({
											title:'指定备份数据库',
											area:['auto'],
											btn:['确定','取消'],
											content:{//配置请查看表单form方法中的类型
												class:'pd20',
												form:[{
													label: '数据库',
													group: {
														type: 'select',
														name: 'db_idx',
														width: '220px',
														list: that.redisDBOption,
													},
												},]
											},success:function(layer){
												$(layer).find('.layui-layer-content').css('overflow','inherit')
												$(layer).find('.bt_select_updown').css('margin-right','56px')
											},yes:function(formData,indexs){
												var params = {
													db_idx:formData.db_idx,
													sid:that.cloudInfo.sid
												}
												bt_tools.send({url:'/database/redis/ToBackup',data:{data:JSON.stringify(params)}},function(ress){
													layer.msg(ress.msg,{icon:ress.status?1:2})
													if(ress.status) redisBackupTable.$refresh_table_list(true);
													layer.close(indexs)
												},'备份指定数据库')
											}
										})
									}
								}
							],
						},
					],
				});
			},
		});
	},
	/**
	 * @description 刷新设置
	 */
	setRefreshLogs: function () {
		var that = this,refTime = that.refresh_second;
		if(this.isRefreshTime){
			if(Number(refTime) > 0){
				clearInterval(that.timer)
				that.timer = setInterval(function(){
					that.render_redis_table($('.redis_content_view .tab-nav .on').data('id'),true)
				},refTime*1000)
				var params = {
					auto_refresh: true,
					refresh_second: refTime
				}
				bt_tools.send({url:'/database/redis/set_redis_settings',data:{data:JSON.stringify(params)}},function(ress){
					layer.msg(ress.msg, { icon: ress.status?1:2 })
				},{verify:false})
			}else{
				layer.msg('请输入正确的间隔', { icon: 2 })
			}
		}else{
			clearInterval(that.timer)
			var params = {
				auto_refresh: false,
				refresh_second: refTime
			}
			bt_tools.send({url:'/database/redis/set_redis_settings',data:{data:JSON.stringify(params)}},function(ress){
				layer.msg(ress.msg, { icon: ress.status?1:2 })
			},{verify:false})
		}
	},
	// 添加/编辑redis库
	set_redis_library: function (row) {
		var that = this,
			redis_form = null,
			cloudList = [];
		if (!row) {
			check_database_status(that.cloudInfo.sid, function (rdata) {
				if (rdata) {
					open_add();
				} else {
					bt.confirm({ msg: '当前数据库服务状态未开启，是否开启？', title: '提示' }, function () {
						bt.load('正在开启redis服务,请稍候...');
						bt.send('ServiceAdmin', 'system/ServiceAdmin', { name: 'redis', type: 'start' }, function (rdata) {
							if (rdata.status) {
								bt_tools.msg({ msg: 'redis服务已启动', status: true });
								setTimeout(function () {
									open_add();
								}, 1000);
							} else {
								bt_tools.msg({ msg: 'redis服务启动失败', status: false });
							}
						});
					});
				}
			});
		} else {
			open_add();
		}
		function open_add() {
			$.each(cloudDatabaseList, function (index, item) {
				var _tips = item.ps != '' ? item.ps + ' (' + item.db_host + ')' : item.db_host;
				cloudList.push({ title: _tips, value: item.id, name: item.db_host });
			});
			bt_tools.open({
				title: (row ? '编辑[' + row.name + ']' : '添加') + 'Key' + (!row ? '至【' + that.cloudInfo.title + '】' : ''),
				area: ['440px'],
				btn: [row ? '保存' : '添加', '取消'],
				content: {
					class:'ptb20 redis_library_form',
					form: [
						{
							label: '数据库',
							group: {
								type: 'select',
								name: 'db_idx',
								width: '260px',
								list: that.redisDBOption,
								disabled: row ? true : false,
							},
						},
						{
							label: '键',
							group: {
								type: 'text',
								name: 'name',
								width: '260px',
								placeholder: '请输入键(key)',
								disabled: row ? true : false,
							},
						},
						{
							label: '类型',
							group: {
								type: 'select',
								name: 'type',
								width: '260px',
								placeholder: '请选择值类型',
								value: row ? row.type : 'String',
								list:that.type_select,
								change: function (formData, element, that) {
									// 选中下拉项后
									if (formData.type == 'Hash' || formData.type == 'list') {
										// 选中项为list或hash时，将值行隐藏并替换为表格
										$('#redis_library_form_table').parent().show();
										$('.addList').show()
									}else{
										$('#redis_library_form_table').parent().hide();
										$('.addList').hide()
										$('.redis_library_form_val').find('textarea[name="val"]').val('')
									}
								}
							},
						},
					],
					data: row ? row : { db_idx: $('#redis_content_tab .tab-nav span.on').data('id') },
				},
				success: function (layers) {
					$(layers).find('.layui-layer-content').css('height', '');
					$(layers).find('.layui-layer-content').css('overflow', 'inherit');

					var list_data = [] // 值列表
					$('.redis_library_form_val').after('<div class="line" style="display:none;padding:0 80px;margin-left:18px">\
						<div id="redis_library_form_table"></div>\
					</div>')
					$('.redis_library_form_val').find('textarea[name="val"]').after('<button style="margin-left:4px;display:none" class="addList btn btn-sm btn-default">添加</button>')
					$('.redis_library_form_val').find('textarea[name="val"]').parent().css({'display':'flex','align-items':'flex-end'})

				},
				yes: function (formD,indexs) {
					if (that.cloudInfo.sid == '0') {
						check_database_status(that.cloudInfo.sid, function (rdata) {
							if (rdata) {
								var formValue = formD
								if (formValue.name == '') return layer.msg('键不能为空');
								if (formValue.val == '') return layer.msg('值不能为空');
								if (formValue.endtime <= 0) delete formValue.endtime;

								formValue['sid'] = that.cloudInfo.sid;

								var params = {
									sid:Number(that.cloudInfo.sid),
									db_idx:Number(formD.db_idx),
									key:formD.name,
									type:formD.type,
								}
								bt_tools.send({url:'/database/redis/add_redis_value',data:{data:JSON.stringify(params)}},function(ress){
									//请求回调
									layer.close(indexs)
									if(ress.status){
										// 刷新列表
										that.render_redis_table(formD.db_idx)
										var gerRedisValueParams = {
											sid:Number(that.cloudInfo.sid),
											db_idx:Number(formD.db_idx),
											key:formD.name,
										}
										if(formD.type == 'string'){
											that.open_edit_key(formD)
										}else{
											bt_tools.send({url:'/database/redis/get_redis_value',data:{data:JSON.stringify(gerRedisValueParams)}},function(ress){
												that.open_edit_key(formD,ress)
											})
										}
									}else{
										layer.msg(ress.msg, { icon: 2 })
									}
								},{load:'获取名称',verify:false})

							} else {
								bt.confirm({ msg: '当前数据库服务状态未开启，是否开启？', title: '提示' }, function () {
									bt.load('正在开启redis服务,请稍候...');
									bt.send('ServiceAdmin', 'system/ServiceAdmin', { name: 'redis', type: 'start' }, function (rdata) {
										if (rdata.status) {
											bt_tools.msg({ msg: 'redis服务已启动', status: true });
											setTimeout(function () {
												var formValue = redis_form.$get_form_value();
												if (formValue.name == '') return layer.msg('键不能为空');
												if (formValue.val == '') return layer.msg('值不能为空');
												if (formValue.endtime <= 0) delete formValue.endtime;
												if (row) {
													formValue['db_idx'] = $('#redis_content_tab .tab-nav span.on').data('id');
												}
												formValue['sid'] = that.cloudInfo.sid;

											}, 1000);
										} else {
											bt_tools.msg({ msg: 'redis服务启动失败', status: false });
										}
									});
								});
							}
						});
					} else {
						// var formValue = redis_form.$get_form_value();
						// if (formValue.name == '') return layer.msg('键不能为空');
						// if (formValue.val == '') return layer.msg('值不能为空');
						// if (formValue.endtime <= 0) delete formValue.endtime;
						// if (row) {
						// 	formValue['db_idx'] = $('#redis_content_tab .tab-nav span.on').data('id');
						// }
						// formValue['sid'] = that.cloudInfo.sid;
						// bt_tools.send(
						// 	{ url: 'database/redis/set_redis_val', data: { data: JSON.stringify(formValue) } },
						// 	function (res) {
						// 		if (res.status) {
						// 			layer.close(indexs);
						// 			that.render_redis_content(formValue.db_idx);
						// 		}
						// 		bt_tools.msg(res);
						// 	},
						// 	(row ? '保存' : '添加') + 'redis数据中'
						// );
					}
				},
			});
		}
	},
	open_edit_key:function (formD,data){
		var that = this
		var time = 0,
			searchVal = ''
		// 值列表
		bt_tools.open({
			title:'填写键值内容',
			area:['720px','600px'],
			btn:formD.type == 'string'?['确定','取消']:false,
			content:"<div class='all_box pd20'>\
								<div class='edit_title'></div>\
								<div class='edit_content'></div>\
							</div>",
			success:function(layers){
				var params = {
					sid:Number(that.cloudInfo.sid),
					db_idx:Number(formD.db_idx),
					key:formD.name || formD.key
				}
				$(layers).find('.layui-layer-content').css('overflow', 'inherit');
				//打开弹窗后执行的事件
				$('.edit_title').html('<div class="edit_title_div">\
						<span style="width:60px" class="bt_select_updown database_data">DB'+(formD.db_idx)+'</span>\
						<span style="width:60px" class="bt_select_updown database_data">'+(formD.type)+'</span>\
						<input value="'+(formD.name || formD.key) +'" class="key_name bt_select_updown" style="width:200px" placeholder="请输入内容"/>\
						<button class="btn btn-sm btn-success edit_key">修改</button>\
						<span class="ttl">有效期</span>\
						<input value="'+(formD.ttl?formD.ttl:'-1')+'" class="bt_select_updown ttl_value" style="width:140px" placeholder="请输入有效期时间"/>\
						<button class="btn btn-sm btn-success edit_ttl">修改</button>\
						<button class="btn btn-sm btn-default refreshRedis relative" style="margin-left:10px"><span>自动刷新</span><div class="refreshMenu2"></div></button>\
					</div>')
				$('.edit_content').html('<textarea class="bt-input-text valueData" placeholder="请输入值内容">'+(formD.value?formD.value:'')+'</textarea><div class="redis_library_data_search" style="position: absolute;right: 20px;z-index: 1;">\
					<input type="text" class="bt-input-text" placeholder="请输入关键词搜索" style="width: 200px;">\
					<button class="btn btn-default btn-sm">搜索</button>\
				</div><div id="redis_library_data" class="hide"></div>')
				// 点击搜索
				$('.redis_library_data_search button').click(function(e){
					var params = {
						sid:Number(that.cloudInfo.sid),
						db_idx:Number(formD.db_idx),
						key:formD.name || formD.key
					}
					params.page = 1
					var _val = $('.redis_library_data_search input').val()
					var gerRedisValueParams = Object.assign({search: _val},params)
					// $('.redis_library_data_loadmore').hide()
					that.get_redis_value(gerRedisValueParams,function(ress){
						render_bottom(ress) // 渲染底部加载
						ress.data.db_idx = Number(formD.db_idx)
						render_table(ress.data.value,ress)
					})
				})
				// 回车搜索
				$('.redis_library_data_search input').keyup(function(e){
					if(e.keyCode == 13){
						$('.redis_library_data_search button').click()
					}
				})
				// 点击修改
				$('.edit_key').click(function(){
					// 当key值为空时，不允许修改
					if($('.key_name').val() == '') return layer.msg('key值不能为空',{icon:0})
					if($('.key_name').val() == (formD.name || formD.key)) return layer.msg('key值未改变',{icon:0})
					params.key = $('.key_name').val()
					params.old_key = formD.name || formD.key
					bt_tools.send({url:'/database/redis/rename_key',data:{data:JSON.stringify(params)}},function(ress){
						delete params.old_key
						if(ress.status && ress.type == 1){
							layer.msg(ress.msg, { icon: 2 ,time:1000})
							$('.key_name').val(formD.name || formD.key)
							params.key = formD.name || formD.key
						}else if(ress.status && !ress.type){
							formD.name = params.key
							formD.key = params.key
							$('.key_name').val(params.key)
							layer.msg(ress.msg, { icon: 1 })
						}else{
							layer.msg(ress.msg, { icon: 2 })
						}
					})
				})
				// 点击修改ttl
				$('.edit_ttl').click(function(){
					params.ttl = $('.ttl_value').val()?$('.ttl_value').val():'-1'
					if($('.ttl_value').val() == (formD.ttl?formD.ttl:'-1')) return layer.msg('有效期未改变',{icon:0})
					bt_tools.send({url:'/database/redis/set_redis_ttl',data:{data:JSON.stringify(params)}},function(ress){
						layer.msg(ress.msg, { icon: ress.status?1:2 })
					})
				})

				$('.refreshMenu2 .line').css('padding','0px')
				$('.refreshMenu2 .tname').css('width','90px')
				$('.refreshMenu2 .tname').css('padding-right','10px')
				$('.refreshMenu2 .tname').css('color','black')

				bt_tools.form({
					el:'.refreshMenu2',
					class:'mt10 font-initial',
					form:[
						{
							label: '自动刷新',
							group:{
								name: 'timeRefresh',
								type: 'other',
								class:'mt5 refreshMenuFix',
								boxcontent:'<input class="btswitch btswitch-ios" id="setTimeRefresh2" type="checkbox"><label style="margin-left:6px;margin-right:6px" class="btswitch-btn phpmyadmin-btn" for="setTimeRefresh2" ></label>'
							}
						},
						{
							label:'间隔',
							group:{
								type:'number',
								name:'time',
								style:'margin-left:-22px; color:#333;',
								width:'50px',
								value:2,
								unit:'秒',
							}
						}
					]
				})
				$('.refreshMenu2').append('<div class="arrow_b" style=""></div><div class="arrow" style=""></div>')
				$('.refreshRedis').off('click').on('click',function (e) {
					$($('.refreshMenu2 .line')[1]).show()
					$('.refreshMenu2').show()
					if($('#setTimeRefresh2').prop('checked')){
						$('#setTimeRefresh2').off('change').on('change',function(){
							// 开启定时刷新
							if($('#setTimeRefresh2').prop('checked')){
								var interval = parseInt($('.refreshMenu2 [name=time]').val()) * 1000; // convert seconds to milliseconds
								that.time = setInterval(function() {
									render_time(params)
								}, interval);
							}else{
								clearInterval(that.time)
							}
						})
						$('.refreshMenu2 [name=time]').off('blur').on('blur',function(){
							var _val = $(this).val()
							if(_val < 1){
								layer.msg('刷新时间不能小于1',{icon:0})
								return false
							}else{
								clearInterval(that.time)
								var interval = parseInt(_val) * 1000; // convert seconds to milliseconds
								that.time = setInterval(function() {
									render_time(params)
								}, interval);
							}
						})
					}else {
						$($('.refreshMenu2 .line')[1]).hide()
					}
					// 刷新操作方法
					function render_time(params){
						if($('.redis_library_data_search input').val() != ''){
							params.search = $('.redis_library_data_search input').val()
							searchVal = params.search
						}else{
							delete params.search
						}
						params.page = 1
						that.get_redis_value(params,function(ress){
							// 渲染顶部数据
							if(ress.status && ress.type == 1){
								$('.ttl_value').val(0);
								$('.key_name').val(formD.key || formD.name);
								layer.msg(ress.msg, { icon: 2 ,time:1000})
							}else if(ress.status && !ress.type){
								$('.key_name').val(ress.data.key);
								$('.ttl_value').val(ress.data.ttl);
								ress.data.db_idx = Number(formD.db_idx)
								// 文本域刷新
								$('.valueData').val(ress.data.value)
								if(formD.type !== 'string') render_table(ress.data.value,ress)
							}else{
								layer.msg(ress.msg, { icon: 2 })
							}
						})
					}

					$(document).one('click',function(){
						$('.refreshMenu2').hide()
					})
					e.stopPropagation();
				});


				if(formD.type == 'string'){
					$('.valueData').removeClass('hide').siblings().addClass('hide')
				}else{
					$('.valueData').addClass('hide').siblings().removeClass('hide')
					render_table(data.data.value,data)
				}
				// 解析输入的json数据
				$('.valueData').on('input propertychange',function(){
					var _val = $(this).val()
					try {
						var jsonStr = JSON.stringify(JSON.parse(_val), null, '\t')
						$(this).val(jsonStr)
					} catch (error) {
						$(this).val(_val)
					}
				})
				var list_data = []
				// 渲染set、list等类型表格方法
				function render_table (list_data,data){
					var tools = [{
						type: 'group',
						positon: ['left', 'top'],
						list: [{
							title: '添加新行',
							active: true,
							event: function (ev) {
								add_new_value()
							}
						}]
					}]
					// 添加操作列
					data.data.show_template.push({
						title: '操作',
						type: 'group',
						align: 'right',
						group: [{
							title: '编辑',
							event: function (row, index, ev, key, that) {
								add_new_value(row)
							}
						},{
							title: '删除',
							event: function (row, index, ev, key) {
								var params = {
									sid: Number(that.cloudInfo.sid),
									db_idx: Number(formD.db_idx),
									key: formD.name || formD.key,
								}
								if(formD.type == 'hash'){
									params.name = row.key
								}else if(formD.type == 'zset'){
									params.value = row.member
								}else {
									params.value = row.value
								}
								bt.confirm(
									{
										title: '删除',
										msg: '即将删除数据，是否继续？',
										icon: 0,
									},
									function (indexc) {
										layer.close(indexc)
										bt_tools.send({url:'/database/redis/del_redis_value',data:{data:JSON.stringify(params)}},function(ress){
											layer.msg(ress.msg, { icon: ress.status?1:2 })
											that.get_redis_value(params,function(ress){
												ress.data.db_idx = Number(formD.db_idx)
												render_table(ress.data.value,ress)
											})
										})
									}
								);
							}
						}]
					})
					$('#redis_library_data').empty()
					var redis_library_data = bt_tools.table({
						el:'#redis_library_data',
						default:'暂无数据',
						height: '370',
						data:list_data,
						column:data.data.show_template,
						success:function(){
							// 自动滚动到that.redisEditScrollHeight位置
							$('#redis_library_data .divtable').scrollTop(that.redisEditScrollHeight)
							$('#redis_library_data .refresh_table_list').remove() // 刷新
							// 在底部增加加载更多按钮
							if(!($('#redis_library_data').find('.redis_library_data_loadmore').length)){
								$('#redis_library_data .divtable').after('<div class="redis_library_data_loadmore" style="display:none">\
								<button class="btn btn-default btn-sm">加载更多</button>\
							</div>')
							}
							// 点击加载更多
							$('.redis_library_data_loadmore').unbind('click').click(function(e){
								params.page = params.page?params.page:2
								// 搜索框存在数据时，将搜索框的值传递给params
								if($('.redis_library_data_search input').val() != ''){
									params.search = $('.redis_library_data_search input').val()
								}else{
									delete params.search
								}
								that.get_redis_value(params,function(ress){
									ress.data.db_idx = Number(formD.db_idx)
									// 循环添加
									render_bottom(ress)
									if(ress.data.value.length){
										list_data = list_data.concat(ress.data.value)
										render_table(list_data,ress)
										params.page = params.page + 1
										$('.redis_library_data_loadmore').hide()
									}
								})
								e.stopPropagation()
							})
							// 滚动到最底部时加载更多数据
							$('#redis_library_data .divtable').scroll(function(){
								var _this = $(this)
								that.redisEditScrollHeight = _this[0].scrollHeight
								if(_this.scrollTop() + _this.height() + 10 >= _this[0].scrollHeight){
									// 出现加载更多按钮
									$('.redis_library_data_loadmore').show()
								}else{
									$('.redis_library_data_loadmore').hide()
								}
							})
						},
						tootls:tools
					})
					function add_new_value(rowData){
						bt_tools.open({
							title:'添加新行',
							area:['460px','auto'],
							btn:['确定','取消'],
							content:{
								class:'pd20',
								form:[{
									label:'key',
									group:{
										name: 'key',
										type: 'text',
										value:rowData?rowData.key:'',
										width:'260px',
										placeholder:'请输入'+(formD.type == 'zset'? 'score值' : 'key值')
									}
								},{
									label:'value',
									group:{
										name: 'value',
										type: 'textarea',
										width:'260px',
										value:rowData?rowData.value:'',
										style:{
											'min-height': '100px',
										},
										placeholder: '请输入'+(formD.type == 'zset'? 'member值' : 'value值')
									}
								}]
							},
							success:function(layer){
								var children = $(layer).find('form').children()
								if(formD.type== "list" || formD.type == "set"){
									children.eq(0).remove()
								}
								if(formD.type == "zset"){
									children.eq(0).find('.tname').html('score')
									children.eq(0).find('input').attr('type','number')
									children.eq(1).find('.tname').html('member')
									if(rowData){
										children.eq(0).find('input').val(rowData.score)
										children.eq(1).find('textarea').val(rowData.member)
									}
								}
							},
							yes:function(formData,indexs){
								// 根据不同的类型，生成不同的params参数
								var gerRedisValueParams = {
									sid:Number(that.cloudInfo.sid),
									db_idx:Number(formD.db_idx),
									key:formD.name || formD.key,
								}
								var params = Object.assign({value: {},
									ttl: $('.ttl_value').val(),},gerRedisValueParams)
								if (formD.type === 'list') {
									// 当状态为修改时，传递index参数
									if(rowData) params.index = rowData.id
									params.value = formData.value;
								} else if (formD.type === 'set') {
									params.value = formData.value;
									// 当状态为修改时，传递old_value参数
									if(rowData) params.old_value = rowData.value
								} else if (formD.type === 'zset') {
									// 当状态为修改时，传递old_value参数
									if(rowData) params.old_value = rowData.member
									params.value = formData.value;
									params.score = formData.key;
									// params.value.score = formData.key; ?
								}else if(formD.type==='hash'){
									params.value.value = formData.value;
									if(rowData) params.value.old_key = rowData.key
									params.value.key = formData.key;
								}

								bt_tools.send({url:'/database/redis/set_redis_value',data:{data:JSON.stringify(params)}},function(ress){
									layer.close(indexs)
									layer.msg(ress.msg, { icon: ress.status?1:2 })
									that.get_redis_value(gerRedisValueParams,function(ress){
										ress.data.db_idx = Number(formD.db_idx)
										render_table(ress.data.value,ress)
									})
								})
							},
						})
					}
				}

				function render_bottom(ress){
					if(ress.data.next_page == 0 || !(ress.data.value.length)){
						$('.redis_library_data_loadmore').html('<span>数据已经到底啦~</span>')
					}else{
						$('.redis_library_data_loadmore').html('<button class="btn btn-default btn-sm">加载更多</button>')
					}
				}
			},
			yes:function(indexs){
				var params = {
					sid:Number(that.cloudInfo.sid),
					db_idx:Number(formD.db_idx),
					key:formD.name || formD.key,
					type:formD.type,
					value:$('.valueData').val(),
					ttl:$('.ttl_value').val(),
				}
				bt_tools.send({url:'/database/redis/set_redis_value',data:{data:JSON.stringify(params)}},function(ress){
					if(ress.status) that.render_redis_table(formD.db_idx)
					layer.msg(ress.msg, { icon: ress.status?1:2 })
				})
			},
			cancel:function(){
				clearInterval(that.time)
			}
		})
	},
	redisEditScrollHeight:0, //记录编辑弹窗的滚动条高度
	get_redis_value:function(data,callback){
		bt_tools.send({url:'/database/redis/get_redis_value',data:{data:JSON.stringify(data)}},function(ress){
			if(callback) callback(ress)
		},{verify:false})
	},
	//选择需要清空的redis库
	choose_redis_list: function () {
		var that = this;
		layer.open({
			type: 1,
			area: '400px',
			title: '清空【' + this.cloudInfo.title + '】数据库',
			shift: 5,
			closeBtn: 2,
			shadeClose: false,
			btn: ['确认', '取消'],
			content:
				'<div class="bt-form pd20" id="choose_redis_from">\
					<div class="line"><span class="tname">选择数据库</span>\
						<div class="info-r">\
							<div class="rule_content_list">\
								<div class="rule_checkbox_group" bt-event-click="checkboxMysql" bt-event-type="active_all"><input name="*" type="checkbox" style="display: none;">\
									<div class="bt_checkbox_groups active"></div>\
									<span class="rule_checkbox_title">全部选中</span></div>\
								<ul class="rule_checkbox_list"></ul>\
							</div>\
						</div>\
					</div>\
				</div>',
			success: function (layers, index) {
				$(':focus').blur();
				var rule_site_list = '';
				$.each(that.redisDBList, function (index, item) {
					rule_site_list +=
						'<li>' +
						'<div class="rule_checkbox_group" bt-event-click="checkboxMysql" bt-event-type="active">' +
						'<span class="glyphicon glyphicon-menu-right" style="display:none" aria-hidden="true" bt-event-click="checkboxMysql" bt-event-type="fold"></span>' +
						'<input name="' +
						item.name +
						'" type="checkbox" data-id="' +
						item.id +
						'" checked=checked style="display: none;">' +
						'<div class="bt_checkbox_groups active"></div>' +
						'<span class="rule_checkbox_title">' +
						item.name +
						'</span>' +
						'</div>' +
						'</li>';
					$('.rule_checkbox_list').html(rule_site_list);
					that.event_bind();
				});
			},
			yes: function (index, layers) {
				var redisIDList = [];
				$('#choose_redis_from .rule_checkbox_list input').each(function (index, el) {
					if ($(this).prop('checked')) {
						redisIDList.push($(this).data('id'));
					}
				});
				if (redisIDList.length == 0) return layer.msg('请选择需要删除的数据库', { icon: 2 });
				var params = {
					id_list: redisIDList,
					sid: Number(that.cloudInfo.sid)
				}
				layer.confirm(
					'清空后数据将无法恢复,是否继续?',
					{
						title: '清空数据库',
						closeBtn: 2,
						icon: 0,
					},
					function (index) {
						bt_tools.send({ url: '/database/redis/clear_flush_db', data: { data: JSON.stringify(params) } }, function (rdata) {
							if (rdata.status) {
								that.render_redis_content();
								layer.closeAll();
							}
							bt_tools.msg(rdata);
						});
					}
				);
			},
		});
	},
	// 集群管理视图
	cluster_manage_viwe: function () {
		var rthat = this;
		bt_tools.open({
			title:'集群管理',
			area:['520px','370px'],
			btn:false,
			content:'<div id="cluster_manage_table" class="pd15"></div>',
			success:function(){
				rthat.get_cluster_list()
			}
		})

		// 集群开关事件绑定
		$('#cluster_manage_table').on('click','.clusterServiceStatus',function(){
			var status = $(this).prev().prop('checked')
			bt_tools.send({url:'database/rediscluster/'+(status?'stop_cluster':'restart_cluster'),data:{}},function(res){
				if(res.status){rthat.get_cluster_list()}
				bt_tools.msg(res);
			},'集群'+(status?'停止':'启动')+'中')
		})
	},
	// 获取集群列表
	get_cluster_list:function(){
		var rthat = this;
		bt_tools.send({url:'database/rediscluster/get_cluster_info',data:{}},function(clist){
			if(typeof clist.msg != 'undefined' && !clist.status){
				layer.closeAll()
				bt_tools.msg(clist);
				return false;
			}
			var newData = [],_column = [],fixedThead= true,num = 0;
			$.each(clist.data.cluster, function (index, item) {
				newData.push($.extend(item, { status: item.status == 'running'?'1':'0' }));
			})
			// 深拷贝容器数据
			rthat.clusterModeConfig = JSON.parse(JSON.stringify(clist));
			_column = rthat.get_cluster_table_config()  //获取集群表格配置
			$('#cluster_manage_table').empty(); // 清空表格
			bt_tools.table({
				el:'#cluster_manage_table',
				data:newData,
				height:240,
				column:_column,
				tootls:[{ // 按钮组
					type: 'group',
					positon: ['left', 'top'],
					list: [{
						title: '集群配置',
						active: true,
						event: function (ev, that) {
							rthat.open_cluster_mode_config()
						}
					}]
				}],
				success:function(){
					if(fixedThead){
						num++;
						if(num >= 2){
							var btnPositionBox = $('#cluster_manage_table').find('.tootls_group.tootls_top .pull-left')
							// 判断模式开关是否已存在
							if(btnPositionBox.find('.cluster_mode_switch').length == 0){
								btnPositionBox.append('<div style="display:inline">当前模式：【<span class="cluster_mode_title">无</span>】</div>')
								$('#cluster_manage_table').find('.tootls_group.tootls_top .pull-right').append('<div class="cluster_mode_switch" style="display: inline-block;margin-left: 20px;">\
								<span>集群开关</span>\
								<div style="display: inline-block;vertical-align: -6px;margin-left:5px;">\
									<input type="checkbox" class="btswitch btswitch-ios" id="clusterServiceStatus">\
									<label class="btswitch-btn clusterServiceStatus" for="clusterServiceStatus"></label>\
								</div></div>')
								rthat.matching_cluster_type(clist.data.config.pattern)
							}
							// 集群开关状态设置
							$('#clusterServiceStatus').prop('checked',clist.data.config.status)
						}
					}
				}
			})
		},{load:'获取集群列表',verify:false})
	},
	// 设置集群表格配置
	get_cluster_table_config:function(){
		var array = [
			{fid:'name',title:'容器名称',type:'text'},
			{fid:'port',title:'端口',type:'text'},
			{fid:'role',title:'角色',type:'text',template:function(row){
					return '<span>'+(row.role?'主':'从')+'库</span>'
				}},
			{fid:'status',title:'状态',config: {
					icon: true,
					list: [
						['1', '运行中', 'bt_success', 'glyphicon-play'],
						['0', '已停止', 'bt_danger', 'glyphicon-pause']
					]
				},
				type: 'status',
				event: function (row, index, ev, key, that) {
					bt_tools.send({ url:'database/rediscluster/set_container',data:{data:JSON.stringify({node_id:row.node_id,status:row.status == '1'?'stop':'start'})}},function(res){
						if(res.status){
							redis.get_cluster_list()
						}
						bt_tools.msg(res);
					},'容器'+(row.status == '1'?'停止':'启动')+'中')
				}
			},
			{
				title: '操作',
				type: 'group',
				width: 44,
				align: 'right',
				group: [{
					title: '删除',
					event: function (row, index, ev, key, that) {
						bt.confirm({
							title: '删除容器【' + row.name + '】',
							msg: '您真的要从列表中删除这个容器吗？'
						}, function () {
							bt_tools.send({url:'database/rediscluster/remove_cluster_node',data:{data:JSON.stringify({node_id:row.node_id})}},function(res){
								if(res.status){
									redis.get_cluster_list()
								}
								bt_tools.msg(res);
							})
						});
					}
				}]
			}
		]
		// 非主从模式
		var _mode = this.clusterModeConfig.data.config.pattern
		if( _mode != 'replicate') array.splice(2,0,{
			fid:'port_2',
			title:(_mode == 'sentinel'?'哨兵端口':'总线端口'),
			type:'text'
		},)
		return array
	},
	// 集群模式管理
	open_cluster_mode_config(){
		var that = this
		bt_tools.open({
			title:'集群模式配置',
			area:['440px','570px'],
			btn:['保存','取消'],
			skin:'cluster_dialog_box',
			content:{
				class:'pd20',
				form:[
					{
						label:'redis版本',
						group:{
							type:'select',
							name:'redis_version',
							placeholder:'请选择版本',
							width:'260px',
							list:(function(){
								var _version = []
								$.each(that.clusterModeConfig.data.redis_version,function(index,item){
									_version.push({title:item,value:item})
								})
								return _version
							})()
						}
					},
					{
						label:'模式',
						group:{
							type:'select',
							name:'pattern',
							width:'260px',
							list:[
								{title:'主从模式',value:'replicate'},
								{title:'哨兵模式',value:'sentinel'},
								{title:'集群模式',value:'cluster'}
							],
							change: function (formData) {
								switchComposeType(formData.pattern)
							}
						}
					},
					{
						label:'数据库',
						group:[{
							type:'number',
							name:'databases',
							width:'76px',
							'class': 'group',
							value:16,
							unit:'个',
							suffix:'* 需要创建的数据库数量'
						}]
					},
					{
						label:'数据库密码',
						group:{
							type:'text',
							name:'requirepass',
							width:'260px',
							placeholder:'请输入数据库密码'
						}
					},{
						group:{
							type:'other',
							boxcontent:'<div class="compose_list_title">容器列表 【当前为：<span class="compose_mode_title"></span>】<button type="button" class="btn btn-success btn-xs ml15 add_redis_compose" style="vertical-align: initial;"><i class="glyphicon glyphicon-plus"></i> 添加容器</button></div><div class="redis_mode_table" id="redis_mode_table">\
							<div class="divtable" style="height:162px">\
								<table class="table table-hover">\
									<thead><tr><th>端口</th><th>CPU</th><th>内存</th><th>角色</th></tr></thead>\
									<tbody></tbody>\
								</table></div></div>'
						}
					}
				],
				data:that.clusterModeConfig.data.config,
			},
			success:function(layers){
				// 表格渲染
				that.render_cluster_mode_table()
				// 模式提示信息
				switchComposeType(that.clusterModeConfig.data.config.pattern)
				// 表头固定
				if (jQuery.prototype.fixedThead) {
					$('.redis_mode_table .divtable').fixedThead({ resize: false });
				}
				// 事件绑定
				$('.cluster_dialog_box').on('click','.add_redis_compose',function(){
					that.clusterModeConfig.data.cluster.splice(0,0,{port:'',use_cpu:1,use_memory:500,role:0})
					that.render_cluster_mode_table()
				})
			},yes:function(formD,indexs){
				var params = {};
				if(formD.databases < 1) return layer.msg('数据库数量不能小于1', {icon:0});
				if(formD.requirepass == '' || formD.requirepass.length < 5) return layer.msg('数据库密码不能小于5位', {icon:0});
				params['redis_version'] = formD.redis_version;
				params['pattern'] = formD.pattern;
				params['databases'] = Number(formD.databases);
				params['requirepass'] = formD.requirepass;
				params['cluster'] = []

				if(params.pattern == 'cluster'){
					params['replicate'] = 0
				}

				// 容器当前的数量
				var _container_num = $('.redis_mode_table tbody tr').length;
				// 循环容器数量取出formD中的数据
				for(var i = 0; i < _container_num; i++){
					// 判断端口是否为空
					if(formD['cluster_port_'+i] == ''){
						$('input[name="cluster_port_'+i+'"]').focus()
						return layer.msg('端口不能为空', {icon:0});
					}
					// 判断cpu是否为空
					if(formD['cluster_cpu_'+i] == ''){
						$('input[name="cluster_cpu_'+i+'"]').focus()
						return layer.msg('容器CPU数量不能为空', {icon:0});
					}
					// 判断内存是否为空
					if(formD['cluster_memory_'+i] == ''){
						$('input[name="cluster_memory_'+i+'"]').focus()
						return layer.msg('内存不能为空', {icon:0});
					}

					params['cluster'].push({
						port:Number(formD['cluster_port_'+i]),
						use_cpu:Number(formD['cluster_cpu_'+i]),
						use_memory:Number(formD['cluster_memory_'+i]),
						role:Number(formD['cluster_role_'+i])
					})
				}

				// 判断各模式下主库的数量
				var _master_num = 0;
				$.each(params.cluster,function(index,item){
					if(item.role == 1) _master_num++
				})
				// 判断主从模式/哨兵模式下主库的数量不能大于或小于1
				if(params.pattern != 'cluster' && _master_num != 1) return layer.msg('只能设置一个主库', {icon:0});
				// 判断集群模式下主库的数量小于3
				if(params.pattern == 'cluster' && _master_num < 3) return layer.msg('主库数量不能小于3个', {icon:0});

				// 提交数据
				bt_tools.send({url:'database/rediscluster/set_cluster',data:{data:JSON.stringify(params)}},function(res){
					if(res.status){
						layer.close(indexs)
						that.get_cluster_list()
						that.matching_cluster_type(params['pattern'])
					}
					bt_tools.msg(res)
				},'保存配置中')
			}
		})
		// 切换模式类型提醒
		function switchComposeType(type){
			var text = ''
			if(typeof type === 'undefined') {
				type = 'replicate'
			}
			switch(type){
				case 'replicate':
					text = '主从模式,请添加不少于3个容器'
					break;
				case 'sentinel':
					text = '哨兵模式,请添加不少于3个容器'
					break;
				case 'cluster':
					text = '集群模式,请添加不少于3个主库'
					break;
			}
			$('.compose_mode_title').html(text)
		}
	},
	/**
	 * @description 渲染集群模式表格
	 * @return {String} body的数据结构
	 */
	render_cluster_mode_table: function(){
		var arrData = [],_body = '';
		// 存在模式
		if(this.clusterModeConfig.data.config.requirepass != ''){
			arrData = this.clusterModeConfig.data.cluster
		}else{
			// 不存在模式(默认生成三个容器)
			arrData = [
				{port:30001,use_cpu:1,use_memory:500,role:1},
				{port:30002,use_cpu:1,use_memory:500,role:0},
				{port:30003,use_cpu:1,use_memory:500,role:0},
			]
			this.clusterModeConfig.data.cluster = arrData
			this.clusterModeConfig.data.config.requirepass = '0' // 标识符可忽略
		}

		// 渲染表格数据
		$.each(arrData, function (index, item) {
			_body += '<tr>\
				<td><input type="number" name="cluster_port_'+index+'" value="' + item.port + '"></td>\
				<td><input type="number" name="cluster_cpu_'+index+'" value="' + item.use_cpu + '"><span class="unit">个</span></td>\
				<td><input type="number" name="cluster_memory_'+index+'" value="' + item.use_memory
				+ '"><span class="unit">MB</span></td>\
				<td><select name="cluster_role_'+index+'" value="'+item.role+'">\
					<option value="1" '+(item.role?'selected':'')+'>主库</option>\
					<option value="0" '+(!item.role?'selected':'')+'>从库</option>\
				</select></td></tr>';
		})

		// 生成表格
		$('.redis_mode_table tbody').html(_body)
	},
	// redis集群管理
	matching_cluster_type:function(type){
		var text = ''
		switch(type){
			case 'replicate':
				text = '主从模式'
				break;
			case 'sentinel':
				text = '哨兵模式'
				break;
			case 'cluster':
				text = '集群模式'
				break;
		}
		$('.cluster_mode_title').html(text)
	},
	event_bind: function () {
		$('.rule_checkbox_group')
			.unbind('click')
			.click(function (ev) {
				var _type = $(this).attr('bt-event-type'),
					_checkbox = '.bt_checkbox_groups';
				switch (_type) {
					case 'active_all': //选中全部
						var thatActive = $(this).find(_checkbox),
							thatList = $(this).next();
						if (thatActive.hasClass('active')) {
							thatActive.removeClass('active').prev().prop('checked', false);
							thatList.find(_checkbox).removeClass('active').prev().prop('checked', false);
						} else {
							thatActive.addClass('active').prev().prop('checked', true);
							thatList.find(_checkbox).addClass('active').prev().prop('checked', true);
						}
						break;
					case 'active': //激活选中和取消
						var thatActive = $(this).find(_checkbox),
							thatList = $(this).next();
						if (thatActive.hasClass('active')) {
							thatActive.removeClass('active').prev().prop('checked', false);
							$('.mysql_content_list>.mysql_checkbox_group input').prop('checked', false).next().removeClass('active');
							if (thatList.length == 1) {
								thatList.find(_checkbox).removeClass('active').prev().prop('checked', false);
							} else {
								var nodeLength = $(this).parent().siblings().length + 1,
									nodeList = $(this).parent().parent();
								if (nodeList.find('.bt_checkbox_groups.active').length != nodeLength) {
									nodeList.prev().find(_checkbox).removeClass('active').prev().prop('checked', false);
								}
							}
						} else {
							thatActive.addClass('active').prev().prop('checked', true);
							if (thatList.length == 1) {
								thatList.find(_checkbox).addClass('active').prev().prop('checked', true);
							} else {
								var nodeLength = $(this).parent().siblings().length + 1,
									nodeList = $(this).parent().parent();
								if (nodeList.find('.bt_checkbox_groups.active').length == nodeLength) {
									nodeList.prev().find(_checkbox).addClass('active').prev().prop('checked', true);
								}
							}
						}
						break;
					case 'fold': //折叠数据库列表
						if ($(this).hasClass('glyphicon-menu-down')) {
							$(this).removeClass('glyphicon-menu-down').addClass('glyphicon-menu-right').parent().next().hide();
						} else {
							$(this).removeClass('glyphicon-menu-rigth').addClass('glyphicon-menu-down').parent().next().show();
						}
						break;
				}
				$('.rule_content_list').removeAttr('style');
				ev.stopPropagation();
			});
	},
	//重置时间格式
	reset_time_format: function (time) {
		if (time == 0) return '永久';
		var theTime = parseInt(time); // 秒
		var middle = 0; // 分
		var hour = 0; // 小时

		if (theTime > 60) {
			middle = parseInt(theTime / 60);
			theTime = parseInt(theTime % 60);
			if (middle > 60) {
				hour = parseInt(middle / 60);
				middle = parseInt(middle % 60);
			}
		}
		var result = '' + parseInt(theTime) + '秒';
		if (middle > 0) {
			result = '' + parseInt(middle) + '分' + result;
		}
		if (hour > 0) {
			result = '' + parseInt(hour) + '小时' + result;
		}
		return result;
	},
};
var pgsql = {
	database_table_view: function (search) {
		var param = {
			table: 'databases',
			search: search || '',
		};
		$('#bt_pgsql_table').empty();
		database_table = bt_tools.table({
			el: '#bt_pgsql_table',
			url: 'database/' + bt.data.db_tab_name + '/get_list',
			param: param, //参数
			minWidth: '1000px',
			load: true,
			autoHeight: true,
			default: '数据库列表为空', // 数据为空时的默认提示
			clickInto:'您的数据库列表为空，您可以<a class="btlink" onClick="$(\'#bt_pgsql_table .pull-left button\').eq(0).click()">添加一个数据库</a>',
			pageName: 'database',
			beforeRequest: function (beforeData) {
				var db_type_val = $('.pgsql_type_select_filter').val();
				switch (db_type_val) {
					case 'all':
						delete param['db_type'];
						delete param['sid'];
						break;
					case 0:
						param['db_type'] = 0;
						break;
					default:
						delete param['db_type'];
						param['sid'] = db_type_val;
				}
				if (beforeData.hasOwnProperty('data') && typeof beforeData.data === 'string') {
					delete beforeData['data'];
					return { data: JSON.stringify($.extend(param, beforeData)) };
				}
				return { data: JSON.stringify(param) };
			},
			column: [
				{ type: 'checkbox', width: 20 },
				{ fid: 'name', title: '数据库名', type: 'text' },
				{ fid: 'username', title: '用户名', type: 'text', sort: true },
				{ fid: 'password', title: '密码', type: 'password', copy: true, eye_open: true },
				{
					fid: 'backup',
					title: '备份数据库',
					width: 130,
					template: function (row) {
						var backup = '点击备份',
							_class = 'bt_warning';
						if (row.backup_count > 0) (backup = lan.database.backup_ok), (_class = 'bt_success');
						return (
							'<span><a href="javascript:;" class="btlink ' +
							_class +
							'" onclick="database.database_detail(' +
							row.id +
							",'" +
							row.name +
							'\')">' +
							backup +
							(row.backup_count > 0 ? '(' + row.backup_count + ')' : '') +
							'</a> | ' +
							'<a href="javascript:database.input_database(\'' +
							row.name +
							'\')" class="btlink">' +
							lan.database.input +
							'</a></span>'
						);
					},
				},
				{
					title: '数据库位置',
					type: 'text',
					width: 116,
					template: function (row) {
						var type_column = '-';
						switch (row.db_type) {
							case 0:
								type_column = '本地数据库';
								break;
							case 1:
								type_column = ('远程库(' + row.conn_config.db_host + ':' + row.conn_config.db_port + ')').toString();
								break;
							case 2:
								$.each(cloudDatabaseList, function (index, item) {
									if (row.sid == item.id) {
										if (item.ps !== '') {
											// 默认显示备注
											type_column = item.ps;
										} else {
											type_column = ('远程服务器(' + item.db_host + ':' + item.db_port + ')').toString();
										}
									}
								});
								break;
						}
						return '<span class="flex" style="width:100px" title="' + type_column + '"><span class="size_ellipsis" style="width: 0; flex: 1;">' + type_column + '</span></span>';
					},
				},
				{
					fid: 'ps',
					title: '备注',
					type: 'input',
					blur: function (row, index, ev) {
						bt.pub.set_data_ps(
							{
								id: row.id,
								table: 'databases',
								ps: ev.target.value,
							},
							function (res) {
								layer.msg(
									res.msg,
									res.status
										? {}
										: {
											icon: 2,
										}
								);
							}
						);
					},
					keyup: function (row, index, ev) {
						if (ev.keyCode === 13) {
							$(this).blur();
						}
					},
				},
				{
					type: 'group',
					title: '操作',
					width: 220,
					align: 'right',
					group: [
						{
							title: '工具',
							tips: 'pgsql工具',
							event: function (row) {
								pgsql.pgsql_tools(row.name);
							},
						},
						{
							title: '改密',
							tips: '修改数据库密码',
							hide: function (rows) {
								return rows.db_type == 1;
							},
							event: function (row) {
								database.set_data_pass(row.id, row.username, row.password);
							},
						},
						{
							title: '删除',
							tips: '删除数据库',
							event: function (row) {
								var list = [];
								list.push(row);
								database.del_database(list, row.name, row, function (res) {
									if (res.status) database_table.$refresh_table_list(true);
									layer.msg(res.msg, {
										icon: res.status ? 1 : 2,
									});
								});
							},
						},
					],
				},
			],
			sortParam: function (data) {
				return {
					order: data.name + ' ' + data.sort,
				};
			},
			tootls: [
				{
					// 按钮组
					type: 'group',
					positon: ['left', 'top'],
					list: [
						{
							title: '添加数据库',
							active: true,
							event: function () {
								open_add();
								function open_add() {
									if (cloudDatabaseList.length == 0) return layer.msg('至少添加一个远程服务器或安装本地数据库', { time: 0, icon: 2, closeBtn: 2, shade: 0.3 });
									var cloudList = [];
									$.each(cloudDatabaseList, function (index, item) {
										var _tips = item.ps != '' ? item.ps + ' (' + item.db_host + ')' : item.db_host;
										cloudList.push({ title: _tips, value: item.id, name: item.db_host });
									});
									bt.database.add_database(cloudList, function (res) {
										if (res.status) database_table.$refresh_table_list(true);
									});
								}
							},
						},
						{
							title: '管理员密码',
							event: function () {
								bt.database.set_root('pgsql');
							},
						},
						{
							title: '远程服务器',
							event: function () {
								db_public_fn.get_cloud_server_list();
							},
						},
					],
				},
				{
					type: 'batch', //batch_btn
					positon: ['left', 'bottom'],
					placeholder: '请选择批量操作',
					buttonValue: '批量操作',
					disabledSelectValue: '请选择需要批量操作的数据库!',
					selectList: [
						{
							title: '同步数据库',
							url: '/database/' + bt.data.db_tab_name + '/SyncToDatabases',
							// paramName: 'data', //列表参数名,可以为空
							// th:'数据库名称',
							// beforeRequest: function(list) {
							//   var arry = [];
							//   $.each(list, function (index, item) {
							//     arry.push(item.id);
							//   });
							//   return JSON.stringify({ids:JSON.stringify(arry),type:1})
							// },
							// success: function (res, list, that) {
							//   layer.closeAll();
							//   var html = '';
							//   $.each(list, function (index, item) {
							//     html += '<tr><td>' + item.name + '</td><td><div style="float:right;"><span style="color:' + (res.status ? '#20a53a' : 'red') + '">' + res.msg + '</span></div></td></tr>';
							//   });
							//   that.$batch_success_table({
							//     title: '批量同步选中',
							//     th: '数据库名称',
							//     html: html
							//   });
							// }
							param: function (row) {
								var arry = [];
								arry.push(row.id);
								return { data: JSON.stringify({ ids: JSON.stringify(arry), type: 1 }) };
							},
							callback: function (that) {
								// 手动执行,data参数包含所有选中的站点
								bt.simple_confirm({ title: '批量同步数据库', msg: '批量同步选中的数据库，同步过程中可能存在风险，请在闲置时间段同步数据库，是否继续操作？' }, function () {
									var param = {};
									that.start_batch(param, function (list) {
										var html = '';
										for (var i = 0; i < list.length; i++) {
											var item = list[i];
											html +=
												'<tr><td>' +
												item.name +
												'</td><td><div style="float:right;"><span style="color:' +
												(item.request.status ? '#20a53a' : 'red') +
												'">' +
												item.request.msg +
												'</span></div></td></tr>';
										}
										database_table.$batch_success_table({ title: '批量同步数据库', th: '数据库名', html: html });
										database_table.$refresh_table_list(true);
									});
								});
							},
						},
						{
							title: '备份数据库',
							url: bt.data.db_tab_name == 'mysql' ? 'database?action=ToBackup' : '/database/' + bt.data.db_tab_name + '/ToBackup',
							load: true,
							param: function (row) {
								return bt.data.db_tab_name == 'mysql' ? { id: row.id } : { data: JSON.stringify({ id: row.id }) };
							},
							callback: function (that) {
								// 手动执行,data参数包含所有选中的站点
								that.start_batch({}, function (list) {
									var html = '';
									for (var i = 0; i < list.length; i++) {
										var item = list[i];
										html +=
											'<tr><td>' +
											item.name +
											'</td><td><div style="float:right;"><span style="color:' +
											(item.request.status ? '#20a53a' : 'red') +
											'">' +
											item.request.msg +
											'</span></div></td></tr>';
									}
									database_table.$batch_success_table({ title: '批量备份数据库', th: '数据库名', html: html });
									database_table.$refresh_table_list(true);
								});
							},
						},
						{
							title: '删除数据库',
							url: '/database/' + bt.data.db_tab_name + '/DeleteDatabase',
							load: true,
							param: function (row) {
								return {
									data: JSON.stringify({
										id: row.id,
										name: row.name,
									}),
								};
							},
							callback: function (that) {
								// 手动执行,data参数包含所有选中的站点
								var ids = [];
								for (var i = 0; i < that.check_list.length; i++) {
									ids.push(that.check_list[i].id);
								}
								database.del_database(that.check_list, function (param) {
									that.start_batch(param, function (list) {
										layer.closeAll();
										var html = '';
										for (var i = 0; i < list.length; i++) {
											var item = list[i];
											html +=
												'<tr><td>' +
												item.name +
												'</td><td><div style="float:right;"><span style="color:' +
												(item.request.status ? '#20a53a' : 'red') +
												'">' +
												item.request.msg +
												'</span></div></td></tr>';
										}
										database_table.$batch_success_table({
											title: '批量删除',
											th: '数据库名称',
											html: html,
										});
										database_table.$refresh_table_list(true);
									});
								});
							},
						},
					],
				},
				{
					type: 'search',
					positon: ['right', 'top'],
					placeholder: '请输入数据库名称/备注',
					searchParam: 'search', //搜索请求字段，默认为 search
					value: '', // 当前内容,默认为空
				},
				{
					//分页显示
					type: 'page',
					positon: ['right', 'bottom'], // 默认在右下角
					pageParam: 'p', //分页请求字段,默认为 : p
					page: 1, //当前分页 默认：1
					numberParam: 'limit', //分页数量请求字段默认为 : limit
					number: 20, //分页数量默认 : 20条
					numberList: [10, 20, 50, 100, 200], // 分页显示数量列表
					numberStatus: true, //　是否支持分页数量选择,默认禁用
					jump: true, //是否支持跳转分页,默认禁用
				},
			],
			success: function (config) {
				//搜索前面新增数据库位置下拉
				if ($('.pgsql_type_select_filter').length == 0) {
					var _option = '<option value="all">全部</option>';
					$.each(cloudDatabaseList, function (index, item) {
						var _tips = item.ps != '' ? item.ps : item.db_host;
						_option += '<option value="' + item.id + '">' + _tips + '</option>';
					});
					$('#bt_pgsql_table .bt_search').before('<select class="bt-input-text mr5 pgsql_type_select_filter" style="width:110px" name="db_type_filter">' + _option + '</select>');

					//事件
					$('.pgsql_type_select_filter').change(function () {
						database_table.config.page.page = 1;
						database_table.$refresh_table_list(true);
					});
				}
				if($('#bt_pgsql_table .db_sync_setting').length == 0){
					db_public_fn.get_sync_all_server('#bt_pgsql_table','button:eq(2)')
				}
			},
		});
	},
	// pgsql工具
	pgsql_tools: function (db_name, res) {
		var loadT = layer.msg('正在获取数据,请稍候...', {
			icon: 16,
			time: 0,
		});
		bt_tools.send({ url: 'database/pgsql/GetInfo', data: { data: JSON.stringify({ db_name: db_name }) } }, function (rdata) {
			layer.close(loadT);
			if (rdata.status === false) {
				layer.msg(rdata.msg, {
					icon: 2,
				});
				return;
			}
			// var types = {
			//   InnoDB: "MyISAM",
			//   MyISAM: "InnoDB"
			// };
			var tbody = '',
				tableList = rdata.data.table_list;
			for (var i = 0; i < tableList.length; i++) {
				// if (!types[rdata.tables[i].type]) continue;
				tbody +=
					'<tr>\
                        <td><span style="width:150px;"> ' +
					tableList[i].table_name +
					'</span></td>\
                        <td><span> ' +
					tableList[i].collation +
					'</span></td>\
                        <td>' +
					tableList[i].rows_count +
					'</td>\
                        <td><span style="width:90px;"> ' +
					tableList[i].indexes_size +
					'</span></td>\
                        <td><span> ' +
					tableList[i].table_size +
					'</span></td>\
                        <td>' +
					tableList[i].total_size +
					'</td>\
                    </tr> ';
			}

			// if (res) {
			//   $(".gztr").html(tbody);
			//   $("#db_tools").html('');
			//   $("input[type='checkbox']").attr("checked", false);
			//   $(".tools_size").html('大小：' + rdata.data.storageSize);
			//   return;
			// }

			layer.open({
				type: 1,
				title: 'PgSQL工具箱【' + db_name + '】',
				area: ['780px', '480px'],
				closeBtn: 2,
				shadeClose: false,
				content:
					'<div class="pd15">\
                                <div class="db_list">\
                                    <span><a>数据库名称：' +
					db_name +
					'</a>\
																		<a class="tools_size">总大小：' +
					rdata.data.total_size +
					'</a></span>\
                                </div >\
                                <div class="divtable">\
                                <div  id="database_fix"  style="height:360px;overflow:auto;border:#ddd 1px solid">\
                                <table class="table table-hover "style="border:none">\
                                    <thead>\
                                        <tr>\
                                            <th>表名</th>\
                                            <th>编码</th>\
                                            <th>行数</th>\
                                            <th>索引大小</th>\
                                            <th>表数据大小</th>\
                                            <th>总大小</th>\
                                        </tr>\
                                    </thead>\
                                    <tbody class="gztr">' +
					tbody +
					'</tbody>\
                                </table>\
                                </div>\
                            </div>\
									</div>',
				success: function () {
					$(':focus').blur();
				},
			});
			tableFixed('database_fix');
			//表格头固定
			function tableFixed(name) {
				var tableName = document.querySelector('#' + name);
				tableName.addEventListener('scroll', scrollHandle);
			}

			function scrollHandle(e) {
				var scrollTop = this.scrollTop;
				//this.querySelector('thead').style.transform = 'translateY(' + scrollTop + 'px)';
				$(this)
					.find('thead')
					.css({
						transform: 'translateY(' + scrollTop + 'px)',
						position: 'relative',
						'z-index': '1',
					});
			}
		});
	},
};
/**
 * @description: 数据库二进制文件分析
 * @type {{}}
 */
var dbBinlogAnalysis = {

	formFactory: function(type,data,style){
		/**
		 * @description: 选择框
		 * @param data {} 数据
		 * @param style
		 */
		function selectForm (data,style){

			var databaseHtml = ''
			var fastItem = ''
			var list = []
			if(data.list == undefined || data.list.length == 0){
				fastItem	= '无数据'
				databaseHtml = `<li class="item" title="无匹配项" data-id="0" data-value="无数据">无数据</li>`
			}else {
				$.each(data.list,function(index,item){
					if(index==0) fastItem = item.value
					list.push({name:item.name,value:item.value})
					databaseHtml += `<li class="item" style="overflow: hidden;white-space: nowrap;text-overflow: ellipsis;" title="${item.name}" data-id="${index}" data-value="${item.value}">${item.name}</li>`
				})
			}

			var html = `
			<div style="display:flex;flex-direction: row;align-items: center;">
				<span class="binglog-form-title" style="width: 60px;text-align: right;">${data.name}：</span>
				<div class="bt_select_updown mr10  0" style="width: 80px;border:0" data-name="sType">
					<input type="text" style="border: 1px solid #DCDFE6;" class="bt_select_value " data-value="${fastItem}" value=""/>
					<div class="icon-down" style="display: block;position: absolute;top: 0px;right: 5px;">
						<svg width="12.000000" height="12.000000" viewBox="0 0 12 5" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><desc>	Created with Pixso.</desc><defs></defs><path id="path" d="M0.123291 0.809418L4.71558 5.84385C4.8786 6.02302 5.16846 6.04432 5.33038 5.86389L9.87927 0.783104C10.0412 0.602676 10.04 0.311989 9.87701 0.132816C9.79626 0.0446892 9.68945 0 9.58374 0C9.47693 0 9.36938 0.0459404 9.28827 0.136574L5.02881 4.89284L0.708618 0.15662C0.627869 0.0684967 0.522217 0.0238075 0.415405 0.0238075C0.307434 0.0238075 0.20105 0.0697479 0.119873 0.160381C-0.041626 0.338303 -0.0393677 0.630241 0.123291 0.809418Z" fill-rule="nonzero" fill="#999999"></path></svg>
					</div>
					<div class="icon_up" style="display: none;position: absolute;top: 0px;right: 5px;">
						<svg width="12.000000" height="12.000000" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><desc>Created with Pixso.</desc><defs></defs><path id="path" d="M1.12328 8.19058L5.71558 3.15616C5.87862 2.97699 6.16847 2.95569 6.33038 3.13611L10.8793 8.21689C11.0412 8.39731 11.04 8.68802 10.877 8.86719C10.7962 8.95532 10.6894 9 10.5838 9C10.477 9 10.3694 8.95407 10.2883 8.86343L6.02883 4.10715L1.70864 8.84338C1.62788 8.93152 1.5222 8.9762 1.41539 8.9762C1.30746 8.9762 1.20103 8.93024 1.11988 8.83963C0.958351 8.66171 0.960617 8.36975 1.12328 8.19058Z" fill-rule="nonzero" fill="#999999"></path></svg>
					</div>
					<ul id="${data.id}" class="bt_select_list" style="display: none;width: 250px;">${databaseHtml}</ul>
					<div class="bt_select_list_arrow" ></div>
					<div class="bt_select_list_arrow_fff" ></div>
				</div>
			</div>`
			$('#'+data.el).html(html)
			if(data.callback) data.callback($('#'+data.el+' .bt_select_list li').data('id'))
			$('#'+data.el+' .bt_select_updown .bt_select_value').on('focus',function(){
				var height = $(this).parent().height()
				$(this).nextAll('ul').css('top',(height+8)+'px')
				$('.bt_select_list_arrow_fff').not('#'+data.id).hide()
				$('.bt_select_list_arrow').not('#'+data.id).hide()
				$('.bt_select_updown .bt_select_value').nextAll('ul').not('#'+data.id).removeClass('show')
				$(this).nextAll('ul').toggleClass('show')
				$(this).nextAll('.icon-down').toggle()
				$(this).nextAll('.icon_up').toggle()
				if($(this).nextAll('ul').hasClass('show')){
					$('#'+data.el+' .bt_select_list_arrow_fff').css('top',(height-6)+'px').show()
					$('#'+data.el+' .bt_select_list_arrow').css('top',(height-7)+'px').show()
				}else {
					$('#'+data.el+' .bt_select_list_arrow_fff').hide()
					$('#'+data.el+' .bt_select_list_arrow').hide()
				}
			})
			$('#'+data.el+' .icon-down').click(function(){
				$('#'+data.el+' .bt_select_updown .bt_select_value').focus()
			})
			$('#'+data.el+' .icon_up').click(function(){
				$('#'+data.el+' .bt_select_updown .bt_select_value').focus()
			})
			$(document).click(function(e){
				if($(e.target).parents('.bt_select_updown').length==0){
					$('#'+data.el+' .bt_select_list').removeClass('show')
					$('#'+data.el+' .icon-down').show()
					$('#'+data.el+' .icon_up').hide()
					$('#'+data.el+' .bt_select_list_arrow_fff').hide()
					$('#'+data.el+' .bt_select_list_arrow').hide()
				}
			})
			/**
			 * @description: 选择列表
			 */
			function selectList() {
				var keyword = $('#binlog-table .bt_select_value').val()
				var keyword2 = $('#binlog-database .bt_select_value').val()
				$('#'+data.el+' .bt_select_list li').click(function () {
					var value = $(this).data('value')
					var name  = $(this).text()
					$(this).addClass('active').siblings().removeClass('active')
					$(this).parents('.bt_select_updown').find('.bt_select_value').val(name).attr('data-value',value).attr('title', value).attr('data-id', $(this).data('id'))
					$(this).parents('.bt_select_updown').find('.bt_select_list').removeClass('show')
					$(this).parents('.bt_select_updown').find('.icon-down').show()
					$(this).parents('.bt_select_updown').find('.icon_up').hide()
					$('.bt_select_list_arrow_fff').hide()
					$('.bt_select_list_arrow').hide()
					if(data.callback) data.callback($(this).data('id'))
				})
				$('#binlog-table .bt_select_value').attr('data-value',keyword).attr('title', keyword).attr('data-id', $(this).data('id'))
				$('#binlog-database .bt_select_value').attr('data-value',keyword2).attr('title', keyword2).attr('data-id', $(this).data('id'))
			}
			selectList()
			$('#'+data.el+' .bt_select_list li').eq(0).click()
			$('#'+data.el+' .bt_select_updown .bt_select_value').on('input',function(){
				var keyword = $(this).val()
				if(keyword==''){
					$(this).nextAll('ul').empty();
					$(this).nextAll('ul').append(databaseHtml);
				}
				// 清空下拉列表
				$(this).nextAll('ul').empty();
				var res = list.filter(option => option.name.toLowerCase().includes(keyword.toLowerCase()));
				if(res.length==0){
					res.push({name:'无匹配项',value:''})
				}
				res.forEach(result=>{
					$(this).nextAll('ul').append(`<li class="item" style="overflow: hidden;white-space: nowrap;text-overflow: ellipsis;" title="${result.value}" data-value="${result.value}">${result.name}</li>`);
				})
				selectList()
			})
		}

		/**
		 * @description: 多选框
		 * @param data
		 * @param style
		 */
		function multiSelectForm(data,style){
			var databaseHtml = ''
			var list = []
			var fastItem = '请选择数据库操作的类型，支持多选'
			if(data.list.length==0){
				databaseHtml = `<li class="item" title="无匹配项" data-id="0" data-value="0">无匹配项</li>`
			}else {
				$.each(data.list,function(index,item){
					if(index==0) fastItem = item.value
					list.push({name:item.name,value:item.value})
					databaseHtml += `
						<li class="item"  title="${item.desc}[${item.name}]" data-id="${index}" data-value="${item.value}">
							<span>${item.desc}[${item.name}]</span>
							<span class="icon-item-active"></span>
						</li>`
				})
			}

			var selectHtml = `
				<div style="display:flex;flex-direction: row;align-items: center;">
					<span class="binglog-form-title" style="width: 90px;text-align: right;">${data.name}：</span>
					<div class="inlineBlock  ">
						<div class="bt_multiple_select_updown bt_select_updown mr10  0" style="width: 460px;">
							<span class="bt_select_value" title="${fastItem}">
								<div class="icon-down" style="display: block;">
									<svg width="12.000000" height="12.000000" viewBox="0 0 12 5" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><desc>Created with Pixso.</desc><defs></defs><path id="path" d="M0.123291 0.809418L4.71558 5.84385C4.8786 6.02302 5.16846 6.04432 5.33038 5.86389L9.87927 0.783104C10.0412 0.602676 10.04 0.311989 9.87701 0.132816C9.79626 0.0446892 9.68945 0 9.58374 0C9.47693 0 9.36938 0.0459404 9.28827 0.136574L5.02881 4.89284L0.708618 0.15662C0.627869 0.0684967 0.522217 0.0238075 0.415405 0.0238075C0.307434 0.0238075 0.20105 0.0697479 0.119873 0.160381C-0.041626 0.338303 -0.0393677 0.630241 0.123291 0.809418Z" fill-rule="nonzero" fill="#999999"></path></svg>
								</div>
								<div class="icon_up" style="display:none;">
									<svg width="12.000000" height="12.000000" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><desc>Created with Pixso.</desc><defs></defs><path id="path" d="M1.12328 8.19058L5.71558 3.15616C5.87862 2.97699 6.16847 2.95569 6.33038 3.13611L10.8793 8.21689C11.0412 8.39731 11.04 8.68802 10.877 8.86719C10.7962 8.95532 10.6894 9 10.5838 9C10.477 9 10.3694 8.95407 10.2883 8.86343L6.02883 4.10715L1.70864 8.84338C1.62788 8.93152 1.5222 8.9762 1.41539 8.9762C1.30746 8.9762 1.20103 8.93024 1.11988 8.83963C0.958351 8.66171 0.960617 8.36975 1.12328 8.19058Z" fill-rule="nonzero" fill="#999999"></path></svg>
								</div>
								<span class="multiple_tip" style="color: #CBCBCB">请选择数据库操作的类型，支持多选</span>
								<div class="multiple_content"></div>
<!--								<span class="moreTips " style="display: block">更多</span>-->
							</span>
							<ul id="${data.id}" class="bt_select_list" style="display: none;">${databaseHtml}</ul>
							<div class="bt_select_list_arrow" ></div>
							<div class="bt_select_list_arrow_fff" ></div>
						</div>
					</div>
				</div>
			`
			$('#'+data.el).html(selectHtml)
			$('.multiple_tip').show()
			$('.bt_select_list_arrow_fff').hide()
			$('.bt_select_list_arrow').hide()
			var $selectValue = $('#'+data.el+' .bt_multiple_select_updown .bt_select_value')
			function checkList() {
				if($('.bt_select_content').length==0){
					$('.multiple_tip').show()
				}else {
					$('.multiple_tip').hide()
				}
			}
			$selectValue.on('click',function(e){
				var height = $(this).parent().height()
				$(this).nextAll('ul').css('top',(height+8)+'px')
				$('.bt_select_list_arrow_fff').not('#'+data.id).hide()
				$('.bt_select_list_arrow').not('#'+data.id).hide()
				$('.bt_select_updown .bt_select_value').nextAll('ul').not('#'+data.id).removeClass('show')
				$(this).nextAll('ul').toggleClass('show')
				if($(this).nextAll('ul').hasClass('show')){
					$(this).find('.icon-down').hide()
					$(this).find('.icon_up').show()
					$('#'+data.el+' .bt_select_list_arrow_fff').css('top',(height-6)+'px').show()
					$('#'+data.el+' .bt_select_list_arrow').css('top',(height-7)+'px').show()
				}else {
					$(this).find('.icon-down').show()
					$(this).find('.icon_up').hide()
					$('#'+data.el+' .bt_select_list_arrow_fff').hide()
					$('#'+data.el+' .bt_select_list_arrow').hide()
				}
			})
			$(document).click(function(e){
				if($(e.target).parents('.bt_select_updown').length==0){
					$('#'+data.el+' .bt_select_list').removeClass('show')
					$('#'+data.el+' .icon-down').show()
					$('#'+data.el+' .icon_up').hide()
					$('#'+data.el+' .bt_select_list_arrow_fff').hide()
					$('#'+data.el+' .bt_select_list_arrow').hide()
				}
			})
			var $li = $('#'+data.el+' .bt_select_list li')
			$li.click(function () {
				var that = this
				if(!$(this).hasClass('active')){
					if($li.eq(0).hasClass('active')){
						$li.eq(0).removeClass('active')
						$('.bt_select_content').remove()
					}
					if($(this).data('id')==0){
						$li.not(':eq(0)').removeClass('active')
						$('.bt_select_content').remove()
					}
					var html=`<span class="bt_select_content"><span>${$(this).find('span').eq(0).text()}</span><span class="icon-trem-close"></span></span>`
					$(this).parent().prev().find('.multiple_content').append(html)
					var height = $('#'+data.el+' .bt_multiple_select_updown .bt_select_value').parent().height()
					$('#'+data.el+' .bt_select_list_arrow_fff').css('top',(height-6)+'px').toggle()
					$('#'+data.el+' .bt_select_list_arrow').css('top',(height-7)+'px').toggle()
					$('#'+data.el+' .bt_select_list ').css('top',(height+8)+'px')
					if($selectValue.nextAll('ul').hasClass('show')){
						$('#'+data.el+' .bt_select_list_arrow_fff').css('top',(height-6)+'px').show()
						$('#'+data.el+' .bt_select_list_arrow').css('top',(height-7)+'px').show()
					}else {
						$('#'+data.el+' .bt_select_list_arrow_fff').hide()
						$('#'+data.el+' .bt_select_list_arrow').hide()
					}
					$(this).addClass('active')

				}else {
					$(this).removeClass('active')
					$('.bt_select_content').each(function(index,item){
						if($(item).find('span').eq(0).text()==$(that).find('span').eq(0).text()){
							$(item).remove()
							var height = $('#'+data.el+' .bt_multiple_select_updown .bt_select_value').parent().height()
							$('#'+data.el+' .bt_select_list_arrow_fff').css('top',(height-6)+'px').toggle()
							$('#'+data.el+' .bt_select_list_arrow').css('top',(height-7)+'px').toggle()
							$('#'+data.el+' .bt_select_list ').css('top',(height+8)+'px')
							if($selectValue.nextAll('ul').hasClass('show')){
								$('#'+data.el+' .bt_select_list_arrow_fff').css('top',(height-6)+'px').show()
								$('#'+data.el+' .bt_select_list_arrow').css('top',(height-7)+'px').show()
							}else {
								$('#'+data.el+' .bt_select_list_arrow_fff').hide()
								$('#'+data.el+' .bt_select_list_arrow').hide()
							}
							return
						}
					})
				}
				var text = ''
				$.each($('#'+data.el+' .bt_select_list li.active'),function(index,item){
					text += $(item).data('value')+','
				})
				text = text.substring(0,text.length-1)
				if(text==''){
					$li.eq(0).click()
				}
				$(this).parents('.bt_select_updown').find('.bt_select_value').val(text).attr('title', text).attr('data-id', $(this).data('id'))
				$(this).parents('.bt_select_updown').find('.icon-down').show()
				$(this).parents('.bt_select_updown').find('.icon_up').hide()
				if(data.callback) data.callback($(this).data('id'))
				checkList()
			})
			$('#'+data.el+' .bt_select_list li').eq(0).click()
			$('.bt_select_value').on('click','.icon-trem-close',function (e) {
				var _that = this
				e.stopPropagation()
				$(this).parent().remove()
				$('#'+data.el+' .bt_select_list li').each(function(index,item){
					if($(_that).parent().find('span').eq(0).text()==$(this).find('span').eq(0).text()){
						$(item).removeClass('active')
						var height = $selectValue.parent().height()
						if($selectValue.nextAll('ul').hasClass('show')){
							$('#'+data.el+' .bt_select_list_arrow_fff').css('top',(height-6)+'px').show()
							$('#'+data.el+' .bt_select_list_arrow').css('top',(height-7)+'px').show()
						}else {
							$('#'+data.el+' .bt_select_list_arrow_fff').hide()
							$('#'+data.el+' .bt_select_list_arrow').hide()
						}
						$('#'+data.el+' .bt_select_list ').css('top',(height+8)+'px')
						checkList()
						return false
					}
				})
				var text = ''
				$.each($('#'+data.el+' .bt_select_list li.active'),function(index,item){
					text += $(item).data('value')+','
				})
				text = text.substring(0,text.length-1)
				if(text==''){
					$li.eq(0).click()
				}

				$('#'+data.el+' .bt_select_value').val(text).attr('title', text).attr('data-id', $(this).data('id'))
			})
		}
		function timeForm(data,style){
			var html = `
				<div style="display:flex;flex-direction: row;align-items: center;">
					<span class="binglog-form-title" style="width: 90px;text-align: right;">${data.name}：</span>
					<div class="date"></div>
					<div id="test" >
						<div style="border: 1px solid #DCDFE6; height: 30px;display: flex;flex-direction: row;align-items: center;padding: 0 10px">
							<i style="background-image: url(/static/vite/svg/crontab.svg);background-size: 100% auto 100% auto;background-position: center;background-repeat: no-repeat;height: 16px;margin-right: 16px;width: 16px;color: #999;display: block;" class="icon"></i>
							<input id="startDate" class="bt_select_value" style="border: 0px;width: 282px;" type="text" value="" placeholder="请选择起始时间" />
						</div>

					</div>
				</div>
			`
			$('#'+data.el).html(html)
			laydate.set({
				rangeLinked: true, // 范围选择的日历面板是否联动
			})
			var time = `${new Date().getFullYear()}-${new Date().getMonth()+1}-${new Date().getDate()} ${new Date().getHours()}:${new Date().getMinutes()}:${new Date().getSeconds()}`
			laydate.render({
				elem: '#startDate',
				range: '至',
				type: 'datetime',
				min: data.firstTime,
				max: time,
			})
			$('#startDate').val(data.time +' 至 ' +time)
		}
		function searchForm(data,style){
			var html = `
				<div style="display:flex;flex-direction: row;align-items: center;">
					<span class="binglog-form-title" style="width: 90px;text-align: right;">${data.name}：</span>
					<input type="text" class="bt_select_value" style="border: 1px solid #DCDFE6;width: 300px;height: 30px" placeholder="请输入查询的语句或内容，该字段可以为空"/>
				</div>
				`
			$('#'+data.el).html(html)
		}
		switch(type){
			case 'select':
				selectForm(data)
				break
			case 'multiSelect':
				multiSelectForm(data)
				break
			case 'time':
				timeForm(data)
				break
			case 'search':
				searchForm(data)
		}
	},
	// binlog分析
	html: `
			<div>
				<div class="binlog-title" style="display: none">
					<div class="sn-home--open-condition" style="display: inline-block;color: #E6A23C;background: #FDF6EC;height: 34px;line-height: 34px;padding: 0 10px;border-radius: 2px;flex: 1;">
						<i class="sn-home--important-note" style="border: 1px solid #E6A23C;border-radius: 8px;cursor: help;display: inline-block;font-family: arial;font-size: 11px;font-style: normal;height: 16px;line-height: 16px;margin-right: 5px;text-align: center;width: 16px;">!</i>
						<span>通过对二进制日志分析，进行数据库操作溯源，帮助运维人员分析数据库问题。</span>
					</div>
				</div>
				<div class="binlog-form">
					<div class="binlog-select-group binlog-defult" style="display: flex">
						<div id="binlog-database"></div>
						<div id="binlog-table"></div>
					</div>
					<div id="binlog-type" class="binlog-defult"></div>
					<div id="binlog-time" class="binlog-defult"></div>
					<div id="binlog-search" class="binlog-defult"></div>
					<div id="binlog-btn" class="binlog-button-defult" ><button class="btn btn-success " style="margin-right: 10px;">立即分析</button></div>
				</div>
				<div class="binlog-result">
					<div class="binlog-tab"></div>
				</div>
			</div>
		`,
	ws: null,
	info:'<div class="thumbnail-introduce-new" style="margin:0;padding:0px 0">\
              <div class="thumbnail-introduce-title-new" style="width:100%;justify-content:normal;flex-direction:column;padding-left: 24px;">\
                  <div class="thumbnail-title-left-new" style="width:100%;">\
                      <div class="thumbnail-title-text-new">\
                          <p>MySQL执行日志分析-功能介绍</p>\
                          <p>二进制日志解析，溯源 SQL 语句执行过程，可用于违规操作追责，问题排查，敏感词搜索.</p>\
                      </div>\
                  </div>\
                   <div class="thumbnail-title-button-new daily-product-buy"  style="margin:16px 0 0 0">\
                      <button class="btn btn-success btn-sm" style="width:80px" onclick="product_recommend.pay_product_sign(\'ltd\',301,\'ltd\')">立即购买</button>\
                  </div>\
            </div>\
              <div class="thumbnail-introduce-hr" style="margin:22px 0"></div>\
              <div class="thumbnail-introduce-ul-new" style="margin-bottom:20px">\
                <ul></ul>\
  </div>\
  <div class="img_view" style="position: relative;">\
    <img class="product_view_img thumbnail-box" src="https://www.bt.cn/Public/new/plugin/introduce/database/BinaryLogAnalysis.png" style="width:auto;margin-top:10px;height:410px"/>\
  </div>\
</div>',
	init: function () {
		var that = this
		if(bt.get_cookie('ltd_end')<=0){
			$('#advance-con').html(that.info)
			return
		}
		var token = $("#request_token_head").attr("token")
		function waitForConnection (callback, interval) {
			if (that.ws.readyState === 1) {
				callback();
			} else {
				setTimeout(function () {
					waitForConnection(callback, interval);
				}, interval);
			}
		};
		var send = function (data, callback) {
			waitForConnection(function () {
				that.ws.send(JSON.stringify({'x-http-token':token}));
				// wsFiles.send(JSON.stringify({mod_name:mod_name}));
				that.ws.send(JSON.stringify(data));
				if (typeof callback !== 'undefined') {
					callback();
				}
			}, 300);
		}
		$('#advance-con').html(dbBinlogAnalysis.html)
		bt_tools.send({
			url: '/project/analysis_binlog/get_search_condition',
		},function(res){
			if(res.data.database.length==0){
				bt.msg({status:false,msg:'当前没有可用的数据库，请先创建数据库！'})
				that.formFactory('select',{name:'数据库',id:'database',list:[],el:'binlog-database',callback:function(index){
						that.formFactory('select',{name:'数据库表',id:'table',list:[],el:'binlog-table'})
					}})
				$('#binlog-btn button').eq(0).attr('disabled',true)
			}else {
				that.formFactory('select',{name:'数据库',id:'database',list:res.data.database,el:'binlog-database',callback:function(index){
						that.formFactory('select',{name:'数据库表',id:'table',list:res.data.database[index].table_list,el:'binlog-table'})
					}})
			}
			that.formFactory('multiSelect',{name:'操作类型',id:'type',list:res.data.sql_type,el:'binlog-type'})
			that.formFactory('time',{name:'查询时间',id:'time',time:res.data.start_time,firstTime:res.data.first_time,el:'binlog-time'})
			that.formFactory('search',{name:'搜索内容',id:'search',el:'binlog-search'})
			$('.binlog-form').addClass('select-type')
			$('.binlog-title').hide()
			$('.binglog-form-title').css('width','auto')
			$('#binlog-database').find('.bt_select_updown').css('width','80px')
			$('#binlog-database').find('.binglog-form-title').css('width','60px')
			$('#binlog-table').find('.bt_select_updown').css('width','80px')
			$('.bt_multiple_select_updown ').css('width','236px')
			$('#binlog-time').css('margin-right','40px')
			$('#startDate').css('width','292px')
			$('#binlog-search').find('.bt_select_value').css('width','346px')
			$('#binlog-btn').addClass('select-type')
			$('.binlog-tab').html(tab.$reader_content())
			$('.res_tab').find('.tab-nav').css('margin','0 10px')
			$('#binlog-btn button').eq(0).css('width','100%')
		},'初始化信息')

		$('#binlog-btn button').eq(0).click(function(){
			if($('#binlog-btn').find('#path').length!=0){
				$('#binlog-btn').find('#path').remove()
			}
			$(this).text('正在分析...').attr('disabled',true)
			if(that.ws != null){
				that.ws.close()
				that.ws = null
			}
			that.ws =new WebSocket((window.location.protocol === 'http:' ? 'ws://' : 'wss://') + window.location.host +'/ws_model');
			that.ws.addEventListener('message', function (ev) { that.on_message(ev) });
			that.ws.addEventListener('close', function (ev) { that.on_close(ev) });
			that.ws.addEventListener('error', function (ev) { that.on_error(ev) });
			that.ws.addEventListener('open', function (ev) { that.on_open(ev) });
			$('.res-table').empty()
			var data = {
				model_index: "project",
				mod_name: "analysis_binlog",
				def_name: "analysis_binlog",
				ws_callback: "1",

				db_list: [],
				tb_list: [],
				start_time: "",
				end_time: "",
				sql_type_list: [],
				search_content: null,
			}
			var $form = $('.binlog-form .bt_select_value')
			data.db_list.push($form.eq(0).attr('title'))
			data.tb_list.push($form.eq(1).attr('title'))
			data.sql_type_list =$form.eq(2).attr('title').split(',')
			data.start_time = $form.eq(3).val().split(' 至 ')[0]
			data.end_time = $form.eq(3).val().split(' 至 ')[1]
			data.search_content = $form.eq(4).val()
			if(data.start_time==''){
				layer.msg('请选择时间范围')
				return
			}

			send(data)
		})

		var tab = bt_tools.tab({
			class: 'res_tab',
			type: 0,
			theme: { nav: 'mlr20' },
			active: 1, //激活TAB下标
			list: [
				{
					title: '查询结果',
					content: `
						<div class="binlog-result-table divtable ">
							<table class="table table-hover">
								<thead>
									<tr>
										<th style="width: 144px;">执行时间</th>
										<th style="width: 100px;">SQL语句类型</th>
										<th style="width:460px">SQL语句</th>
										<th style="width: 50px">详情</th>
									</tr>
								</thead>
								<tbody class="res-table">
								</tbody>
						</div>
					`,
					success:function(){
					}
				}
			]
		})

	},
	num: 0,
	//连接服务器成功
	on_open: function (ws_event,callback) {
	},

	//服务器消息事件
	on_message: function (ws_event) {
		var rdata = JSON.parse(ws_event.data);
		this.num++
		if(rdata.result) {
			$('#binlog-btn .btn-success').attr('disabled',false).text('重新分析')
			if($('#binlog-btn').find('#path').length==0){
				$('#binlog-btn').append('<button id="path" class="btn btn-default" style="margin-top: 10px">导出分析数据</button>')
				$('#binlog-btn button').eq(1).click(function(){
					var path
					var data = {
						model_index: "project",
						mod_name: "analysis_binlog",
						def_name: "analysis_binlog",
						ws_callback: "1",

						db_list: [],
						tb_list: [],
						start_time: "",
						end_time: "",
						sql_type_list: [],
						search_content: null,
					}
					var $form = $('.binlog-form .bt_select_value')
					data.db_list.push($form.eq(0).attr('title'))
					data.tb_list.push($form.eq(1).attr('title'))
					data.sql_type_list =$form.eq(2).attr('title').split(',')
					data.start_time = $form.eq(3).val().split(' 至 ')[0]
					data.end_time = $form.eq(3).val().split(' 至 ')[1]
					data.search_content = $form.eq(4).val()
					if(data.start_time==''){
						layer.msg('请选择时间范围')
						return
					}
					bt.select_path('path','dir',function(res){
						path = res
						bt_tools.send({
							url: '/project/analysis_binlog/analysis_binlog_dump',
							data: {
								db_list: JSON.stringify(data.db_list),
								tb_list: JSON.stringify(data.tb_list),
								start_time: data.start_time,
								end_time: data.end_time,
								sql_type_list: JSON.stringify(data.sql_type_list),
								search_content: data.search_content,
								dump_dir: path
							},
						},function(res){
							bt_tools.open({
								title: '导出数据',
								area: ['540px', '360px'],
								btn: false,
								content: '<div id="">\
									<div class="batch_title"><span class=""><span class="batch_icon"></span><span class="batch_text">导出成功！</span></span></div>\
									<div class=" batch_tabel divtable" style="margin: 15px 30px 15px 30px;overflow: auto;height: 200px;">\
									<table class="table table-hover"><thead>\
									<tr><th>文件名称</th><th style="text-align:right;">文件大小</th><th style="text-align:right;width:150px;">操作</th></tr></thead><tbody></tbody></table></div>\
									</div>',
								success:function(){
									var html=''
									$.each(res.data,function(index,item){
										console.log(item)
										html += '\
											<tr>\
												<td title="'+ item.path + '">' + item.name + '</td><td><div style="float:right;"><span>' + bt.format_size(item.size, true, 2) + '</span></div></td>\
												<td style="text-align: right;"><span style="width: 150px;"><a onclick="bt.pub.copy_pass(\''+ item.path + '\')" class="btlink group_1_srk5n" title="复制路径">复制路径</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="/download?filename=' + item.path + '" class="btlink group_2_srk5n" title="下载">下载</a></span></td>\
											</tr>\
										'
									})
									$('.batch_tabel tbody').html(html)

								}
							})
						},'导出分析数据')
					},'www/wwwroot')
				})
			}

			if(this.num==1){
				$('.res-table').append('<span style="text-align: center;width: 100%;    display: block;color: #999999;margin-top: 10px">暂无数据</span>')
			}
			if(this.num>=10){
				$('.binlog-result-table>table thead tr th').last().css('width','calc(100% + 18px)')
			}else {
				$('.binlog-result-table>table thead tr th').last().css('width','50px')
			}
			this.num = 0
			this.ws.close()
		}else {
			$('.res-table').append(`
			<tr>
				<td style="width: 144px;">${rdata.timestamp}</td>
				<td style="width: 100px;">${rdata.sql_type}</td>
				<td style="width:460px;text-overflow:ellipsis;white-space: nowrap;overflow:hidden;" title="${rdata.sql}">${rdata.sql}</td>
				<td style="width: 50px"><span class="btlink binlog-info">详情</span></td>
				<td class="item-data" style="display: none">${JSON.stringify(rdata)}</td>
			</tr>`)
			$('.binlog-result-table .res-table').off().on('click','.binlog-info',function(){
				var that = this
				layer.open({
					type: 1,
					area: ['800px', '600px'],
					title: '详情',
					shadeClose: false,
					closeBtn: 2,
					content: `
									<div class="table-info" style="padding: 20px">
										<table class="table table-hover">
											<tbody></tbody>
										</table>
									</div>
								`,
					success:function(){
						var data = JSON.parse($(that).parents('tr').find('.item-data').text())
						var html = `
							<tr>
								<td style="width: 100px;background-color: #f7f7f7;">服务器ID</td>
								<td>${data.server_id}</td>
							</tr>
							<tr>
								<td style="width: 100px;background-color: #f7f7f7;">事件类型</td>
								<td>${data.event_type}</td>
							</tr>
							<tr>
								<td style="width: 100px;background-color: #f7f7f7;">起始位置</td>
								<td>${data.start_log_pos}</td>
							</tr>
							<tr>
								<td style="width: 100px;background-color: #f7f7f7;">结束位置</td>
								<td>${data.end_log_pos}</td>
							</tr>
							<tr>
								<td style="width: 100px;background-color: #f7f7f7;">执行时间</td>
								<td>${data.timestamp}</td>
							</tr>
							<tr>
								<td style="width: 100px;background-color: #f7f7f7;">执行SQL语句</td>
								<td style="white-space: pre-line;">${data.sql}</td>
							</tr>
						`
						$('.table-info table tbody').html(html)
					}
				})
			})
		}
	},
	//websocket关闭事件
	on_close: function (ws_event) {
	},
}
var db_public_fn = {
	// 远程服务器列表
	get_cloud_server_list: function (type) {
		var that = this;
		var tdHTML = [
			{
				fid: 'db_host',
				title: '服务器地址',
				width: 170,
				template: function (item) {
					return '<span class="flex" style="width:154px" title="' + item.db_host + '"><span class="size_ellipsis" style="width: 0; flex: 1;">' + item.db_host + '</span></span>';
				},
			},
			{ fid: 'db_port', width: 80, title: '数据库端口' },
			{ fid: 'db_type', width: 80, title: '数据库类型' },
			{
				fid: 'db_user',
				width: 100,
				title: '管理员名称',
			},
			{ fid: 'db_password', type: 'password', title: '管理员密码', copy: true, eye_open: true },
			{
				fid: 'ps',
				title: '备注',
				width: 160,
				template: function (item) {
					return '<span class="flex" style="width:144px" title="' + item.ps + '"><span class="size_ellipsis" style="width: 0; flex: 1;">' + item.ps + '</span></span>';
				},
			},
			{
				type: 'group',
				width: 100,
				title: '操作',
				align: 'right',
				group: [
					{
						title: '编辑',
						hide: function (row) {
							return row.id == 0;
						},
						event: function (row) {
							that.render_db_cloud_server_view(row, true);
						},
					},
					{
						title: '删除',
						hide: function (row) {
							return row.id == 0;
						},
						event: function (row) {
							that.del_db_cloud_server(row);
						},
					},
				],
			},
		];
		if (type) {
			var requestParam = { url: 'database/' + bt.data.db_tab_name + '/GetCloudServer', data: { data: JSON.stringify({ type: bt.data.db_tab_name }) } };
			if (bt.data.db_tab_name == 'mysql') requestParam = { url: 'database?action=GetCloudServer', data: { type: bt.data.db_tab_name } };
			dbCloudServerTable = bt_tools.table({
				el: '#advance-con',
				default: '服务器列表为空',
				default: '服务器列表为空',
				url:requestParam.url,
				param: requestParam.data,
				column: tdHTML,
				tootls: [
					{
						type: 'group',
						positon: ['left', 'top'],
						list: [
							{
								title: '添加远程服务器',
								active: true,
								event: function () {
									that.render_db_cloud_server_view();
								},
							},
						],
					},
				],
			});
			return
		}
		bt_tools.open({
			title: bt.data.db_tab_name + '远程服务器列表',
			area: '860px',
			btn: false,
			skin: 'databaseCloudServer',
			content: '<div id="db_cloud_server_table" class="pd20"></div>',
			success: function ($layer) {
				if (bt.data.db_tab_name == 'redis') tdHTML.splice(3, 1);
				dbCloudServerTable = bt_tools.table({
					el: '#db_cloud_server_table',
					default: '服务器列表为空',
					data: [],
					column: tdHTML,
					tootls: [
						{
							type: 'group',
							positon: ['left', 'top'],
							list: [
								{
									title: '添加远程服务器',
									active: true,
									event: function () {
										that.render_db_cloud_server_view();
									},
								},
							],
						},
					],
					success: function () {
						var height = $(window).height();
						var layerHeight = $layer.height();
						var top = (height - layerHeight) / 2;
						$layer.css('top', top);
					},
				});
				that.render_cloud_server_table();
			},
		});
	},
	// 重新渲染远程服务器
	render_cloud_server_table: function (callback) {
		var param = { url: 'database/' + bt.data.db_tab_name + '/GetCloudServer', data: { data: JSON.stringify({ type: bt.data.db_tab_name }) } };
		if (bt.data.db_tab_name == 'mysql') param = { url: 'database?action=GetCloudServer', data: { type: bt.data.db_tab_name } };
		bt_tools.send(param, function (rdata) {
			var arry = [];
			for (var i = 0; i < rdata.length; i++) {
				var element = rdata[i];
				if (element.id == 0) continue;
				arry.push(element);
			}
			dbCloudServerTable.$reader_content(arry);
			if (callback) callback(rdata);
		});
	},
	// 添加/编辑远程服务器视图
	render_db_cloud_server_view: function (config, is_edit) {
		var that = this,
			_type = bt.data.db_tab_name;
		if (!config) {
			config = { db_host: '', db_port: '3306', db_user: '', db_password: '', db_user: 'root', ps: '' };
			if (_type == 'sqlserver') {
				config['db_port'] = 1433;
				config['db_user'] = 'sa';
			} else if (_type == 'redis') {
				config['db_port'] = 6379;
				config['db_user'] = '';
			} else if (_type == 'mongodb') {
				config['db_port'] = 27017;
			} else if (_type == 'pgsql') {
				config['db_port'] = 5432;
				config['db_user'] = 'postgres';
			}
		}
		var tips = ['支持MySQL5.5、MariaDB10.1及以上版本', '支持阿里云、腾讯云等云厂商的云数据库', '注意1：请确保本服务器有访问数据库的权限', '注意2：请确保填写的管理员帐号具备足够的权限'];
		if (bt.data.db_tab_name === 'mysql') {
			tips.push('注意3：通过宝塔安装的数据库root默认不支持远程权限');
		}
		bt_tools.open({
			title: (is_edit ? '编辑' : '添加') + bt.data.db_tab_name + '远程服务器',
			area: '450px',
			btn: ['保存', '取消'],
			skin: 'addCloudServerProject',
			content: {
				class: 'pd20',
				form: [
					{
						label: '服务器地址',
						group: {
							type: 'text',
							name: 'db_host',
							width: '260px',
							value: config.db_host,
							placeholder: '请输入服务器地址',
							event: function () {
								$('[name=db_host]').on('input blur', function (e) {
									switch (e.type) {
										case 'input':
											$('[name=db_ps]').val($(this).val());
											break;
										case 'blur':
											if ($(this).val().indexOf(':') != -1) {
												var reg = /:(\d+)/,
													_post = $(this).val().match(reg);
												$('[name=db_port]').val(_post[1]);
												$(this).val($(this).val().replace(reg, ''));
											}
											break;
									}
								});
							},
						},
					},
					{
						label: '数据库端口',
						group: {
							type: 'number',
							name: 'db_port',
							width: '260px',
							value: config.db_port,
							placeholder: '请输入数据库端口',
						},
					},
					{
						label: '管理员名称',
						hide: bt.data.db_tab_name == 'redis' ? true : false,
						group: {
							type: 'text',
							name: 'db_user',
							width: '260px',
							value: config.db_user,
							placeholder: '请输入管理员名称',
						},
					},
					{
						label: '管理员密码',
						group: {
							type: 'text',
							name: 'db_password',
							width: '260px',
							value: config.db_password,
							placeholder: '请输入管理员密码',
						},
					},
					{
						label: '备注',
						group: {
							type: 'text',
							name: 'db_ps',
							width: '260px',
							value: config.ps,
							placeholder: '服务器备注',
						},
					},
					{
						group: {
							type: 'help',
							style: { 'margin-top': '0' },
							list: tips,
						},
					},
				],
			},
			success: function () {
				if (bt.data.db_tab_name != 'mysql') $('.addCloudServerProject .help-info-text li').eq(0).remove();
			},
			yes: function (form, indexs) {
				var interface = is_edit ? 'ModifyCloudServer' : 'AddCloudServer';
				if (form.db_host == '') return layer.msg('请输入服务器地址', { icon: 2 });
				if (form.db_port == '') return layer.msg('请输入数据库端口', { icon: 2 });
				if (!bt.check_port(form.db_port)) return layer.msg('端口格式错误，可用范围：1-65535', { icon: 2 });
				if (form.db_user == '' && bt.data.db_tab_name != 'redis') return layer.msg('请输入管理员名称', { icon: 2 });
				if (form.db_password == '') return layer.msg('请输入管理员密码', { icon: 2 });

				if (is_edit) form['id'] = config['id'];
				form['type'] = bt.data.db_tab_name;
				that.layerT = bt.load('正在' + (is_edit ? '修改' : '创建') + '远程服务器,请稍候...');

				var param = { url: 'database/' + bt.data.db_tab_name + '/' + interface, data: { data: JSON.stringify(form) } };
				if (bt.data.db_tab_name == 'mysql') param = { url: 'database?action=' + interface, data: form };
				bt_tools.send(param, function (rdata) {
					that.layerT.close();
					if (rdata.status) {
						that.reset_server_config();
						layer.close(indexs);
						layer.msg(rdata.msg, { icon: 1 });
					} else {
						layer.msg(rdata.msg, { time: 0, icon: 2, closeBtn: 2, shade: 0.3, area: '650px' });
					}
				});
			},
		});
	},
	// 删除远程服务器管理关系
	del_db_cloud_server: function (row) {
		var that = this;
		layer.confirm(
			'删除后将不再支持管理该远程数据库，是否继续操作？',
			{
				title: '删除远程数据库【' + row.db_host + '】连接配置',
				icon: 0,
				closeBtn: 2,
			},
			function () {
				var param = { url: 'database/' + bt.data.db_tab_name + '/RemoveCloudServer', data: { data: JSON.stringify({ id: row.id }) } };
				if (bt.data.db_tab_name == 'mysql') param = { url: 'database?action=RemoveCloudServer', data: { id: row.id } };
				bt_tools.send(param, function (rdata) {
					if (rdata.status) that.reset_server_config();
					layer.msg(rdata.msg, {
						icon: rdata.status ? 1 : 2,
					});
				});
			}
		);
	},
	// 重新加载服务
	reset_server_config: function () {
		this.render_cloud_server_table(function () {
			if (bt.data.db_tab_name == 'redis') redis.cloudInfo.sid = 0; //redis恢复默认是本地服务器
			db_public_fn.showDatabase();
		});
	},
	//显示mysql运行环境
	show_run_panel: function () {
		// var runPanel=$('#runPanel')
		function soft_setup_find() {
			bt.send('get_soft_find','plugin/get_soft_find',{sName: 'mysql'},
				function (rdata) {
					if (rdata.task == '-1') {
						setTimeout(function () {
							soft_setup_find();
						}, 3000);
					} else {
						var pan = '<span id="runPanel" style="cursor:pointer">\
					<img src="/static/img/soft_ico/ico-'+(rdata.name)+'.svg"><span class="Resize">'+(rdata.title + ' ' + rdata.version)+'</span>\
					'+(rdata.status ? '<span class="glyphicon glyphicon-play ac"></span>' : '<span style="color: #ef0808; margin-left: 3px;" class="glyphicon glyphicon-pause"></span>')+'</span>';
						$('.pull-left button').eq(8).css({ padding: '3px 10px', height: '30px', 'box-sizing': 'border-box' });
						if (!rdata.status) {
							$('.pull-left button').eq(8).addClass('stopStatus');
						}
						$('.pull-left button').eq(8).html(pan);
						var manu = $('<div class="flex manu" style="display:none;width:200px"><div class="arrow_b" style=""></div><div class="arrow" style=""></div></div>');
						var status_list = [
							{
								opt: rdata.status? 'stop':'start',
								title: rdata.status? '停止':'启动'
							},
							{
								opt: 'restart',
								title: '重启'
							},{
								opt: 'reload',
								title: '重载'
							}
						];
						for (var i = 0; i < status_list.length; i++)
							manu.append('<div class="ac" onclick="bt.pub.set_server_status(\'' + rdata.name + "','" + status_list[i].opt + '\')">' + status_list[i].title + '</div> |');
						manu.append('<div class="ac" id="alarm_btn">' + '告警设置' + '</div>');
						$('#runPanel').wrap('<div class="runcon"></div>');
						var time = null;
						$('#runPanel')
							.parents('.btn')
							.off('click')
							.on('click', function (e) {
								if ($(e.target).parents('.manu').length > 0 || e.target == $('.manu')[0]) {
									return;
								}
								soft.set_soft_config(rdata.name);
							});

						$('#runPanel')
							.parents('.btn')
							.on('mouseover', function () {
								manu.show();
							});
						$('#runPanel')
							.parents('.btn')
							.on('mouseleave', function () {
								time = setTimeout(function () {
									manu.hide();
								}, 200);
							});
						manu.on('mouseenter', function () {
							clearTimeout(time);
						});
						manu.on('mouseleave', function () {
							manu.hide();
						});
						$('.runcon').append(manu);
						var div = $('.Resize');
						if (window.innerWidth < 1600 && window.innerWidth > 1500) {
							$('.pull-left button').eq(8).show();
							div.html(rdata.title);
						} else if (window.innerWidth <= 1500) {
							$('.pull-left button').eq(8).hide();
						} else {
							$('.pull-left button').eq(8).show();
							div.html(rdata.title + ' ' + rdata.version);
						}
						$(window).resize(function () {
							if (window.innerWidth < 1600 && window.innerWidth > 1500) {
								$('.pull-left button').eq(8).show();
								div.html(rdata.title);
							} else if (window.innerWidth <= 1500) {
								$('.pull-left button').eq(8).hide();
							} else {
								$('.pull-left button').eq(8).show();
								div.html(rdata.title + ' ' + rdata.version);
							}
						});
					}
					if (!rdata.setup) {
						$('.pull-left button').eq(8).hide();
					}
					bt_tools.send({ url: '/push?action=get_push_list' }, function (ress) {
						// 判断是否存在服务停止告警 -循环判断是否存在值
						var key = Object.keys(ress.site_push);
						var data = {
							name: 'mysql',
						};
						var alert_message = {
							type: 'services',
							cycle: 0,
							count: 0,
							interval: 600,
							project: data.name,
							status: false,
							push_count: 0,
							module_type: 'site_push',
							tid: 'site_push@6',
							module: '',
						};
						// 告警列表中已存在当前类型告警，则此处循环展示内容
						for (var i = 0; i < key.length; i++) {
							var item = ress.site_push[key[i]];
							if (item.type == 'services' && item.project == data.name) alert_message = item;
						}
						// 打开详细设置弹窗
						$('#alarm_btn').click(function () {
							var that = this;
							bt_tools.open({
								area: ['500px'],
								skin: 'alert_layer',
								btn: ['确定', '取消'],
								title: '状态停止告警设置',
								content: {
									class: 'pd20',
									form: [
										{
											label: '停止告警',
											name: 'alert_status',
											group: {
												type: 'other',
												boxcontent:
													'<div class="mr10 alert_status_input"  style="vertical-align: middle;display: inline-block;">\
														<input class="btswitch btswitch-ios" id="status" type="checkbox">\
														<label class="btswitch-btn"></label>\
													</div>',
											},
										},
										{
											label: '间隔时间',
											group: {
												type: 'number',
												name: 'interval',
												width: '70px',
												value: alert_message ? alert_message.interval : 100,
												unit: '秒后再次监控检测条件',
											},
										},
										{
											class: 'alert_type',
											label: '告警方式',
											group: switchPushType(alert_message),
										},
										{
											group: {
												type: 'help',
												style: {
													'margin-top': 0,
													'margin-left': '20px',
												},
												list: ['开启该告警后，若该插件状态停止，将会使用您选中的告警方式发送告警信息', '点击安装后状态未更新，尝试点击【<a class="btlink handRefresh">手动刷新</a>】'],
											},
										},
									],
								},
								success: function () {
									// 点开页面默认设置状态为开启
									$('.alert_status_input').find('input').prop('checked', true);
									$('#status').prop('checked', alert_message.status);
									// 切换状态
									$('.alert_status_input').click(function () {
										var status = $(this).find('input').prop('checked');
										$(this).find('input').prop('checked', !status);
									});
									// 点击安装消息通道
									$('.alertInstall').click(function (ev) {
										var type = $(ev.currentTarget).parent('span').siblings('input').attr('name');
										openAlertModuleInstallView(type);
									});
									// 点击手动刷新
									$('.handRefresh').click(function () {
										renderConfigHTML();
									});
									// 获取配置
									function renderConfigHTML() {
										bt.site.get_msg_configs(function (rdata) {
											var html = '',
												unInstall = '';
											for (var key in rdata) {
												var item = rdata[key],
													_html = '',
													wx_html = '',
													accountConfigStatus = false;
												if (key == 'sms') continue;
												if (key === 'wx_account') {
													if (!$.isEmptyObject(item.data) && item.data.res.is_subscribe && item.data.res.is_bound) {
														accountConfigStatus = true; //安装微信公众号模块且绑定
													}
													// 微信公众号模块置顶
													wx_html =
														'<div class="inlineBlock module-check ' +
														(!item.setup || $.isEmptyObject(item.data) ? 'check_disabled' : key == 'wx_account' && !accountConfigStatus ? 'check_disabled' : '') +
														'">' +
														'<div class="cursor-pointer form-checkbox-label mr10" style="height:35px">' +
														'<i class="form-checkbox cust—checkbox cursor-pointer mr5 ' +
														(alert_message.module.indexOf(item.name) > -1 ? (!item.setup || $.isEmptyObject(item.data) ? '' : key == 'wx_account' && !accountConfigStatus ? '' : 'active') : '') +
														'" data-type="' +
														item.name +
														'"></i>' +
														'<input type="checkbox" class="form—checkbox-input hide mr10" name="' +
														item.name +
														'" ' +
														(item.setup || !$.isEmptyObject(item.data) ? (key == 'wx_account' && !accountConfigStatus ? '' : 'checked') : '') +
														'/>' +
														'<span class="vertical_middle" title="' +
														item.ps +
														'"><b class="' +
														(item.name === 'wx_account' ? '' : 'hide') +
														'" style="color: #fc6d26;">[推荐]</b>' +
														item.title +
														(!item.setup || $.isEmptyObject(item.data)
															? '[<a target="_blank" class="bterror installNotice" data-type="' + item.name + '">点击安装</a>]'
															: key == 'wx_account' && !accountConfigStatus
																? '[<a target="_blank" class="bterror alertInstall" data-type="' + item.name + '">未配置</a>]'
																: '') +
														'</span>' +
														'</div>' +
														'</div>';
													continue;
												}
												_html =
													'<div class="inlineBlock module-check ' +
													(!item.setup || $.isEmptyObject(item.data) ? 'check_disabled' : key == 'wx_account' && !accountConfigStatus ? 'check_disabled' : '') +
													'">' +
													'<div class="cursor-pointer form-checkbox-label mr10" style="height:35px">' +
													'<i class="form-checkbox cust—checkbox cursor-pointer mr5 ' +
													(alert_message.module.indexOf(item.name) > -1 ? (!item.setup || $.isEmptyObject(item.data) ? '' : key == 'wx_account' && !accountConfigStatus ? '' : 'active') : '') +
													'" data-type="' +
													item.name +
													'"></i>' +
													'<input type="checkbox" class="form—checkbox-input hide mr10" name="' +
													item.name +
													'" ' +
													(item.setup || !$.isEmptyObject(item.data) ? (key == 'wx_account' && !accountConfigStatus ? '' : 'checked') : '') +
													'/>' +
													'<span class="vertical_middle" title="' +
													item.ps +
													'"><b class="' +
													(item.name === 'wx_account' ? '' : 'hide') +
													'" style="color: #fc6d26;">[推荐]</b>' +
													item.title +
													(!item.setup || $.isEmptyObject(item.data)
														? '[<a target="_blank" class="bterror alertInstall" data-type="' + item.name + '">点击安装</a>]'
														: key == 'wx_account' && !accountConfigStatus
															? '[<a target="_blank" class="bterror installNotice" data-type="' + item.name + '">未配置</a>]'
															: '') +
													'</span>' +
													'</div>' +
													'</div>';
												if (!item.setup) {
													unInstall += _html;
												} else {
													html += _html;
												}
											}
											$('.alert_type .info-r').html(wx_html + html + unInstall);
											$('.alertInstall').click(function (ev) {
												var type = $(ev.currentTarget).parent('span').siblings('input').attr('name');
												openAlertModuleInstallView(type);
											});
											$('.form-checkbox-label').on('click', function () {
												var that = $(this).find('i');
												if (!that.parent().parent().hasClass('check_disabled')) {
													if (that.hasClass('active')) {
														that.removeClass('active');
														that.next().prop('checked', false);
													} else {
														that.addClass('active');
														that.next().prop('checked', true);
													}
												}
											});
										});
									}
								},
								yes: function (form, index) {
									var dom = $('.alert_status_input').find('input'); // 获取告警状态
									var params = {
										type: 'services',
										project: data.name,
										status: dom.prop('checked') ? true : false,
										tid: 'site_push@6',
										cycle: 0,
										count: 0,
										interval: Number(form.interval),
										title: '服务停止告警',
										push_count: '0',
									}; // 请求参数
									var temp_arr = []; // 临时存储选中的告警方式
									// 获取选中的告警方式，排除未安装的
									$('.alert_type .info-r')
										.children()
										.each(function (index, item) {
											if (!$(item).hasClass('check_disabled')) {
												var name = $(item).find('input').attr('name');
												if ($(item).find('input').prop('checked')) {
													temp_arr.push(name);
												}
											}
										});
									params.module = temp_arr.join(',');
									// 发送修改状态请求
									soft.set_push_config(params, function (res) {
										if (res.status) {
											$('.outer_state_alert').find('input').prop('checked', dom.prop('checked'));
											alert_message = params;
											if (res.status) layer.close(index);
										}
									});
								},
							});
						});
						// 点击外层告警开关
						$('.outer_state_alert').click(function () {
							var status = $(this).find('input').prop('checked');
							$.ajaxSettings.async = false; // 暂时设置为同步请求
							if (!soft.alert_modules.length) {
								// 获取告警通道
								bt_tools.send({ url: 'config?action=get_msg_configs' }, function (rdata) {
									$.each(Object.keys(rdata), function (index, item) {
										if (item !== 'sms') {
											soft.alert_modules.push(rdata[item]);
										}
									});
								});
							}
							if (!status) {
								// 判断是否有安装的模块
								var is_installFlag = false;
								$.each(soft.alert_modules, function (index) {
									if (Object.keys(soft.alert_modules[index].data).length) {
										is_installFlag = true;
									}
								});
								// 模块为空且无安装的模块
								if (alert_message.module === '' || !is_installFlag) {
									$('.setting_alert').click();
								} else {
									$(this).find('input').prop('checked', !status);
									alert_message.module = '';
									$.each(soft.alert_modules, function (index) {
										// 安装了该模块且有配置信息
										if (Object.keys(soft.alert_modules[index].data).length && soft.alert_modules[index].name !== 'sms') {
											alert_message.module = soft.alert_modules[index].name + ',' + alert_message.module;
										}
									});
									$.ajaxSettings.async = true;
									//去除最后的逗号
									alert_message.module = alert_message.module.substring(0, alert_message.module.length - 1);
									$.ajaxSettings.async = true;
									alert_message.status = !status;
									soft.set_push_config(alert_message, function (res) {
										if (res.status) {
											$(this).find('input').prop('checked', !status);
										}
										if (!res.status) {
											$('.outer_state_alert').find('input').prop('checked', status); // 同步外层开关状态
										}
									});
								}
							} else {
								// 直接关闭告警
								$(this).find('input').prop('checked', !status);
								$.ajaxSettings.async = true;
								alert_message.status = !status;
								soft.set_push_config(alert_message, function (res) {
									if (!res.status) $('.outer_state_alert').find('input').prop('checked', status);
								});
							}
						});
					});
					function switchPushType(formData) {
						$.ajaxSettings.async = false;
						var alertListModule = [],
							isCheckType = [],
							accountConfigStatus = false,
							_checklist = [];
						// 获取告警通道
						bt_tools.send({ url: 'config?action=get_msg_configs' }, function (rdata) {
							var resetChannelMessage = [],
								prevArray = [];
							Object.getOwnPropertyNames(rdata).forEach(function (key) {
								var mod = rdata[key];
								key == 'wx_account' ? prevArray.push(mod) : resetChannelMessage.push(mod);
							});
							alertListModule = prevArray.concat(resetChannelMessage);
							soft.alert_modules = alertListModule;
							alertListModule.forEach(function (mod, i) {
								if (formData) {
									isCheckType = formData.module.split(',');
								}
								if (mod.name === 'wx_account') {
									if (!$.isEmptyObject(mod.data) && mod.data.res.is_subscribe && mod.data.res.is_bound) {
										accountConfigStatus = true; //安装微信公众号模块且绑定
									}
								}
								if (mod.name !== 'sms') {
									_checklist.push({
										type: 'checkbox',
										name: mod.name,
										class: 'module-check ' + (!mod.setup || $.isEmptyObject(mod.data) ? 'check_disabled' : mod.name == 'wx_account' && !accountConfigStatus ? 'check_disabled' : '') + '',
										style: { 'margin-right': '10px' },
										disabled: !mod.setup || $.isEmptyObject(mod.data) ? true : mod.name == 'wx_account' && !accountConfigStatus ? true : false,
										value: $.inArray(mod.name, isCheckType) >= 0 ? 1 : 0,
										title:
											(mod.name == 'wx_account' ? '<b style="color: #fc6d26;">[推荐]</b>' : '') +
											mod.title +
											(!mod.setup || $.isEmptyObject(mod.data)
												? '<span style="color:red;cursor: pointer;" class="alertInstall">[点击安装]</span>'
												: mod.name == 'wx_account' && !accountConfigStatus
													? '[<a target="_blank" class="bterror alertInstall">未配置</a>]'
													: ''),
										event: function (formData, element, thatE) {
											// thatE.config.form[4].group[i].value = !formData[mod.name] ?0:1;
										},
									});
								}
							});
						});
						$.ajaxSettings.async = true;
						return _checklist;
					}
				}
			);
		}
		soft_setup_find();
	},
	// 显示当前数据库
	showDatabase: function (showTips) {
		var type = $('.database-pos .tabs-item.active').data('type');
		bt.set_cookie('db_page_model', type);
		bt.data.db_tab_name = type;
		if (type == 'redis') {
			$('.info-title-tips').hide();
		} else {
			$('.info-title-tips').show();
		}
		var loadT = layer.msg('正在获取远程服务器列表,请稍候...', {
			icon: 16,
			time: 0,
			shade: [0.3, '#000'],
		});

		var requestParam = { url: 'database/' + bt.data.db_tab_name + '/GetCloudServer', data: { data: JSON.stringify({ type: bt.data.db_tab_name }) } };
		if (bt.data.db_tab_name == 'mysql') requestParam = { url: 'database?action=GetCloudServer', data: { type: bt.data.db_tab_name } };
		bt_tools.send(requestParam, function (cloudData) {
			layer.close(loadT);
			cloudDatabaseList = cloudData;
			//是否安装本地或远程服务器
			if (cloudData.length <= 0) {
				var tips = '当前未安装本地服务器/远程服务器,<a class="btlink install_server">点击安装</a> | <a class="btlink" onclick="db_public_fn.get_cloud_server_list()">添加远程服务器</a>';
				if (bt.data.db_tab_name == 'sqlserver') tips = '当前未配置远程服务器,<a class="btlink" onclick="db_public_fn.get_cloud_server_list()">添加远程服务器</a>';
				$('.mask_layer').removeAttr('style');
				$('.prompt_description').html(tips);

				// 安装pgsql
				$('.install_server').click(function () {
					var db_type = bt.data.db_tab_name;
					if (db_type == 'pgsql') {
						bt.soft.get_soft_find('pgsql_manager', function (rdata) {
							//判断是否安装插件
							for (var i = 0; i < rdata.versions.length; i++) {
								if (rdata.versions[i].setup == true) {
									//判断是否安装版本
									bt.soft.set_lib_config('pgsql_manager', 'PostgreSQL管理器');
									break;
								} else {
									bt.soft.install('pgsql_manager');
									break;
								}
							}
						});
					} else {
						bt.soft.install(db_type);
					}
				});
			} else {
				$('.mask_layer').hide();
				if (showTips && type == 'mysql' && !isSetup) {
					layer.msg('未安装本地数据库，已隐藏无法使用的功能!', { time: 2000 });
				}
			}
			// $('#runPanel').hide();
			switch (type) {
				case 'mysql':
					database.database_table_view();
					if (cloudData.length > 0 && !isSetup) {
						// db_public_fn.show_run_panel()
						$('#bt_database_table .tootls_group.tootls_top .pull-left button').eq(1).hide();
						$('#bt_database_table .tootls_group.tootls_top .pull-left button').eq(2).hide();
						$('#bt_database_table .tootls_group.tootls_top .pull-left button').eq(4).hide();
						$('#bt_database_table .tootls_group.tootls_top .pull-left button').eq(7).hide();
						$('#bt_database_table .tootls_group.tootls_top .pull-left button').eq(8).hide();
					}
					break;
				case 'sqlserver':
					sql_server.database_table_view();
					break;
				case 'mongodb':
					bt_tools.send(
						{ url: 'database/' + bt.data.db_tab_name + '/get_root_pwd' },
						function (_status) {
							mongoDBAccessStatus = _status.authorization == 'enabled' ? true : false;
							mongodb.database_table_view();
						},
						'获取访问状态'
					);
					break;
				case 'redis':
					redis.database_table_view();
					break;
				case 'pgsql':
					pgsql.database_table_view();
					break;
			}
		});
	},
	//计算工具的数据格式和单位
	compute_data_unit: function (data) {
		if (typeof data !== 'number' || isNaN(data)) {
			return 'Invalid input';
		}
		var size = data;
		var ext_list = ['b', 'KB', 'MB', 'GB', 'TB'];

		for (var ext of ext_list) {
			if (size < 1024) return size + ext;
			size = size / 1024;
			if (!bt.isInteger(size)) size = size.toFixed(2);
		}
		return size + ext_list[ext_list.length - 1];
	},
	/**
	 * 组装同步所有、从服务器获取
	 * @param {string} syncEl 当前表名
	 * @param {string} position 插入的位置
	 */
	get_sync_all_server: function (syncEl,position) {
		var show =true,
			syncHoverTime,
			type = $('.database-pos .tabs-item.active').data('type'),
			html = '\
				<div class="btn-group db_sync_setting '+(type != 'mysql' ?'btn-divider-line':'')+'" style="margin-right: 30px">\
				<button type="button" class="btn btn-default base-btn sync_the_data_click" style="height: 100%;font-size: 12px" >同步设置</button>\
				<button type="button" class="btn btn-default dropdown-toggle sync_the_data_hover" style="display: flex;align-items: center;justify-content: center;height: 100%;">\
					<svg width="12.000000" height="12.000000" viewBox="0 0 12 5" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
						<desc>\
							Created with Pixso.\
						</desc>\
						<defs></defs>\
						<path id="path" d="M0.123291 0.809418L4.71558 5.84385C4.8786 6.02302 5.16846 6.04432 5.33038 5.86389L9.87927 0.783104C10.0412 0.602676 10.04 0.311989 9.87701 0.132816C9.79626 0.0446892 9.68945 0 9.58374 0C9.47693 0 9.36938 0.0459404 9.28827 0.136574L5.02881 4.89284L0.708618 0.15662C0.627869 0.0684967 0.522217 0.0238075 0.415405 0.0238075C0.307434 0.0238075 0.20105 0.0697479 0.119873 0.160381C-0.041626 0.338303 -0.0393677 0.630241 0.123291 0.809418Z" fill-rule="nonzero" fill="' + (show ? '#20A53A' : '#999999') + '"></path>\
					</svg>\
				</button>\
				<ul class="dropdown-menu bt_select_list sync_the_data " >\
					<li style="display: flex;flex-direction: column;padding: 4px 12px;align-items: flex-start;">\
						<a style="font-size: 12px;padding: 0;margin-bottom: -8px">同步所有</a>\
						<span style="color: #999999;font-size: 11px;height: 28px;">同步当前数据库信息</span>\
					</li>\
					<li style="display: flex;flex-direction: column;padding: 4px 12px;align-items: flex-start;">\
						<a style="font-size: 12px;padding: 0;margin-bottom: -8px">从服务器获取</a>\
						<span style="color: #999999;font-size: 11px;height: 28px;">从服务器获取数据库列表信息</span>\
					</li>\
				</ul>\
				</div>'
		// 插入html
		$(syncEl).find('.tootls_top .pull-left').find(position).after(html);
		$(syncEl+' .pull-left').css({'display': 'flex'})

		// 绑定事件
		$(syncEl+' .sync_the_data_hover').find('svg').find('path').attr('fill', '#999999')
		$(syncEl+' .sync_the_data_hover').hover(function () {
			$(this).find('svg').find('path').attr('fill', '#20A53A')
		},function () {
			$(this).find('svg').find('path').attr('fill', '#999999')
		})
		$(syncEl+' .sync_the_data_hover').hover(function () {
			$('.sync_the_data').addClass('show')
		}, function () {
			syncHoverTime = setTimeout(function () {
				$('.sync_the_data').removeClass('show')
			}, 100)
		})

		$(syncEl+' .sync_the_data').mouseenter(function () {
			clearTimeout(syncHoverTime)
		}).mouseleave(function () {
			$('.sync_the_data').removeClass('show')
		})
		$(syncEl+' .sync_the_data li').off().click(function () {
			if ($(this).index() == 0) {
				database.sync_to_database(
					{
						type: 0,
						data: [],
					},
					function (res) {
						if (res.status) database_table.$refresh_table_list(true);
					}
				);
			}else {
				if (cloudDatabaseList.length == 0) return layer.msg('至少添加一个远程服务器或安装本地数据库', { time: 0, icon: 2, closeBtn: 2, shade: 0.3 });
				var _list = [];
				$.each(cloudDatabaseList, function (index, item) {
					var _tips = item.ps != '' ? item.ps + ' (服务器地址:' + item.db_host + ')' : item.db_host;
					_list.push({ title: _tips, value: item.id });
				});
				bt_tools.open({
					title: '选择数据库位置',
					area: '450px',
					btn: ['确认', '取消'],
					skin: 'databaseCloudServer',
					content: {
						class: 'pd20',
						form: [
							{
								label: '数据库位置',
								group: {
									type: 'select',
									name: 'sid',
									width: '288px',
									list: _list,
								},
							},
						],
					},
					success: function (layers) {
						$(layers).find('.layui-layer-content').css('overflow', 'inherit');
					},
					yes: function (form, layers, index) {
						bt.database.sync_database(form.sid, function (rdata) {
							if (rdata.status) {
								database_table.$refresh_table_list(true);
								layer.close(layers);
							}
						});
					},
				});
			}
		})
	},
	//敏感词
	sensitive_words:{
		formFactory: function(type,data,style){
			/**
			 * @description: 选择框
			 * @param data {} 数据
			 * @param style
			 */
			function selectForm (data,style){

				var databaseHtml = ''
				var fastItem = ''
				var list = []
				if(data.list == undefined || data.list.length == 0){
					fastItem	= '无数据'
					databaseHtml = `<li class="item" title="无匹配项" data-id="0" data-value="无数据">无数据</li>`
				}else {
					$.each(data.list,function(index,item){
						if(index==0) fastItem = item.value
						list.push({name:item.name,value:item.value})
						databaseHtml += `<li class="item" style="overflow: hidden;white-space: nowrap;text-overflow: ellipsis;" title="${item.name}" data-id="${index}" data-value="${item.value}">${item.name}</li>`
					})
				}

				var html = `
				<div style="display:flex;flex-direction: row;align-items: center;">
					<span class="binglog-form-title" style="width: 60px;text-align: right;">${data.name}：</span>
					<div class="bt_select_updown mr10  0" style="width: 140px;border:0" data-name="sType">
						<input type="text" style="border: 1px solid #DCDFE6;" class="bt_select_value " data-value="${fastItem}" value=""/>
						<div class="icon-down" style="display: block;position: absolute;top: 0px;right: 5px;">
							<svg width="12.000000" height="12.000000" viewBox="0 0 12 5" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><desc>	Created with Pixso.</desc><defs></defs><path id="path" d="M0.123291 0.809418L4.71558 5.84385C4.8786 6.02302 5.16846 6.04432 5.33038 5.86389L9.87927 0.783104C10.0412 0.602676 10.04 0.311989 9.87701 0.132816C9.79626 0.0446892 9.68945 0 9.58374 0C9.47693 0 9.36938 0.0459404 9.28827 0.136574L5.02881 4.89284L0.708618 0.15662C0.627869 0.0684967 0.522217 0.0238075 0.415405 0.0238075C0.307434 0.0238075 0.20105 0.0697479 0.119873 0.160381C-0.041626 0.338303 -0.0393677 0.630241 0.123291 0.809418Z" fill-rule="nonzero" fill="#999999"></path></svg>
						</div>
						<div class="icon_up" style="display: none;position: absolute;top: 0px;right: 5px;">
							<svg width="12.000000" height="12.000000" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><desc>Created with Pixso.</desc><defs></defs><path id="path" d="M1.12328 8.19058L5.71558 3.15616C5.87862 2.97699 6.16847 2.95569 6.33038 3.13611L10.8793 8.21689C11.0412 8.39731 11.04 8.68802 10.877 8.86719C10.7962 8.95532 10.6894 9 10.5838 9C10.477 9 10.3694 8.95407 10.2883 8.86343L6.02883 4.10715L1.70864 8.84338C1.62788 8.93152 1.5222 8.9762 1.41539 8.9762C1.30746 8.9762 1.20103 8.93024 1.11988 8.83963C0.958351 8.66171 0.960617 8.36975 1.12328 8.19058Z" fill-rule="nonzero" fill="#999999"></path></svg>
						</div>
						<ul id="${data.id}" class="bt_select_list" style="display: none;width: 250px;">${databaseHtml}</ul>
						<div class="bt_select_list_arrow" ></div>
						<div class="bt_select_list_arrow_fff" ></div>
					</div>
				</div>`
				$('#'+data.el).html(html)
				if(data.callback) data.callback($('#'+data.el+' .bt_select_list li').data('id'))
				$('#'+data.el+' .bt_select_updown .bt_select_value').on('focus',function(){
					var height = $(this).parent().height()
					$(this).nextAll('ul').css('top',(height+8)+'px')
					$('.bt_select_list_arrow_fff').not('#'+data.id).hide()
					$('.bt_select_list_arrow').not('#'+data.id).hide()
					$('.bt_select_updown .bt_select_value').nextAll('ul').not('#'+data.id).removeClass('show')
					$(this).nextAll('ul').toggleClass('show')
					$(this).nextAll('.icon-down').toggle()
					$(this).nextAll('.icon_up').toggle()
					if($(this).nextAll('ul').hasClass('show')){
						$('#'+data.el+' .bt_select_list_arrow_fff').css('top',(height-6)+'px').show()
						$('#'+data.el+' .bt_select_list_arrow').css('top',(height-7)+'px').show()
					}else {
						$('#'+data.el+' .bt_select_list_arrow_fff').hide()
						$('#'+data.el+' .bt_select_list_arrow').hide()
					}
				})
				$('#'+data.el+' .icon-down').click(function(){
					$('#'+data.el+' .bt_select_updown .bt_select_value').focus()
				})
				$('#'+data.el+' .icon_up').click(function(){
					$('#'+data.el+' .bt_select_updown .bt_select_value').focus()
				})
				$(document).click(function(e){
					if($(e.target).parents('.bt_select_updown').length==0){
						$('#'+data.el+' .bt_select_list').removeClass('show')
						$('#'+data.el+' .icon-down').show()
						$('#'+data.el+' .icon_up').hide()
						$('#'+data.el+' .bt_select_list_arrow_fff').hide()
						$('#'+data.el+' .bt_select_list_arrow').hide()
					}
				})
				/**
				 * @description: 选择列表
				 */
				function selectList() {
					var keyword = $('#binlog-table .bt_select_value').val()
					var keyword2 = $('#binlog-database .bt_select_value').val()
					$('#'+data.el+' .bt_select_list li').click(function () {
						var value = $(this).data('value')
						var name  = $(this).text()
						$(this).addClass('active').siblings().removeClass('active')
						$(this).parents('.bt_select_updown').find('.bt_select_value').val(name).attr('data-value',value).attr('title', value).attr('data-id', $(this).data('id'))
						$(this).parents('.bt_select_updown').find('.bt_select_list').removeClass('show')
						$(this).parents('.bt_select_updown').find('.icon-down').show()
						$(this).parents('.bt_select_updown').find('.icon_up').hide()
						$('.bt_select_list_arrow_fff').hide()
						$('.bt_select_list_arrow').hide()
						if(data.callback) data.callback($(this).data('id'))
					})
					$('#binlog-table .bt_select_value').attr('data-value',keyword).attr('title', keyword).attr('data-id', $(this).data('id'))
					$('#binlog-database .bt_select_value').attr('data-value',keyword2).attr('title', keyword2).attr('data-id', $(this).data('id'))
				}
				selectList()
				$('#'+data.el+' .bt_select_list li').eq(0).click()
				$('#'+data.el+' .bt_select_updown .bt_select_value').on('input',function(){
					var keyword = $(this).val()
					if(keyword==''){
						$(this).nextAll('ul').empty();
						$(this).nextAll('ul').append(databaseHtml);
					}
					// 清空下拉列表
					$(this).nextAll('ul').empty();
					var res = list.filter(option => option.name.toLowerCase().includes(keyword.toLowerCase()));
					if(res.length==0){
						res.push({name:'无匹配项',value:''})
					}
					res.forEach(result=>{
						$(this).nextAll('ul').append(`<li class="item" style="overflow: hidden;white-space: nowrap;text-overflow: ellipsis;" title="${result.value}" data-value="${result.value}">${result.name}</li>`);
					})
					selectList()
				})
			}

			/**
			 * @description: 多选框
			 * @param data
			 * @param style
			 */
			function multiSelectForm(data,style){
				var databaseHtml = ''
				var list = []
				var fastItem = '请选择数据库操作的类型，支持多选'
				if(data.list.length==0){
					databaseHtml = `<li class="item" title="无匹配项" data-id="0" data-value="0">无匹配项</li>`
				}else {
					$.each(data.list,function(index,item){
						if(index==0) fastItem = item.value
						list.push({name:item.name,value:item.value})
						databaseHtml += `
							<li class="item"  title="${item.desc}[${item.name}]" data-id="${index}" data-value="${item.value}">
								<span>${item.desc}[${item.name}]</span>
								<span class="icon-item-active"></span>
							</li>`
					})
				}

				var selectHtml = `
					<div style="display:flex;flex-direction: row;align-items: center;">
						<span class="binglog-form-title" style="width: 90px;text-align: right;">${data.name}：</span>
						<div class="inlineBlock  ">
							<div class="bt_multiple_select_updown bt_select_updown mr10  0" style="width: 460px;">
								<span class="bt_select_value" title="${fastItem}">
									<div class="icon-down" style="display: block;">
										<svg width="12.000000" height="12.000000" viewBox="0 0 12 5" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><desc>Created with Pixso.</desc><defs></defs><path id="path" d="M0.123291 0.809418L4.71558 5.84385C4.8786 6.02302 5.16846 6.04432 5.33038 5.86389L9.87927 0.783104C10.0412 0.602676 10.04 0.311989 9.87701 0.132816C9.79626 0.0446892 9.68945 0 9.58374 0C9.47693 0 9.36938 0.0459404 9.28827 0.136574L5.02881 4.89284L0.708618 0.15662C0.627869 0.0684967 0.522217 0.0238075 0.415405 0.0238075C0.307434 0.0238075 0.20105 0.0697479 0.119873 0.160381C-0.041626 0.338303 -0.0393677 0.630241 0.123291 0.809418Z" fill-rule="nonzero" fill="#999999"></path></svg>
									</div>
									<div class="icon_up" style="display:none;">
										<svg width="12.000000" height="12.000000" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><desc>Created with Pixso.</desc><defs></defs><path id="path" d="M1.12328 8.19058L5.71558 3.15616C5.87862 2.97699 6.16847 2.95569 6.33038 3.13611L10.8793 8.21689C11.0412 8.39731 11.04 8.68802 10.877 8.86719C10.7962 8.95532 10.6894 9 10.5838 9C10.477 9 10.3694 8.95407 10.2883 8.86343L6.02883 4.10715L1.70864 8.84338C1.62788 8.93152 1.5222 8.9762 1.41539 8.9762C1.30746 8.9762 1.20103 8.93024 1.11988 8.83963C0.958351 8.66171 0.960617 8.36975 1.12328 8.19058Z" fill-rule="nonzero" fill="#999999"></path></svg>
									</div>
									<span class="multiple_tip" style="color: #CBCBCB">请选择数据库操作的类型，支持多选</span>
									<div class="multiple_content"></div>
	<!--								<span class="moreTips " style="display: block">更多</span>-->
								</span>
								<ul id="${data.id}" class="bt_select_list" style="display: none;">${databaseHtml}</ul>
								<div class="bt_select_list_arrow" ></div>
								<div class="bt_select_list_arrow_fff" ></div>
							</div>
						</div>
					</div>
				`
				$('#'+data.el).html(selectHtml)
				$('.multiple_tip').show()
				$('.bt_select_list_arrow_fff').hide()
				$('.bt_select_list_arrow').hide()
				var $selectValue = $('#'+data.el+' .bt_multiple_select_updown .bt_select_value')
				function checkList() {
					if($('.bt_select_content').length==0){
						$('.multiple_tip').show()
					}else {
						$('.multiple_tip').hide()
					}
				}
				$selectValue.on('click',function(e){
					var height = $(this).parent().height()
					$(this).nextAll('ul').css('top',(height+8)+'px')
					$('.bt_select_list_arrow_fff').not('#'+data.id).hide()
					$('.bt_select_list_arrow').not('#'+data.id).hide()
					$('.bt_select_updown .bt_select_value').nextAll('ul').not('#'+data.id).removeClass('show')
					$(this).nextAll('ul').toggleClass('show')
					if($(this).nextAll('ul').hasClass('show')){
						$(this).find('.icon-down').hide()
						$(this).find('.icon_up').show()
						$('#'+data.el+' .bt_select_list_arrow_fff').css('top',(height-6)+'px').show()
						$('#'+data.el+' .bt_select_list_arrow').css('top',(height-7)+'px').show()
					}else {
						$(this).find('.icon-down').show()
						$(this).find('.icon_up').hide()
						$('#'+data.el+' .bt_select_list_arrow_fff').hide()
						$('#'+data.el+' .bt_select_list_arrow').hide()
					}
				})
				$(document).click(function(e){
					if($(e.target).parents('.bt_select_updown').length==0){
						$('#'+data.el+' .bt_select_list').removeClass('show')
						$('#'+data.el+' .icon-down').show()
						$('#'+data.el+' .icon_up').hide()
						$('#'+data.el+' .bt_select_list_arrow_fff').hide()
						$('#'+data.el+' .bt_select_list_arrow').hide()
					}
				})
				var $li = $('#'+data.el+' .bt_select_list li')
				$li.click(function () {
					var that = this
					if(!$(this).hasClass('active')){
						if($li.eq(0).hasClass('active')){
							$li.eq(0).removeClass('active')
							$('.bt_select_content').remove()
						}
						if($(this).data('id')==0){
							$li.not(':eq(0)').removeClass('active')
							$('.bt_select_content').remove()
						}
						var html=`<span class="bt_select_content"><span>${$(this).find('span').eq(0).text()}</span><span class="icon-trem-close"></span></span>`
						$(this).parent().prev().find('.multiple_content').append(html)
						var height = $('#'+data.el+' .bt_multiple_select_updown .bt_select_value').parent().height()
						$('#'+data.el+' .bt_select_list_arrow_fff').css('top',(height-6)+'px').toggle()
						$('#'+data.el+' .bt_select_list_arrow').css('top',(height-7)+'px').toggle()
						$('#'+data.el+' .bt_select_list ').css('top',(height+8)+'px')
						if($selectValue.nextAll('ul').hasClass('show')){
							$('#'+data.el+' .bt_select_list_arrow_fff').css('top',(height-6)+'px').show()
							$('#'+data.el+' .bt_select_list_arrow').css('top',(height-7)+'px').show()
						}else {
							$('#'+data.el+' .bt_select_list_arrow_fff').hide()
							$('#'+data.el+' .bt_select_list_arrow').hide()
						}
						$(this).addClass('active')

					}else {
						$(this).removeClass('active')
						$('.bt_select_content').each(function(index,item){
							if($(item).find('span').eq(0).text()==$(that).find('span').eq(0).text()){
								$(item).remove()
								var height = $('#'+data.el+' .bt_multiple_select_updown .bt_select_value').parent().height()
								$('#'+data.el+' .bt_select_list_arrow_fff').css('top',(height-6)+'px').toggle()
								$('#'+data.el+' .bt_select_list_arrow').css('top',(height-7)+'px').toggle()
								$('#'+data.el+' .bt_select_list ').css('top',(height+8)+'px')
								if($selectValue.nextAll('ul').hasClass('show')){
									$('#'+data.el+' .bt_select_list_arrow_fff').css('top',(height-6)+'px').show()
									$('#'+data.el+' .bt_select_list_arrow').css('top',(height-7)+'px').show()
								}else {
									$('#'+data.el+' .bt_select_list_arrow_fff').hide()
									$('#'+data.el+' .bt_select_list_arrow').hide()
								}
								return
							}
						})
					}
					var text = ''
					$.each($('#'+data.el+' .bt_select_list li.active'),function(index,item){
						text += $(item).data('value')+','
					})
					text = text.substring(0,text.length-1)
					if(text==''){
						$li.eq(0).click()
					}
					$(this).parents('.bt_select_updown').find('.bt_select_value').val(text).attr('title', text).attr('data-id', $(this).data('id'))
					$(this).parents('.bt_select_updown').find('.icon-down').show()
					$(this).parents('.bt_select_updown').find('.icon_up').hide()
					if(data.callback) data.callback($(this).data('id'))
					checkList()
				})
				$('#'+data.el+' .bt_select_list li').eq(0).click()
				$('.bt_select_value').on('click','.icon-trem-close',function (e) {
					var _that = this
					e.stopPropagation()
					$(this).parent().remove()
					$('#'+data.el+' .bt_select_list li').each(function(index,item){
						if($(_that).parent().find('span').eq(0).text()==$(this).find('span').eq(0).text()){
							$(item).removeClass('active')
							var height = $selectValue.parent().height()
							if($selectValue.nextAll('ul').hasClass('show')){
								$('#'+data.el+' .bt_select_list_arrow_fff').css('top',(height-6)+'px').show()
								$('#'+data.el+' .bt_select_list_arrow').css('top',(height-7)+'px').show()
							}else {
								$('#'+data.el+' .bt_select_list_arrow_fff').hide()
								$('#'+data.el+' .bt_select_list_arrow').hide()
							}
							$('#'+data.el+' .bt_select_list ').css('top',(height+8)+'px')
							checkList()
							return false
						}
					})
					var text = ''
					$.each($('#'+data.el+' .bt_select_list li.active'),function(index,item){
						text += $(item).data('value')+','
					})
					text = text.substring(0,text.length-1)
					if(text==''){
						$li.eq(0).click()
					}

					$('#'+data.el+' .bt_select_value').val(text).attr('title', text).attr('data-id', $(this).data('id'))
				})
			}
			function timeForm(data,style){
				var html = `
					<div style="display:flex;flex-direction: row;align-items: center;">
						<span class="binglog-form-title" style="width: 90px;text-align: right;">${data.name}：</span>
						<div class="date"></div>
						<div id="test" >
							<div style="border: 1px solid #DCDFE6; height: 30px;display: flex;flex-direction: row;align-items: center;padding: 0 10px">
								<i style="background-image: url(/static/vite/svg/crontab.svg);background-size: 100% auto 100% auto;background-position: center;background-repeat: no-repeat;height: 16px;margin-right: 16px;width: 16px;color: #999;display: block;" class="icon"></i>
								<input id="startDate" class="bt_select_value" style="border: 0px;width: 282px;" type="text" value="" placeholder="请选择起始时间" />
							</div>

						</div>
					</div>
				`
				$('#'+data.el).html(html)
				laydate.set({
					rangeLinked: true, // 范围选择的日历面板是否联动
				})
				var time = `${new Date().getFullYear()}-${new Date().getMonth()+1}-${new Date().getDate()} ${new Date().getHours()}:${new Date().getMinutes()}:${new Date().getSeconds()}`
				laydate.render({
					elem: '#startDate',
					range: '至',
					type: 'datetime',
					min: data.firstTime,
					max: time,
				})
				$('#startDate').val(data.time +' 至 ' +time)
			}
			function searchForm(data,style){
				var html = `
					<div style="display:flex;flex-direction: row;align-items: center;">
						<span class="binglog-form-title" style="width: 90px;text-align: right;">${data.name}：</span>
						<input type="text" class="bt_select_value" style="border: 1px solid #DCDFE6;width: 300px;height: 30px" placeholder="请输入查询的语句或内容，该字段可以为空"/>
					</div>
					`
				$('#'+data.el).html(html)
			}
			switch(type){
				case 'select':
					selectForm(data)
					break
				case 'multiSelect':
					multiSelectForm(data)
					break
				case 'time':
					timeForm(data)
					break
				case 'search':
					searchForm(data)
			}
		},
		// binlog分析
		html: `
				<div>
					<div class="binlog-form">
						<div class="binlog-select-group binlog-defult" style="display: flex">
							<div id="binlog-server"></div>
							<div id="binlog-database"></div>
							<div id="binlog-table"></div>
						</div>
						<div id="binlog-search" class="binlog-defult"></div>
						<div id="binlog-btn" class="binlog-button-defult" style="flex-direction: row;"><button class="btn btn-success " style="margin-right: 10px;">搜索</button><button class="btn btn-default" style="margin-right: 10px;">索引记录</button></div>
					</div>
					<div class="binlog-result plr10"></div>
				</div>
			`,
		ws: null,
		info:'<div class="thumbnail-introduce-new" style="margin:0;padding:0px 0">\
				  <div class="thumbnail-introduce-title-new" style="width:100%;justify-content:normal;flex-direction:column;padding-left: 24px;">\
					  <div class="thumbnail-title-left-new" style="width:100%;">\
						  <div class="thumbnail-title-text-new">\
							  <p>MySQL全文搜索-功能介绍</p>\
							  <p>基于Sphinx的全文检索，高速索引，高速搜索，高可用性，中文搜索</p>\
						  </div>\
					  </div>\
					   <div class="thumbnail-title-button-new daily-product-buy"  style="margin:16px 0 0 0">\
						  <button class="btn btn-success btn-sm" style="width:80px" onclick="product_recommend.pay_product_sign(\'ltd\',304,\'ltd\')">立即购买</button>\
					  </div>\
				</div>\
				  <div class="thumbnail-introduce-hr" style="margin:22px 0"></div>\
				  <div class="thumbnail-introduce-ul-new" style="margin-bottom:20px">\
					<ul></ul>\
	  </div>\
	  <div class="img_view" style="position: relative;">\
		<img class="product_view_img thumbnail-box" src="https://www.bt.cn/Public/new/plugin/introduce/database/sensitive_words.png" style="width:auto;margin-top:10px;height:410px"/>\
	  </div>\
	</div>',
		server_sid:0,
		init: function () {
			var that = this
			if(bt.get_cookie('ltd_end')<=0){
				$('#advance-con').html(that.info)
				return
			}
			var token = $("#request_token_head").attr("token")
			function waitForConnection (callback, interval) {
				if (that.ws.readyState === 1) {
					callback();
				} else {
					setTimeout(function () {
						waitForConnection(callback, interval);
					}, interval);
				}
			};
			var send = function (data, callback) {
				waitForConnection(function () {
					that.ws.send(JSON.stringify({'x-http-token':token}));
					// wsFiles.send(JSON.stringify({mod_name:mod_name}));
					that.ws.send(JSON.stringify(data));
					if (typeof callback !== 'undefined') {
						callback();
					}
				}, 300);
			}
			$('#advance-con').html(db_public_fn.sensitive_words.html)
			//搜索前面新增数据库位置下拉
			var _option = '';
			$.each(cloudDatabaseList, function (index, item) {
				var _tips = item.ps != '' ? item.ps : item.db_host;
				_option += '<option value="' + Number(item.id) + '">' + _tips + '</option>';
			});
			$('#binlog-server').html('<span class="binglog-form-title" style="vertical-align: -6px;">服务器：</span><select class="bt-input-text mr5 sensitive_server_filter bt_select_value" style="width:110px;height:30px">' + _option + '</select>');

			//事件
			$('.sensitive_server_filter').change(function () {
				if($(this).val() == ''){
					delete db_public_fn.sensitive_words.server_sid
				}else{
					db_public_fn.sensitive_words.server_sid = $(this).val()
				}
				bt_tools.send({
					url: '/project/sphinx_search/get_database',
					data:{sid:db_public_fn.sensitive_words.server_sid}
				},function(res){
					if(res.data.length==0){
						bt.msg({status:false,msg:'当前没有可用的数据库，请先创建数据库！'})
						that.formFactory('select',{name:'数据库',id:'database',list:[],el:'binlog-database',callback:function(index){
								that.formFactory('select',{name:'数据库表',id:'table',list:[],el:'binlog-table'})
							}})
						$('#binlog-btn button').eq(0).attr('disabled',true)
					}else {
						that.formFactory('select',{name:'数据库',id:'database',list:res.data,el:'binlog-database',callback:function(index){
								that.formFactory('select',{name:'数据库表',id:'table',list:res.data[index].table_list,el:'binlog-table'})
							}})
					}
					that.formFactory('search',{name:'搜索内容',id:'search',el:'binlog-search'})
					$('.binlog-form').addClass('select-type')
					$('.binlog-title').hide()
					$('.binglog-form-title').css('width','auto')
					$('#binlog-database').find('.bt_select_updown').css('width','220px')
					$('#binlog-database').find('.binglog-form-title').css('width','60px')
					$('#binlog-table').find('.bt_select_updown').css('width','220px')
					$('.bt_multiple_select_updown ').css('width','236px')
					$('#binlog-search').find('.bt_select_value').css('width','346px')
					$('#binlog-btn').addClass('select-type').css('top','93px')
					$('#binlog-btn button').eq(0).css('width','100%')
				},'初始化信息')
			});
			$('.sensitive_server_filter').change() //默认触发一次
			//分页
			$('.binlog-result').on('click','.page a',function(e){
				var _href = $(this).attr('href');
				var page = _href.match(/p=([0-9]*)/)[1]
				db_public_fn.sensitive_words.serach_page = page
				$('#binlog-btn button').eq(0).trigger('click')

				e.preventDefault();
				e.stopPropagation();
			})
			$('#binlog-btn button').eq(0).click(function(event){
				that.loading_tips = layer.msg('正在搜索，请稍候...',{icon:16,time:0,shade: [0.3, '#000']})
				//区分事件触发/手动触发
				if(event.hasOwnProperty('originalEvent')){
					db_public_fn.sensitive_words.serach_page = 1
				}
				if($('#binlog-btn').find('#path').length!=0){
					$('#binlog-btn').find('#path').remove()
				}
				$(this).text('正在搜索...').attr('disabled',true)
				if(that.ws != null){
					that.ws.close()
					that.ws = null
				}
				that.ws =new WebSocket((window.location.protocol === 'http:' ? 'ws://' : 'wss://') + window.location.host +'/ws_model');
				that.ws.addEventListener('message', function (ev) { that.on_message(ev) });
				that.ws.addEventListener('close', function (ev) { that.on_close(ev) });
				that.ws.addEventListener('error', function (ev) { that.on_error(ev) });
				that.ws.addEventListener('open', function (ev) { that.on_open(ev) });
				$('.res-table').empty()
				var $form = $('.binlog-form .bt_select_value')
				var data = {
					sid: db_public_fn.sensitive_words.server_sid,
					model_index: "project",
					mod_name: "sphinx_search",
					def_name: "sphinx_search",
					ws_callback: "1",
					p:db_public_fn.sensitive_words.serach_page,
					db_name: $form.eq(1).attr('title'),
					tb_name: $form.eq(2).attr('title'),
					search: $form.eq(3).val()
				}

				send(data)
			})
			$('#binlog-btn button').eq(1).click(function(){
				bt_tools.open({
					title: '索引记录',
					area: ['750px', '500px'],
					btn: false,
					content: '<div id="sensitive_index_table" class="pd15"></div>',
					success:function(){
						bt_tools.table({
							el:'#sensitive_index_table',
							url:'/project/sphinx_search/get_index_list',
							param:{sid:db_public_fn.sensitive_words.server_sid},
							column:[
								{
									fid:'db_name',
									title:'数据库名称',
									type:'text',
								},
								{
									fid:'tb_name',
									title:'表',
									type:'text',
								},
								{
									fid:'search_port',
									title:'端口号',
									type:'text',
								},
								{
									fid:'create_index',
									title:'创建索引时间',
									type:'text',
								},
								{
									fid:'size',
									title:'大小',
									width: 130,
									template:function(item){
										return '<span>'+bt.format_size(item.size)+'</span>'
									}
								},
								{
									type: 'group',
									title: '操作',
									align: 'right',
									group: [
										{
											title: '删除',
											event: function (item, index,ev, key, that) {
												bt.confirm({
														title: '删除索引',
														msg: '是否删除索引？'},
													function () {
														bt_tools.send({url:'/project/sphinx_search/del_index_list',data:{sid:item.sid,db_name:item.db_name,tb_name:item.tb_name}},function(res){
															if(res.status){
																that.$refresh_table_list();
															}
															layer.msg(res.msg, { icon: res.status ? 1 : 2 });
														})
													})
											}
										}
									]
								}
							]
						})
					}
				})
			})
		},
		num: 0,
		search_result:{},
		serach_page:1, //默认查询第一页
		loading_tips:null,
		//连接服务器成功
		on_open: function (ws_event,callback) {
		},

		//服务器消息事件
		on_message: function (ws_event) {
			var rdata = JSON.parse(ws_event.data);
			this.num++
			if(rdata.result) {
				$('#binlog-btn .btn-success').attr('disabled',false).text('搜索')
				if(this.num>=10){
					$('.binlog-result-table>table thead tr th').last().css('width','calc(100% + 18px)')
				}
				// 异常提示
				if(this.search_result.hasOwnProperty('msg') && !this.search_result.status){
					layer.msg(this.search_result.msg,{icon:2,time:0,shadeClose: true,shade: [0.3, '#000']})
				}

				// 总数大于显示的数量，显示分页
				if(this.search_result.status && this.search_result.data.total_found == 0){
					layer.msg('暂无数据',{icon:0,time:0,shadeClose: true,shade: [0.3, '#000']})
				}

				layer.close(this.loading_tips)
				this.num = 0
				this.ws.close()
			}else {
				if(this.num == 1){
					this.search_result = rdata
					this.render_table_head()
				}
				if(this.num >= 2){
					var tbody = '<tr>'
					$.each(rdata.data,function(index,item){
						tbody += '<td '+(index==0?'style="width: 86px;"':'')+'>'+item+'</td>'
					})
					tbody += '</tr>'
					$('.res-table').append(tbody)
				}
			}
		},
		//websocket关闭事件
		on_close: function (ws_event) {
		},
		//渲染表头（默认第一次）
		render_table_head:function(){
			// 根据data渲染动态表头
			var head = ''
			$.each(this.search_result.data.field_list,function(index,item){
				head += '<th '+((item.indexOf('id') > '-1')?'style="width: 86px;"':'')+'>'+item+'</th>'
			})

			$('.binlog-result').html('<div class="binlog-result-table divtable"><table class="table table-hover"><thead>'+head+'</thead><tbody class="res-table"></tbody></div>')
			$('.binlog-result').append('<div class="page">'+this.search_result.data.page+'</div>')
		},
	}
};

//检测数据库是否启动
function check_database_status(name, callback) {
	bt.send('CheckDatabaseStatus', 'database/CheckDatabaseStatus', { name: name }, function (rdata) {
		if (callback) callback(rdata);
	});
}

$('.database-pos .tabs-item[data-type="' + (bt.get_cookie('db_page_model') || 'mysql') + '"]').trigger('click');
