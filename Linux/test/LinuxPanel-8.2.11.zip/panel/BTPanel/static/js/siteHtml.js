function CreateWebsiteModel(config) {
    this.type = config.type;
    this.tips = config.tips;
    this.methods = {
      createProject: ['create_project', '创建' + config.tips + '项目'],
      modifyProject: ['modify_project', '修改' + config.tips + '项目'],
      getProjectInfo: ['get_project_info', '获取' + config.tips + '项目信息'],
      getProjectDomain: ['project_get_domain', '获取' + config.tips + '项目域名'],
      addProjectDomain: ['project_add_domain', '添加' + config.tips + '项目域名'],
      removeProjectDomain: [
        'project_remove_domain',
        '删除' + config.tips + '项目域名',
      ],
    };
    this.bindHttp(); //将请求映射到对象
    this.reanderProjectList(); // 渲染列表
  }
  /**
   * @description 渲染获取项目列表
   */
  CreateWebsiteModel.prototype.reanderProjectList = function () {
    var _that = this;
    $('#bt_' + this.type + '_table').empty();
    site.model_table = bt_tools.table({
      el: '#bt_' + this.type + '_table',
      url: '/project/' + _that.type + '/get_project_list',
      minWidth: '1000px',
      autoHeight: true,
      default: '项目列表为空', //数据为空时的默认提示\
      load: '正在获取' + _that.tips + '项目列表，请稍候...',
      pageName: 'html',
      beforeRequest: function (params) {
        params['table']='sites';
        params['type_id']=bt.get_cookie('site_type_' + _that.type);
        return params;
      },
      dataFilter: function (res) {
        bt.getSiteNum() // 获取数量
        return res
      },
      column: [
        { type: 'checkbox', class: '', width: 20 },
        {
          fid: 'name',
          title: '项目名称',
          type: 'link',
          event: function (row, index, ev) {
            _that.reanderProjectInfoView(row);
          },
        },
        {
          fid: 'path',
          title: '根目录',
          width: 250,
          type: 'link',
          event:function(row,index,ev){
            openPath(row.path)
          },
        },{
          title: '<span style="display:flex"><span onclick="bt.soft.product_pay_view({ totalNum: 67, limit: \'ltd\', closePro: true })" class="firwall_place_of_attribution"></span>目录详情</span>',
          width:120,
          type: 'text',
          template:function(row,index,ev){
            return bt.files.dir_details_span(row.path);
          },
        },
        {
          fid: 'ps',
          title: '备注',
          type: 'input',
          blur: function (row, index, ev, key, that) {
            if (row.ps == ev.target.value) return false;
            bt.pub.set_data_ps(
              { id: row.id, table: 'sites', ps: ev.target.value },
              function (res) {
                bt_tools.msg(res, { is_dynamic: true });
              }
            );
          },
          keyup: function (row, index, ev) {
            if (ev.keyCode === 13) {
              $(this).blur();
            }
          },
        },
        {
          fid: 'ssl',
          title: 'SSL证书',
          tips: '部署证书',
          width: 85,
          type: 'text',
          template: function (row, index) {
            var _ssl = row.ssl,
              _info = '',
              _arry = [
                ['issuer', '证书品牌'],
                ['notAfter', '到期日期'],
                ['notBefore', '申请日期'],
                ['dns', '可用域名'],
              ];
            try {
              if (typeof row.ssl.endtime != 'undefined') {
                if (row.ssl.endtime < 0) {
                  return '<a class="btlink bt_danger" href="javascript:;">已过期</a>';
                }
              }
            } catch (error) {}
            for (var i = 0; i < _arry.length; i++) {
              var item = _ssl[_arry[i][0]];
              _info += _arry[i][1] + ':' + item + (_arry.length - 1 != i ? '\n' : '');
            }
            return row.ssl === -1
              ? '<a class="btlink bt_warning" href="javascript:;">未部署</a>'
              : '<a class="btlink ' + (row.ssl.endtime < 10 ? 'bt_danger' : '') + '" href="javascript:;" title="' + _info + '">剩余' + row.ssl.endtime + '天</a>';
          },
          event: function (row, index, ev, key, that) {
            _that.reanderProjectInfoView(row);
            setTimeout(function () {
              $('.site-menu p:eq(5)').click();
            }, 500);
          },
        },
        {
          title: '操作',
          type: 'group',
          width: 100,
          align: 'right',
          group: [
            {
              title: '设置',
              event: function (row, index, ev, key, that) {
                _that.reanderProjectInfoView(row);
              },
            },
            {
              title: '删除',
              event: function (row, index, ev, key, that) {
                bt.input_confirm({
                    title: '删除项目 - [' + row.name + ']',
                    value: '删除项目',
                    msg: '<span class="color-org">风险操作，此操作不可逆</span>，删除项目后您将无法管理该项目，是否继续操作？'},
                  function () {
                    bt_tools.send({
                      url:'/project/' + _that.type + '/remove_project',
                      data:{
                        project_name:row.name,
                      }
                    },function (res){
                      if(res!=null){
                        bt.msg({status:res.status,msg:res.data})
                        site.model_table.$refresh_table_list(true);
                      }
                    },'删除项目')
                  }
                );
              },
            },
          ],
        },
      ],
      // 渲染完成
      tootls: [
        {
          // 按钮组
          type: 'group',
          positon: ['left', 'top'],
          list: [
            {
              title: '添加' + _that.tips + '项目',
              active: true,
              event: function (ev) {
                _that.reanderAddProject(function (res) {
                  site.model_table.$refresh_table_list(true);
                });
              },
            }
          ],
        },
        {
          // 搜索内容
          type: 'search',
          positon: ['right', 'top'],
          placeholder: '请输入项目名称或备注',
          searchParam: 'search', //搜索请求字段，默认为 search
          value: '', // 当前内容,默认为空
        },
        {
          // 批量操作
          type: 'batch', //batch_btn
          positon: ['left', 'bottom'],
          placeholder: '请选择批量操作',
          buttonValue: '批量操作',
          disabledSelectValue: '请选择需要批量操作的站点!',
          selectList: [
            {
              title: '设置分类',
              url: '/project/' + _that.type + '/set_project_site_type',
              paramName: 'site_ids', //列表参数名,可以为空
              paramId: 'type_id', // 需要传入批量的id
              refresh: true,
              beforeRequest: function (list) {
                var arry = [];
                $.each(list, function (index, item) {
                  arry.push(item.id);
                });
                return JSON.stringify(arry);
              },
              confirm: {
                title: '批量设置分类',
                content:
                    '<div class="line"><span class="tname">站点分类</span><div class="info-r"><select class="bt-input-text mr5 site_types" name="site_types" style="width:150px"></select></span></div></div>',
                success: function () {
                  bt_tools.send({url:'/project/' + _that.type + '/project_site_types'},function(res){
                    var html = '';
                    $.each(res, function (index, item) {
                      html += '<option value="' + item.id + '">' + item.name + '</option>';
                    });
                    $('[name="site_types"]').html(html);
                  });
                },
                yes: function (index, layers, request) {
                  request({ type_id: $('[name="site_types"]').val() });
                },
              },
              tips: false,
              success: function (res, list, that) {
                var html = '';
                $.each(list, function (index, item) {
                  html += '<tr><td>' + item.name + '</td><td><div style="float:right;"><span style="color:' + (res.status ? '#20a53a' : 'red') + '">' + res.msg + '</span></div></td></tr>';
                });
                that.$batch_success_table({ title: '批量设置分类', th: '站点名称', html: html });
                that.$refresh_table_list(true);
              },
            },
            {
              title: '删除项目',
              url: '/project/' + _that.type + '/remove_project',
              param: function (row) {
                return {
                    project_name: row.name,
                };
              },
              refresh: true,
              callback: function (that) {
                bt.prompt_confirm(
                  '批量删除项目',
                  '您正在删除选中的项目，继续吗？',
                  function () {
                    that.start_batch({}, function (list) {
                      var html = '';
                      for (var i = 0; i < list.length; i++) {
                        var item = list[i];
                        html +=
                          '<tr><td><span>' +
                          item.name +
                          '</span></td><td><div style="float:right;"><span style="color:' +
                          (item.requests.status ? '#20a53a' : 'red') +
                          '">' +
                          (item.requests.status
                            ? item.requests.data
                            : item.requests.data) +
                          '</span></div></td></tr>';
                      }
                      site.model_table.$batch_success_table({
                        title: '批量删除项目',
                        th: '项目名称',
                        html: html,
                      });
                      site.model_table.$refresh_table_list(true);
                    });
                  }
                );
              },
            }
          ],
        },
        {
          //分页显示
          type: 'page',
          positon: ['right', 'bottom'], // 默认在右下角
          pageParam: 'p', //分页请求字段,默认为 : p
          page: 1, //当前分页 默认：1
          numberParam: 'limit',
          //分页数量请求字段默认为 : limit
          number: 20,
          //分页数量默认 : 20条
          numberList: [10, 20, 50, 100, 200], // 分页显示数量列表
          numberStatus: true, //　是否支持分页数量选择,默认禁用
          jump: true, //是否支持跳转分页,默认禁用
        },
      ],
      success: function () {
        if(site.model_table){
                  var elTable = site.model_table.config.el
                  if($(elTable+' .tootls_top .pull-left .bt-desired').length === 0){
                      $(elTable+' .tootls_top .pull-left').append('<span class="bt-desired ml10" style="background-size:contain;"><a href="javascript:;" class="btlink ml5 npsFeedback">需求反馈</a></span>')
                      // 网站nps入口
                      $('.npsFeedback').on('click',function(){
                          bt_tools.nps({name:'网站',type:14})
                      })
                  }
          site.init_project_type(_that.type)
              }
        // 详情事件
        bt.files.dir_details()
      }
    });
  };
  
  /**
   * @description 获取添加项目配置
   */
  CreateWebsiteModel.prototype.getAddProjectConfig = function (data) {
    var that = this,
      data = data || {},
      config = [
        {
            label: '域名',
            must: '*',
            group: [{
                type: 'textarea', //当前表单的类型 支持所有常规表单元素、和复合型的组合表单元素
                name: 'webname', //当前表单的name
                style: { width: '440px', height: '100px', 'line-height': '22px' },
                tips: {
                    //使用hover的方式显示提示
                    text: '如需填写多个域名，请换行填写，每行一个域名，默认为80端口<br>IP地址格式：192.168.1.199<br>泛解析添加方法：先添加一个域名 domain.com，后换行添加*.domain.com<br>如另加端口格式为 www.domain.com:88',
                    style: { top: '2px', left: '15px' },
                },
                input: function (value, form, that, config, ev) {
                    //键盘事件
                    var array = value.webname.split('\n'),
                    ress = array[0].split(':')[0],
                    oneVal = bt.strim(ress.replace(new RegExp(/([-.])/g), '_')),
                    defaultPath = $('#defaultPath').text(),
                    is_oneVal = ress.length > 0;
                    that.$set_find_value(
                        is_oneVal
                            ? {
                                    ftp_username: oneVal,
                                    ftp_password: bt.get_random(16),
                                    ps: ress,
                                    path: bt.rtrim(defaultPath, '/') + '/' + ress,
                                }
                            : { ftp_username: '', ftp_password: '', ps: '', path: bt.rtrim(defaultPath, '/') }
                    );
                },
            }]
        },
        {
            label: '备注',
            group: {
                type: 'text',
                name: 'ps',
                width: '400px',
                placeholder: '网站备注，可为空', //默认标准备注提示
            },
        },
        {
            label: '根目录',
            must: '*',
            group: {
                type: 'text',
                width: '400px',
                name: 'path',
                icon: {
                    type: 'glyphicon-folder-open',
                    event: function (ev) {},
                },
                value: bt.get_cookie('sites_path') ? bt.get_cookie('sites_path') : '/www/wwwroot',
                placeholder: '请选择文件目录',
            },
        },
        {
            label: 'FTP',
            group: [
                {
                    type: 'select',
                    name: 'ftp',
                    width: '120px',
                    disabled: (function () {
                        if (bt.config['pure-ftpd']) return !bt.config['pure-ftpd'].setup;
                        return true;
                    })(),
                    list: [
                        { title: '不创建', value: false },
                        { title: '创建', value: true },
                    ],
                    change: function (value, form, that, config, ev) {
                        if (value['ftp'] === 'true') {
                            form['ftp_username'].parents('.line').removeClass('hide');
                        } else {
                            form['ftp_username'].parents('.line').addClass('hide');
                        }
                    },
                },
                (function () {
                    if (bt.config['pure-ftpd']['setup']) return {};
                    return {
                        type: 'link',
                        title: '未安装FTP，点击安装',
                        subclass: 'bterror',
                        name: 'installed_ftp',
                        event: function (ev) {
                            bt.soft.install('pureftpd');
                        },
                    };
                })(),
            ],
        },
        {
            label: 'FTP账号',
            hide: true,
            group: [
                { type: 'text', name: 'ftp_username', placeholder: '创建FTP账号', width: '175px', style: { 'margin-right': '15px' } },
                { label: '密码', type: 'text', placeholder: 'FTP密码', name: 'ftp_password', width: '175px' },
            ],
            help: {
                list: ['创建站点的同时，为站点创建一个对应FTP帐户，并且FTP目录指向站点所在目录。'],
            },
        },
    ];
  
    if (data.type == 'edit') {
      config.push({
        formLabelWidth: '110px',
        group: {
          type: 'button',
          name: 'submitForm',
          title: '保存配置',
          event: function (fromData) {
            // 编辑项目
            fromData.is_power_on = fromData.is_power_on ? 1 : 0;
            if (parseInt(fromData.port) < 0 || parseInt(fromData.port) > 65535) return layer.msg('项目端口格式错误，可用范围：1-65535',{icon:2})
            that.modifyProject(fromData, function (res) {
              bt.msg({ status: res.status, msg: res.data });
              
              if(res.status) {
                var _sel = $('.site-menu p.bgw');
                if (_sel.length == 0) _sel = $('.proxy-menu p').eq(1);
                _sel.trigger('click');
                site.model_table.$refresh_table_list(true);
              }
            });
            // console.log(arguments, 'event');
          },
        },
      });
    }
    return config;
  };
  
  
  /**
   * @description 渲染添加项目表单
   */
  CreateWebsiteModel.prototype.reanderAddProject = function (callback) {
    var that = this;
    var modelForm = bt_tools.open({
      title: '添加' + this.tips + '项目',
      area: ['620px','446px'],
      btn: ['提交', '取消'],
      content: {
        class: 'pd20',
        form: (function () {
          return that.getAddProjectConfig();
        })(),
      },
      success: function (layers, index) {
        $(layers).find('.layui-layer-content').css('overflow', window.innerHeight > $(layers).height() ? 'inherit' : 'auto');
      },
      yes: function (formData, indexs, layero) {
        if (formData.webname === '') {
            keydept_web.form_element.webname.focus();
            bt_tools.msg('域名不能为空！', 2);
            return;
        }
        var webname = bt.replace_all(formData.webname, 'http[s]?:\\/\\/', ''),
            web_list = webname.split('\n'),
            param = { webname: { domain: '', domainlist: [], count: 0 }, port: 80 },
            arry = ['ps', ['path', '网站目录'], 'type_id', 'version', 'ftp','ftp_username', 'ftp_password', 'codeing'];
        for (var i = 0; i < web_list.length; i++) {
            var temps = web_list[i].replace(/\r\n/, '').split(':');
            if (i === 0) {
                param['webname']['domain'] = web_list[i].replace(/[\r\n]/g, '');
                if (typeof temps[1] != 'undefined') param['port'] = temps[1];
            } else {
                param['webname']['domainlist'].push(web_list[i]);
            }
        }
        param['webname']['count'] = param['webname']['domainlist'].length;
        param['webname'] = JSON.stringify(param['webname']);
        $.each(arry, function (index, item) {
            if (formData[item] == '' && Array.isArray(item)) {
                bt_tools.msg(item[1] + '不能为空?', 2);
                return false;
            }
            Array.isArray(item) ? (item = item[0]) : '';
            if ((formData['ftp'] === 'false' || formData['ftp'] === undefined) && (item === 'ftp_username' || item === 'ftp_password')) return true;
            param[item] = formData[item];
        });

        bt_tools.send({
          url:'/project/html/create_project',
          data:param
        },function (res){
          if(res!=null){
            layer.close(indexs);
            if (callback) callback(res);
          }
        },'添加项目')
      },
    });
  };
  
  /**
   * @description 模拟点击
   */
  CreateWebsiteModel.prototype.simulatedClick = function (num) {
    $('.bt-w-menu p:eq(' + num + ')').click();
  };
  
  
  /**
   * @description
   * @param {string} name 站点名称
   */
  CreateWebsiteModel.prototype.reanderProjectInfoView = function (row) {
      var that = this;
      bt.open({
          type: 1,
          title:
              this.tips + '项目管理-[' + row.name + ']，添加时间[' + row.addtime + ']',
          skin: 'model_project_dialog',
          area: ['800px', '770px'],
          content:
              '<div class="bt-tabs">' +
              '<div class="bt-w-menu site-menu pull-left"></div>' +
              '<div id="webedit-con" class="bt-w-con pd15" style="height:100%">' +
              '</div>' +
              '</div>',
          btn: false,
          success: function (layers) {
              var $layers = $(layers),
                  $content = $layers.find('#webedit-con');
  
              function reander_tab_list(config) {
                  for (var i = 0; i < config.list.length; i++) {
                      var item = config.list[i],
                          tab = $(
                              '<p class="' + (i === 0 ? 'bgw' : '') + '">' + item.title + '</p>'
                          );
                      $(config.el).append(tab);
                      (function (i, item) {
                          tab.on('click', function (ev) {
                              $(this).addClass('bgw').siblings().removeClass('bgw');
                              if ($(this).hasClass('bgw')) {
                                  that.getProjectInfo({ project_name: row.name }, function (res) {
                                      config.list[i].event.call(that, $content, res, ev);
                                  });
                              }
                          });
                          if (item.active) tab.click();
                      })(i, item);
                  }
              }
              reander_tab_list(
                {
                    el: $layers.find('.bt-w-menu'),
                    list: [
                        {
                            title: '域名管理',
							active: true,
                            event: that.reanderDomainManageView,
                        },
                        {
                            title: '流量限制',
                            event: that.reander_limit_network,
                        },
                        {
							title: '伪静态',
							event: that.reanderProjectRewriteView,
						},
                        {
                            title: '配置文件',
                            event: that.renderFileConfigView,
                        },
                        {
                            title: '重定向',
                            event: that.reander_node_project_redirect,
                        },
                        { title: 'SSL', event: that.reanderProjectSslView },
                        { title: '网站日志', event: that.reanderProjectLogView },
                    ],
                },
                function (config, i, ev) {}
                );
          },
      });
  };
  /**
   * @description 渲染项目配置文件
   * @param el {object} 当前element节点
   * @param row {object} 当前项目数据
   */
  CreateWebsiteModel.prototype.renderFileConfigView = function (el, row) {
      el.empty();
      site.edit.set_config({ name: this.type + '_' + row.name });
  };
  /**
   * @description 项目SSL
   * @param el {object} 当前element节点
   * @param row {object} 当前项目数据
   */
  CreateWebsiteModel.prototype.reanderProjectSslView = function (el, row) {
      el.empty();
      site.set_ssl({ name: row.name, ele: el, id: row.id });
      site.ssl.reload();
  };
  
  /**
   * @description 项目SSL
   * @param el {object} 当前element节点
   * @param row {object} 当前项目数据
   */
  CreateWebsiteModel.prototype.reanderProjectLogView = function (el, row) {
      el.empty();
      site.edit.get_site_logs({ name: row.name, ele: el, id: row.id });
      site.ssl.reload();
  };
  
  /**
   * @description 绑定请求
   */
  CreateWebsiteModel.prototype.bindHttp = function () {
    var that = this;
    for (const item in this.methods) {
      if (Object.hasOwnProperty.call(this.methods, item)) {
        const element = that.methods[item];
        (function (element) {
          CreateWebsiteModel.prototype[item] = function (param, callback) {
            bt_tools.send(
              {
                url: '/project/' + that.type + '/' + element[0],
                data: { data: JSON.stringify(param) },
              },
              function (data) {
                if (callback) callback(data);
              },
              { load: element[1] }
            );
          };
        })(element);
      }
    }
  };
  CreateWebsiteModel.prototype.layerFrom = null;
  
  /**
   * @description 域名管理
   * @param {object} row 项目信息
   */
  CreateWebsiteModel.prototype.reanderDomainManageView = function (el, row) {
    var that = this,
      list = [
        {
          class: 'mb0',
          items: [
            {
              name: 'modeldomain',
              width: '430px',
              type: 'textarea',
              placeholder:
                '如果需要绑定外网，请输入需要映射的域名<br>多个域名，请换行填写，每行一个域名，默认为80端口<br>泛解析添加方法：先添加一个域名 domain.com，后换行添加*.domain.com<br>如另加端口格式为 www.domain.com:88',
            },
            {
              name: 'btn_model_submit_domain',
              text: '添加',
              type: 'button',
              callback: function (sdata) {
                var arrs = sdata.modeldomain.split('\n');
                var domins = [];
                for (var i = 0; i < arrs.length; i++) domins.push(arrs[i]);
                if (domins[0] == '')
                  return layer.msg('域名不能为空', { icon: 0 });
                that.addProjectDomain(
                  { project_name: row.name, domains: domins },
                  function (res) {
                    if (typeof res.status == 'undefined') {
                      $('[name=modeldomain]').val('');
                      $('.placeholder').css('display', 'block');
                      site.render_domain_result_table(res)
                      project_domian.$refresh_table_list(true);
                    }else{
                      bt.msg({
                        status: res.status,
                        msg: res.msg || res.error_msg,
                      });
                    }
  
                  }
                );
              },
            },
          ],
        },
      ];
    var _form_data = bt.render_form_line(list[0]),
      loadT = null,
      placeholder = null;
    el.html(_form_data.html + '<div id="project_domian_list"></div>');
    bt.render_clicks(_form_data.clicks);
    // domain样式
    $('.btn_model_submit_domain')
      .addClass('pull-right')
      .css('margin', '30px 35px 0 0');
    $('textarea[name=modeldomain]').css('height', '120px');
    placeholder = $('.placeholder');
    placeholder
      .click(function () {
        $(this).hide();
        $('.modeldomain').focus();
      })
      .css({
        width: '430px',
        heigth: '120px',
        left: '0px',
        top: '0px',
        'padding-top': '10px',
        'padding-left': '15px',
      });
    $('.modeldomain')
      .focus(function () {
        placeholder.hide();
        loadT = layer.tips(placeholder.html(), $(this), {
          tips: [1, '#20a53a'],
          time: 0,
          area: $(this).width(),
        });
      })
      .blur(function () {
        if ($(this).val().length == 0) placeholder.show();
        layer.close(loadT);
      });
    var project_domian = bt_tools.table({
      el: '#project_domian_list',
      url: '/data?action=getData',
      default: '暂无域名列表',
      param: { table: 'domain', list: 'True', search: row.id },
      height: 375,
      column: [
        { type: 'checkbox', class: '', width: 20 },
        {
          fid: 'name',
          title: '域名',
          type: 'text',
          template: function (row) {
            return (
              '<a href="http://' +
              row.name +
              ':' +
              row.port +
              '" target="_blank" class="btlink">' +
              row.name +
              '</a>'
            );
          },
        },
        {
          fid: 'port',
          title: '端口',
          type: 'text',
        },
        {
          title: '操作',
          type: 'group',
          width: '100px',
          align: 'right',
          group: [
            {
              title: '删除',
              template: function (row, that) {
                return that.data.length === 1 ? '<span>不可操作</span>' : '删除';
              },
              event: function (rowc, index, ev, key, rthat) {
                if (ev.target.tagName == 'SPAN') return;
                if (rthat.data.length === 1) {
                  return bt.msg({ status: false, msg: '最后一个域名不能删除!' });
                }
                that.removeProjectDomain(
                  { project_name: row.name, domain: rowc.name + ':' + rowc.port },
                  function (res) {
                    bt.msg({
                      status: res.status,
                      msg: res.data || res.error_msg,
                    });
                    rthat.$refresh_table_list(true);
                  }
                );
              },
            },
          ],
        },
      ],
      tootls: [
        {
          // 批量操作
          type: 'batch',
          positon: ['left', 'bottom'],
          placeholder: '请选择批量操作',
          buttonValue: '批量操作',
          disabledSelectValue: '请选择需要批量操作的站点!',
          selectList: [
            {
              title: '删除域名',
              load: true,
              url: '/project/' + that.type + '/project_remove_domain',
              param: function (crow) {
                return {
                  data: JSON.stringify({
                    project_name: row.name,
                    domain: crow.name + ':' + crow.port,
                  }),
                };
              },
              callback: function (that) {
                // 手动执行,data参数包含所有选中的站点
                bt.show_confirm(
                  '批量删除域名',
                  "<span style='color:red'>同时删除选中的域名，是否继续？</span>",
                  function () {
                    var param = {};
                    that.start_batch(param, function (list) {
                      var html = '';
                      for (var i = 0; i < list.length; i++) {
                        var item = list[i];
                        html +=
                          '<tr><td>' +
                          item.name +
                          '</td><td><div style="float:right;"><span style="color:' +
                          (item.request.status ? '#20a53a' : 'red') +
                          '">' +
                          (item.request.status ? '成功' : '失败') +
                          '</span></div></td></tr>';
                      }
                      project_domian.$batch_success_table({
                        title: '批量删除',
                        th: '删除域名',
                        html: html,
                      });
                      project_domian.$refresh_table_list(true);
                    });
                  }
                );
              },
            },
          ],
        },
      ],
    });
    setTimeout(function () {
      $(el).append(
        '<ul class="help-info-text c7">' +
        '<li>如果您的是HTTP项目，且需要映射到外网，请至少绑定一个域名</li>' +
        '<li>建议所有域名都使用默认的80端口</li>' +
        '</ul>'
      );
    }, 100);
  };
  
  /**
   * @description 渲染项目伪静态视图
   * @param el {object} 当前element节点
   * @param row {object} 当前项目数据
   */
  CreateWebsiteModel.prototype.reanderProjectRewriteView = function (el, row) {
    el.empty();
    site.edit.get_rewrite_list({ name: this.type + '_' + row.name }, function () {
      $('.webedit-box .line:first').remove();
      $('[name=btn_save_to]').remove();
      $('.webedit-box .help-info-text li:first').remove();
    });
  };
  /**
 * @description 渲染项目流量限制
 */
  CreateWebsiteModel.prototype.reander_limit_network = function (el, row) {
    var that = this;
    el.empty();
    bt_tools.send({url:'/project/'+that.type+'/get_limit_net',data:{site_id:row.id}},function(rdata){
        if (!rdata.limit_rate && !rdata.perip && !rdata.perserver) rdata.value = 1;
        var limits = [
            { title: '论坛/博客', value: 1, items: { perserver: 300, perip: 25, limit_rate: 512 } },
            { title: '图片站', value: 2, items: { perserver: 200, perip: 10, limit_rate: 1024 } },
            { title: '下载站', value: 3, items: { perserver: 50, perip: 3, limit_rate: 2048 } },
            { title: '商城', value: 4, items: { perserver: 500, perip: 10, limit_rate: 2048 } },
            { title: '门户', value: 5, items: { perserver: 400, perip: 15, limit_rate: 1024 } },
            { title: '企业', value: 6, items: { perserver: 60, perip: 10, limit_rate: 512 } },
            { title: '视频', value: 7, items: { perserver: 150, perip: 4, limit_rate: 1024 } },
            { title: '自定义', value: 0, items: { perserver: '', perip: '', limit_rate: '' } },
        ];
        var datas = [
            {
                items: [
                    {
                        name: 'status',
                        type: 'checkbox',
                        value: rdata.perserver != 0 ? true : false,
                        text: '启用流量控制',
                        callback: function (ldata) {
                            if (ldata.status) {
                                if (!$('input[name=perip]').val() && !$('input[name=limit_rate]').val() && !$('input[name=perserver]').val()) {
                                    layer.msg('您的输入为空，请重新填写', { icon: 2 });
                                    $('#status').prop('checked', rdata.perserver != 0 ? true : false);
                                    return;
                                }
                                bt_tools.send({url:'/project/'+that.type+'/set_limit_net',data:{site_id:row.id,perserver:ldata.perserver,perip:ldata.perip,limit_rate:ldata.limit_rate}},function(ret){
                                    layer.msg(ret.msg, { icon: ret.status ? 1 : 2 });
                                    if (ret.status) $('.bt-w-menu p:eq(1)').click()
                                });
                            } else {
                                bt_tools.send({url:'/project/'+that.type+'/close_limit_net',data:{site_id:row.id}},function(ret){
                                    layer.msg(ret.msg, { icon: ret.status ? 1 : 2 });
                                    if (ret.status) $('.bt-w-menu p:eq(1)').click()
                                });
                            }
                        },
                    },
                ],
            },
            {
                items: [
                    {
                        title: '限制方案  ',
                        width: '200px',
                        name: 'limit',
                        type: 'select',
                        value: rdata.value,
                        items: limits,
                        callback: function (obj) {
                            var data = limits.filter(function (p) {
                                return p.value === parseInt(obj.val());
                            })[0];
                            for (var key in data.items) {
                                $('input[name="' + key + '"]').val(data.items[key]);
                            }
                        },
                    },
                ],
            },
            {
                items: [{ title: '并发限制   ', type: 'number', width: '200px', value: rdata.perserver, name: 'perserver', unit: '<span style="margin-left: 5px;">* 限制当前站点最大并发数</span>' }],
            },
            { items: [{ title: '单IP限制   ', type: 'number', width: '200px', value: rdata.perip, name: 'perip', unit: '<span style="margin-left: 5px;">* 限制单个IP访问最大并发数</span>' }] },
            {
                items: [
                    {
                        title: '流量限制   ',
                        type: 'number',
                        width: '200px',
                        value: rdata.limit_rate,
                        name: 'limit_rate',
                        unit: '<span style="margin-left: 5px;">* 限制每个请求的流量上限（单位：KB）</span>',
                    },
                ],
            },
            {
                name: 'btn_limit_get',
                text: rdata.perserver != 0 ? '保存' : '保存并启用',
                type: 'button',
                callback: function (ldata) {
                    if (ldata.perserver <= 0 || ldata.perip <= 0 || ldata.limit_rate <= 0) {
                        return layer.msg('并发限制，IP限制，流量限制必需大于0且不为空值！', { icon: 2 });
                    }
                    bt_tools.send({url:'/project/'+that.type+'/set_limit_net',data:{site_id:row.id,perserver:ldata.perserver,perip:ldata.perip,limit_rate:ldata.limit_rate}},function(ret){
                        layer.msg(ret.msg, { icon: ret.status ? 1 : 2 });
                        if (ret.status) $('.bt-w-menu p:eq(1)').click()
                    });
                },
            },
        ];
        var _html = $("<div class='webedit-box soft-man-con'></div>");
        var clicks = [];
        for (var i = 0; i < datas.length; i++) {
            var _form_data = bt.render_form_line(datas[i]);
            _html.append(_form_data.html);
            clicks = clicks.concat(_form_data.clicks);
        }
        _html.find('input[type="checkbox"]').parent().addClass('label-input-group ptb10');
        // _html.append(bt.render_help(['限制当前站点最大并发数', '限制单个IP访问最大并发数', '限制每个请求的流量上限（单位：KB）']));
        el.html(_html);
        bt.render_clicks(clicks);
        if (rdata.perserver == 0) $("select[name='limit']").trigger('change');
        $('.soft-man-con').on('keyup', '.perserver, .perip, .limit_rate', function () {
            var val = $(this).val();
            if (val == '') return;
            // 判断不是正整数
            if (!/(^[1-9]\d*$)/.test(val)) {
                $(this).val(Math.floor(val));
            }
        });
        $('select[name=limit]').attr('autocomplete', 'off');
        var timer = 0;
        $('input[name=perip],input[name=perserver],input[name=limit_rate]').change(function () {
            clearTimeout(timer);
            timer = setTimeout(function () {
                var limit_perserver_val = $('input[name=perserver]').val();
                var limit_perip_val = $('input[name=perip]').val();
                var limit_rate_val = $('input[name=limit_rate]').val();
                for (var i = 0; i < limits.length; i++) {
                    var limit_item = limits[i].items;
                    var flag_1 = limit_perserver_val == limit_item.perserver && limit_perip_val == limit_item.perip && limit_rate_val == limit_item.limit_rate;
                    $('select[name=limit]').children().prop('selected', false);
                    if (flag_1) {
                        $('select[name=limit]')
                            .find('option[value=' + limits[i].value + ']')
                            .prop('selected', true);
                        break;
                    } else {
                        $('select[name=limit]').find('option[value=0]').prop('selected', true);
                    }
                }
            }, 500);
        });
    });
}


  /**
 * @description 重定向
 */
  CreateWebsiteModel.prototype.reander_node_project_redirect = function (el, row) {
    var that = this;
    el.empty();
    
    el.html(
        '<div>\
        <div id="website_redirect"></div>\
        <ul class="help-info-text c7">\
            <li>设置域名重定向后，该域名的404重定向将失效</li>\
        </ul>\
    </div>'
    );
    site.edit.redirect_table = bt_tools.table({
        el: '#website_redirect',
        url: '/project/'+that.type+'/get_project_redirect_list',
        param: { sitename: row.name },
        height: 500,
        dataFilter: function (res) {
            $.each(res, function (i, item) {
                if (!item.hasOwnProperty('errorpage')) {
                    item.errorpage = 0;
                }
            });
            return { data: res };
        },
        column: [
            // { type: 'checkbox', width: 20 },
            {
                fid: 'sitename',
                title: '被重定向',
                type: 'text',
                width: 120,
                template: function (row, index) {
                    var conter = '空';
                    if (row.domainorpath == 'path' && row.errorpage !== 1) {
                        conter = row.redirectpath || '空';
                    } else {
                        conter = row.redirectdomain ? row.redirectdomain.join('、') : '空';
                    }
                    return '<span style="width:100px;" title="' + conter + '">' + conter + '</span>';
                },
            },
            {
                fid: 'method',
                title: '重定向类型',
                type: 'text',
                width: 90,
                template: function (row, index) {
                    var str = '';
                    if (row.errorpage == 1) {
                        str = '错误';
                    } else if (row.domainorpath == 'path') {
                        str = '路径';
                    } else if (row.domainorpath == 'domain') {
                        str = '域名';
                    }
                    return '<span>' + str + '</span>';
                },
            },
            {
                fid: 'path',
                title: '重定向到',
                type: 'text',
                template: function (row, index) {
                    var path = row.tourl ? row.tourl : row.topath;
                    return (
                        '<span title="' +
                        path +
                        '" style="display: flex;">\
                        <span class="size_ellipsis" style="flex: 1; width: 0;">' +
                        (row.topath && path == '/' ? '首页' : path) +
                        '</span>\
                    </span>'
                    );
                },
            },
            {
                fid: 'type',
                title: '状态',
                width: 70,
                config: {
                    icon: true,
                    list: [
                        [1, '运行中', 'bt_success', 'glyphicon-play'],
                        [0, '已停止', 'bt_danger', 'glyphicon-pause'],
                    ],
                },
                type: 'status',
                event: function (row, index, ev, key, that) {
                    row.type = !row.type ? 1 : 0;
                    row.redirectdomain = JSON.stringify(row['redirectdomain']);
                    modify_node_refirect(row, function (res) {
                        row.redirectdomain = JSON.parse(row['redirectdomain']);
                        that.$modify_row_data({ status: row.type });
                        bt.msg(res);
                    });
                },
            },
            {
                title: '操作',
                width: 150,
                type: 'group',
                align: 'right',
                group: [
                    {
                        title: '配置文件',
                        event: function (row, index, ev, key, that) {
                            if(row.type == 0){
                                return layer.msg('重定向已暂停',{icon:2})
                            }
                            var type = '';
                            try {
                                type = bt.get_cookie('serverType') || serverType;
                            } catch (err) {}
                            bt.open({
                                type: 1,
                                area: ['550px', '550px'],
                                title: '编辑配置文件[' + row.redirectname + ']',
                                closeBtn: 2,
                                shift: 0,
                                content:
                                    '\
                            <div class="bt-form pd15">\
                                <p style="color: #666; margin-bottom: 7px">提示：Ctrl+F 搜索关键字，Ctrl+S 保存，Ctrl+H 查找替换</p>\
                                <div id="redirect_config_con" class="bt-input-text ace_config_editor_scroll" style="height: 350px; line-height: 18px;"></div>\
                                <button id="OnlineEditFileBtn" class="btn btn-success btn-sm" style="margin-top:10px;">保存</button>\
                                <ul class="help-info-text c7">\
                                    <li>此处为该负载均衡的配置文件，若您不了解配置规则,请勿随意修改。</li>\
                                </ul>\
                            "</div>',
                                success: function (layers, indexs) {
                                    bt_tools.send(
                                        { url: '/files?action=GetFileBody', data: { path: row.redirect_conf_file } },function (res) {
                                            var editor = bt.aceEditor({
                                                el: 'redirect_config_con',
                                                content: res.data,
                                                mode: 'nginx',
                                                path: row.redirect_conf_file,
                                            });
                                            $('#OnlineEditFileBtn').click(function () {
                                                bt.saveEditor(editor);
                                            });
                                        })
                                },
                            });
                        },
                    },
                    {
                        title: '编辑',
                        event: function (crow, index, ev, key, that) {
                            if (crow.errorpage == 1) {
                                node_refirect_404(row.name, crow);
                            } else {
                                node_refirect_301(row.name, row.id, crow);
                            }
                        },
                    },
                    {
                        title: '删除',
                        event: function (row, index, ev, key, that) {
                            bt_tools.send({url:'/project/'+that.type+'/remove_project_redirect',data:{sitename:row.sitename,redirectname:row.redirectname}},function(rdata){
                                bt.msg(rdata);
                                if (rdata.status) that.$delete_table_row(index);
                            });
                        },
                    },
                ],
            },
        ],
        tootls: [
            {
                // 按钮组
                type: 'group',
                positon: ['left', 'top'],
                list: [
                    {
                        title: '添加重定向',
                        active: true,
                        event: function (ev) {
                            node_refirect_301(row.name, row.id);
                        },
                    },
                    {
                        title: '404重定向',
                        event: function (ev) {
                            var crow = undefined;
                            var data = site.edit.redirect_table.data;
                            for (var i = 0; i < data.length; i++) {
                                if (data[i].errorpage == 1) {
                                    crow = data[i];
                                    break;
                                }
                            }
                            node_refirect_404(row.name, crow);
                        },
                    },
                ],
            },
        ],
    });
    function modify_node_refirect(obj,callback){
        bt_tools.send({url:'/project/'+that.type+'/modify_project_redirect',data:obj},function(res){
            if(callback) callback(res)
        },'设置重定向')
    }
    function node_refirect_301(sitename, id, nrow){
        var isEdit = !!nrow;
        var form = isEdit
            ? nrow
            : {
                redirectname: new Date().valueOf(),
                tourl: 'http://',
                redirectdomain: [],
                redirectpath: '',
                redirecttype: '',
                type: 1,
                domainorpath: 'domain',
                holdpath: 1,
            };
        var helps = [
            '重定向类型：表示访问选择的“域名”或输入的“路径”时将会重定向到指定URL',
            '目标URL：可以填写你需要重定向到的站点，目标URL必须为可正常访问的URL，否则将返回错误',
            '重定向方式：使用301表示永久重定向，使用302表示临时重定向',
            '保留URI参数：表示重定向后访问的URL是否带有子路径或参数如设置访问http://b.com 重定向到http://a.com',
            '保留URI参数：  http://b.com/1.html ---> http://a.com/1.html',
            '不保留URI参数：http://b.com/1.html ---> http://a.com',
        ];
        bt_tools.send({url:'/data?action=getData',data:{table: 'domain', list: 'True', search: id}},function(rdata){
            var flag = true;
            var domain_html = '';
            var select_list = [];
            var table_data = site.edit.redirect_table.data;
            for (var i = 0; i < rdata.length; i++) {
                flag = true;
                for (var j = 0; j < table_data.length; j++) {
                    var con1 = site.edit.get_list_equal(table_data[j].redirectdomain, rdata[i].name);
                    var con2 = !site.edit.get_list_equal(form.redirectdomain, rdata[i].name);
                    if (con1 && con2) {
                        flag = false;
                        break;
                    }
                }
                if (flag) {
                    select_list.push(rdata[i]);
                    var selected = site.edit.get_list_equal(form.redirectdomain, rdata[i].name);
                    domain_html += '<li ' + (selected ? 'class="selected"' : '') + '><a><span class="text">' + rdata[i].name + '</span><span class="glyphicon glyphicon-ok check-mark"></span></a></li>';
                }
            }
            if (!domain_html) {
                domain_html = '<div style="padding: 14px 0; color: #999; text-align: center; font-size: 12px;">暂无域名可选</div>';
            }
            var content =
                '<style>select.bt-input-text { width: 100px; }</style>\
            <div id="form_redirect" class="bt-form-new pd20">\
                <div class="form-inline">\
                    <div class="form-item">\
                        <div class="form-label">开启重定向</div>\
                        <div class="form-value">\
                            <input class="btswitch btswitch-ios" id="type" type="checkbox" name="type" checked />\
                            <label class="btswitch-btn phpmyadmin-btn" for="type"></label>\
                        </div>\
                    </div>\
                    <div class="form-item">\
                        <div class="form-label">保留URI参数</div>\
                        <div class="form-value">\
                            <input class="btswitch btswitch-ios" id="holdpath" type="checkbox" name="holdpath" checked />\
                            <label class="btswitch-btn phpmyadmin-btn" for="holdpath"></label>\
                        </div>\
                    </div>\
                </div>\
                <div class="form-inline">\
                    <div class="form-item">\
                        <div class="form-label">重定向类型</div>\
                        <div class="form-value">\
                            <select class="bt-input-text" name="domainorpath">\
                                <option value="domain">域名</option>\
                                <option value="path">路径</option>\
                            </select>\
                        </div>\
                    </div>\
                    <div class="form-item">\
                        <div class="form-label" style="width: 90px;">重定向方式</div>\
                        <div class="form-value">\
                            <select class="bt-input-text" style="width: 150px;" name="redirecttype">\
                                <option value="301">301（永久重定向）</option>\
                                <option value="302">302（临时重定向）</option>\
                            </select>\
                        </div>\
                    </div>\
                </div>\
                <div class="form-inline redirectdomain" style="flex-wrap: nowrap;">\
                    <div class="form-item">\
                        <div class="form-label">重定向域名</div>\
                        <div class="form-value">\
                            <div class="btn-group bootstrap-select show-tick redirect_domain" style="width: 200px;">\
                                <button type="button" class="btn dropdown-toggle btn-default" style="height: 32px; line-height: 18px; font-size: 12px">\
                                    <span class="filter-option pull-left"></span>\
                                    <span class="bs-caret"><span class="caret"></span></span>\
                                </button>\
                                <div class="dropdown-menu open">\
                                    <div class="bs-actionsbox">\
                                        <div class="btn-group btn-group-sm btn-block">\
                                            <button type="button" class="actions-btn bs-select-all btn btn-default">全选</button>\
                                            <button type="button" class="actions-btn bs-deselect-all btn btn-default">取消全选</button>\
                                        </div>\
                                    </div>\
                                    <div class="dropdown-menu inner">' +
                domain_html +
                '</div>\
                                </div>\
                            </div>\
                        </div>\
                    </div>\
                    <div class="form-item">\
                        <div class="form-label" style="width: 80px;">目标URL</div>\
                        <div class="form-value">\
                            <input class="bt-input-text" name="tourl" type="text" style="width: 200px;" value="http://" />\
                        </div>\
                    </div>\
                </div>\
                <div class="form-inline redirectpath" style="display: none; flex-wrap: nowrap;">\
                    <div class="form-item">\
                        <div class="form-label">重定向路径</div>\
                        <div class="form-value">\
                            <input class="bt-input-text" name="redirectpath" placeholder="如: http://' +
                sitename +
                ' " type="text" style="width: 200px;" />\
                        </div>\
                    </div>\
                    <div class="form-item">\
                        <div class="form-label" style="width: 80px;">目标URL</div>\
                        <div class="form-value">\
                            <input class="bt-input-text" name="tourl1" type="text" style="width: 200px;" value="http://" />\
                        </div>\
                    </div>\
                </div>\
                <div style="height: 15px;"></div>\
                ' +
                bt.render_help(helps) +
                '\
            </div>';
            var redirectdomain = form.redirectdomain;
            var form_redirect = bt.open({
                type: 1,
                skin: 'demo-class',
                area: '650px',
                title: !isEdit ? '添加重定向' : '修改重定向',
                closeBtn: 2,
                shift: 5,
                shadeClose: false,
                btn: ['提交', '取消'],
                content: content,
                success: function () {
                    var show_domain_name = function () {
                        var text = '';
                        if (redirectdomain.length > 0) {
                            text = [];
                            for (var i = 0; i < redirectdomain.length; i++) {
                                text.push(redirectdomain[i]);
                            }
                            text = text.join(', ');
                        } else {
                            text = '请选择站点';
                        }
                        $('.redirect_domain .btn .filter-option').text(text);
                    };
                    show_domain_name();
                    $('.redirect_domain .btn').click(function (e) {
                        var $parent = $(this).parent();
                        $parent.toggleClass('open');
                        $(document).one('click', function () {
                            $parent.removeClass('open');
                        });
                        e.stopPropagation();
                    });
                    // 单选
                    $('.redirect_domain .dropdown-menu li').click(function (e) {
                        var $this = $(this);
                        var index = $this.index();
                        var name = select_list[index].name;
                        $this.toggleClass('selected');
                        if ($this.hasClass('selected')) {
                            redirectdomain.push(name);
                        } else {
                            var remove_index = -1;
                            for (var i = 0; i < redirectdomain.length; i++) {
                                if (redirectdomain[i] == name) {
                                    remove_index = i;
                                    break;
                                }
                            }
                            if (remove_index != -1) {
                                redirectdomain.splice(remove_index, 1);
                            }
                        }
                        show_domain_name();
                        e.stopPropagation();
                    });
                    // 全选
                    $('.redirect_domain .bs-select-all').click(function () {
                        redirectdomain = [];
                        for (var i = 0; i < select_list.length; i++) {
                            redirectdomain.push(select_list[i].name);
                        }
                        $('.redirect_domain .dropdown-menu li').addClass('selected');
                        show_domain_name();
                    });
                    // 取消全选
                    $('.redirect_domain .bs-deselect-all').click(function () {
                        redirectdomain = [];
                        $('.redirect_domain .dropdown-menu li').removeClass('selected');
                        show_domain_name();
                    });
                    // 重定向类型
                    $('[name="domainorpath"]').change(function () {
                        var path = $(this).val();
                        $('.redirect_domain .bs-deselect-all').click();
                        $('[name="redirectpath"]').val('');
                        $('.redirectpath, .redirectdomain').hide();
                        switch (path) {
                            case 'path':
                                $('.redirectpath').show();
                                break;
                            case 'domain':
                                $('.redirectdomain').show();
                                break;
                        }
                    });
                    if (isEdit) {
                        $('[name="type"]').prop('checked', form.type == 1);
                        $('[name="holdpath"]').prop('checked', form.holdpath == 1);
                        $('[name="domainorpath"]').val(form.domainorpath);
                        $('[name="redirecttype"]').val(form.redirecttype);
                        $('[name="' + (form.domainorpath == 'path' ? 'tourl1' : 'tourl') + '"]').val(form.tourl);
                        $('[name="redirectpath"]').val(form.redirectpath);
                        $('.redirectpath, .redirectdomain').hide();
                        switch (form.domainorpath) {
                            case 'path':
                                $('.redirectpath').show();
                                break;
                            case 'domain':
                                $('.redirectdomain').show();
                                break;
                        }
                    }
                    $('#form_redirect').parent().css('overflow', 'inherit');
                },
                yes: function () {
                    form.type = $('[name="type"]').prop('checked') ? 1 : 0;
                    form.holdpath = $('[name="holdpath"]').prop('checked') ? 1 : 0;
                    form.redirecttype = $('[name="redirecttype"]').val();
                    form.domainorpath = $('[name="domainorpath"]').val();
                    form.redirectpath = $('[name="redirectpath"]').val();
                    form.tourl = $('[name="' + (form.domainorpath == 'path' ? 'tourl1' : 'tourl') + '"]').val();
                    form.redirectdomain = JSON.stringify(redirectdomain);
                    bt_tools.send({url:'/project/'+that.type+'/'+(isEdit?'modify':'create')+'_project_redirect',data:$.extend(form,{sitename: sitename})},function(rdata){
                        if (rdata.status) {
                            form_redirect.close();
                            site.edit.redirect_table.$refresh_table_list();
                        }
                        bt.msg(rdata);
                    })
                },
            });
        },'获取域名列表')
    }
    function node_refirect_404(sitename, nrow) {
        var isEdit = !!nrow;
        var form = isEdit
            ? nrow
            : {
                    sitename: sitename,
                    errorpage: 1,
                    redirectname: new Date().valueOf(),
              };
        bt.open({
            type: 1,
            shift: 5,
            closeBtn: 2,
            shadeClose: false,
            area: '400px',
            title: isEdit ? '编辑404重定向' : '添加404重定向',
            btn: ['提交', '取消'],
            content:
                '<style>.form-item .form-label { width: 132px; } .form-item .bt-input-text { width: 180px; } </style>\
            <div class="bt-form-new pd20" style="padding-bottom: 25px;">\
                <div class="form-item">\
                    <div class="form-label">开启重定向</div>\
                    <div class="form-value">\
                        <input type="checkbox" id="redirect_status" class="btswitch btswitch-ios" name="redirect_status" checked="checked" />\
                        <label class="btswitch-btn" for="redirect_status"></label>\
                    </div>\
                </div>\
                <div class="form-item">\
                    <div class="form-label">错误类型</div>\
                    <div class="form-value">\
                        <select class="bt-input-text">\
                            <option selected>页面404</option>\
                        </select>\
                    </div>\
                </div>\
                <div class="form-item">\
                    <div class="form-label">重定向方式</div>\
                    <div class="form-value">\
                        <select class="bt-input-text" name="redirecttype">\
                            <option value="301" selected>301</option>\
                            <option value="302">302</option>\
                        </select>\
                    </div>\
                </div>\
                <div class="form-item">\
                    <div class="form-label">404错误重定向到</div>\
                    <div class="form-value">\
                        <select class="bt-input-text" name="redirect_method">\
                            <option value="topath" selected>首页</option>\
                            <option value="tourl">自定义页面</option>\
                        </select>\
                        <input type="text" name="tourl" class="bt-input-text mt10" style="display: none;" placeholder="例: http://www.bt.cn" />\
                    </div>\
                </div>\
            </div>',
            success: function () {
                $('select[name="redirect_method"]').change(function () {
                    var val = $(this).val();
                    if (val == 'tourl') {
                        $('input[name="tourl"]').show();
                    } else {
                        $('input[name="tourl"]').hide();
                    }
                });

                if (isEdit) {
                    $('[name="redirect_status"]').prop('checked', form.type == 1);
                    $('[name="redirecttype"]').val(form.redirecttype);
                    $('[name="redirect_method"]').val(form.topath ? 'topath' : 'tourl');
                    $('[name="redirect_method"]').change();
                    if (form.tourl) {
                        $('[name="tourl"]').val(form.tourl);
                    }
                }
            },
            yes: function (index) {
                form.redirecttype = $('select[name="redirecttype"]').val();
                form.type = $('[name="redirect_status"]').is(':checked') ? 1 : 0;
                var method = $('[name="redirect_method"]').val();
                if (method == 'topath') {
                    form.topath = '/';
                    form.tourl = '';
                } else {
                    var tourl = $('[name="tourl"]').val().trim();
                    if (tourl === '') {
                        layer.msg('请输入自定义页面路径', { icon: 2 });
                        return;
                    }
                    form.tourl = tourl;
                    form.topath = '';
                }
                form.domainorpath = 'path'
                form.holdpath = 999
                form.redirectpath = ' '
                bt_tools.send({url:'/project/'+that.type+'/'+(isEdit?'modify':'create')+'_project_redirect',data:form},function(res){
                        if (res.status) {
                            layer.close(index);
                            site.edit.redirect_table.$refresh_table_list();
                        }
                        bt.msg(res);
                    }
                );
            },
        });
    }

}

  
  /**
   * @description 渲染项目配置文件
   * @param el {object} 当前element节点
   * @param row {object} 当前项目数据
   */
  CreateWebsiteModel.prototype.reanderFileConfigView = function (el, row) {
    el.empty();
    site.edit.set_config({ name: this.type + '_' + row.name });
  };
  