function CreateWebsiteModel(config) {
  this.type = config.type;
  this.tips = config.tips;
  this.netVersionList = []; // net版本列表
  this.netVindexOf = 0; // net版本索引
  this.methods = {
    createProject: ['create_project', '创建' + config.tips + '项目'],
    modifyProject: ['modify_project', '修改' + config.tips + '项目'],
    removeProject: ['remove_project', '删除' + config.tips + '项目'],
    startProject: ['start_project', '启动' + config.tips + '项目'],
    stopProject: ['stop_project', '停止' + config.tips + '项目'],
    restartProject: ['restart_project', '重启' + config.tips + '项目'],
    getProjectInfo: ['get_project_info', '获取' + config.tips + '项目信息'],
    getProjectDomain: ['project_get_domain', '获取' + config.tips + '项目域名'],
    addProjectDomain: ['project_add_domain', '添加' + config.tips + '项目域名'],
    removeProjectDomain: [
      'project_remove_domain',
      '删除' + config.tips + '项目域名',
    ],
    getProjectLog: ['get_project_log', '获取' + config.tips + '项目日志'],
    change_log_path: ['change_log_path', '修改' + config.tips + '项目日志路径'],
    get_log_split: ['get_log_split', '获取' + config.tips + '项目日志切割任务'],
    mamger_log_split: ['mamger_log_split', '设置' + config.tips + '项目日志切割任务'],
    set_log_split: ['set_log_split', '设置' + config.tips + '项目日志切割状态'],
    bindExtranet: ['bind_extranet', '开启外网映射'],
    unbindExtranet: ['unbind_extranet', '关闭外网映射'],
    getNetVersion: ['GetNetVersion', '获取' + config.tips + '版本'],
  };
  this.bindHttp(); //将请求映射到对象
  this.getNetVersionData(); // 获取Net版本
  this.reanderProjectList(); // 渲染列表
}
/**
 * @description 渲染获取项目列表
 */
CreateWebsiteModel.prototype.reanderProjectList = function () {
  var _that = this;
  $('#bt_' + this.type + '_table').empty();
  site.model_table = bt_tools.table({
    el: '#bt_' + this.type + '_table',
    url: '/project/' + _that.type + '/get_project_list',
    minWidth: '1000px',
    autoHeight: true,
    default: '项目列表为空', //数据为空时的默认提示\
    load: '正在获取' + _that.tips + '项目列表，请稍候...',
    pageName: 'nodejs',
    beforeRequest: function (params) {
      params['table']='sites';
      params['type_id']=bt.get_cookie('site_type_' + _that.type);
      return params;
    },
    dataFilter: function (res) {
      bt.getSiteNum() // 获取数量
      return res
    },
    column: [
      { type: 'checkbox', class: '', width: 20 },
      {
        fid: 'name',
        title: '项目名称',
        type: 'link',
        event: function (row, index, ev) {
          _that.reanderProjectInfoView(row);
        },
      },
      {
				fid: 'run',
				title: '服务状态',
				width: 80,
				// config: {
					// 	icon: true,
					// 	list: [
						// 		[true, '运行中', 'bt_success', 'glyphicon-play'],
						// 		[false, '未启动', 'bt_danger', 'glyphicon-pause'],
					// 	],
				// },
				// type: 'status',
				template: function (row) {
					return '<a class="btlink '+ (row.run ? 'bt_success':'bt_danger') +' status_tips" data-project="'+ row.id +'" data-name="'+ row.name +'" data-type="'+ _that.tips.toLowerCase() +'" data-status="'+ row.run +'" href="javascript:;">\
						<span>'+ (row.run ? '运行中':'未启动') +'</span>\
						<span class="glyphicon '+ (row.run ? 'glyphicon-play':'glyphicon-pause') +'"></span>\
					</a>'
				},
				event: function (row, index, ev, key, that) {
					var status = row.run;
					bt.simple_confirm(
						{
							title: (status ? '停止项目' : '启动项目')+'【' + row.name + '】',
							msg: status
								? '停用项目后将无法正常访问项目，是否继续操作？'
								: '启用项目后，用户可以正常访问项目内容，是否继续操作？',
						},
						function (index) {
							layer.close(index);
							_that[status ? 'stopProject' : 'startProject'](
								{ project_name: row.name },
								function (res) {
									bt.msg({
										status: res.status,
										msg: res.data || res.error_msg,
									});
									that.$refresh_table_list(true);
								}
							);
						}
					);
				},
			},
      {
        fid: 'path',
        title: '根目录',
        width: 250,
        type: 'link',
        event:function(row,index,ev){
          openPath(row.path)
        },
      },{
        title: '<span style="display:flex"><span onclick="bt.soft.product_pay_view({ totalNum: 67, limit: \'ltd\', closePro: true })" class="firwall_place_of_attribution"></span>目录详情</span>',
        width:120,
        type: 'text',
        template:function(row,index,ev){
          return bt.files.dir_details_span(row.path);
        },
      },
      {
        fid: 'ps',
        title: '备注',
        type: 'input',
        blur: function (row, index, ev, key, that) {
          if (row.ps == ev.target.value) return false;
          bt.pub.set_data_ps(
            { id: row.id, table: 'sites', ps: ev.target.value },
            function (res) {
              bt_tools.msg(res, { is_dynamic: true });
            }
          );
        },
        keyup: function (row, index, ev) {
          if (ev.keyCode === 13) {
            $(this).blur();
          }
        },
      },
      {
        title: '操作',
        type: 'group',
        width: 100,
        align: 'right',
        group: [
          {
            title: '设置',
            event: function (row, index, ev, key, that) {
              _that.reanderProjectInfoView(row);
            },
          },
          {
            title: '删除',
            event: function (row, index, ev, key, that) {
              bt.input_confirm({
                  title: '删除项目 - [' + row.name + ']',
                  value: '删除项目',
                  msg: '<span class="color-org">风险操作，此操作不可逆</span>，删除' + _that.tips + '项目后您将无法管理该项目，是否继续操作？'},
                function () {
                  bt_tools.send({
                    url:'/project/net/remove_project',
                    data:{
                      project_name:row.name,
                    }
                  },function (res){
                    if(res!=null){
                      bt.msg({status:res.status,msg:res.msg})
                      site.model_table.$refresh_table_list(true);
                    }
                  },'删除项目')
                }
              );
            },
          },
        ],
      },
    ],
    // 渲染完成
    tootls: [
      {
        // 按钮组
        type: 'group',
        positon: ['left', 'top'],
        list: [
          {
            title: '添加' + _that.tips + '项目',
            active: true,
            event: function (ev) {
              _that.reanderAddProject(function (res) {
                site.model_table.$refresh_table_list(true);
              });
            },
          },
          {
            title: '.Net环境管理',
            event: function(){
              var name = 'dotnet';
              bt.send('get_soft_find','plugin/get_soft_find',{sName: name},function (rdata) {
                if (!rdata.setup) {
                  bt.soft.install(name);
                } else {
                  bt.soft.set_lib_config(name, rdata.title, rdata.version);
                }
              })
            }
          }
        ],
      },
      {
        // 搜索内容
        type: 'search',
        positon: ['right', 'top'],
        placeholder: '请输入项目名称或备注',
        searchParam: 'search', //搜索请求字段，默认为 search
        value: '', // 当前内容,默认为空
      },
      {
        // 批量操作
        type: 'batch', //batch_btn
        positon: ['left', 'bottom'],
        placeholder: '请选择批量操作',
        buttonValue: '批量操作',
        disabledSelectValue: '请选择需要批量操作的站点!',
        selectList: [
          {
            title: '设置分类',
            url: '/project/' + _that.type + '/set_project_site_type',
            paramName: 'site_ids', //列表参数名,可以为空
            paramId: 'type_id', // 需要传入批量的id
            refresh: true,
            beforeRequest: function (list) {
              var arry = [];
              $.each(list, function (index, item) {
                arry.push(item.id);
              });
              return JSON.stringify(arry);
            },
            confirm: {
              title: '批量设置分类',
              content:
                  '<div class="line"><span class="tname">站点分类</span><div class="info-r"><select class="bt-input-text mr5 site_types" name="site_types" style="width:150px"></select></span></div></div>',
              success: function () {
                bt_tools.send({url:'/project/' + _that.type + '/project_site_types'},function(res){
                  var html = '';
                  $.each(res, function (index, item) {
                    html += '<option value="' + item.id + '">' + item.name + '</option>';
                  });
                  $('[name="site_types"]').html(html);
                });
              },
              yes: function (index, layers, request) {
                request({ type_id: $('[name="site_types"]').val() });
              },
            },
            tips: false,
            success: function (res, list, that) {
              var html = '';
              $.each(list, function (index, item) {
                html += '<tr><td>' + item.name + '</td><td><div style="float:right;"><span style="color:' + (res.status ? '#20a53a' : 'red') + '">' + res.msg + '</span></div></td></tr>';
              });
              that.$batch_success_table({ title: '批量设置分类', th: '站点名称', html: html });
              that.$refresh_table_list(true);
            },
          },
          {
            title: '删除项目',
            url: '/project/net/remove_project',
            param: function (row) {
              return {
                  project_name: row.name,
              };
            },
            refresh: true,
            callback: function (that) {
              bt.prompt_confirm(
                '批量删除项目',
                '您正在删除选中的' + _that.tips + '，继续吗？',
                function () {
                  that.start_batch({}, function (list) {
                    var html = '';
                    for (var i = 0; i < list.length; i++) {
                      var item = list[i];
                      html +=
                        '<tr><td><span>' +
                        item.name +
                        '</span></td><td><div style="float:right;"><span style="color:' +
                        (item.requests.status ? '#20a53a' : 'red') +
                        '">' +
                        (item.requests.status
                          ? item.requests.msg
                          : item.requests.msg) +
                        '</span></div></td></tr>';
                    }
                    site.model_table.$batch_success_table({
                      title: '批量删除项目',
                      th: '项目名称',
                      html: html,
                    });
                    site.model_table.$refresh_table_list(true);
                  });
                }
              );
            },
          }
        ],
      },
      {
        //分页显示
        type: 'page',
        positon: ['right', 'bottom'], // 默认在右下角
        pageParam: 'p', //分页请求字段,默认为 : p
        page: 1, //当前分页 默认：1
        numberParam: 'limit',
        //分页数量请求字段默认为 : limit
        number: 20,
        //分页数量默认 : 20条
        numberList: [10, 20, 50, 100, 200], // 分页显示数量列表
        numberStatus: true, //　是否支持分页数量选择,默认禁用
        jump: true, //是否支持跳转分页,默认禁用
      },
    ],
    success: function () {
      if(site.model_table){
				var elTable = site.model_table.config.el
				if($(elTable+' .tootls_top .pull-left .bt-desired').length === 0){
					$(elTable+' .tootls_top .pull-left').append('<span class="bt-desired ml10" style="background-size:contain;"><a href="javascript:;" class="btlink ml5 npsFeedback">需求反馈</a></span>')
					// 网站nps入口
					$('.npsFeedback').on('click',function(){
						bt_tools.nps({name:'网站',type:14})
					})
				}
        site.init_project_type(_that.type)
			}
      // 服务状态事件
      // site.server_status_event()
      // 详情事件
      bt.files.dir_details()
    }
  });
};

/**
 * @description 获取添加项目配置
 */
CreateWebsiteModel.prototype.getAddProjectConfig = function (data) {
  var that = this,
    data = data || {},
    config = [
      {
        label: '项目名称',
        formLabelWidth: '110px',
        must: '*',
        group: [{
            type: 'text',
            name: 'project_name',
            width: '400px',
            placeholder: '请输' + that.tips + '项目名称',
            disabled: data.type != 'edit' ? false : true,
            verify: function (val) {
                if (val === '') {
                    bt.msg({ msg: '请输入项目名称', status: false });
                    return false;
                }
            },
        }],
    },
    {
      label: '运行路径',
      formLabelWidth: '110px',
      must: '*',
      group: [{
          type: 'text',
          width: '400px',
          value: '',
          name: 'project_path',
          placeholder: '项目的运行路径',
          disabled: data.type != 'edit' ? false : true,
          icon: {
              type: 'glyphicon-folder-open',
              select: 'dir',
              defaultPath: '/www/wwwroot',
              event: function (ev) {},
              callback: function (path) {
                  var pathList = path.split('/');
                  var fileName = pathList[pathList.length - 1] == '' ? pathList[pathList.length - 2] : pathList[pathList.length - 1];
                  this.config.form[1].group[0].value = path;
                  this.config.form[0].group[0].value = fileName.replace(/[^a-zA-Z0-9]/g, '_');
                  this.$replace_render_content(0);
                  this.$replace_render_content(1);
              },
          },
          verify: function (val) {
              if (val === '') {
                  bt.msg({ msg: '请选择项目运行文件', status: false });
                  return false;
              }
          },
      }],
  },
  {
    label: '启动命令',
    formLabelWidth: '110px',
    must: '*',
    group: {
      type: 'text',
      name: 'project_cmd',
      width: '400px',
      placeholder: '请输入项目的启动命令',
      value: '',
      verify: function (val) {
        if (val === '') {
          bt.msg({ msg: '请输入启动命令', status: false });
          return false;
        }
      },
      input: function (form, value, val, field) {
        if(form.project_cmd !== '') {
          form.port = form.project_cmd.match(/([0-9]*)$/)[0];
          val.config.form[3].group[0].value = form.port;
          val.$replace_render_content(3);
        }
      }
    },
  },
  {
    label: '项目端口',
    formLabelWidth: '110px',
    must: '*',
    group: [{
      type: 'number',
      name: 'port',
      class: 'port_input',
      width: '220px',
      placeholder: '请输入项目的真实端口',
      verify: function (val) {
        if (val === '') {
          bt.msg({ msg: '请输入项目端口', status: false });
          return false;
        }
      },
      change: function (form, value, val, field) {
        setTimeout(function () {//延迟校验端口,解决点击放行端口无效问题
          if(form.port !== '') {
            bt_tools.send({url:'/project/'+ that.type + '/' + 'advance_check_port',data:{port:form.port}},function(res){
              if (!res.status){
                $('.port_input').val('')
                bt_tools.msg({status:false,msg:res.msg})
              }
            },{load:'正在校验端口',verify:false})
          }
        },500)
      }
    },{
      type: 'checkbox',
      class: 'port_check',
      name: 'release_firewall',
      width: '220px',
      display: data.type == 'edit' ? false : true,
      title: '放行端口<a class="bt-ico-ask">?</a>'
    }],
  },
  {
    label: 'Net版本',
    formLabelWidth: '110px',
    group: [{
        type: 'select',
        name: 'dotnet_version',
        width: '150px',
        disabled: data.type != 'edit' ? false : true,
        value: that.netVindexOf != undefined ? that.netVindexOf : '',
        placeholder: '请选择Net版本',
        list: {
          url: '/project/net/GetNetVersion',
          dataFilter: function (res, that) {
            var list = [];
            for(var i=0;i<res.length;i++){
                list.push({title:res[i],value:res[i]});
            }
            return list;
          },
        },
        tips: '',
    },{
        type:'link',
        'class': 'mr5',
        title:'版本管理',
        event:function(){
          var name = 'dotnet';
          bt.send('get_soft_find','plugin/get_soft_find',{sName: name},function (rdata) {
            if (!rdata.setup) {
              bt.soft.install(name);
            } else {
              bt.soft.set_lib_config(name, rdata.title, rdata.version);
            }
          })
        }
    }]
  },
  {
    label: '开机启动',
    formLabelWidth: '110px',
    group: {
        type: 'checkbox',
        name: 'is_power_on',
        title: '是否开启启动项目（默认自带守护进程每120秒检测一次）',
    },
  },
  {
    label: '外网映射',
    formLabelWidth: '110px',
    group: {
        type: 'checkbox',
        name: 'bind_extranet',
        title: '是否开启外网映射',
    },
  },
  {
    label: '启动用户',
    formLabelWidth: '110px',
    group: {
        type: 'select',
        name: 'run_user',
        width: '150px',
        list: [
            { title: 'www', value: 'www' },
            { title: 'root', value: 'root' },
        ],
        disabled: data.type != 'edit' ? false : true,
    }
  },
  {
    label: '备注',
    formLabelWidth: '110px',
    group: {
      type: 'text',
      name: 'project_ps',
      width: '400px',
      placeholder: '请输入项目备注',
      value: '',
    },
  },
  ];

  if (data.type == 'edit') {
    config.push({
      formLabelWidth: '110px',
      group: {
        type: 'button',
        name: 'submitForm',
        title: '保存配置',
        event: function (fromData) {
          // 编辑项目
          fromData.is_power_on = fromData.is_power_on ? 1 : 0;
          if (parseInt(fromData.port) < 0 || parseInt(fromData.port) > 65535) return layer.msg('项目端口格式错误，可用范围：1-65535',{icon:2})
          that.modifyProject(fromData, function (res) {
            bt.msg({ status: res.status, msg: res.data });
            
            if(res.status) {
              var _sel = $('.site-menu p.bgw');
              if (_sel.length == 0) _sel = $('.proxy-menu p').eq(1);
              _sel.trigger('click');
              site.model_table.$refresh_table_list(true);
            }
          });
          // console.log(arguments, 'event');
        },
      },
    });
  }
  return config;
};

/**
 * @description 获取Net版本安装情况
 */
CreateWebsiteModel.prototype.getNetVersionData = function (callback) {
  var _this = this;
  this.getNetVersion({},function (res) {
      _this.netVersionList = res;
      _this.netVindexOf = res[0]
      if(callback) callback(res)
  })
}


/**
 * @description 渲染添加项目表单
 */
CreateWebsiteModel.prototype.reanderAddProject = function (callback) {
  var that = this;
  var modelForm = bt_tools.open({
    title: '添加' + this.tips + '项目',
    area: ['720px','590px'],
    btn: ['提交', '取消'],
    content: {
      class: 'pd30',
      formLabelWidth: '120px',
      form: (function () {
        return that.getAddProjectConfig();
      })(),
    },
    success: function (layers, index) {
      $(layers).find('.port_check .bt-ico-ask').hover(function () {
        layer.tips('选中将在防火墙安全组放行监听端口，放行后该项目可在外网访问', $(this), { tips: [2, '#555'],time: 0})
      },function () {
        layer.closeAll('tips')
      })
      var obj = { type: 1, cache: 0, proxyname: '', proxydir: '/', proxysite: 'http://', cachetime: 1, todomain: '$host', subfilter: [{ sub1: '', sub2: '' }] };
      var type = true;
      var sub_conter = '';
      if (typeof obj.subfilter === 'string') obj.subfilter = JSON.parse(obj.subfilter);
      for (var i = 0; i < obj.subfilter.length; i++) {
        if (i == 0 || obj.subfilter[i]['sub1'] != '') {
          sub_conter +=
            "<div class='sub-groud'>" +
            "<input name='rep" +
            ((i + 1) * 2 - 1) +
            "' class='bt-input-text mr10' placeholder='被替换的文本,可留空' type='text' style='width:200px' value='" +
            obj.subfilter[i]['sub1'] +
            "'>" +
            "<input name='rep" +
            (i + 1) * 2 +
            "' class='bt-input-text ml10' placeholder='替换为,可留空' type='text' style='width:200px' value='" +
            obj.subfilter[i]['sub2'] +
            "'>" +
            "<a href='javascript:;' class='proxy_del_sub' style='color:red;'>删除</a>" +
            '</div>';
        }
        if (i == 2) $('.add-replace-prosy').attr('disabled', 'disabled');
      }
    },
    yes: function (formData, indexs, layero) {
      formData.bind_extranet = formData.bind_extranet ? 1 : 0;
      formData.is_power_on = formData.is_power_on ? 1 : 0;
      bt_tools.send({
        url:'/project/net/create_project',
        data:formData
      },function (res){
        if(res!=null){
          bt.msg({
            status: res.status,
            msg: res.msg || res.error_msg || res.data,
          });
          layer.close(indexs);
          if (callback) callback(res);
        }
      },'添加项目')
    },
  });
};

/**
 * @description 模拟点击
 */
CreateWebsiteModel.prototype.simulatedClick = function (num) {
  $('.bt-w-menu p:eq(' + num + ')').click();
};


/**
 * @description
 * @param {string} name 站点名称
 */
CreateWebsiteModel.prototype.reanderProjectInfoView = function (row) {
	var that = this;
	bt.open({
		type: 1,
		title:
			this.tips + '项目管理-[' + row.name + ']，添加时间[' + row.addtime + ']',
		skin: 'model_project_dialog',
		area: ['800px', '770px'],
		content:
			'<div class="bt-tabs">' +
			'<div class="bt-w-menu site-menu pull-left"></div>' +
			'<div id="webedit-con" class="bt-w-con pd15" style="height:100%">' +
			'</div>' +
			'<div class="mask_module hide" style="left:110px;width: 690px;"><div class="node_mask_module_text">请开启<a href="javascript:;" class="btlink mapExtranet" onclick="site.node.simulated_click(2)"> 外网映射 </a>后查看配置信息</div></div>' +
			'</div>',
		btn: false,
		success: function (layers) {
			var $layers = $(layers),
				$content = $layers.find('#webedit-con');

			function reander_tab_list(config) {
				for (var i = 0; i < config.list.length; i++) {
					var item = config.list[i],
						tab = $(
							'<p class="' + (i === 0 ? 'bgw' : '') + '">' + item.title + '</p>'
						);
					$(config.el).append(tab);
					(function (i, item) {
						tab.on('click', function (ev) {
							$('.mask_module').addClass('hide');
							$(this).addClass('bgw').siblings().removeClass('bgw');
							if ($(this).hasClass('bgw')) {
								that.getProjectInfo({ project_name: row.name }, function (res) {
									config.list[i].event.call(that, $content, res, ev);
								});
							}
						});
						if (item.active) tab.click();
					})(i, item);
				}
			}
			reander_tab_list(
				{
					el: $layers.find('.bt-w-menu'),
					list: [
						{
							title: '项目配置',
							active: true,
							event: that.reanderProjectConfigView,
						},
						{
							title: '域名管理',
							event: that.reanderDomainManageView,
						},
						{
							title: '外网映射',
							event: that.reanderProjectMapView,
						},
            {
              title: '配置文件',
              event: that.renderFileConfigView,
            },
            { title: 'SSL', event: that.reanderProjectSslView },
						{
							title: '重定向',
							event: that.reander_project_redirect,
						},
						{
							title: '服务状态',
							event: that.renderServiceStatusView,
						},
						{
							title: '项目日志',
							event: that.renderProjectLogsView,
						},
            { title: '网站日志', event: that.reanderProjectLogView },
					],
				},
				function (config, i, ev) {}
			);
		},
	});
};
/**
 * @description 渲染项目配置文件
 * @param el {object} 当前element节点
 * @param row {object} 当前项目数据
 */
CreateWebsiteModel.prototype.renderFileConfigView = function (el, row) {
    el.empty();
    if (row.project_config.bind_extranet === 0) {
        $('.mask_module')
            .removeClass('hide')
            .find('.node_mask_module_text:eq(1)')
            .hide()
            .prev()
            .show();
        return false;
    }
    site.edit.set_config({ name: this.type + '_' + row.name });
};
/**
 * @description 项目SSL
 * @param el {object} 当前element节点
 * @param row {object} 当前项目数据
 */
CreateWebsiteModel.prototype.reanderProjectSslView = function (el, row) {
	el.empty();
	if (row.project_config.bind_extranet === 0) {
		$('.mask_module')
			.removeClass('hide')
			.find('.node_mask_module_text:eq(1)')
			.hide()
			.prev()
			.show();
		return false;
	}
	site.set_ssl({ name: row.name, ele: el, id: row.id });
	site.ssl.reload();
};
 /**
         * @description 项目重定向
         */
 CreateWebsiteModel.prototype.reander_project_redirect = function (el, row) {
	var _that = this;
	el.empty();
	if (row.project_config.bind_extranet === 0) {
			$('.mask_module').removeClass('hide').find('.node_mask_module_text:eq(1)').hide().prev().show();
			return false;
	}
	el.html(
			'<div>\
			<div id="website_redirect"></div>\
			<ul class="help-info-text c7">\
					<li>设置域名重定向后，该域名的404重定向将失效</li>\
			</ul>\
	</div>'
	);
	site.edit.redirect_table = bt_tools.table({
			el: '#website_redirect',
			url: '/project/'+ _that.type +'/get_project_redirect_list',
			param: { sitename: row.name },
			height: 500,
			dataFilter: function (res) {
					$.each(res, function (i, item) {
							if (!item.hasOwnProperty('errorpage')) {
									item.errorpage = 0;
							}
					});
					return { data: res };
			},
			column: [
					// { type: 'checkbox', width: 20 },
					{
							fid: 'sitename',
							title: '被重定向',
							type: 'text',
							width: 120,
							template: function (row, index) {
									var conter = '空';
									if (row.domainorpath == 'path' && row.errorpage !== 1) {
											conter = row.redirectpath || '空';
									} else {
											conter = row.redirectdomain ? row.redirectdomain.join('、') : '空';
									}
									return '<span style="width:100px;" title="' + conter + '">' + conter + '</span>';
							},
					},
					{
							fid: 'method',
							title: '重定向类型',
							type: 'text',
							width: 90,
							template: function (row, index) {
									var str = '';
									if (row.errorpage == 1) {
											str = '错误';
									} else if (row.domainorpath == 'path') {
											str = '路径';
									} else if (row.domainorpath == 'domain') {
											str = '域名';
									}
									return '<span>' + str + '</span>';
							},
					},
					{
							fid: 'path',
							title: '重定向到',
							type: 'text',
							template: function (row, index) {
									var path = row.tourl ? row.tourl : row.topath;
									return (
											'<span title="' +
											path +
											'" style="display: flex;">\
											<span class="size_ellipsis" style="flex: 1; width: 0;">' +
											(row.topath && path == '/' ? '首页' : path) +
											'</span>\
									</span>'
									);
							},
					},
					{
							fid: 'type',
							title: '状态',
							width: 70,
							config: {
									icon: true,
									list: [
											[1, '运行中', 'bt_success', 'glyphicon-play'],
											[0, '已停止', 'bt_danger', 'glyphicon-pause'],
									],
							},
							type: 'status',
							event: function (row, index, ev, key, that) {
									row.type = !row.type ? 1 : 0;
									row.redirectdomain = JSON.stringify(row['redirectdomain']);

									modify_node_refirect(row, function (res) {
											row.redirectdomain = JSON.parse(row['redirectdomain']);
											that.$modify_row_data({ status: row.type });
											bt.msg(res);
									});
							},
					},
					{
							title: '操作',
							width: 150,
							type: 'group',
							align: 'right',
							group: [
									{
											title: '配置文件',
											event: function (row, index, ev, key, that) {
													if(row.type == 0){
															return layer.msg('重定向已暂停',{icon:2})
													}
													var type = '';
													try {
															type = bt.get_cookie('serverType') || serverType;
													} catch (err) {}
													bt.open({
															type: 1,
															area: ['550px', '550px'],
															title: '编辑配置文件[' + row.redirectname + ']',
															closeBtn: 2,
															shift: 0,
															content:
																	'\
													<div class="bt-form pd15">\
															<p style="color: #666; margin-bottom: 7px">提示：Ctrl+F 搜索关键字，Ctrl+S 保存，Ctrl+H 查找替换</p>\
															<div id="redirect_config_con" class="bt-input-text ace_config_editor_scroll" style="height: 350px; line-height: 18px;"></div>\
															<button id="OnlineEditFileBtn" class="btn btn-success btn-sm" style="margin-top:10px;">保存</button>\
															<ul class="help-info-text c7">\
																	<li>此处为该负载均衡的配置文件，若您不了解配置规则,请勿随意修改。</li>\
															</ul>\
													"</div>',
															success: function (layers, indexs) {
																	bt_tools.send(
																			{ url: '/files?action=GetFileBody', data: { path: row.redirect_conf_file } },function (res) {
																					var editor = bt.aceEditor({
																							el: 'redirect_config_con',
																							content: res.data,
																							mode: 'nginx',
                                              path: row.redirect_conf_file,
																							// saveCallback: function (val) {
																							// 	bt.site.save_redirect_config({ path: rdata[1], data: val, encoding: rdata[0].encoding }, function (ret) {
																							// 		if (ret.status) {
																							// 			site.reload(11);
																							// 			layer.close(indexs);
																							// 		}
																							// 		bt.msg(ret);
																							// 	});
																							// },
																					});
																					$('#OnlineEditFileBtn').click(function () {
																							bt.saveEditor(editor);
																					});
																			})
															},
													});
											},
									},
									{
											title: '编辑',
											event: function (crow, index, ev, key, that) {
													node_refirect_301(row.name, row.id, crow);
											},
									},
									{
											title: '删除',
											event: function (row, index, ev, key, that) {
													bt_tools.send({url:'/project/'+ _that.type +'/remove_project_redirect',data:{sitename:row.sitename,redirectname:row.redirectname}},function(rdata){
															bt.msg(rdata);
															if (rdata.status) that.$delete_table_row(index);
													});
											},
									},
							],
					},
			],
			tootls: [
					{
							// 按钮组
							type: 'group',
							positon: ['left', 'top'],
							list: [
									{
											title: '添加重定向',
											active: true,
											event: function (ev) {
													node_refirect_301(row.name, row.id);
											},
									}
							],
					},
					// {
					// 	//批量操作
					// 	type: 'batch',
					// 	positon: ['left', 'bottom'],
					// 	placeholder: '请选择批量操作',
					// 	buttonValue: '批量操作',
					// 	disabledSelectValue: '请选择需要批量操作的任务!',
					// 	selectList: [
					// 		{
					// 			title: '启用重定向规则',
					// 			url: '/site?action=ModifyRedirect',
					// 			param: function (row) {
					// 				row.type = 1;
					// 				row.redirectdomain = JSON.stringify(row['redirectdomain']);
					// 				return row;
					// 			},
					// 			callback: function (that) {
					// 				bt.simple_confirm({ title: '批量启用重定向规则', msg: '批量启用当前选中的规则后，配置的重定向域名/目录将重新指向目标地址，是否继续操作？' }, function (index) {
					// 					layer.close(index);
					// 					var param = {};
					// 					that.start_batch(param, function (list) {
					// 						var html = '';
					// 						for (var i = 0; i < list.length; i++) {
					// 							var item = list[i];
					// 							var name = '';
					// 							if (item.domainorpath == 'path' && item.errorpage !== 1) {
					// 								name = item.redirectpath;
					// 							} else {
					// 								item.redirectdomain = JSON.parse(item.redirectdomain);
					// 								name = item.redirectdomain ? item.redirectdomain.join('、') : '空';
					// 							}
					// 							html +=
					// 								'<tr><td>' + name + '</td><td><div class="text-right"><span style="color:' + (item.request.status ? '#20a53a' : 'red') + '">' + item.request.msg + '</span></div></td></tr>';
					// 						}
					// 						site.edit.redirect_table.$batch_success_table({
					// 							title: '批量开启服务',
					// 							th: '被重定向',
					// 							html: html,
					// 						});
					// 						site.edit.redirect_table.$refresh_table_list(true);
					// 					});
					// 				});
					// 			},
					// 		},
					// 		{
					// 			title: '停用重定向规则',
					// 			url: '/site?action=ModifyRedirect',
					// 			param: function (row) {
					// 				row.type = 0;
					// 				row.redirectdomain = JSON.stringify(row['redirectdomain']);
					// 				return row;
					// 			},
					// 			callback: function (that) {
					// 				bt.simple_confirm({ title: '批量停用重定向规则', msg: '批量停用当前选中的规则后，配置的重定向域名/目录将指向源地址，是否继续操作？' }, function (index) {
					// 					layer.close(index);
					// 					var param = {};
					// 					that.start_batch(param, function (list) {
					// 						var html = '';
					// 						for (var i = 0; i < list.length; i++) {
					// 							var item = list[i];
					// 							var name = '';
					// 							if (item.domainorpath == 'path' && item.errorpage !== 1) {
					// 								name = item.redirectpath;
					// 							} else {
					// 								item.redirectdomain = JSON.parse(item.redirectdomain);
					// 								name = item.redirectdomain ? item.redirectdomain.join('、') : '空';
					// 							}
					// 							html +=
					// 								'<tr><td>' + name + '</td><td><div class="text-right"><span style="color:' + (item.request.status ? '#20a53a' : 'red') + '">' + item.request.msg + '</span></div></td></tr>';
					// 						}
					// 						site.edit.redirect_table.$batch_success_table({
					// 							title: '批量停止服务',
					// 							th: '被重定向',
					// 							html: html,
					// 						});
					// 						site.edit.redirect_table.$refresh_table_list(true);
					// 					});
					// 				});
					// 			},
					// 		},
					// 		{
					// 			title: '删除重定向规则',
					// 			url: '/site?action=del_redirect_multiple',
					// 			// param: { site_id: web.id },
					// 			// paramId: 'redirectname',
					// 			// paramName: 'redirectnames',
					// 			// theadName: '重定向名称',
					// 			// confirmVerify: false, // 是否提示验证方式
					// 			// refresh: true,
					// 			param: function (row) {
					// 				return {
					// 					site_id: web.id,
					// 					redirectnames: row.redirectname,
					// 				};
					// 			},
					// 			callback: function (that) {
					// 				bt.simple_confirm(
					// 					{
					// 						title: '批量删除重定向规则',
					// 						msg: '批量删除当前选中的规则后，配置的重定向域名/目录将会彻底失效，是否继续操作？',
					// 					},
					// 					function (index) {
					// 						layer.close(index);
					// 						var param = {};
					// 						that.start_batch(param, function (list) {
					// 							var html = '';
					// 							for (var i = 0; i < list.length; i++) {
					// 								var item = list[i];
					// 								var name = '';
					// 								if (item.domainorpath == 'path' && item.errorpage !== 1) {
					// 									name = item.redirectpath;
					// 								} else {
					// 									name = item.redirectdomain ? item.redirectdomain.join('、') : '空';
					// 								}
					// 								html +=
					// 									'<tr><td>' +
					// 									name +
					// 									'</td><td><div class="text-right"><span style="color:' +
					// 									(item.request.status ? '#20a53a' : 'red') +
					// 									'">' +
					// 									(item.request.status ? '删除成功' : '删除失败') +
					// 									'</span></div></td></tr>';
					// 							}
					// 							site.edit.redirect_table.$batch_success_table({
					// 								title: '批量删除操作完成！',
					// 								th: '被重定向',
					// 								html: html,
					// 							});
					// 							site.edit.redirect_table.$refresh_table_list(true);
					// 						});
					// 					}
					// 				);
					// 			},
					// 		},
					// 	],
					// },
			],
	});
	function modify_node_refirect(obj,callback){
			bt_tools.send({url:'/project/'+ _that.type +'/modify_project_redirect',data:obj},function(res){
					if(callback) callback(res)
			},'设置重定向')
	}
	function node_refirect_301(sitename, id, nrow){
			var isEdit = !!nrow;
			var form = isEdit
					? nrow
					: {
							redirectname: new Date().valueOf(),
							tourl: 'http://',
							redirectdomain: [],
							redirectpath: '',
							redirecttype: '',
							type: 1,
							domainorpath: 'domain',
							holdpath: 1,
					};
			var helps = [
					'重定向类型：表示访问选择的“域名”或输入的“路径”时将会重定向到指定URL',
					'目标URL：可以填写你需要重定向到的站点，目标URL必须为可正常访问的URL，否则将返回错误',
					'重定向方式：使用301表示永久重定向，使用302表示临时重定向',
					'保留URI参数：表示重定向后访问的URL是否带有子路径或参数如设置访问http://b.com 重定向到http://a.com',
					'保留URI参数：  http://b.com/1.html ---> http://a.com/1.html',
					'不保留URI参数：http://b.com/1.html ---> http://a.com',
			];
			bt_tools.send({url:'/project/'+ _that.type +'/project_get_domain',data:{data:JSON.stringify({project_name:sitename})}},function(rdata){

					var flag = true;
					var domain_html = '';
					var select_list = [];
					var table_data = site.edit.redirect_table.data;
					for (var i = 0; i < rdata.length; i++) {
							flag = true;
							for (var j = 0; j < table_data.length; j++) {
									var con1 = site.edit.get_list_equal(table_data[j].redirectdomain, rdata[i].name);
									var con2 = !site.edit.get_list_equal(form.redirectdomain, rdata[i].name);
									if (con1 && con2) {
											flag = false;
											break;
									}
							}
							if (flag) {
									select_list.push(rdata[i]);
									var selected = site.edit.get_list_equal(form.redirectdomain, rdata[i].name);
									domain_html += '<li ' + (selected ? 'class="selected"' : '') + '><a><span class="text">' + rdata[i].name + '</span><span class="glyphicon glyphicon-ok check-mark"></span></a></li>';
							}
					}
					if (!domain_html) {
							domain_html = '<div style="padding: 14px 0; color: #999; text-align: center; font-size: 12px;">暂无域名可选</div>';
					}

					var content =
							'<style>select.bt-input-text { width: 100px; }</style>\
					<div id="form_redirect" class="bt-form-new pd20">\
							<div class="form-inline">\
									<div class="form-item">\
											<div class="form-label">开启重定向</div>\
											<div class="form-value">\
													<input class="btswitch btswitch-ios" id="type" type="checkbox" name="type" checked />\
													<label class="btswitch-btn phpmyadmin-btn" for="type"></label>\
											</div>\
									</div>\
									<div class="form-item">\
											<div class="form-label">保留URI参数</div>\
											<div class="form-value">\
													<input class="btswitch btswitch-ios" id="holdpath" type="checkbox" name="holdpath" checked />\
													<label class="btswitch-btn phpmyadmin-btn" for="holdpath"></label>\
											</div>\
									</div>\
							</div>\
							<div class="form-inline">\
									<div class="form-item">\
											<div class="form-label">重定向类型</div>\
											<div class="form-value">\
													<select class="bt-input-text" name="domainorpath">\
															<option value="domain">域名</option>\
															<option value="path">路径</option>\
													</select>\
											</div>\
									</div>\
									<div class="form-item">\
											<div class="form-label" style="width: 90px;">重定向方式</div>\
											<div class="form-value">\
													<select class="bt-input-text" style="width: 150px;" name="redirecttype">\
															<option value="301">301（永久重定向）</option>\
															<option value="302">302（临时重定向）</option>\
													</select>\
											</div>\
									</div>\
							</div>\
							<div class="form-inline redirectdomain" style="flex-wrap: nowrap;">\
									<div class="form-item">\
											<div class="form-label">重定向域名</div>\
											<div class="form-value">\
													<div class="btn-group bootstrap-select show-tick redirect_domain" style="width: 200px;">\
															<button type="button" class="btn dropdown-toggle btn-default" style="height: 32px; line-height: 18px; font-size: 12px">\
																	<span class="filter-option pull-left"></span>\
																	<span class="bs-caret"><span class="caret"></span></span>\
															</button>\
															<div class="dropdown-menu open">\
																	<div class="bs-actionsbox">\
																			<div class="btn-group btn-group-sm btn-block">\
																					<button type="button" class="actions-btn bs-select-all btn btn-default">全选</button>\
																					<button type="button" class="actions-btn bs-deselect-all btn btn-default">取消全选</button>\
																			</div>\
																	</div>\
																	<div class="dropdown-menu inner">' +
							domain_html +
							'</div>\
															</div>\
													</div>\
											</div>\
									</div>\
									<div class="form-item">\
											<div class="form-label" style="width: 80px;">目标URL</div>\
											<div class="form-value">\
													<input class="bt-input-text" name="tourl" type="text" style="width: 200px;" value="http://" />\
											</div>\
									</div>\
							</div>\
							<div class="form-inline redirectpath" style="display: none; flex-wrap: nowrap;">\
									<div class="form-item">\
											<div class="form-label">重定向路径</div>\
											<div class="form-value">\
													<input class="bt-input-text" name="redirectpath" placeholder="如: http://' +
							sitename +
							' " type="text" style="width: 200px;" />\
											</div>\
									</div>\
									<div class="form-item">\
											<div class="form-label" style="width: 80px;">目标URL</div>\
											<div class="form-value">\
													<input class="bt-input-text" name="tourl1" type="text" style="width: 200px;" value="http://" />\
											</div>\
									</div>\
							</div>\
							<div style="height: 15px;"></div>\
							' +
							bt.render_help(helps) +
							'\
					</div>';
					var redirectdomain = form.redirectdomain;

					var form_redirect = bt.open({
							type: 1,
							skin: 'demo-class',
							area: '650px',
							title: !isEdit ? '添加重定向' : '修改重定向',
							closeBtn: 2,
							shift: 5,
							shadeClose: false,
							btn: ['提交', '取消'],
							content: content,
							success: function () {
									var show_domain_name = function () {
											var text = '';
											if (redirectdomain.length > 0) {
													text = [];
													for (var i = 0; i < redirectdomain.length; i++) {
															text.push(redirectdomain[i]);
													}
													text = text.join(', ');
											} else {
													text = '请选择站点';
											}
											$('.redirect_domain .btn .filter-option').text(text);
									};

									show_domain_name();

									$('.redirect_domain .btn').click(function (e) {
											var $parent = $(this).parent();
											$parent.toggleClass('open');
											$(document).one('click', function () {
													$parent.removeClass('open');
											});
											e.stopPropagation();
									});

									// 单选
									$('.redirect_domain .dropdown-menu li').click(function (e) {
											var $this = $(this);
											var index = $this.index();
											var name = select_list[index].name;
											$this.toggleClass('selected');
											if ($this.hasClass('selected')) {
													redirectdomain.push(name);
											} else {
													var remove_index = -1;
													for (var i = 0; i < redirectdomain.length; i++) {
															if (redirectdomain[i] == name) {
																	remove_index = i;
																	break;
															}
													}
													if (remove_index != -1) {
															redirectdomain.splice(remove_index, 1);
													}
											}
											show_domain_name();
											e.stopPropagation();
									});

									// 全选
									$('.redirect_domain .bs-select-all').click(function () {
											redirectdomain = [];
											for (var i = 0; i < select_list.length; i++) {
													redirectdomain.push(select_list[i].name);
											}
											$('.redirect_domain .dropdown-menu li').addClass('selected');
											show_domain_name();
									});

									// 取消全选
									$('.redirect_domain .bs-deselect-all').click(function () {
											redirectdomain = [];
											$('.redirect_domain .dropdown-menu li').removeClass('selected');
											show_domain_name();
									});

									// 重定向类型
									$('[name="domainorpath"]').change(function () {
											var path = $(this).val();
											$('.redirect_domain .bs-deselect-all').click();
											$('[name="redirectpath"]').val('');
											$('.redirectpath, .redirectdomain').hide();
											switch (path) {
													case 'path':
															$('.redirectpath').show();
															break;
													case 'domain':
															$('.redirectdomain').show();
															break;
											}
									});

									if (isEdit) {
											$('[name="type"]').prop('checked', form.type == 1);
											$('[name="holdpath"]').prop('checked', form.holdpath == 1);
											$('[name="domainorpath"]').val(form.domainorpath);
											$('[name="redirecttype"]').val(form.redirecttype);
											$('[name="' + (form.domainorpath == 'path' ? 'tourl1' : 'tourl') + '"]').val(form.tourl);
											$('[name="redirectpath"]').val(form.redirectpath);
											$('.redirectpath, .redirectdomain').hide();
											switch (form.domainorpath) {
													case 'path':
															$('.redirectpath').show();
															break;
													case 'domain':
															$('.redirectdomain').show();
															break;
											}
									}

									$('#form_redirect').parent().css('overflow', 'inherit');
							},
							yes: function () {
									form.type = $('[name="type"]').prop('checked') ? 1 : 0;
									form.holdpath = $('[name="holdpath"]').prop('checked') ? 1 : 0;
									form.redirecttype = $('[name="redirecttype"]').val();
									form.domainorpath = $('[name="domainorpath"]').val();
									form.redirectpath = $('[name="redirectpath"]').val();
									form.tourl = $('[name="' + (form.domainorpath == 'path' ? 'tourl1' : 'tourl') + '"]').val();
									form.redirectdomain = JSON.stringify(redirectdomain);
									bt_tools.send({url:'/project/'+ _that.type +'/'+(isEdit?'modify':'create')+'_project_redirect',data:$.extend(form,{sitename: sitename})},function(rdata){
											if (rdata.status) {
													form_redirect.close();
													site.edit.redirect_table.$refresh_table_list();
											}
											bt.msg(rdata);
									})
							},
					});

			},'获取域名列表')
	}
};

/**
 * @description 项目SSL
 * @param el {object} 当前element节点
 * @param row {object} 当前项目数据
 */
CreateWebsiteModel.prototype.reanderProjectLogView = function (el, row) {
	el.empty();
	if (row.project_config.bind_extranet === 0) {
		$('.mask_module')
			.removeClass('hide')
			.find('.node_mask_module_text:eq(1)')
			.hide()
			.prev()
			.show();
		return false;
	}
	site.edit.get_site_logs({ name: row.name, ele: el, id: row.id });
	site.ssl.reload();
};

// /**
//  * @description
//  * @param {string} name 站点名称
//  */
// CreateWebsiteModel.prototype.reanderProjectInfoView = function (row) {
//   var that = this;
//   var item = row;
//   bt.open({
//     type: 1,
//     area: ['836px', '725px'],
//     title: lan.site.website_change + '[' + item.name + ']  --  ' + lan.site.addtime + '[' + item.addtime + ']',
//     closeBtn: 2,
//     shift: 0,
//     content:
//       "<div class='bt-tabs'>\
//         <div class='bt-w-menu proxy-menu pull-left' style='height: 100%;width: 126px;'></div>\
//         <div id='webedit-con' class='bt-w-con webedit-con pd15' style='margin-left: 126px;'></div>\
//       </div>",
//   });
//   setTimeout(function () {
//     // var webcache = bt.get_cookie('serverType') == 'openlitespeed' ? { title: 'LS-Cache', callback: site.edit.ols_cache } : '';
//     var menus = [
//       { title: '项目配置', callback: CreateWebsiteModel.prototype.reanderProjectConfigView},
//       { title: '域名管理', callback: CreateWebsiteModel.prototype.set_domains },
//       { title: '服务状态', callback: CreateWebsiteModel.prototype.renderServiceStatusView },
//       { title: '外网映射', callback: CreateWebsiteModel.prototype.renderProjectMapView },
//       { title: '项目日志', callback: CreateWebsiteModel.prototype.renderProjectLogsView },
//     ];
//     // if (webcache !== '') menus.splice(3, 0, webcache);
//     for (var i = 0; i < menus.length; i++) {
//       var men = menus[i];
//       var _p = $('<p>' + men.title + '</p>');
//       _p.data('callback', men.callback);
//       $('.proxy-menu').append(_p);
//     }
//     $('.proxy-menu p').css('padding-left', '36px');
//     $('.proxy-menu p').click(function () {
//       $('#webedit-con').html('');
//       $(this).addClass('bgw').siblings().removeClass('bgw');
//       var callback = $(this).data('callback');
//       if (callback) callback(item);
//     });
//     var _sel = $('.site-menu p.bgw');
//     if (_sel.length == 0) _sel = $('.proxy-menu p').eq(0);
//     _sel.trigger('click');
//   }, 100);
// };
// /**
//  * @description 渲染项目外网映射
//  * @param el {object} 当前element节点
//  * @param row {object} 当前项目数据
//  */
// CreateWebsiteModel.prototype.renderProjectMapView = function (row) {
//   var el = $('#webedit-con');
//   var that = this;
//   el.html(
//       '<div class="pd15"><div class="ss-text mr50" style="display: block;height: 35px;">' +
//       '   <em title="外网映射">外网映射</em>' +
//       '       <div class="ssh-item">' +
//       '           <input class="btswitch btswitch-ios" id="model_project_map" type="checkbox">' +
//       '           <label class="btswitch-btn" for="model_project_map" name="model_project_map"></label>' +
//       '       </div>' +
//       '</div><ul class="help-info-text c7"><li>如果您的是HTTP项目，且需要外网通过80/443访问，请开启外网映射</li><li>开启外网映射前，请到【域名管理】中至少添加1个域名</li></ul></div>'
//   );
//   $('#model_project_map').attr(
//       'checked',
//       row['project_config']['bind_extranet'] ? true : false
//   );
//   $('[name=model_project_map]').click(function () {
//       var _check = $('#model_project_map').prop('checked'),
//           param = { project_name: row.name };
//       if (!_check) param['domains'] = row['project_config']['domains'];
//       layer.confirm(
//           (!_check ? '开启外网映射后，可以通过绑定域名进行访问' : '关闭外网映射后，已绑定域名将取消关联访问') + '，是否继续操作？',
//           {
//               title: '外网映射',
//               icon: 0,
//               closeBtn: 2,
//               cancel: function () {
//                   $('#model_project_map').prop('checked', _check);
//               },
//           },
//           function () {
//             bt_tools.send({url: '/project/net/'+ (_check ? 'unbind_extranet' : 'bind_extranet'),data:param},function (res){
//               if (!res.status) $('#model_project_map').prop('checked', _check);
//               bt.msg({
//                   status: res.status,
//                   msg: res.msg || res.error_msg || res.data,
//               });
//               row['project_config']['bind_extranet'] = _check ? 0 : 1;
//             },{verify:false});
//           },
//           function () {
//             $('#model_project_map').prop('checked', _check);
//           }
//       );
//   });
// };
/**
 * @description 渲染项目服务状态
 * @param el {object} 当前element节点
 * @param row {object} 当前项目数据
 */
CreateWebsiteModel.prototype.renderServiceStatusView = function (el,row) {
  var _this = this
  bt_tools.send({url: '/project/net/get_project_run_state',data:{project_name:row.name}},function (run){
    var arry = [
      { title: '启动', event: _this.startProject, fun: 'start_project' },
      { title: '停止', event: _this.stopProject, fun: 'stop_project' },
      { title: '重启', event: _this.restartProject, fun: 'restart_project' },
    ],
    html = $(
      '<div class="soft-man-con bt-form"><p class="status"></p><div class="sfm-opt"></div>\
      <div class="run_setting flex ptb20 mt20 align-center" style="border-top: 1px dashed #EBEEF5;">\
              <span style="margin-right:10px;font-size:14px">项目定时重启：</span>\
              <div class="outer_state_alert">\
                <input class="btswitch btswitch-ios isRunStop" data-type="node" type="checkbox" id="isRunStop">\
                <label class="btswitch-btn" for="isRunStop"></label>\
              </div>\
              <span class="btlink runStopSet" data-type="node" style="margin-left:10px;font-size:14px">定时重启设置</span>\
            </div>\
      </div>'
    )
    bt.timingRestartProject({name: row.name,type: _this.type})
    // <div id="alert_setting">\
    //   <span style="margin-right:10px;font-size:14px">项目异常停止时提醒我:</span>\
    //   <div class="outer_state_alert">\
    //     <input class="btswitch btswitch-ios isServerStop" data-project="'+ row.id +'" data-name="'+ row.name +'" data-status="'+ row.run +'" data-type="'+ _this.tips.toLowerCase() +'" type="checkbox" id="is'+ _this.tips +'Stop"><label class="btswitch-btn" for="is'+ _this.tips +'Stop"></label>\
    //   </div>\
    //   <span class="btlink serverStopSet" data-project="'+ row.id +'" data-name="'+ row.name +'" data-status="'+ row.run +'" data-type="'+ _this.tips.toLowerCase() +'" style="margin-left:10px;font-size:14px">告警设置</span>\
    // </div>\
    function reander_service(status) {
      var status_info = status
          ? ['开启', '#20a53a', 'play']
          : ['停止', 'red', 'pause'];
      return (
          '当前状态：<span>' +
          status_info[0] +
          '</span><span style="color:' +
          status_info[1] +
          '; margin-left: 3px;" class="glyphicon glyphicon glyphicon-' +
          status_info[2] +
          '"></span>'
      );
    }
    html.find('.status').html(reander_service(run));
    el.html(html);
    for (var i = 0; i < arry.length; i++) {
      var item = arry[i],
          btn = $('<button class="btn btn-default btn-sm"></button>');
      (function (btn, item, indexs) {
          !(run && indexs === 0) || btn.addClass('hide');
          !(!run && indexs === 1) || btn.addClass('hide');
          btn.on('click', function () {
                  bt.simple_confirm(
                      {
                          title: item.title +'.Net项目【' + row.name + '】',
                          msg: item.title + '项目后'+ (item.title === '停止' ? '将无法正常访问项目' : (item.title === '启动' ? '，用户可以正常访问项目内容' : '将重新加载项目')) + '，是否继续操作？',
                      },
                      function () {
                        bt_tools.send({url:  '/project/net/'+ item.fun,data:{project_name:row.name}},function (res){
                          bt.msg({ status: res.status, msg: res.msg || res.error_msg || res.data });
                          if(res.status) {
                            var _sel = $('.site-menu p.bgw');
                            if (_sel.length == 0) _sel = $('.proxy-menu p').eq(1);
                            _sel.trigger('click');
                            site.model_table.$refresh_table_list(true);
                          }
                        }, '设置服务状态')
                      }
                  );
              })
              .text(item.title);
      })(btn, item, i);
      el.find('.sfm-opt').append(btn);
    }
  }, {verify:false})
  
};

/**
 * @description 渲染项目日志
 * @param el {object} 当前element节点
 * @param row {object} 当前项目数据
 */
CreateWebsiteModel.prototype.renderProjectLogsView = function (el, row) {
  var that = this,
      _config = row.project_config,
      log_config = '<div class="model_project_log_config" style="margin-bottom: 15px;">\
  日志路径 <input type="text" name="model_log_path" id="model_log_path" value="" placeholder="项目日志路径" class="bt-input-text mr10" style="width:350px" />\
  <span class="glyphicon glyphicon-folder-open cursor mr10" onclick="bt.select_path(\'model_log_path\',\'dir\')"></span>\
  <button class="btn btn-success btn-sm" name="submitLogConfig">保存</button>\
  </div>'
  el.html(log_config+'<div class="model_project_log"></div>');
  $('[name=model_log_level]').val(_config.loglevel);
  bt_tools.send({url:'/project/net/get_project_log',data:{project_name:row.name}},function (res){
    $('#webedit-con .model_project_log').html(
      '<div class="mb15">日志大小<span class="ml10">'+ res.size +'</span></div><pre class="command_output_pre" style="height:500px;">' +
      (typeof res == 'object' ? res.data || '暂无日志信息' : res) +
      '</pre>'
    );
    $('[name=model_log_path]').val(res.path);
    bt_tools.send({url:'/project/net/get_log_split',data: { project_name: row.name }},function (rdata){
      var html = '',configInfo = {}
      if(rdata.status) configInfo = rdata.data
      html = '开启后' + (rdata.status ? rdata.data.log_size ? '日志文件大小超过'+ bt.format_size(rdata.data.log_size,true,2,'MB') +'时进行切割日志文件' : '每天'+ rdata.data.hour +'点' + rdata.data.minute + '分进行切割日志文件' : '默认每天2点0分进行切割日志文件')
      $('#webedit-con .model_project_log .command_output_pre').before('<div class="inlineBlock log-split mb20" style="line-height: 32px;">\
      <label>\
        <div class="bt-checkbox '+ (rdata.status && rdata.data.status ? 'active':'') +'"></div>\
        <span>日志切割</span>\
      </label>\
      <span class="unit">'+html+'，如需修改请点击<a href="javascript:;" class="btlink mamger_log_split">编辑配置</a></span>\
      </div>')
      $('#webedit-con .model_project_log .log-split').hover(function(){
        layer.tips('当日志文件过大时，读取和搜索时间会增加，同时也会占用存储空间，因此需要对日志进行切割以方便管理和维护。', $(this), {tips: [3, '#20a53a'], time: 0});
      },function(){
        layer.closeAll('tips');
      })
      $('#webedit-con .model_project_log label').click(function(){
        if(rdata['is_old']){
            bt_tools.msg(rdata)
            return;
        }
        bt.confirm({title:'设置日志切割任务',msg: !rdata.status || (rdata.status && !rdata.data.status) ? '开启后对该项目日志进行切割，是否继续操作？' : '关闭后将无法对该项目日志进行切割，是否继续操作？'},function(){
          if(rdata.status){
            bt_tools.send({url:'/project/net/set_log_split',data:{project_name: row.name}},function(res){
              bt_tools.msg(res)
              if(res.status) {
                var _sel = $('.site-menu p.bgw');
                if (_sel.length == 0) _sel = $('.proxy-menu p').eq(1);
                _sel.trigger('click');
              }
            },'设置日志切割任务')
          }else{
            bt_tools.send({url:'/project/net/mamger_log_split',data:{project_name: row.name}},function(res){
              bt_tools.msg(res)
              if(res.status) {
                var _sel = $('.site-menu p.bgw');
                if (_sel.length == 0) _sel = $('.proxy-menu p').eq(1);
                _sel.trigger('click');
              }
            },'设置日志切割任务')
          }
        })
      })
      $('.mamger_log_split').click(function(){
        if(rdata['is_old']){
            bt_tools.msg(rdata)
            return;
        }
        bt_tools.open({
          type: 1,
          area: '460px',
          title: '配置日志切割任务',
          closeBtn: 2,
          btn: ['提交', '取消'],
          content: {
            'class': 'pd20 mamger_log_split_box',
            form: [{
              label: '执行时间',
              group: [{
                type: 'text',
                name: 'day',
                width: '44px',
                value: '每天',
                disabled: true
              },{
                type: 'number',
                name: 'hour',
                'class': 'group',
                width: '70px',
                value: configInfo.hour || '2',
                unit: '时',
                min: 0,
                max: 23
              }, {
                type: 'number',
                name: 'minute',
                'class': 'group',
                width: '70px',
                min: 0,
                max: 59,
                value: configInfo.minute || '0',
                unit: '分'
              }]
            },{
              label: '日志大小',
              group:{
                type: 'text',
                name: 'log_size',
                width: '210px',
                value: configInfo.log_size ? bt.format_size(configInfo.log_size,true,2,'MB').replace(' MB','') : '',
                unit: 'MB',
                placeholder: '请输入日志大小',
              }
            }, {
              label: '保留最新',
              group:{
                type: 'number',
                name: 'num',
                'class': 'group',
                width: '70px',
                value: configInfo.num || '180',
                unit: '份'
              }
            },
            {
                label: '',
                group: [
                    {
                        type: 'checkbox',
                        name: 'compress',
                        title: '切割后压缩日志',
                        value: configInfo.compress,
                    },
                ],
            },]
          },
          success: function (layero, index) {
            $(layero).find('.mamger_log_split_box .bt-form').prepend('<div class="line">\
            <span class="tname">切割方式</span>\
            <div class="info-r">\
              <div class="replace_content_view" style="line-height: 32px;">\
                <div class="checkbox_config">\
                  <i class="file_find_radio '+ (configInfo.log_size ? 'active' : '') +'"></i>\
                  <span class="laberText" style="font-size: 12px;">按日志大小</span>\
                </div>\
                <div class="checkbox_config">\
                  <i class="file_find_radio '+ (configInfo.log_size > 0 ? '' : 'active') +'"></i>\
                  <span class="laberText" style="font-size: 12px;">按执行时间</span>\
                </div>\
              </div>\
            </div>')
            $(layero).find('.mamger_log_split_box .bt-form').append('<div class="line"><div class=""><div class="inlineBlock  "><ul class="help-info-text c7"><li>每5分钟执行一次</li><li>【日志大小】：日志文件大小超过指定大小时进行切割日志文件</li><li>【保留最新】：保留最新的日志文件，超过指定数量时，将自动删除旧的日志文件</li></ul></div></div></div>')
            $(layero).find('.replace_content_view .checkbox_config').click(function(){
              var index = $(this).index()
              $(this).find('i').addClass('active').parent().siblings().find('i').removeClass('active')
              if(index){
                $(layero).find('[name=hour]').parent().parent().parent().show()
                $(layero).find('[name=log_size]').parent().parent().parent().hide()
                $(layero).find('.help-info-text li').eq(0).hide().next().hide()
              }else{
                $(layero).find('[name=hour]').parent().parent().parent().hide()
                $(layero).find('[name=log_size]').parent().parent().parent().show()
                $(layero).find('.help-info-text li').eq(0).show().next().show()
              }
            })
            if(configInfo.log_size) {
              $(layero).find('[name=hour]').parent().parent().parent().hide()
            }else{
              $(layero).find('[name=log_size]').parent().parent().parent().hide()
              $(layero).find('.help-info-text li').eq(0).hide().next().hide()
            }
            $(layero).find('[name=log_size]').on('input', function(){
              if($(this).val() < 1 || !bt.isInteger(parseFloat($(this).val()))) {
                layer.tips('请输入日志大小大于0的的整数', $(this), { tips: [1, 'red'], time: 2000 })
              }
            })
            $(layero).find('[name=hour]').on('input', function(){
              if($(this).val() > 23 || $(this).val() < 0 || !bt.isInteger(parseFloat($(this).val()))) {
                layer.tips('请输入小时范围0-23的整数时', $(this), { tips: [1, 'red'], time: 2000 })
              }
              $(layero).find('.hour').text($(this).val())
            })
            $(layero).find('[name=minute]').on('input', function(){
              if($(this).val() > 59 || $(this).val() < 0 || !bt.isInteger(parseFloat($(this).val()))) {
                layer.tips('请输入正确分钟范围0-59分的整数', $(this), { tips: [1, 'red'], time: 2000 })
              }
              $(layero).find('.minute').text($(this).val())
            })
            $(layero).find('[name=num]').on('input', function(){
              if($(this).val() < 1 || $(this).val() > 1800 || !bt.isInteger(parseFloat($(this).val()))) {
                layer.tips('请输入保留最新范围1-1800的整数', $(this), { tips: [1, 'red'], time: 2000 })
              }
            })
          },
          yes: function (formD,indexs) {
            formD['project_name'] = row.name
            delete formD['day']
            if($('.mamger_log_split_box .file_find_radio.active').parent().index()) {
              if (formD.hour < 0 || formD.hour > 23 || isNaN(formD.hour) || formD.hour === '' || !bt.isInteger(parseFloat(formD.hour))) return layer.msg('请输入小时范围0-23时的整数')
              if (formD.minute < 0 || formD.minute > 59 || isNaN(formD.minute) || formD.minute === '' || !bt.isInteger(parseFloat(formD.minute))) return layer.msg('请输入正确分钟范围0-59分的整数')
              formD['log_size'] = 0
            }else{
              if(formD.log_size == '' || !bt.isInteger(parseFloat(formD.log_size))) return layer.msg('请输入日志大小大于0的的整数')
            }
            if(formD.num < 1 || formD.num > 1800 || !bt.isInteger(parseFloat(formD.num))) return layer.msg('请输入保留最新范围1-1800的整数')
        formD.compress = formD.compress ? 1 : 0;
            if(!rdata.status || (rdata.status && !rdata.data.status)) {
              if(rdata.status){
                bt_tools.send({url: '/project/net/set_log_split',data: {project_name: row.name}},function(res){
                  if(res.status) {
                    pub_open()
                  }
                }, '设置日志切割')
              }else{
                pub_open()
              }
            }else{
              pub_open()
            }
            function pub_open() {
              bt_tools.send({url: '/project/net/mamger_log_split',data: formD},function(res){
                bt.msg(res)
                if(res.status) {
                  var _sel = $('.site-menu p.bgw');
                  if (_sel.length == 0) _sel = $('.proxy-menu p').eq(1);
                  _sel.trigger('click');
                  layer.close(indexs)
                }
              }, '配置日志切割任务')
            }
          }
        })
      })
    },{verify:false})
    $('.command_output_pre').scrollTop(
        $('.command_output_pre').prop('scrollHeight')
    );
  }, {verify:false})
  // 保存按钮
  $('[name=submitLogConfig]').click(function () {
      var logpath = $('[name=model_log_path]').val(),
          loglevel = $('[name=model_log_level]').val(),
          param  = { name: row.name, data:{logpath: logpath} };
      if (!logpath) {
          bt.msg({ status: false, msg: '日志路径不能为空' });
          return;
      }
      //gunicorn时才有日志级别
      if(_config.stype == 'gunicorn'){
          param.data.loglevel = loglevel;
      }
      // 编辑项目
      that.modifyProject(param, function (res) {
          bt.msg({ status: res.status, msg: res.msg });
          that.simulatedClick(5);
      });
  })
};
/**
 * @description ip限制
 */
CreateWebsiteModel.prototype.set_ip_limit = function (web) {
  var isInit = true;
  $('#webedit-con').html('<div id="ip-mode-select"></div><div id="tabIpLimit" class="tab-nav"></div><div class="tab-con" style="padding:15px 0px;"></div>');

  var _tab = [
    {
      title: '白名单',
      on: true,
      callback: function (robj) {
        robj.html('<div id="proxy-ip-list"></div>');
        getProxyIpList(0);
      }
    },{
      title:'黑名单',
      callback:function(robj){
        robj.html('<div id="proxy-ip-list"></div>');
        getProxyIpList(1);
      }
    }]
  // 渲染反向代理ip黑白名单列表
  function renderProxyIpInfo(type,ipList){
    var activeOption = [
      {arr:'white_list',addApi:'add_white_ip_restrict',delApi:'remove_white_ip_restrict'},
      {arr:'black_list',addApi:'add_black_ip_restrict',delApi:'remove_black_ip_restrict'},
    ]
    bt_tools.table({
      el: '#proxy-ip-list',
      data: ipList[activeOption[type].arr],
      cancelRefresh:true,
      column: [
        { title: 'IP', type: 'text',template:function(row){
            return '<span title="'+row+'">'+row+'</span>'
          }},
        {
          title: '操作',
          width: 100,
          type: 'group',
          align: 'right',
          group: [
            {
              title: '删除',
              event: function (row, index, ev, key, that) {
                bt_tools.send({url:'/project/proxy/'+activeOption[type].delApi,data:{site_name:web.name,value:row}},function(res){
                  bt_tools.msg(res);
                  if(res.status) getProxyIpList(type);
                },'删除IP')
              },
            },
          ],
        },
      ],
      tootls: [
        { // 按钮组
          type: 'group',
          positon: ['left', 'top'],
          list: [{
            title: '添加',
            active: true,
            event: function (ev, that) {
              var _ip = $('input[name=ip_address]').val()
              if(_ip == '') return layer.msg('请输入ip', {icon:2})
              bt_tools.send({url:'/project/proxy/'+activeOption[type].addApi,data:{site_name:web.name,value:_ip}}, function (rdata) {
                bt_tools.msg(rdata);
                if (rdata.status) {
                  $('input[name=ip_address]').val('')
                  if(rdata.status) getProxyIpList(type);
                }
              },'添加IP')
            }
          }]
        }
      ],
      success: function () {
        if($('input[name=ip_address]').length == 0){
          $('#proxy-ip-list .tootls_top .pull-left .btn').before('<input type="text" name="ip_address" placeholder="支持IP和IP段【例：192.168.1.11/24】" class="bt-input-text mr10 " value="" style="width: 260px;">')
          $('#proxy-ip-list').append(bt.render_help(['非IP内容的填写可能会导致Nginx无法启动']));
        }
      }
    });
  }
  // 获取反向代理ip黑白名单列表
  function getProxyIpList(type){
    bt_tools.send({url:'/project/proxy/get_ip_restrict',data:{site_name:web.name}},function(res){
      if($.isEmptyObject(res)) res = {white_list:[],black_list:[]}
      if(!res.hasOwnProperty('white_list')) res.white_list = []
      if(!res.hasOwnProperty('black_list')) res.black_list = []
      renderProxyIpInfo(type,res)
      if(isInit){
        isInit = false;
        renderProxyMode(res.restrict_type)
      }
    })
  }
  bt.render_tab('tabIpLimit', _tab);
  $('#tabIpLimit span:eq(0)').click();

  function renderProxyMode(val){
    bt_tools.form({
      el: '#ip-mode-select',
      class:'mb15',
      form: [{
        label: '访问控制模式',
        group: {
          type: 'select',
          name: 'restrict_type',
          width: '110px',
          value: val,
          list: [
            { title: '白名单', value: 'white' },
            { title: '黑名单', value: 'black' },
            { title: '关闭', value: 'closed' },
          ],
          placeholder: '请选择限制类型',
          change: function (formData) {
            bt_tools.send({url:'/project/proxy/set_ip_restrict',data:{site_name:web.name,set_type:formData.restrict_type}},function(res){
              bt_tools.msg(res);
            })
          }
        }
      }
      ]
    })
  }
}
/**
 * @description 绑定请求
 */
CreateWebsiteModel.prototype.bindHttp = function () {
  var that = this;
  for (const item in this.methods) {
    if (Object.hasOwnProperty.call(this.methods, item)) {
      const element = that.methods[item];
      (function (element) {
        CreateWebsiteModel.prototype[item] = function (param, callback) {
          bt_tools.send(
            {
              url: '/project/' + that.type + '/' + element[0],
              data: { data: JSON.stringify(param) },
            },
            function (data) {
              if (callback) callback(data);
            },
            { load: element[1] }
          );
        };
      })(element);
    }
  }
};
CreateWebsiteModel.prototype.layerFrom = null;
/**
 * @description 项目配置
 * @param {object} row 项目信息
 */
CreateWebsiteModel.prototype.reanderProjectConfigView = function (el, row) {
  var that = this
    projectConfig = row.project_config,
    param = $.extend(projectConfig, { project_ps: row.ps, listen:row.listen });
  CreateWebsiteModel.prototype.layerFrom = bt_tools.form({
    el: '#webedit-con',
    data: param,
    class: 'ptb15',
    form: CreateWebsiteModel.prototype.getAddProjectConfig({ type: 'edit' }),
  });
  setTimeout(function () {
    $('[name="project_cmd"]').val(param.project_cmd);
  },50)
  if (row.listen.length && !(row.listen.indexOf(parseInt($('input[name=port]').val())) > -1)) {
    $('.error_port').remove()
    $('input[name=port]').next().after('<div class="error_port" style="margin-top: 10px;color: red;">项目端口可能有误，检测到当前项目监听了以下端口'+ row.listen +'</div>')
  }
};

/**
 * @description 域名管理
 * @param {object} row 项目信息 
 */
CreateWebsiteModel.prototype.reanderDomainManageView = function (el, row) {
  var that = this,
    list = [
      {
        class: 'mb0',
        items: [
          {
            name: 'modeldomain',
            width: '430px',
            type: 'textarea',
            placeholder:
              '如果需要绑定外网，请输入需要映射的域名<br>多个域名，请换行填写，每行一个域名，默认为80端口<br>泛解析添加方法：先添加一个域名 domain.com，后换行添加*.domain.com<br>如另加端口格式为 www.domain.com:88',
          },
          {
            name: 'btn_model_submit_domain',
            text: '添加',
            type: 'button',
            callback: function (sdata) {
              var arrs = sdata.modeldomain.split('\n');
              var domins = [];
              for (var i = 0; i < arrs.length; i++) domins.push(arrs[i]);
              if (domins[0] == '')
                return layer.msg('域名不能为空', { icon: 0 });
              that.addProjectDomain(
                { project_name: row.name, domains: domins },
                function (res) {
                  if (typeof res.status == 'undefined') {
                    $('[name=modeldomain]').val('');
                    $('.placeholder').css('display', 'block');
                    site.render_domain_result_table(res)
                    project_domian.$refresh_table_list(true);
                  }else{
                    bt.msg({
                      status: res.status,
                      msg: res.msg || res.error_msg,
                    });
                  }

                }
              );
            },
          },
        ],
      },
    ];
  var _form_data = bt.render_form_line(list[0]),
    loadT = null,
    placeholder = null;
  el.html(_form_data.html + '<div id="project_domian_list"></div>');
  bt.render_clicks(_form_data.clicks);
  // domain样式
  $('.btn_model_submit_domain')
    .addClass('pull-right')
    .css('margin', '30px 35px 0 0');
  $('textarea[name=modeldomain]').css('height', '120px');
  placeholder = $('.placeholder');
  placeholder
    .click(function () {
      $(this).hide();
      $('.modeldomain').focus();
    })
    .css({
      width: '430px',
      heigth: '120px',
      left: '0px',
      top: '0px',
      'padding-top': '10px',
      'padding-left': '15px',
    });
  $('.modeldomain')
    .focus(function () {
      placeholder.hide();
      loadT = layer.tips(placeholder.html(), $(this), {
        tips: [1, '#20a53a'],
        time: 0,
        area: $(this).width(),
      });
    })
    .blur(function () {
      if ($(this).val().length == 0) placeholder.show();
      layer.close(loadT);
    });
  var project_domian = bt_tools.table({
    el: '#project_domian_list',
    url: '/project/' + that.type + '/project_get_domain',
    default: '暂无域名列表',
    param: { project_name: row.name },
    height: 375,
    beforeRequest: function (params) {
      if (params.hasOwnProperty('data') && typeof params.data === 'string')
        return params;
      return { data: JSON.stringify(params) };
    },
    column: [
      { type: 'checkbox', class: '', width: 20 },
      {
        fid: 'name',
        title: '域名',
        type: 'text',
        template: function (row) {
          return (
            '<a href="http://' +
            row.name +
            ':' +
            row.port +
            '" target="_blank" class="btlink">' +
            row.name +
            '</a>'
          );
        },
      },
      {
        fid: 'port',
        title: '端口',
        type: 'text',
      },
      {
        title: '操作',
        type: 'group',
        width: '100px',
        align: 'right',
        group: [
          {
            title: '删除',
            template: function (row, that) {
              return that.data.length === 1 ? '<span>不可操作</span>' : '删除';
            },
            event: function (rowc, index, ev, key, rthat) {
              if (ev.target.tagName == 'SPAN') return;
              if (rthat.data.length === 1) {
                return bt.msg({ status: false, msg: '最后一个域名不能删除!' });
              }
              that.removeProjectDomain(
                { project_name: row.name, domain: rowc.name + ':' + rowc.port },
                function (res) {
                  bt.msg({
                    status: res.status,
                    msg: res.data || res.error_msg,
                  });
                  rthat.$refresh_table_list(true);
                }
              );
            },
          },
        ],
      },
    ],
    tootls: [
      {
        // 批量操作
        type: 'batch',
        positon: ['left', 'bottom'],
        placeholder: '请选择批量操作',
        buttonValue: '批量操作',
        disabledSelectValue: '请选择需要批量操作的站点!',
        selectList: [
          {
            title: '删除域名',
            load: true,
            url: '/project/' + that.type + '/project_remove_domain',
            param: function (crow) {
              return {
                data: JSON.stringify({
                  project_name: row.name,
                  domain: crow.name + ':' + crow.port,
                }),
              };
            },
            callback: function (that) {
              // 手动执行,data参数包含所有选中的站点
              bt.show_confirm(
                '批量删除域名',
                "<span style='color:red'>同时删除选中的域名，是否继续？</span>",
                function () {
                  var param = {};
                  that.start_batch(param, function (list) {
                    var html = '';
                    for (var i = 0; i < list.length; i++) {
                      var item = list[i];
                      html +=
                        '<tr><td>' +
                        item.name +
                        '</td><td><div style="float:right;"><span style="color:' +
                        (item.request.status ? '#20a53a' : 'red') +
                        '">' +
                        (item.request.status ? '成功' : '失败') +
                        '</span></div></td></tr>';
                    }
                    project_domian.$batch_success_table({
                      title: '批量删除',
                      th: '删除域名',
                      html: html,
                    });
                    project_domian.$refresh_table_list(true);
                  });
                }
              );
            },
          },
        ],
      },
    ],
  });
  setTimeout(function () {
    $(el).append(
      '<ul class="help-info-text c7">' +
      '<li>如果您的是HTTP项目，且需要映射到外网，请至少绑定一个域名</li>' +
      '<li>建议所有域名都使用默认的80端口</li>' +
      '</ul>'
    );
  }, 100);
};

/**
 * @description 渲染项目外网映射
 * @param el {object} 当前element节点
 * @param row {object} 当前项目数据
 */
CreateWebsiteModel.prototype.reanderProjectMapView = function (el, row) {
  var that = this;
  el.html(
    '<div class="pd15"><div class="ss-text mr50" style="display: block;height: 35px;">' +
    '   <em title="外网映射">外网映射</em>' +
    '       <div class="ssh-item">' +
    '           <input class="btswitch btswitch-ios" id="model_project_map" type="checkbox">' +
    '           <label class="btswitch-btn" for="model_project_map" name="model_project_map"></label>' +
    '       </div>' +
    '</div><ul class="help-info-text c7"><li>如果您的是HTTP项目，且需要外网通过80/443访问，请开启外网映射</li><li>开启外网映射前，请到【域名管理】中至少添加1个域名</li></ul></div>'
  );
  $('#model_project_map').attr(
    'checked',
    row['project_config']['bind_extranet'] ? true : false
  );
  $('[name=model_project_map]').click(function () {
    var _check = $('#model_project_map').prop('checked'),
      param = { project_name: row.name };
    if (!_check) param['domains'] = row['project_config']['domains'];
    layer.confirm(
      (!_check ? '开启外网映射后，可以通过绑定域名进行访问' : '关闭外网映射后，已绑定域名将取消关联访问') + '，是否继续操作？',
      {
        title: '外网映射',
        icon: 0,
        closeBtn: 2,
        cancel: function () {
          $('#model_project_map').prop('checked', _check);
        },
      },
      function () {
        that[_check ? 'unbindExtranet' : 'bindExtranet'](param, function (res) {
          if (!res.status) $('#model_project_map').prop('checked', _check);
          bt.msg({
            status: res.status,
            msg: typeof res.data != 'string' ? res.error_msg : res.data,
          });
          row['project_config']['bind_extranet'] = _check ? 0 : 1;
        });
      },
      function () {
        $('#model_project_map').prop('checked', _check);
      }
    );
  });
};

/**
 * @description 渲染项目伪静态视图
 * @param el {object} 当前element节点
 * @param row {object} 当前项目数据
 */
CreateWebsiteModel.prototype.reanderProjectRewriteView = function (el, row) {
  el.empty();
  if (row.project_config.bind_extranet === 0) {
    $('.mask_module')
      .removeClass('hide')
      .find('.node_mask_module_text:eq(1)')
      .hide()
      .prev()
      .show();
    return false;
  }
  site.edit.get_rewrite_list({ name: this.type + '_' + row.name }, function () {
    $('.webedit-box .line:first').remove();
    $('[name=btn_save_to]').remove();
    $('.webedit-box .help-info-text li:first').remove();
  });
};

/**
 * @description 渲染项目配置文件
 * @param el {object} 当前element节点
 * @param row {object} 当前项目数据
 */
CreateWebsiteModel.prototype.reanderFileConfigView = function (el, row) {
  el.empty();
  if (row.project_config.bind_extranet === 0) {
    $('.mask_module')
      .removeClass('hide')
      .find('.node_mask_module_text:eq(1)')
      .hide()
      .prev()
      .show();
    return false;
  }
  site.edit.set_config({ name: this.type + '_' + row.name });
};

/**
 * @description 渲染项目使用情况
 * @param el {object} 当前element节点
 * @param row {object} 当前项目数据
 */
CreateWebsiteModel.prototype.reanderServiceCondition = function (el, row) {
  if (!row.run) {
    el.html('').next().removeClass('hide');
    if (el.next().find('.node_mask_module_text').length === 1) {
      el.next()
        .find('.node_mask_module_text')
        .hide()
        .parent()
        .append(
          '<div class="node_mask_module_text">请先启动服务后重新尝试，<a href="javascript:;" class="btlink" onclick="site.node.simulated_click(7)">设置服务状态</a></div'
        );
    } else {
      el.next().find('.node_mask_module_text:eq(1)').show().prev().hide();
    }
    return false;
  }
  el.html(
    '<div class="line" style="padding-top: 0;"><span class="tname" style="width: 30px;text-align:left;padding-right: 5px;">PID</span><div class="info-r"><select class="bt-input-text mr5" name="node_project_pid"></select></div></div><div class="node_project_pid_datail"></div>'
  );
  var _option = '',
    tabelCon = '';
  for (var load in row.load_info) {
    if (row.load_info.hasOwnProperty(load)) {
      _option += '<option value="' + load + '">' + load + '</option>';
    }
  }
  var node_pid = $('[name=node_project_pid]');
  node_pid.html(_option);
  node_pid
    .change(function () {
      var _pid = $(this).val(),
        rdata = row['load_info'][_pid],
        fileBody = '',
        connectionsBody = '';
      for (var i = 0; i < rdata.open_files.length; i++) {
        var itemi = rdata.open_files[i];
        fileBody +=
          '<tr>' +
          '<td>' +
          itemi['path'] +
          '</td>' +
          '<td>' +
          itemi['mode'] +
          '</td>' +
          '<td>' +
          itemi['position'] +
          '</td>' +
          '<td>' +
          itemi['flags'] +
          '</td>' +
          '<td>' +
          itemi['fd'] +
          '</td>' +
          '</tr>';
      }
      for (var k = 0; k < rdata.connections.length; k++) {
        var itemk = rdata.connections[k];
        connectionsBody +=
          '<tr>' +
          '<td>' +
          itemk['client_addr'] +
          '</td>' +
          '<td>' +
          itemk['client_rport'] +
          '</td>' +
          '<td>' +
          itemk['family'] +
          '</td>' +
          '<td>' +
          itemk['fd'] +
          '</td>' +
          '<td>' +
          itemk['local_addr'] +
          '</td>' +
          '<td>' +
          itemk['local_port'] +
          '</td>' +
          '<td>' +
          itemk['status'] +
          '</td>' +
          '</tr>';
      }

      //     tabelCon = reand_table_config([
      //         [{"名称":rdata.name},{"PID":rdata.pid},{"状态":rdata.status},{"父进程":rdata.ppid}],
      //         [{"用户":rdata.user},{"Socket":rdata.connects},{"CPU":rdata.cpu_percent},{"线程":rdata.threads}],
      //         [{"内存":rdata.user},{"io读":rdata.connects},{"io写":rdata.cpu_percent},{"启动时间":rdata.threads}],
      //         [{"启动命令":rdata.user}],
      //     ])
      //
      // console.log(tabelCon)
      //
      //
      //     function reand_table_config(conifg){
      //         var html = '';
      //         for (var i = 0; i < conifg.length; i++) {
      //             var item = conifg[i];
      //             html += '<tr>';
      //             for (var j = 0; j < item; j++) {
      //                 var items = config[j],name = Object.keys(items)[0];
      //                 console.log(items,name)
      //                 html += '<td>'+  name +'</td><td>'+ items[name] +'</td>'
      //             }
      //             console.log(html)
      //             html += '</tr>'
      //         }
      //         return '<div class="divtable"><table class="table"><tbody>'+ html  +'</tbody></tbody></table></div>';
      //     }

      tabelCon =
        '<div class="divtable">' +
        '<table class="table">' +
        '<tbody>' +
        '<tr>' +
        '<th width="50">名称</th><td  width="100">' +
        rdata.name +
        '</td>' +
        '<th width="50">状态</th><td  width="90">' +
        rdata.status +
        '</td>' +
        '<th width="60">用户</th><td width="100">' +
        rdata.user +
        '</td>' +
        '<th width="80">启动时间</th><td width="150">' +
        getLocalTime(rdata.create_time) +
        '</td>' +
        '</tr>' +
        '<tr>' +
        '<th>PID</th><td  >' +
        rdata.pid +
        '</td>' +
        '<th>PPID</th><td >' +
        rdata.ppid +
        '</td>' +
        '<th>线程</th><td>' +
        rdata.threads +
        '</td>' +
        '<th>Socket</th><td>' +
        rdata.connects +
        '</td>' +
        '</tr>' +
        '<tr>' +
        '<th>CPU</th><td>' +
        rdata.cpu_percent +
        '%</td>' +
        '<th>内存</th><td>' +
        ToSize(rdata.memory_used) +
        '</td>' +
        '<th>io读</th><td>' +
        ToSize(rdata.io_read_bytes) +
        '</td>' +
        '<th>io写</th><td>' +
        ToSize(rdata.io_write_bytes) +
        '</td>' +
        '</tr>' +
        '<tr>' +
        '</tr>' +
        '<tr>' +
        '<th width="50">命令</th><td colspan="7" style="word-break: break-word;width: 570px">' +
        rdata.exe +
        '</td>' +
        '</tr>' +
        '</tbody>' +
        '</table>' +
        '</div>' +
        '<h3 class="tname">网络</h3>' +
        '<div class="divtable" >' +
        '<div style="height:160px;overflow:auto;border:#ddd 1px solid" id="nodeNetworkList">' +
        '<table class="table table-hover" style="border:none">' +
        '<thead>' +
        '<tr>' +
        '<th>客户端地址</th>' +
        '<th>客户端端口</th>' +
        '<th>协议</th>' +
        '<th>FD</th>' +
        '<th>本地地址</th>' +
        '<th>本地端口</th>' +
        '<th>状态</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        connectionsBody +
        '</tbody>' +
        '</table>' +
        '</div>' +
        '</div>' +
        '<h3 class="tname">打开的文件列表</h3>' +
        '<div class="divtable" >' +
        '<div style="height:160px;overflow:auto;border:#ddd 1px solid" id="nodeFileList">' +
        '<table class="table table-hover" style="border:none">' +
        '<thead>' +
        '<tr>' +
        '<th>文件</th>' +
        '<th>mode</th>' +
        '<th>position</th>' +
        '<th>flags</th>' +
        '<th>fd</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>' +
        fileBody +
        '</tbody>' +
        '</table>' +
        '</div>' +
        '</div>';
      $('.node_project_pid_datail').html(tabelCon);
      bt_tools.$fixed_table_thead('#nodeNetworkList');
      bt_tools.$fixed_table_thead('#nodeFileList');
    })
    .change()
    .html(_option);
};

/**
 * @description 项目SSL
 * @param el {object} 当前element节点
 * @param row {object} 当前项目数据
 */
CreateWebsiteModel.prototype.reanderProjectSslView = function (el, row) {
  el.empty();
  if (row.project_config.bind_extranet === 0) {
    $('.mask_module')
      .removeClass('hide')
      .find('.node_mask_module_text:eq(1)')
      .hide()
      .prev()
      .show();
    return false;
  }
  site.set_ssl({ name: row.name, ele: el, id: row.id });
  site.ssl.reload();
};

/**
 * 第一次开打go项目的SDK管理渲染模块
 * @param {Object} options 参数里面有sdk的类型，和是否重新刷新
 */
CreateWebsiteModel.prototype.firstRenderSDKTable  = function (options) {
  var _that = options._that;
  var type = options.type || 'all';
  var used = ''
  // 生成表格
  var versionTable = bt_tools.table({
    el: '#versionManagement',
    url: '/project/go/list_go_sdk',
    height: '500px',
    load: '正在获取版本信息...',
    dataFilter: function (res) {
      _that.goSDKVersionList = res.sdk;
      used = res.used // 获取正在使用的sdk版本
      res.sdk[type].sort((a,b)=> b.installed - a.installed)   // 排序，已安装的先显示
      return { data: res.sdk[type] };
    },
    column: [
      // { type: 'text', fid: 'version', title: 'GoSDK版本' },
      {
        type: 'text',
        title: 'SDK版本',
        template: function (row) {
          const version = row.version.slice(2);
          return '<span class="version">'+ version + (row.type === "stable" ? "(稳定版)" : "") +('go'+version === used?'<span style="color: #333;font-weight: bold;">【正在使用】</span>':'')+'</span>'
          // return row.type === 'stable' ? '<span class="stable">'+version+'(稳定版)</span>' : '<span>'+ version+'</span>';
        },
      },
      {
        type: 'text',
        title: '安装状态',
        template: function (row) {
          return row.installed ? '<span style="color:#20a53a;cursor:pointer;">已安装</span>' : '<span style="color:#d9534f;cursor:pointer;">未安装</span>';
        },
      },
      {
        type: 'text',
        align: 'right',
        title: '操作',
        template: function (row) {
          return row.installed ? '<a class="bterror">卸载</a>' : '<a class="btlink">安装</a>';
        },
        event: function (row) {
          if(this.classList.contains('version')) return;
          var is_installed = row.installed;
          bt.confirm(
            {
              title: (is_installed ? '卸载' : '安装') + 'SDK版本',
              msg: is_installed ? '卸载[' + row.version + ']版本后，相关项目将无法启动，是否继续？' : '是否安装[' + row.version + ']版本？',
            },
            function () {
              if(is_installed){
                //卸载
                bt_tools.send({url:'/project/go/uninstall_go_sdk',data:{version:row.version}},function (data){
                  // bt.msg({status:data.status,msg:data.msg})
                  // console.log(_that.clickUpdateHandle);
                  _that.clickUpdateHandle(_that)()

                },'正在卸载请稍候...')
              }else{
                //安装
                bt_tools.send({url:'/project/go/install_go_sdk',data:{version:row.version}},function (data){
                  // bt.msg({status:data.status,msg:data.msg})
                  _that.clickUpdateHandle(_that)()
                },'正在安装请稍候...')
              }
            }
          );
        },
      },
    ],
  });
}


//渲染表格的函数
CreateWebsiteModel.prototype.renderTable = function  (data)  {
  data.sort((a,b)=> b.installed - a.installed)   // 排序，已安装的先显示
  //根据数据渲染表格
  bt_tools.table({
    el: '#versionManagement',
    data:data,
    height: '500px',
    load: '正在获取版本信息...',
    column: [
      {
        type: 'text',
        title: 'SDK版本',
        template: function (row) {
          const version = row.version.slice(2);
          return '<span class="version">'+ version + (row.type === "stable" ? "(稳定版)" : "") +'</span>'
        },
      },
      {
        type: 'text',
        title: '安装状态',
        template: function (row) {
          return row.installed ? '<span style="color:#20a53a">已安装</span>' : '<span style="color:#d9534f">未安装</span>';
        },
      },
      {
        type: 'text',
        align: 'right',
        title: '操作',
        template: function (row) {
          return row.installed ? '<a class="bterror">卸载</a>' : '<a class="btlink">安装</a>';
        },
      }]
  })
}


//sdk版本管理里面的下拉框事件处理函数
CreateWebsiteModel.prototype.changeSelectHandle = function (that,index) {
  localStorage.setItem('currentSDKType', index);
  var type = index == 0 ? 'all' : 'streamline';
  var data = that.goSDKVersionList[type];
  //更新表格渲染。
  that.renderTable(data)
}


//sdk版本管理里面的更新列表点击处理函数
CreateWebsiteModel.prototype.clickUpdateHandle = function (that) {
  return function () {
    var type = localStorage.currentSDKType == 0 ? 'all' : 'streamline';
    var loadT = layer.msg('正在获取版本列表，请稍侯...', {
      icon: 16,
      time: 0,
      shade: 0.3,
    })
    bt_tools.send({url:'/project/go/list_go_sdk'},function (data) {
      that.goSDKVersionList = data.sdk;
      var data = that.goSDKVersionList[type];
      //更新表格渲染。
      // 加载中的loading效果
      // ??????
      that.renderTable(data)
      layer.close(loadT);
    })
  };
}
