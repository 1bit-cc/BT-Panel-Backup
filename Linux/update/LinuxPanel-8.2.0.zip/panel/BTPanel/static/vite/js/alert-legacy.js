System.register([],(function(e,t){"use strict";return{execute:function(){}}}));
